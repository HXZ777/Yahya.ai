package com.example

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertContentDescriptionEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.data.network.CompanionProtocol
import com.example.data.network.InboundFrame
import com.example.data.network.QrCodeUtils
import com.example.data.preferences.PairingPayloadCodec
import com.example.domain.model.MicStatus
import com.example.ui.components.FloatingMicControl
import com.example.ui.theme.YahyaCompanionTheme
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Yahya Assistant - Companion", appName)
    }

    @Test
    fun `companion protocol signs and verifies command frames`() {
        val secret = "super-secret-key-123"
        val payload = JSONObject().apply {
            put("commandId", "cmd-42")
            put("action", "open_url")
            put("url", "https://example.com")
        }
        val envelope = CompanionProtocol.buildSignedEnvelope(
            type = "command",
            deviceId = "rn11p-test",
            secret = secret,
            payload = payload,
        )

        val validFrame = CompanionProtocol.parseInboundFrame(envelope, secret)
        assertTrue(validFrame is InboundFrame.CommandFrame)

        val tamperedFrame = CompanionProtocol.parseInboundFrame(envelope, "wrong-secret")
        assertTrue(tamperedFrame is InboundFrame.AuthRejected)
    }

    @Test
    fun `pairing payload codec round-trips and generates qr bitmap`() {
        val rawUri = "yahya://pair?host=192.168.1.40&port=8765&code=482910&secret=abc123&name=BrainPhone"
        val parsed = PairingPayloadCodec.parseBrainPayload(rawUri)
        assertNotNull(parsed)
        assertEquals("192.168.1.40", parsed?.host)
        assertEquals(8765, parsed?.port)
        assertEquals("482910", parsed?.pairingCode)
        assertEquals("abc123", parsed?.secret)

        val qr = QrCodeUtils.generateQrBitmap(rawUri, 128)
        assertNotNull(qr)
        assertEquals(128, qr?.width)
    }

    @Test
    fun `floating mic control toggles between muted and listening states`() {
        var listeningState by mutableStateOf(false)
        var micStatusState by mutableStateOf(MicStatus.READY)

        composeRule.setContent {
            YahyaCompanionTheme {
                FloatingMicControl(
                    assistantName = "يحيى",
                    isListening = listeningState,
                    micStatus = micStatusState,
                    rmsLevel = 0.4f,
                    onToggleMute = {
                        listeningState = !listeningState
                        micStatusState = if (listeningState) MicStatus.LISTENING else MicStatus.READY
                    },
                )
            }
        }

        // Default state: muted
        composeRule.onNodeWithTag("floating_mic_button")
            .assertIsDisplayed()
            .assertContentDescriptionEquals("إلغاء كتم الميكروفون وبدء الاستماع")
        composeRule.onNodeWithTag("floating_listening_indicator").assertDoesNotExist()

        // First tap: unmute & start listening
        composeRule.onNodeWithTag("floating_mic_button").performClick()
        composeRule.onNodeWithTag("floating_mic_button")
            .assertContentDescriptionEquals("كتم الميكروفون وإيقاف الاستماع")
        composeRule.onNodeWithTag("floating_listening_indicator").assertIsDisplayed()
        composeRule.onNodeWithText("يحيى يستمع الآن").assertIsDisplayed()

        // Second tap: mute & stop listening
        composeRule.onNodeWithTag("floating_mic_button").performClick()
        composeRule.onNodeWithTag("floating_mic_button")
            .assertContentDescriptionEquals("إلغاء كتم الميكروفون وبدء الاستماع")
        composeRule.onNodeWithTag("floating_listening_indicator").assertDoesNotExist()
    }
}
