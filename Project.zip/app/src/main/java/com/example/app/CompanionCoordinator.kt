package com.example.app

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.example.accessibility.DeviceCommandExecutor
import com.example.accessibility.YahyaAccessibilityService
import com.example.data.network.CompanionWebSocketClient
import com.example.data.network.NsdBrainDiscovery
import com.example.data.network.TransportEvent
import com.example.data.preferences.PairingPayloadCodec
import com.example.data.preferences.SettingsRepository
import com.example.domain.model.AccessibilityHealth
import com.example.domain.model.AssistantSettings
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.CompanionCommand
import com.example.domain.model.ConnectionState
import com.example.domain.model.ConnectionStatus
import com.example.domain.model.DiscoveredBrainDevice
import com.example.domain.model.ListeningMode
import com.example.domain.model.LogDirection
import com.example.domain.model.LogStatus
import com.example.domain.model.MicStatus
import com.example.domain.model.PendingConfirmation
import com.example.domain.policy.CommandSafetyPolicy
import com.example.domain.voice.ArabicWakeMatcher
import com.example.voice.ArabicSpeechEngine
import com.example.voice.ArabicTtsEngine
import com.example.voice.FloatingMicOverlayService
import com.example.voice.VoiceListenerForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class CompanionCoordinator(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val settingsRepository = SettingsRepository(context)
    val webSocketClient = CompanionWebSocketClient()
    val nsdDiscovery = NsdBrainDiscovery(context)
    val ttsEngine = ArabicTtsEngine(context)
    private val commandExecutor = DeviceCommandExecutor(context, ttsEngine)

    private val _settings = MutableStateFlow(AssistantSettings())
    val settings: StateFlow<AssistantSettings> = _settings.asStateFlow()

    private val _logs = MutableStateFlow<List<CommandExecutionLog>>(emptyList())
    val logs: StateFlow<List<CommandExecutionLog>> = _logs.asStateFlow()

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation.asStateFlow()

    private val _accessibilityHealth = MutableStateFlow(YahyaAccessibilityService.currentHealth(context))
    val accessibilityHealth: StateFlow<AccessibilityHealth> = _accessibilityHealth.asStateFlow()

    private val _localIp = MutableStateFlow(PairingPayloadCodec.getLocalWifiIpAddress())
    val localIp: StateFlow<String?> = _localIp.asStateFlow()

    private val _canDrawOverlays = MutableStateFlow(Settings.canDrawOverlays(context))
    val canDrawOverlays: StateFlow<Boolean> = _canDrawOverlays.asStateFlow()

    private var awaitingCommandAfterWake: Boolean = false

    val speechEngine = ArabicSpeechEngine(
        context = context,
        onTranscriptReady = { transcript, mode ->
            handleRecognizedSpeech(transcript, mode)
        },
        onStatusLog = { title, detail, isError ->
            appendLog(
                direction = LogDirection.SYSTEM,
                title = title,
                detail = detail,
                status = if (isError) LogStatus.FAILED else LogStatus.INFO,
            )
        },
        onSessionEnded = {
            if (VoiceListenerForegroundService.isRunning.value) {
                VoiceListenerForegroundService.stop(context)
            }
        },
    )

    val connectionState: StateFlow<ConnectionState> = webSocketClient.connectionState
    val micStatus: StateFlow<MicStatus> = speechEngine.micStatus
    val isMicListening: StateFlow<Boolean> = speechEngine.isListeningActive
    val partialTranscript: StateFlow<String> = speechEngine.partialTranscript
    val rmsLevel: StateFlow<Float> = speechEngine.rmsLevel
    val isForegroundServiceRunning: StateFlow<Boolean> = VoiceListenerForegroundService.isRunning
    val isSystemOverlayRunning: StateFlow<Boolean> = FloatingMicOverlayService.isRunning
    val discoveredDevices: StateFlow<List<DiscoveredBrainDevice>> = nsdDiscovery.discoveredDevices
    val isNsdScanning: StateFlow<Boolean> = nsdDiscovery.isScanning

    init {
        VoiceListenerForegroundService.onStopRequestedCallback = {
            stopMicrophone()
        }

        scope.launch {
            val initialized = settingsRepository.ensureDeviceIdentity()
            _settings.value = initialized
            if (initialized.systemOverlayEnabled && Settings.canDrawOverlays(context)) {
                FloatingMicOverlayService.start(context)
            }
            if (initialized.isPaired) {
                webSocketClient.connect(
                    initialized,
                    YahyaAccessibilityService.currentHealth(context).isOperational,
                )
            }
            settingsRepository.settingsFlow.collect { updated ->
                _settings.value = updated
            }
        }

        scope.launch {
            webSocketClient.events.collect { event ->
                when (event) {
                    is TransportEvent.CommandReceived -> handleIncomingCommand(event.command)
                    is TransportEvent.SystemNotice -> appendLog(
                        direction = LogDirection.SYSTEM,
                        title = event.title,
                        detail = event.detail,
                        status = if (event.isError) LogStatus.FAILED else LogStatus.INFO,
                    )
                }
            }
        }

        scope.launch {
            YahyaAccessibilityService.isBound.collect {
                refreshDeviceHealth()
            }
        }
    }

    fun refreshDeviceHealth() {
        speechEngine.refreshAvailability()
        _accessibilityHealth.value = YahyaAccessibilityService.currentHealth(context)
        _localIp.value = PairingPayloadCodec.getLocalWifiIpAddress()
        val overlayAllowed = Settings.canDrawOverlays(context)
        _canDrawOverlays.value = overlayAllowed
        if (_settings.value.systemOverlayEnabled && overlayAllowed && !FloatingMicOverlayService.isRunning.value) {
            FloatingMicOverlayService.start(context)
        } else if (!overlayAllowed && FloatingMicOverlayService.isRunning.value) {
            FloatingMicOverlayService.stop(context)
        }
    }

    fun setSystemOverlayEnabled(enabled: Boolean) {
        scope.launch {
            settingsRepository.updateSystemOverlayEnabled(enabled)
            if (enabled && Settings.canDrawOverlays(context)) {
                FloatingMicOverlayService.start(context)
                appendLog(
                    direction = LogDirection.SYSTEM,
                    title = "تم تفعيل الزر العائم فوق التطبيقات",
                    detail = "يمكنك الآن تشغيل وكتم يحيى من فوق أي تطبيق على الهاتف.",
                    status = LogStatus.INFO,
                )
            } else {
                FloatingMicOverlayService.stop(context)
            }
        }
    }

    fun toggleMicrophone() {
        if (isCurrentlyListening()) {
            stopMicrophone()
        } else {
            startMicrophone()
        }
    }

    fun toggleDirectMicrophone() {
        if (isCurrentlyListening()) {
            stopMicrophone()
        } else {
            startDirectListening()
        }
    }

    private fun isCurrentlyListening(): Boolean {
        val current = speechEngine.micStatus.value
        return speechEngine.isListeningActive.value ||
            current == MicStatus.LISTENING ||
            current == MicStatus.WAKE_ARMED ||
            current == MicStatus.PROCESSING
    }

    fun startMicrophone() {
        val currentSettings = _settings.value
        val mode = if (currentSettings.continuousListening) {
            ListeningMode.CONTINUOUS_WAKE
        } else {
            ListeningMode.PUSH_TO_TALK
        }
        startListeningWithMode(mode)
    }

    fun startDirectListening() {
        startListeningWithMode(ListeningMode.DIRECT_CONTINUOUS)
    }

    private fun startListeningWithMode(mode: ListeningMode) {
        val currentSettings = _settings.value
        if (!speechEngine.hasRecordPermission()) {
            speechEngine.refreshAvailability()
            return
        }
        awaitingCommandAfterWake = false
        if (currentSettings.foregroundServiceEnabled) {
            val notifText = when (mode) {
                ListeningMode.CONTINUOUS_WAKE -> "في انتظار كلمة التنبيه: \"${currentSettings.wakePhrase}\""
                ListeningMode.DIRECT_CONTINUOUS -> "يحيى يستمع للأوامر الصوتية الآن..."
                ListeningMode.PUSH_TO_TALK -> "جاري الاستماع باللغة العربية..."
            }
            VoiceListenerForegroundService.startOrUpdate(context, notifText)
        }
        speechEngine.startListening(
            language = currentSettings.speechLanguage,
            mode = mode,
            awaitingFollowUpAfterWake = false,
        )
    }

    fun stopMicrophone() {
        awaitingCommandAfterWake = false
        speechEngine.stopListening()
        if (VoiceListenerForegroundService.isRunning.value) {
            VoiceListenerForegroundService.stop(context)
        }
    }

    fun logMicPermissionDenied() {
        speechEngine.refreshAvailability()
        appendLog(
            direction = LogDirection.SYSTEM,
            title = "تم رفض صلاحية الميكروفون",
            detail = "يتطلب الاستماع الصوتي السماح بالوصول إلى الميكروفون من إعدادات التطبيق.",
            status = LogStatus.FAILED,
        )
    }

    fun sendManualTextTranscript(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        dispatchTranscriptToBrain(clean, triggeredByWakePhrase = false)
    }

    private fun handleRecognizedSpeech(transcript: String, mode: ListeningMode) {
        val currentSettings = _settings.value
        if (mode == ListeningMode.PUSH_TO_TALK) {
            if (VoiceListenerForegroundService.isRunning.value) {
                VoiceListenerForegroundService.stop(context)
            }
            dispatchTranscriptToBrain(transcript, triggeredByWakePhrase = false)
            return
        }

        if (mode == ListeningMode.DIRECT_CONTINUOUS) {
            dispatchTranscriptToBrain(transcript, triggeredByWakePhrase = false)
            speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
            return
        }

        // Continuous Wake-Word Mode
        if (awaitingCommandAfterWake) {
            awaitingCommandAfterWake = false
            dispatchTranscriptToBrain(transcript, triggeredByWakePhrase = true)
            speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
            return
        }

        val wakeMatch = ArabicWakeMatcher.matchWakePhrase(transcript, currentSettings.wakePhrase)
        if (!wakeMatch.matched) {
            // Ignored ambient speech; resume wake listening
            speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
            return
        }

        if (wakeMatch.remainingCommand.isNotBlank()) {
            dispatchTranscriptToBrain(wakeMatch.remainingCommand, triggeredByWakePhrase = true)
            speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
        } else {
            awaitingCommandAfterWake = true
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم التقاط كلمة التنبيه",
                detail = "\"${currentSettings.wakePhrase}\" — في انتظار أمرك الصوتي...",
                status = LogStatus.INFO,
            )
            if (currentSettings.foregroundServiceEnabled) {
                VoiceListenerForegroundService.startOrUpdate(
                    context,
                    "تحدث الآن — في انتظار الأمر بعد \"${currentSettings.wakePhrase}\"",
                )
            }
            speechEngine.continueListeningCycle(awaitFollowUpCommand = true)
        }
    }

    private fun dispatchTranscriptToBrain(transcript: String, triggeredByWakePhrase: Boolean) {
        val currentSettings = _settings.value
        val sent = webSocketClient.sendSpeechTranscript(
            settings = currentSettings,
            transcript = transcript,
            triggeredByWakePhrase = triggeredByWakePhrase,
        )
        if (sent) {
            appendLog(
                direction = LogDirection.OUTBOUND_SPEECH,
                title = "أُرسل إلى الهاتف الرئيسي",
                detail = transcript,
                status = LogStatus.SENT,
            )
        } else {
            val reason = if (!currentSettings.isPaired) {
                "الهاتف غير مقترن بعد. انتقل إلى شاشة الإقران لربط الهاتف الرئيسي."
            } else {
                "الهاتف الرئيسي غير متصل حالياً (${connectionState.value.status.name})."
            }
            appendLog(
                direction = LogDirection.OUTBOUND_SPEECH,
                title = "تم التعرف على النص (غير مُرسل)",
                detail = "$transcript\n— $reason",
                status = LogStatus.QUEUED,
            )
        }
    }

    private fun handleIncomingCommand(command: CompanionCommand) {
        val currentSettings = _settings.value
        val safety = CommandSafetyPolicy.assess(command, currentSettings.confirmSensitiveActions)

        if (safety.requiresUserConfirmation) {
            _pendingConfirmation.value = PendingConfirmation(
                command = command,
                title = "تأكيد مطلوب قبل التنفيذ",
                explanation = "${command.rawDescription}\nالسبب: ${safety.reasonArabic}",
                riskLevel = safety.riskLevel,
            )
            appendLog(
                direction = LogDirection.INBOUND_COMMAND,
                title = "أمر بانتظار موافقتك",
                detail = "${command.rawDescription} — ${safety.reasonArabic}",
                status = LogStatus.AWAITING_CONFIRMATION,
                isSensitive = true,
            )
            webSocketClient.sendCommandResult(
                settings = currentSettings,
                commandId = command.commandId,
                status = "awaiting_confirmation",
                detail = safety.reasonArabic,
            )
            return
        }

        executeCommandAndReport(command, isSensitive = false)
    }

    fun approvePendingConfirmation() {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        executeCommandAndReport(pending.command, isSensitive = true)
    }

    fun rejectPendingConfirmation() {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        val currentSettings = _settings.value
        appendLog(
            direction = LogDirection.EXECUTION_RESULT,
            title = "تم رفض الأمر الحساس",
            detail = pending.command.rawDescription,
            status = LogStatus.REJECTED,
            isSensitive = true,
        )
        webSocketClient.sendCommandResult(
            settings = currentSettings,
            commandId = pending.command.commandId,
            status = "rejected_by_user",
            detail = "رفض المستخدم تنفيذ الإجراء الحساس.",
        )
    }

    private fun executeCommandAndReport(command: CompanionCommand, isSensitive: Boolean) {
        val currentSettings = _settings.value
        val outcome = commandExecutor.execute(command, currentSettings.autoSpeakReplies)
        appendLog(
            direction = LogDirection.EXECUTION_RESULT,
            title = if (outcome.success) "تم تنفيذ الأمر" else "تعذر تنفيذ الأمر",
            detail = "${command.rawDescription}: ${outcome.detail}",
            status = if (outcome.success) LogStatus.EXECUTED else LogStatus.FAILED,
            isSensitive = isSensitive,
        )
        webSocketClient.sendCommandResult(
            settings = currentSettings,
            commandId = command.commandId,
            status = if (outcome.success) "executed" else "failed",
            detail = outcome.detail,
        )
    }

    fun pairAndConnect(
        deviceName: String,
        host: String,
        port: Int,
        pairingCode: String,
        secret: String,
        useTls: Boolean,
    ) {
        scope.launch {
            settingsRepository.savePairingConfig(
                deviceName = deviceName,
                host = host,
                port = port,
                pairingCode = pairingCode,
                pairingSecret = secret,
                useTls = useTls,
            )
            val updated = settingsRepository.settingsFlow.first()
            _settings.value = updated
            webSocketClient.connect(updated, _accessibilityHealth.value.isOperational)
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "بدء الاتصال بالهاتف الرئيسي",
                detail = "${updated.pairedDeviceName} (${updated.pairedHost}:${updated.pairedPort})",
                status = LogStatus.INFO,
            )
        }
    }

    fun reconnectPairedDevice() {
        val current = _settings.value
        if (current.isPaired) {
            webSocketClient.connect(current, _accessibilityHealth.value.isOperational)
        }
    }

    fun disconnectAndUnpair() {
        scope.launch {
            webSocketClient.disconnect(clearError = true)
            settingsRepository.clearPairing()
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم إلغاء الإقران",
                detail = "تم مسح بيانات اتصال الهاتف الرئيسي.",
                status = LogStatus.INFO,
            )
        }
    }

    fun sendPingTest() {
        val ok = webSocketClient.sendPing(_settings.value)
        if (!ok) {
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "اختبار الاتصال",
                detail = "لا يوجد اتصال نشط بالهاتف الرئيسي حالياً.",
                status = LogStatus.FAILED,
            )
        }
    }

    fun rotateLocalPairingCredentials() {
        scope.launch {
            settingsRepository.rotateLocalPairingCredentials()
        }
    }

    fun updateAssistantIdentity(name: String, wakePhrase: String) {
        scope.launch {
            settingsRepository.updateAssistantIdentity(name, wakePhrase)
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم تحديث هوية المساعد",
                detail = "الاسم: $name | كلمة التنبيه: \"$wakePhrase\"",
                status = LogStatus.INFO,
            )
        }
    }

    fun updateSpeechSettings(
        language: String,
        continuousListening: Boolean,
        foregroundServiceEnabled: Boolean,
        autoSpeakReplies: Boolean,
    ) {
        scope.launch {
            settingsRepository.updateSpeechSettings(
                language = language,
                continuousListening = continuousListening,
                foregroundServiceEnabled = foregroundServiceEnabled,
                autoSpeakReplies = autoSpeakReplies,
            )
        }
    }

    fun updateSafetyAndUi(confirmSensitiveActions: Boolean, rtlEnabled: Boolean) {
        scope.launch {
            settingsRepository.updateSafetyAndUi(confirmSensitiveActions, rtlEnabled)
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun testSafeUrlPreview() {
        val cmd = CompanionCommand.OpenUrl(
            commandId = "local-safe-test",
            url = "https://www.wikipedia.org",
            rawDescription = "اختبار فتح رابط آمن",
        )
        executeCommandAndReport(cmd, isSensitive = false)
    }

    fun testSensitiveGuardrailPreview() {
        val cmd = CompanionCommand.Tap(
            commandId = "local-guardrail-test",
            targetText = "تأكيد الدفع وحذف الحساب",
            x = null,
            y = null,
        )
        handleIncomingCommand(cmd)
    }

    private fun appendLog(
        direction: LogDirection,
        title: String,
        detail: String,
        status: LogStatus,
        isSensitive: Boolean = false,
    ) {
        val entry = CommandExecutionLog(
            direction = direction,
            title = title,
            detail = detail,
            status = status,
            isSensitive = isSensitive,
        )
        _logs.value = (listOf(entry) + _logs.value).take(40)
    }

    fun shutdown() {
        nsdDiscovery.stopDiscovery()
        webSocketClient.disconnect()
        speechEngine.stopListening()
        ttsEngine.shutdown()
    }

    val isConnected: Boolean
        get() = connectionState.value.status == ConnectionStatus.CONNECTED

    val deviceModelLabel: String
        get() = "${Build.MANUFACTURER} ${Build.MODEL}"
}
