package com.example.domain.model

import java.util.UUID

enum class ConnectionStatus {
    DISCONNECTED,
    DISCOVERING,
    CONNECTING,
    CONNECTED,
    ERROR,
}

enum class MicStatus {
    PERMISSION_MISSING,
    READY,
    WAKE_ARMED,
    LISTENING,
    PROCESSING,
    UNAVAILABLE,
    ERROR,
}

enum class ListeningMode {
    PUSH_TO_TALK,
    DIRECT_CONTINUOUS,
    CONTINUOUS_WAKE,
}

enum class ScrollDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT,
}

enum class GlobalDeviceAction {
    BACK,
    HOME,
    RECENTS,
    NOTIFICATIONS,
}

enum class RiskLevel {
    SAFE,
    MODERATE,
    SENSITIVE,
}

enum class LogDirection {
    OUTBOUND_SPEECH,
    INBOUND_COMMAND,
    EXECUTION_RESULT,
    SYSTEM,
}

enum class LogStatus {
    SENT,
    QUEUED,
    AWAITING_CONFIRMATION,
    EXECUTED,
    REJECTED,
    FAILED,
    INFO,
}

data class AssistantSettings(
    val assistantName: String = "يحيى",
    val wakePhrase: String = "يا يحيى",
    val speechLanguage: String = "ar-SA",
    val continuousListening: Boolean = false,
    val foregroundServiceEnabled: Boolean = true,
    val autoSpeakReplies: Boolean = true,
    val confirmSensitiveActions: Boolean = true,
    val rtlEnabled: Boolean = true,
    val systemOverlayEnabled: Boolean = false,
    val pairedDeviceName: String = "",
    val pairedHost: String = "",
    val pairedPort: Int = 8765,
    val pairingCode: String = "",
    val pairingSecret: String = "",
    val useTls: Boolean = false,
    val deviceId: String = "",
) {
    val isPaired: Boolean
        get() = pairedHost.isNotBlank() && pairingSecret.isNotBlank()
}

data class ConnectionState(
    val status: ConnectionStatus = ConnectionStatus.DISCONNECTED,
    val pairedDeviceName: String = "",
    val endpointLabel: String = "",
    val latencyMs: Long? = null,
    val errorMessage: String? = null,
    val lastSyncTimestamp: Long? = null,
)

data class DiscoveredBrainDevice(
    val serviceName: String,
    val host: String,
    val port: Int,
)

sealed interface CompanionCommand {
    val commandId: String
    val rawDescription: String

    data class OpenApp(
        override val commandId: String,
        val packageName: String?,
        val appName: String?,
        override val rawDescription: String = "فتح تطبيق ${appName ?: packageName.orEmpty()}",
    ) : CompanionCommand

    data class OpenUrl(
        override val commandId: String,
        val url: String,
        override val rawDescription: String = "فتح رابط $url",
    ) : CompanionCommand

    data class Tap(
        override val commandId: String,
        val targetText: String?,
        val x: Float?,
        val y: Float?,
        override val rawDescription: String = when {
            !targetText.isNullOrBlank() -> "النقر على \"$targetText\""
            x != null && y != null -> "النقر عند (${x.toInt()}, ${y.toInt()})"
            else -> "نقر على الشاشة"
        },
    ) : CompanionCommand

    data class Scroll(
        override val commandId: String,
        val direction: ScrollDirection,
        override val rawDescription: String = "التمرير للاتجاه ${direction.name}",
    ) : CompanionCommand

    data class TypeText(
        override val commandId: String,
        val text: String,
        val targetHint: String?,
        override val rawDescription: String = "كتابة نص (${text.take(24)})",
    ) : CompanionCommand

    data class GlobalAction(
        override val commandId: String,
        val action: GlobalDeviceAction,
        override val rawDescription: String = "إجراء نظام: ${action.name}",
    ) : CompanionCommand

    data class Speak(
        override val commandId: String,
        val text: String,
        override val rawDescription: String = "نطق الرد الصوتي",
    ) : CompanionCommand
}

data class PendingConfirmation(
    val command: CompanionCommand,
    val title: String,
    val explanation: String,
    val riskLevel: RiskLevel,
    val createdAt: Long = System.currentTimeMillis(),
)

data class CommandExecutionLog(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val direction: LogDirection,
    val title: String,
    val detail: String,
    val status: LogStatus,
    val isSensitive: Boolean = false,
)

data class AccessibilityHealth(
    val isEnabledInSettings: Boolean = false,
    val isServiceBound: Boolean = false,
) {
    val isOperational: Boolean get() = isEnabledInSettings && isServiceBound
}
