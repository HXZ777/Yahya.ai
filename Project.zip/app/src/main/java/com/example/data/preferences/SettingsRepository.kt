package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.AssistantSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.SecureRandom
import java.util.UUID

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "yahya_companion_settings",
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
        val WAKE_PHRASE = stringPreferencesKey("wake_phrase")
        val SPEECH_LANGUAGE = stringPreferencesKey("speech_language")
        val CONTINUOUS_LISTENING = booleanPreferencesKey("continuous_listening")
        val FOREGROUND_SERVICE_ENABLED = booleanPreferencesKey("foreground_service_enabled")
        val AUTO_SPEAK_REPLIES = booleanPreferencesKey("auto_speak_replies")
        val CONFIRM_SENSITIVE_ACTIONS = booleanPreferencesKey("confirm_sensitive_actions")
        val RTL_ENABLED = booleanPreferencesKey("rtl_enabled")
        val SYSTEM_OVERLAY_ENABLED = booleanPreferencesKey("system_overlay_enabled")
        val PAIRED_DEVICE_NAME = stringPreferencesKey("paired_device_name")
        val PAIRED_HOST = stringPreferencesKey("paired_host")
        val PAIRED_PORT = intPreferencesKey("paired_port")
        val PAIRING_CODE = stringPreferencesKey("pairing_code")
        val PAIRING_SECRET = stringPreferencesKey("pairing_secret")
        val USE_TLS = booleanPreferencesKey("use_tls")
        val DEVICE_ID = stringPreferencesKey("device_id")
    }

    val settingsFlow: Flow<AssistantSettings> = context.settingsDataStore.data.map { prefs ->
        AssistantSettings(
            assistantName = prefs[Keys.ASSISTANT_NAME] ?: "يحيى",
            wakePhrase = prefs[Keys.WAKE_PHRASE] ?: "يا يحيى",
            speechLanguage = prefs[Keys.SPEECH_LANGUAGE] ?: "ar-SA",
            continuousListening = prefs[Keys.CONTINUOUS_LISTENING] ?: false,
            foregroundServiceEnabled = prefs[Keys.FOREGROUND_SERVICE_ENABLED] ?: true,
            autoSpeakReplies = prefs[Keys.AUTO_SPEAK_REPLIES] ?: true,
            confirmSensitiveActions = prefs[Keys.CONFIRM_SENSITIVE_ACTIONS] ?: true,
            rtlEnabled = prefs[Keys.RTL_ENABLED] ?: true,
            systemOverlayEnabled = prefs[Keys.SYSTEM_OVERLAY_ENABLED] ?: false,
            pairedDeviceName = prefs[Keys.PAIRED_DEVICE_NAME] ?: "",
            pairedHost = prefs[Keys.PAIRED_HOST] ?: "",
            pairedPort = prefs[Keys.PAIRED_PORT] ?: 8765,
            pairingCode = prefs[Keys.PAIRING_CODE] ?: "",
            pairingSecret = prefs[Keys.PAIRING_SECRET] ?: "",
            useTls = prefs[Keys.USE_TLS] ?: false,
            deviceId = prefs[Keys.DEVICE_ID] ?: "",
        )
    }

    suspend fun ensureDeviceIdentity(): AssistantSettings {
        val current = settingsFlow.first()
        if (current.deviceId.isNotBlank() && current.pairingCode.isNotBlank() && current.pairingSecret.isNotBlank()) {
            return current
        }
        val generatedId = current.deviceId.ifBlank {
            "rn11p-${UUID.randomUUID().toString().take(8)}"
        }
        val generatedCode = current.pairingCode.ifBlank { generateSixDigitCode() }
        val generatedSecret = current.pairingSecret.ifBlank { generateHexSecret() }
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.DEVICE_ID] = generatedId
            if (prefs[Keys.PAIRING_CODE].isNullOrBlank()) prefs[Keys.PAIRING_CODE] = generatedCode
            if (prefs[Keys.PAIRING_SECRET].isNullOrBlank()) prefs[Keys.PAIRING_SECRET] = generatedSecret
        }
        return settingsFlow.first()
    }

    suspend fun updateAssistantIdentity(assistantName: String, wakePhrase: String) {
        context.settingsDataStore.edit { prefs ->
            if (assistantName.isNotBlank()) prefs[Keys.ASSISTANT_NAME] = assistantName.trim()
            if (wakePhrase.isNotBlank()) prefs[Keys.WAKE_PHRASE] = wakePhrase.trim()
        }
    }

    suspend fun updateSpeechSettings(
        language: String,
        continuousListening: Boolean,
        foregroundServiceEnabled: Boolean,
        autoSpeakReplies: Boolean,
    ) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.SPEECH_LANGUAGE] = language
            prefs[Keys.CONTINUOUS_LISTENING] = continuousListening
            prefs[Keys.FOREGROUND_SERVICE_ENABLED] = foregroundServiceEnabled
            prefs[Keys.AUTO_SPEAK_REPLIES] = autoSpeakReplies
        }
    }

    suspend fun updateSafetyAndUi(
        confirmSensitiveActions: Boolean,
        rtlEnabled: Boolean,
    ) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.CONFIRM_SENSITIVE_ACTIONS] = confirmSensitiveActions
            prefs[Keys.RTL_ENABLED] = rtlEnabled
        }
    }

    suspend fun updateSystemOverlayEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.SYSTEM_OVERLAY_ENABLED] = enabled
        }
    }

    suspend fun savePairingConfig(
        deviceName: String,
        host: String,
        port: Int,
        pairingCode: String,
        pairingSecret: String,
        useTls: Boolean,
    ) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.PAIRED_DEVICE_NAME] = deviceName.trim().ifBlank { "AI Brain Phone" }
            prefs[Keys.PAIRED_HOST] = host.trim()
            prefs[Keys.PAIRED_PORT] = port
            if (pairingCode.isNotBlank()) prefs[Keys.PAIRING_CODE] = pairingCode.trim()
            if (pairingSecret.isNotBlank()) prefs[Keys.PAIRING_SECRET] = pairingSecret.trim()
            prefs[Keys.USE_TLS] = useTls
        }
    }

    suspend fun rotateLocalPairingCredentials(): Pair<String, String> {
        val code = generateSixDigitCode()
        val secret = generateHexSecret()
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.PAIRING_CODE] = code
            prefs[Keys.PAIRING_SECRET] = secret
        }
        return code to secret
    }

    suspend fun clearPairing() {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.PAIRED_DEVICE_NAME] = ""
            prefs[Keys.PAIRED_HOST] = ""
            prefs[Keys.PAIRED_PORT] = 8765
            prefs[Keys.USE_TLS] = false
        }
    }

    private fun generateSixDigitCode(): String {
        val random = SecureRandom()
        return (100000 + random.nextInt(900000)).toString()
    }

    private fun generateHexSecret(): String {
        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
