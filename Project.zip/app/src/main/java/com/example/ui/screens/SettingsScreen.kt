package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AssistantSettings
import com.example.domain.model.ConnectionState
import com.example.domain.model.ConnectionStatus
import com.example.ui.theme.LocalYahyaColors

private data class SpeechLocaleOption(
    val code: String,
    val label: String,
)

private val speechLocales = listOf(
    SpeechLocaleOption("ar-SA", "العربية (السعودية)"),
    SpeechLocaleOption("ar-EG", "العربية (مصر)"),
    SpeechLocaleOption("ar-AE", "العربية (الإمارات)"),
    SpeechLocaleOption("ar-JO", "العربية (الأردن)"),
    SpeechLocaleOption("en-US", "English (US)"),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AssistantSettings,
    connectionState: ConnectionState,
    onSaveIdentity: (assistantName: String, wakePhrase: String) -> Unit,
    onUpdateSpeechSettings: (
        language: String,
        continuousListening: Boolean,
        foregroundServiceEnabled: Boolean,
        autoSpeakReplies: Boolean,
    ) -> Unit,
    onUpdateSafetyAndUi: (confirmSensitiveActions: Boolean, rtlEnabled: Boolean) -> Unit,
    canDrawOverlays: Boolean,
    isSystemOverlayRunning: Boolean,
    onToggleSystemOverlay: (Boolean) -> Unit,
    onOpenPairing: () -> Unit,
    onUnpair: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    var assistantName by rememberSaveable(settings.assistantName) { mutableStateOf(settings.assistantName) }
    var wakePhrase by rememberSaveable(settings.wakePhrase) { mutableStateOf(settings.wakePhrase) }
    var savedBanner by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                text = "إعدادات المساعد",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "خصّص اسم المساعد، كلمة التنبيه الصوتية، إعدادات النطق العربي، والهاتف الرئيسي المقترن.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // Assistant Name & Wake Phrase
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Person, contentDescription = null, tint = yColors.accentTeal)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "هوية المساعد وكلمة التنبيه",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    OutlinedTextField(
                        value = assistantName,
                        onValueChange = {
                            assistantName = it
                            savedBanner = false
                        },
                        label = { Text("اسم المساعد") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_assistant_name_input"),
                    )

                    OutlinedTextField(
                        value = wakePhrase,
                        onValueChange = {
                            wakePhrase = it
                            savedBanner = false
                        },
                        label = { Text("كلمة التنبيه (الافتراضية: يا يحيى)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_wake_phrase_input"),
                    )

                    Button(
                        onClick = {
                            onSaveIdentity(assistantName, wakePhrase)
                            savedBanner = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = yColors.accentTeal,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_identity_button"),
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ الاسم وكلمة التنبيه", fontWeight = FontWeight.Bold)
                    }

                    if (savedBanner) {
                        Surface(
                            color = yColors.onlineContainer,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Rounded.Check, contentDescription = null, tint = yColors.online, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تم حفظ التغييرات بنجاح", style = MaterialTheme.typography.bodySmall, color = yColors.online)
                            }
                        }
                    }
                }
            }
        }

        // Speech & Voice Settings
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.RecordVoiceOver, contentDescription = null, tint = yColors.accentTeal)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إعدادات الصوت والتعرف على الكلام",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    Text(
                        text = "لهجة التعرف الصوتي",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        speechLocales.forEach { option ->
                            FilterChip(
                                selected = settings.speechLanguage == option.code,
                                onClick = {
                                    onUpdateSpeechSettings(
                                        option.code,
                                        settings.continuousListening,
                                        settings.foregroundServiceEnabled,
                                        settings.autoSpeakReplies,
                                    )
                                },
                                label = { Text(option.label) },
                            )
                        }
                    }

                    SettingToggleRow(
                        title = "الاستماع المستمر لكلمة التنبيه",
                        subtitle = "ينتظر سماع \"${settings.wakePhrase}\" قبل إرسال الأمر للهاتف الرئيسي.",
                        checked = settings.continuousListening,
                        onCheckedChange = {
                            onUpdateSpeechSettings(
                                settings.speechLanguage,
                                it,
                                settings.foregroundServiceEnabled,
                                settings.autoSpeakReplies,
                            )
                        },
                        testTag = "switch_continuous_wake",
                    )

                    SettingToggleRow(
                        title = "تشغيل خدمة الميكروفون الأمامية",
                        subtitle = "يبقي الميكروفون نشطاً مع إشعار ظاهر وفق سياسات أندرويد 13.",
                        checked = settings.foregroundServiceEnabled,
                        onCheckedChange = {
                            onUpdateSpeechSettings(
                                settings.speechLanguage,
                                settings.continuousListening,
                                it,
                                settings.autoSpeakReplies,
                            )
                        },
                        testTag = "switch_foreground_service",
                    )

                    SettingToggleRow(
                        title = "نطق الردود الواردة صوتياً (TTS)",
                        subtitle = "قراءة الردود المرسلة من الهاتف الرئيسي باللغة العربية.",
                        checked = settings.autoSpeakReplies,
                        onCheckedChange = {
                            onUpdateSpeechSettings(
                                settings.speechLanguage,
                                settings.continuousListening,
                                settings.foregroundServiceEnabled,
                                it,
                            )
                        },
                        testTag = "switch_auto_tts",
                    )
                }
            }
        }

        // Paired Phone Configuration Summary
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Link, contentDescription = null, tint = yColors.accentTeal)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الهاتف الرئيسي المقترن",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    if (settings.isPaired) {
                        Text(
                            text = "${settings.pairedDeviceName} (${settings.pairedHost}:${settings.pairedPort})",
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Text(
                            text = "الحالة الحالية: ${
                                if (connectionState.status == ConnectionStatus.CONNECTED) "متصل" else "غير متصل"
                            }",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (connectionState.status == ConnectionStatus.CONNECTED) yColors.online else yColors.warning,
                        )
                    } else {
                        Text(
                            text = "لا يوجد هاتف رئيسي مقترن حالياً.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onOpenPairing,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                        ) {
                            Text(if (settings.isPaired) "تعديل الإقران" else "إقران هاتف جديد")
                        }
                        if (settings.isPaired) {
                            OutlinedButton(
                                onClick = onUnpair,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                            ) {
                                Text("إلغاء الإقران", color = yColors.danger)
                            }
                        }
                    }
                }
            }
        }

        // Safety & RTL Layout
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Security, contentDescription = null, tint = yColors.warning)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الأمان والواجهة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    SettingToggleRow(
                        title = "تأكيد الإجراءات الحساسة قبل التنفيذ",
                        subtitle = "منع تنفيذ أوامر الدفع، الحذف، الكتابة أو النقر الحساس دون موافقة.",
                        checked = settings.confirmSensitiveActions,
                        onCheckedChange = { onUpdateSafetyAndUi(it, settings.rtlEnabled) },
                        testTag = "switch_settings_confirm",
                    )

                    SettingToggleRow(
                        title = "فرض الاتجاه العربي (RTL)",
                        subtitle = "عرض الواجهة من اليمين لليسار بغض النظر عن لغة النظام.",
                        checked = settings.rtlEnabled,
                        onCheckedChange = { onUpdateSafetyAndUi(settings.confirmSensitiveActions, it) },
                        testTag = "switch_rtl_mode",
                    )

                    SettingToggleRow(
                        title = "الزر العائم فوق جميع التطبيقات",
                        subtitle = "إظهار زر الميكروفون العائم فوق أي تطبيق في النظام.",
                        checked = settings.systemOverlayEnabled && canDrawOverlays && isSystemOverlayRunning,
                        onCheckedChange = onToggleSystemOverlay,
                        testTag = "switch_settings_system_overlay",
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
        )
    }
}
