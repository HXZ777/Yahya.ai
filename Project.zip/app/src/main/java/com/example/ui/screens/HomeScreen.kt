package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AssistantSettings
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.ConnectionState
import com.example.domain.model.MicStatus
import com.example.domain.model.PendingConfirmation
import com.example.ui.components.ActivityLogItemCard
import com.example.ui.components.PendingConfirmationCard
import com.example.ui.components.StatusSummaryGrid
import com.example.ui.components.VoiceOrbButton
import com.example.ui.theme.LocalYahyaColors

@Composable
fun HomeScreen(
    settings: AssistantSettings,
    connectionState: ConnectionState,
    micStatus: MicStatus,
    partialTranscript: String,
    rmsLevel: Float,
    isForegroundServiceRunning: Boolean,
    pendingConfirmation: PendingConfirmation?,
    logs: List<CommandExecutionLog>,
    onMicClick: () -> Unit,
    onSendManualText: (String) -> Unit,
    onApproveConfirmation: () -> Unit,
    onRejectConfirmation: () -> Unit,
    onNavigateToPairing: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    var manualInput by rememberSaveable { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Header Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "مساعد ${settings.assistantName}",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = yColors.accentTealSoft,
                            shape = MaterialTheme.shapes.small,
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Hearing,
                                    contentDescription = "كلمة التنبيه",
                                    tint = yColors.accentTeal,
                                    modifier = Modifier.size(14.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "كلمة التنبيه: \"${settings.wakePhrase}\"",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = yColors.accentTeal,
                                )
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onNavigateToPairing,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("home_pairing_shortcut"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.QrCode2,
                            contentDescription = "إقران الهاتف الرئيسي",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("home_settings_shortcut"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "الإعدادات",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // Connection & Microphone Status Cards
        item {
            StatusSummaryGrid(
                connectionState = connectionState,
                micStatus = micStatus,
                isForegroundServiceRunning = isForegroundServiceRunning,
                onOpenPairing = onNavigateToPairing,
            )
        }

        // Sensitive Action Safety Confirmation Banner
        item {
            AnimatedVisibility(visible = pendingConfirmation != null) {
                pendingConfirmation?.let { pending ->
                    PendingConfirmationCard(
                        pending = pending,
                        onApprove = onApproveConfirmation,
                        onReject = onRejectConfirmation,
                    )
                }
            }
        }

        // Large Centerpiece Microphone Button
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 20.dp, horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    VoiceOrbButton(
                        micStatus = micStatus,
                        rmsLevel = rmsLevel,
                        wakePhrase = settings.wakePhrase,
                        continuousWakeMode = settings.continuousListening,
                        onClick = onMicClick,
                    )

                    AnimatedVisibility(visible = partialTranscript.isNotBlank()) {
                        Surface(
                            color = yColors.surfaceElevated,
                            shape = MaterialTheme.shapes.medium,
                            border = BorderStroke(1.dp, yColors.accentTeal.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp, start = 6.dp, end = 6.dp),
                        ) {
                            Text(
                                text = partialTranscript,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(14.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Direct text command input (sends same structured speech_transcript packet)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedTextField(
                            value = manualInput,
                            onValueChange = { manualInput = it },
                            placeholder = { Text("أو اكتب أمراً لإرساله للهاتف الرئيسي...") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = yColors.accentTeal,
                                unfocusedBorderColor = yColors.borderSubtle,
                                focusedContainerColor = yColors.surfaceDeep,
                                unfocusedContainerColor = yColors.surfaceDeep,
                            ),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("manual_command_input"),
                        )
                        Surface(
                            onClick = {
                                if (manualInput.isNotBlank()) {
                                    onSendManualText(manualInput)
                                    manualInput = ""
                                }
                            },
                            color = if (manualInput.isNotBlank()) yColors.accentTeal else yColors.surfaceElevated,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .size(52.dp)
                                .testTag("send_manual_command_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = "إرسال الأمر",
                                tint = if (manualInput.isNotBlank()) {
                                    MaterialTheme.colorScheme.onPrimary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.padding(14.dp),
                            )
                        }
                    }
                }
            }
        }

        // Activity & Command Log Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "سجل الأوامر والنشاط",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                if (logs.isNotEmpty()) {
                    TextButton(
                        onClick = onClearLogs,
                        modifier = Modifier.testTag("clear_logs_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteSweep,
                            contentDescription = "مسح السجل",
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مسح")
                    }
                }
            }
        }

        if (logs.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                    border = BorderStroke(1.dp, yColors.borderSubtle),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = yColors.accentTeal.copy(alpha = 0.7f),
                            modifier = Modifier.size(32.dp),
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "لا توجد أوامر مسجلة بعد",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اقرن الهاتف الرئيسي ثم اضغط زر الميكروفون أو قل \"${settings.wakePhrase}\" لبدء التفاعل.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        } else {
            items(logs, key = { it.id }) { entry ->
                ActivityLogItemCard(item = entry)
            }
        }
    }
}
