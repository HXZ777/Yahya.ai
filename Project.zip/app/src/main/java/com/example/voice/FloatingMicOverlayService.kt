package com.example.voice

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.example.MainActivity
import com.example.R
import com.example.YahyaCompanionApp
import com.example.domain.model.MicStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingMicOverlayService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var windowManager: WindowManager? = null
    private var rootContainer: LinearLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var pulseRingView: View? = null
    private var orbButtonView: FrameLayout? = null
    private var micIconView: ImageView? = null
    private var statusPillView: LinearLayout? = null
    private var statusDotView: View? = null
    private var statusTextView: TextView? = null

    private var pulseAnimator: AnimatorSet? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlayViews()
        observeVoiceState()
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        _isRunning.value = false
        pulseAnimator?.cancel()
        pulseAnimator = null
        scope.cancel()
        rootContainer?.let { view ->
            runCatching { windowManager?.removeView(view) }
        }
        rootContainer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        resources.displayMetrics,
    ).toInt()

    private fun createOverlayViews() {
        val density = resources.displayMetrics.density
        val cairoFont = runCatching { ResourcesCompat.getFont(this, R.font.cairo) }.getOrNull()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // Listening indicator pill (hidden when muted)
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f
                setColor(Color.parseColor("#F00F1623"))
                setStroke((1.2f * density).toInt(), Color.parseColor("#2EE6D6"))
            }
            elevation = 8f * density
        }

        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2EE6D6"))
            }
        }
        pill.addView(dot, LinearLayout.LayoutParams(dp(9), dp(9)).apply {
            marginEnd = dp(8)
        })

        val label = TextView(this).apply {
            text = "يحيى يستمع الآن"
            setTextColor(Color.parseColor("#F2F6FC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = cairoFont
        }
        pill.addView(label)

        // Orb stack (outer pulse ring + 58dp circular mic button)
        val orbContainer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }

        val ring = View(this).apply {
            visibility = View.INVISIBLE
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke((2.5f * density).toInt(), Color.parseColor("#2EE6D6"))
            }
        }
        orbContainer.addView(ring, FrameLayout.LayoutParams(dp(68), dp(68), Gravity.CENTER))

        val orb = FrameLayout(this).apply {
            elevation = 10f * density
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#162032"))
                setStroke((1.8f * density).toInt(), Color.parseColor("#FF5C6C"))
            }
            contentDescription = "إلغاء كتم الميكروفون وبدء الاستماع"
        }

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_overlay_mic_off)
            setColorFilter(Color.parseColor("#FF5C6C"))
        }
        orb.addView(icon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        orbContainer.addView(orb, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER))

        container.addView(pill, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply {
            marginEnd = dp(8)
        })
        container.addView(orbContainer, FrameLayout.LayoutParams(dp(72), dp(72)))

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(84)
            y = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        }

        attachDragAndTapListener(orb, params)

        windowManager?.addView(container, params)
        rootContainer = container
        layoutParams = params
        pulseRingView = ring
        orbButtonView = orb
        micIconView = icon
        statusPillView = pill
        statusDotView = dot
        statusTextView = label
    }

    private fun attachDragAndTapListener(targetView: View, params: WindowManager.LayoutParams) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        targetView.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        moved = true
                    }
                    if (moved) {
                        val maxX = (resources.displayMetrics.widthPixels - (rootContainer?.width ?: dp(72))).coerceAtLeast(0)
                        val maxY = (resources.displayMetrics.heightPixels - dp(96)).coerceAtLeast(0)
                        params.x = (initialX + dx).coerceIn(0, maxX)
                        params.y = (initialY + dy).coerceIn(dp(24), maxY)
                        rootContainer?.let { runCatching { windowManager?.updateViewLayout(it, params) } }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        handleOverlayTap()
                    } else {
                        snapToNearestHorizontalEdge(params)
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun snapToNearestHorizontalEdge(params: WindowManager.LayoutParams) {
        val viewWidth = rootContainer?.width ?: dp(72)
        val screenWidth = resources.displayMetrics.widthPixels
        val centerX = params.x + viewWidth / 2
        val targetX = if (centerX < screenWidth / 2) {
            dp(8)
        } else {
            (screenWidth - viewWidth - dp(8)).coerceAtLeast(0)
        }
        ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 200L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                rootContainer?.let { runCatching { windowManager?.updateViewLayout(it, params) } }
            }
            start()
        }
    }

    private fun handleOverlayTap() {
        val hasMic = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMic) {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_REQUEST_MIC_PERMISSION, true)
            }
            startActivity(intent)
            return
        }

        val app = application as? YahyaCompanionApp ?: return
        app.coordinator.toggleDirectMicrophone()
    }

    private fun observeVoiceState() {
        val app = application as? YahyaCompanionApp ?: return
        val coordinator = app.coordinator
        scope.launch {
            combine(
                coordinator.isMicListening,
                coordinator.micStatus,
                coordinator.settings,
            ) { isListening, micStatus, settings ->
                Triple(isListening, micStatus, settings.assistantName)
            }.collect { (isListening, micStatus, assistantName) ->
                updateVisualState(isListening, micStatus, assistantName)
            }
        }
    }

    private fun updateVisualState(
        isListening: Boolean,
        micStatus: MicStatus,
        assistantName: String,
    ) {
        val isActive = isListening ||
            micStatus == MicStatus.LISTENING ||
            micStatus == MicStatus.WAKE_ARMED ||
            micStatus == MicStatus.PROCESSING

        val accentColor = when {
            micStatus == MicStatus.WAKE_ARMED -> Color.parseColor("#FFB547")
            isActive -> Color.parseColor("#2EE6D6")
            else -> Color.parseColor("#FF5C6C")
        }

        val density = resources.displayMetrics.density

        orbButtonView?.apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (isActive) accentColor else Color.parseColor("#162032"))
                setStroke((2f * density).toInt(), accentColor)
            }
            contentDescription = if (isActive) {
                "كتم الميكروفون وإيقاف الاستماع"
            } else {
                "إلغاء كتم الميكروفون وبدء الاستماع"
            }
        }

        micIconView?.apply {
            setImageResource(if (isActive) R.drawable.ic_overlay_mic_on else R.drawable.ic_overlay_mic_off)
            setColorFilter(if (isActive) Color.parseColor("#070B12") else accentColor)
        }

        statusPillView?.apply {
            visibility = if (isActive) View.VISIBLE else View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 999f
                setColor(Color.parseColor("#F00F1623"))
                setStroke((1.2f * density).toInt(), accentColor)
            }
        }

        statusDotView?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(accentColor)
        }

        statusTextView?.text = when {
            micStatus == MicStatus.WAKE_ARMED -> "$assistantName بانتظار التنبيه..."
            micStatus == MicStatus.PROCESSING -> "جاري معالجة الصوت..."
            else -> "$assistantName يستمع الآن"
        }

        pulseRingView?.apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke((2.5f * density).toInt(), accentColor)
            }
            if (isActive) {
                visibility = View.VISIBLE
                startPulseAnimation(this)
            } else {
                stopPulseAnimation()
                visibility = View.INVISIBLE
            }
        }
    }

    private fun startPulseAnimation(view: View) {
        if (pulseAnimator?.isRunning == true) return
        val scaleX = ObjectAnimator.ofFloat(view, View.SCALE_X, 0.92f, 1.24f).apply {
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
        }
        val scaleY = ObjectAnimator.ofFloat(view, View.SCALE_Y, 0.92f, 1.24f).apply {
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
        }
        val alpha = ObjectAnimator.ofFloat(view, View.ALPHA, 0.85f, 0f).apply {
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
        }
        pulseAnimator = AnimatorSet().apply {
            playTogether(scaleX, scaleY, alpha)
            duration = 1350L
            start()
        }
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        pulseRingView?.apply {
            scaleX = 1f
            scaleY = 1f
            alpha = 1f
        }
    }

    companion object {
        const val ACTION_START = "com.example.voice.OVERLAY_START"
        const val ACTION_STOP = "com.example.voice.OVERLAY_STOP"
        const val EXTRA_REQUEST_MIC_PERMISSION = "extra_request_mic_permission"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, FloatingMicOverlayService::class.java).apply {
                action = ACTION_START
            }
            runCatching { context.startService(intent) }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingMicOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.startService(intent) }
        }
    }
}
