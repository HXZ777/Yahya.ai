package com.example.vr.world

import com.example.vr.model.AlphaMode
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.WorldSubMeshData
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Inflater
import kotlin.math.sqrt

object FbxAndObjParser {

    fun parseObjFile(
        objFile: File,
        baseSearchDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int,
        maxVertices: Int
    ): ImportedMeshData? {
        val verts = ArrayList<Float>(4096)
        val uvs = ArrayList<Float>(4096)
        val norms = ArrayList<Float>(4096)

        val mtlMaterials = LinkedHashMap<String, PbrMaterialSpec>()
        val missingMtlFiles = mutableListOf<String>()

        data class SubMeshBucket(
            val name: String,
            val matName: String,
            val data: ArrayList<Float> = ArrayList(2048),
            var hasUvs: Boolean = false
        )

        val buckets = LinkedHashMap<String, SubMeshBucket>()
        var currentObjName = objFile.nameWithoutExtension
        var currentMatName = "default_material"
        var totalVertsCount = 0

        fun getBucket(): SubMeshBucket {
            val key = "$currentObjName|$currentMatName"
            return buckets.getOrPut(key) { SubMeshBucket(currentObjName, currentMatName) }
        }

        BufferedReader(InputStreamReader(FileInputStream(objFile)), 64 * 1024).use { reader ->
            while (true) {
                val rawLine = reader.readLine() ?: break
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue

                when {
                    line.startsWith("mtllib ") -> {
                        val mtlRef = line.removePrefix("mtllib ").trim()
                        val resolvedMtl = findRelativeFile(mtlRef, objFile.parentFile, baseSearchDir)
                        if (resolvedMtl != null) {
                            parseMtlFile(resolvedMtl, objFile.parentFile, baseSearchDir, texturesOutDir, maxTexDimPx, mtlMaterials)
                        } else {
                            missingMtlFiles.add(mtlRef)
                        }
                    }
                    line.startsWith("o ") || line.startsWith("g ") -> {
                        val nextName = line.substring(2).trim()
                        if (nextName.isNotEmpty()) currentObjName = nextName
                    }
                    line.startsWith("usemtl ") -> {
                        currentMatName = line.removePrefix("usemtl ").trim().ifEmpty { "default_material" }
                    }
                    line.startsWith("v ") -> {
                        val p = line.split(Regex("\\s+"))
                        if (p.size >= 4) {
                            verts.add(p[1].toFloatOrNull() ?: 0f)
                            verts.add(p[2].toFloatOrNull() ?: 0f)
                            verts.add(p[3].toFloatOrNull() ?: 0f)
                        }
                    }
                    line.startsWith("vt ") -> {
                        val p = line.split(Regex("\\s+"))
                        if (p.size >= 3) {
                            uvs.add(p[1].toFloatOrNull() ?: 0f)
                            uvs.add(1f - (p[2].toFloatOrNull() ?: 0f)) // OpenGL flip V
                        }
                    }
                    line.startsWith("vn ") -> {
                        val p = line.split(Regex("\\s+"))
                        if (p.size >= 4) {
                            norms.add(p[1].toFloatOrNull() ?: 0f)
                            norms.add(p[2].toFloatOrNull() ?: 1f)
                            norms.add(p[3].toFloatOrNull() ?: 0f)
                        }
                    }
                    line.startsWith("f ") && totalVertsCount < maxVertices -> {
                        val tokens = line.split(Regex("\\s+")).drop(1)
                        if (tokens.size >= 3) {
                            val totalV = verts.size / 3
                            val totalVt = uvs.size / 2
                            val totalVn = norms.size / 3
                            val parsed = tokens.mapNotNull { tok ->
                                val slash = tok.split('/')
                                val vRaw = slash.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
                                val vIdx = if (vRaw < 0) totalV + vRaw else vRaw - 1
                                if (vIdx !in 0 until totalV) return@mapNotNull null
                                val vtRaw = slash.getOrNull(1)?.toIntOrNull()
                                val vtIdx = if (vtRaw != null) (if (vtRaw < 0) totalVt + vtRaw else vtRaw - 1) else -1
                                val vnRaw = slash.getOrNull(2)?.toIntOrNull()
                                val vnIdx = if (vnRaw != null) (if (vnRaw < 0) totalVn + vnRaw else vnRaw - 1) else -1
                                Triple(vIdx, if (vtIdx in 0 until totalVt) vtIdx else -1, if (vnIdx in 0 until totalVn) vnIdx else -1)
                            }
                            val bucket = getBucket()
                            for (k in 1 until parsed.size - 1) {
                                if (totalVertsCount >= maxVertices) break
                                val tri = arrayOf(parsed[0], parsed[k], parsed[k + 1])
                                val a = tri[0].first * 3; val b = tri[1].first * 3; val c = tri[2].first * 3
                                val ax = verts[a]; val ay = verts[a + 1]; val az = verts[a + 2]
                                val bx = verts[b]; val by = verts[b + 1]; val bz = verts[b + 2]
                                val cx = verts[c]; val cy = verts[c + 1]; val cz = verts[c + 2]
                                val ux = bx - ax; val uy = by - ay; val uz = bz - az
                                val vx = cx - ax; val vy = cy - ay; val vz = cz - az
                                var fnx = uy * vz - uz * vy
                                var fny = uz * vx - ux * vz
                                var fnz = ux * vy - uy * vx
                                val fLen = sqrt(fnx * fnx + fny * fny + fnz * fnz).coerceAtLeast(1e-5f)
                                fnx /= fLen; fny /= fLen; fnz /= fLen

                                for (pt in tri) {
                                    val pi = pt.first * 3
                                    bucket.data.add(verts[pi]); bucket.data.add(verts[pi + 1]); bucket.data.add(verts[pi + 2])
                                    if (pt.third >= 0) {
                                        val ni = pt.third * 3
                                        bucket.data.add(norms[ni]); bucket.data.add(norms[ni + 1]); bucket.data.add(norms[ni + 2])
                                    } else {
                                        bucket.data.add(fnx); bucket.data.add(fny); bucket.data.add(fnz)
                                    }
                                    if (pt.second >= 0) {
                                        val ti = pt.second * 2
                                        bucket.data.add(uvs[ti]); bucket.data.add(uvs[ti + 1])
                                        bucket.hasUvs = true
                                    } else {
                                        bucket.data.add(0f); bucket.data.add(0f)
                                    }
                                    bucket.data.add(1f); bucket.data.add(1f); bucket.data.add(1f); bucket.data.add(1f)
                                    totalVertsCount++
                                }
                            }
                        }
                    }
                }
            }
        }

        if (buckets.isEmpty()) return null

        val matList = mutableListOf<PbrMaterialSpec>()
        val matIndexByName = mutableMapOf<String, Int>()
        val subMeshes = mutableListOf<WorldSubMeshData>()

        for ((_, bucket) in buckets) {
            if (bucket.data.isEmpty()) continue
            val mIdx = matIndexByName.getOrPut(bucket.matName) {
                val resolved = mtlMaterials[bucket.matName] ?: PbrMaterialSpec(
                    id = "mat_${matList.size}_${bucket.matName}",
                    name = bucket.matName,
                    baseColorArgb = 0xFFCBD5E1,
                    missingTextureName = if (missingMtlFiles.isNotEmpty()) "${bucket.matName} (MTL missing)" else null,
                    isOriginalIntact = false
                )
                matList.add(resolved)
                matList.lastIndex
            }
            val arr = bucket.data.toFloatArray()
            subMeshes.add(
                WorldSubMeshData(
                    name = bucket.name,
                    nodeName = bucket.name,
                    materialIndex = mIdx,
                    interleavedVertices = arr,
                    vertexCount = arr.size / 12,
                    boundsMin = floatArrayOf(0f, 0f, 0f),
                    boundsMax = floatArrayOf(0f, 0f, 0f),
                    categoryHint = MeshDiagnosticsHelper.classifyCategory(bucket.name),
                    hasValidUvs = bucket.hasUvs
                )
            )
        }

        return MeshDiagnosticsHelper.auditAndNormalize(
            worldName = objFile.name,
            rawSubMeshes = subMeshes,
            materials = matList,
            missingMtlFiles = missingMtlFiles
        )
    }

    private fun parseMtlFile(
        mtlFile: File,
        objParent: File?,
        baseSearchDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int,
        outMap: MutableMap<String, PbrMaterialSpec>
    ) {
        var curName = ""
        var kdColor = 0xFFFFFFFF
        var metallic = 0.08f
        var roughness = 0.68f
        var alpha = 1.0f
        var emissive = 0.0f
        var texPath: String? = null
        var normalPath: String? = null
        var missingTex: String? = null
        var hasTextureOrColor = false

        fun flush() {
            if (curName.isNotEmpty()) {
                val isLeafTex = texPath != null && (
                    curName.lowercase().contains("leaf") ||
                        curName.lowercase().contains("foliage") ||
                        curName.lowercase().contains("tree") ||
                        alpha < 0.99f
                    )
                outMap[curName] = PbrMaterialSpec(
                    id = "mtl_${outMap.size}_$curName",
                    name = curName,
                    baseColorArgb = kdColor,
                    metallic = metallic,
                    roughness = roughness,
                    alpha = alpha,
                    alphaMode = if (alpha < 0.98f) AlphaMode.BLEND else if (isLeafTex) AlphaMode.MASK else AlphaMode.OPAQUE,
                    alphaCutoff = 0.45f,
                    emissiveStrength = emissive,
                    texturePath = texPath,
                    normalTexturePath = normalPath,
                    missingTextureName = missingTex,
                    isOriginalIntact = missingTex == null && hasTextureOrColor
                )
            }
        }

        BufferedReader(InputStreamReader(FileInputStream(mtlFile)), 32 * 1024).use { reader ->
            while (true) {
                val line = reader.readLine()?.trim() ?: break
                if (line.isEmpty() || line.startsWith("#")) continue
                val parts = line.split(Regex("\\s+"))
                when (parts[0].lowercase()) {
                    "newmtl" -> {
                        flush()
                        curName = line.substringAfter(' ').trim()
                        kdColor = 0xFFFFFFFF
                        metallic = 0.08f
                        roughness = 0.68f
                        alpha = 1.0f
                        emissive = 0.0f
                        texPath = null
                        normalPath = null
                        missingTex = null
                        hasTextureOrColor = false
                    }
                    "kd" -> if (parts.size >= 4) {
                        val r = ((parts[1].toFloatOrNull() ?: 1f).coerceIn(0f, 1f) * 255f).toInt()
                        val g = ((parts[2].toFloatOrNull() ?: 1f).coerceIn(0f, 1f) * 255f).toInt()
                        val b = ((parts[3].toFloatOrNull() ?: 1f).coerceIn(0f, 1f) * 255f).toInt()
                        kdColor = ((255 shl 24) or (r shl 16) or (g shl 8) or b).toLong() and 0xFFFFFFFFL
                        hasTextureOrColor = true
                    }
                    "ks" -> if (parts.size >= 4) {
                        val s = ((parts[1].toFloatOrNull() ?: 0f) + (parts[2].toFloatOrNull() ?: 0f) + (parts[3].toFloatOrNull() ?: 0f)) / 3f
                        metallic = s.coerceIn(0f, 1f)
                    }
                    "ns" -> if (parts.size >= 2) {
                        val ns = (parts[1].toFloatOrNull() ?: 32f).coerceIn(1f, 512f)
                        roughness = (1f - (ns / 512f)).coerceIn(0.12f, 0.96f)
                    }
                    "d" -> if (parts.size >= 2) {
                        alpha = (parts[1].toFloatOrNull() ?: 1f).coerceIn(0.05f, 1f)
                    }
                    "tr" -> if (parts.size >= 2) {
                        alpha = (1f - (parts[1].toFloatOrNull() ?: 0f)).coerceIn(0.05f, 1f)
                    }
                    "ke" -> if (parts.size >= 4) {
                        val e = ((parts[1].toFloatOrNull() ?: 0f) + (parts[2].toFloatOrNull() ?: 0f) + (parts[3].toFloatOrNull() ?: 0f)) / 3f
                        emissive = e.coerceIn(0f, 2f)
                    }
                    "map_kd", "map_ka" -> {
                        val texRef = parts.lastOrNull() ?: ""
                        if (texRef.isNotEmpty() && texPath == null) {
                            val resolved = findRelativeFile(texRef, mtlFile.parentFile, baseSearchDir, objParent)
                            if (resolved != null && texturesOutDir != null) {
                                val outPng = File(texturesOutDir, "obj_${resolved.nameWithoutExtension}_${texRef.hashCode()}.png")
                                val saved = WorldProjectRepository.saveDownsampledTextureBytes(resolved.readBytes(), outPng, maxTexDimPx)
                                if (saved != null) {
                                    texPath = saved
                                    hasTextureOrColor = true
                                } else {
                                    missingTex = texRef
                                }
                            } else {
                                missingTex = texRef
                            }
                        }
                    }
                    "map_bump", "bump" -> {
                        val texRef = parts.lastOrNull() ?: ""
                        if (texRef.isNotEmpty() && texturesOutDir != null) {
                            val resolved = findRelativeFile(texRef, mtlFile.parentFile, baseSearchDir, objParent)
                            if (resolved != null) {
                                val outPng = File(texturesOutDir, "obj_norm_${resolved.nameWithoutExtension}.png")
                                normalPath = WorldProjectRepository.saveDownsampledTextureBytes(resolved.readBytes(), outPng, maxTexDimPx)
                            }
                        }
                    }
                }
            }
            flush()
        }
    }

    /**
     * Parses both ASCII FBX and Binary FBX (Kaydara FBX Binary) with zlib compressed arrays,
     * UV coordinates, Normals, Material colors, and embedded Video/Texture images.
     */
    fun parseFbxFile(
        fbxFile: File,
        baseSearchDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int,
        maxVertices: Int
    ): ImportedMeshData? {
        if (!fbxFile.exists() || fbxFile.length() < 32L) return null
        val header = ByteArray(21)
        FileInputStream(fbxFile).use { it.read(header) }
        val isBinary = String(header, 0, minOf(header.size, 18)) == "Kaydara FBX Binary"
        return if (isBinary) {
            parseBinaryFbx(fbxFile, baseSearchDir, texturesOutDir, maxTexDimPx, maxVertices)
        } else {
            parseAsciiFbx(fbxFile, baseSearchDir, texturesOutDir, maxTexDimPx, maxVertices)
        }
    }

    private fun parseAsciiFbx(
        fbxFile: File,
        baseSearchDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int,
        maxVertices: Int
    ): ImportedMeshData? {
        val text = runCatching { fbxFile.readText() }.getOrNull() ?: return null
        val geoBlocks = Regex("""Geometry:\s*\d+,\s*"Geometry::([^"]*)"[^\{]*\{([\s\S]*?)^\s*\}""", RegexOption.MULTILINE)
            .findAll(text).toList()

        val matSpecs = mutableListOf<PbrMaterialSpec>()
        val matMatches = Regex("""Material:\s*\d+,\s*"Material::([^"]*)"[^\{]*\{([\s\S]*?)^\s*\}""", RegexOption.MULTILINE)
            .findAll(text)
        for (m in matMatches) {
            val matName = m.groupValues[1].ifBlank { "FBX_Mat_${matSpecs.size}" }
            val body = m.groupValues[2]
            val diffMatch = Regex("""DiffuseColor"[^,]*,[^,]*,[^,]*,\s*([0-9.\-]+),\s*([0-9.\-]+),\s*([0-9.\-]+)""").find(body)
            val colorArgb = if (diffMatch != null) {
                val r = ((diffMatch.groupValues[1].toFloatOrNull() ?: 0.8f).coerceIn(0f, 1f) * 255f).toInt()
                val g = ((diffMatch.groupValues[2].toFloatOrNull() ?: 0.8f).coerceIn(0f, 1f) * 255f).toInt()
                val b = ((diffMatch.groupValues[3].toFloatOrNull() ?: 0.8f).coerceIn(0f, 1f) * 255f).toInt()
                ((255 shl 24) or (r shl 16) or (g shl 8) or b).toLong() and 0xFFFFFFFFL
            } else 0xFFE2E8F0
            matSpecs.add(PbrMaterialSpec(id = "fbx_mat_${matSpecs.size}", name = matName, baseColorArgb = colorArgb))
        }

        // Link ASCII Texture filenames if present
        val texMatches = Regex("""RelativeFilename:\s*"([^"]+)"""").findAll(text).map { it.groupValues[1] }.toList()
        if (texMatches.isNotEmpty() && texturesOutDir != null) {
            texMatches.forEachIndexed { i, ref ->
                val resolved = findRelativeFile(ref, fbxFile.parentFile, baseSearchDir)
                val targetIdx = minOf(i, matSpecs.lastIndex.coerceAtLeast(0))
                if (resolved != null && matSpecs.isNotEmpty()) {
                    val outPng = File(texturesOutDir, "fbx_tex_${i}_${resolved.nameWithoutExtension}.png")
                    val saved = WorldProjectRepository.saveDownsampledTextureBytes(resolved.readBytes(), outPng, maxTexDimPx)
                    matSpecs[targetIdx] = matSpecs[targetIdx].copy(texturePath = saved, missingTextureName = if (saved == null) ref else null)
                } else if (matSpecs.isNotEmpty()) {
                    matSpecs[targetIdx] = matSpecs[targetIdx].copy(missingTextureName = ref, isOriginalIntact = false)
                }
            }
        }
        if (matSpecs.isEmpty()) {
            matSpecs.add(PbrMaterialSpec(id = "fbx_default", name = "FBX_Default", baseColorArgb = 0xFFD9E2EC, isOriginalIntact = false))
        }

        val subMeshes = mutableListOf<WorldSubMeshData>()
        var totalVerts = 0
        for ((gIdx, geo) in geoBlocks.withIndex()) {
            if (totalVerts >= maxVertices) break
            val geoName = geo.groupValues[1].ifBlank { "FBX_Mesh_$gIdx" }
            val body = geo.groupValues[2]
            val verts = extractAsciiFbxDoubleArray(body, "Vertices:")
            val polyIdx = extractAsciiFbxIntArray(body, "PolygonVertexIndex:")
            val uvCoords = extractAsciiFbxDoubleArray(body, "UV:")
            val uvIdx = extractAsciiFbxIntArray(body, "UVIndex:")
            if (verts.size < 9 || polyIdx.isEmpty()) continue

            val sm = triangulateFbxGeometry(
                name = geoName,
                matIdx = gIdx.coerceAtMost(matSpecs.lastIndex),
                verts = verts,
                polyIndices = polyIdx,
                uvCoords = uvCoords,
                uvIndices = uvIdx,
                normals = DoubleArray(0),
                maxRemainVerts = maxVertices - totalVerts
            )
            if (sm != null) {
                subMeshes.add(sm)
                totalVerts += sm.vertexCount
            }
        }
        if (subMeshes.isEmpty()) return null
        return MeshDiagnosticsHelper.auditAndNormalize(fbxFile.name, subMeshes, matSpecs)
    }

    private fun parseBinaryFbx(
        fbxFile: File,
        baseSearchDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int,
        maxVertices: Int
    ): ImportedMeshData? {
        val bytes = runCatching { fbxFile.readBytes() }.getOrNull() ?: return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        if (bytes.size < 27) return null
        bb.position(23)
        val version = bb.int
        val is64Bit = version >= 7500

        data class FbxNode(
            val name: String,
            val props: List<Any?>,
            val children: List<FbxNode>
        )

        fun readProperty(): Any? {
            if (bb.remaining() < 1) return null
            val type = bb.get().toInt().toChar()
            return when (type) {
                'Y' -> bb.short.toInt()
                'C' -> (bb.get().toInt() != 0)
                'I' -> bb.int
                'F' -> bb.float.toDouble()
                'D' -> bb.double
                'L' -> bb.long
                'S', 'R' -> {
                    val len = bb.int.coerceIn(0, bb.remaining())
                    val arr = ByteArray(len)
                    bb.get(arr)
                    if (type == 'S') String(arr) else arr
                }
                'f', 'd', 'i', 'l' -> {
                    val arrLen = bb.int
                    val encoding = bb.int
                    val compLen = bb.int.coerceIn(0, bb.remaining())
                    val raw = ByteArray(compLen)
                    bb.get(raw)
                    val elemSize = when (type) { 'f', 'i' -> 4; else -> 8 }
                    val dataBytes = if (encoding == 1) {
                        val expected = (arrLen.toLong() * elemSize).coerceIn(0L, 48L * 1024L * 1024L).toInt()
                        val out = ByteArray(expected)
                        runCatching {
                            val inf = Inflater()
                            inf.setInput(raw)
                            inf.inflate(out)
                            inf.end()
                        }
                        out
                    } else raw
                    val dbb = ByteBuffer.wrap(dataBytes).order(ByteOrder.LITTLE_ENDIAN)
                    when (type) {
                        'd' -> DoubleArray(minOf(arrLen, dataBytes.size / 8)) { dbb.double }
                        'f' -> DoubleArray(minOf(arrLen, dataBytes.size / 4)) { dbb.float.toDouble() }
                        'i' -> IntArray(minOf(arrLen, dataBytes.size / 4)) { dbb.int }
                        'l' -> IntArray(minOf(arrLen, dataBytes.size / 8)) { dbb.long.toInt() }
                        else -> null
                    }
                }
                else -> null
            }
        }

        fun readNode(limit: Long): FbxNode? {
            val headerSize = if (is64Bit) 25 else 13
            if (bb.position() + headerSize > limit) return null
            val endOffset = if (is64Bit) bb.long else (bb.int.toLong() and 0xFFFFFFFFL)
            val numProps = (if (is64Bit) bb.long else (bb.int.toLong() and 0xFFFFFFFFL)).toInt()
            val propListLen = if (is64Bit) bb.long else (bb.int.toLong() and 0xFFFFFFFFL)
            val nameLen = bb.get().toInt() and 0xFF
            if (endOffset == 0L) return null // NULL sentinel record

            val nameBytes = ByteArray(minOf(nameLen, bb.remaining()))
            bb.get(nameBytes)
            val nodeName = String(nameBytes)
            val propsEnd = minOf(bb.position() + propListLen, limit)
            val props = ArrayList<Any?>(minOf(numProps, 16))
            for (i in 0 until numProps) {
                if (bb.position() >= propsEnd) break
                props.add(readProperty())
            }
            bb.position(propsEnd.toInt())

            val children = mutableListOf<FbxNode>()
            val safeEnd = minOf(endOffset, limit).toInt()
            while (bb.position() + headerSize <= safeEnd) {
                val child = readNode(safeEnd.toLong()) ?: break
                children.add(child)
            }
            bb.position(safeEnd)
            return FbxNode(nodeName, props, children)
        }

        val rootNodes = mutableListOf<FbxNode>()
        while (bb.position() + (if (is64Bit) 25 else 13) <= bytes.size) {
            val n = readNode(bytes.size.toLong()) ?: break
            rootNodes.add(n)
        }

        val objectsNode = rootNodes.firstOrNull { it.name == "Objects" } ?: return null
        val matSpecs = mutableListOf<PbrMaterialSpec>()
        val extractedTexturePaths = mutableListOf<String>()

        // Extract embedded Video image blobs & Texture references
        for (child in objectsNode.children) {
            if (child.name == "Video" && texturesOutDir != null) {
                val content = child.children.firstOrNull { it.name == "Content" }?.props?.firstOrNull() as? ByteArray
                if (content != null && content.size > 64) {
                    val outPng = File(texturesOutDir, "fbx_vid_${extractedTexturePaths.size}.png")
                    WorldProjectRepository.saveDownsampledTextureBytes(content, outPng, maxTexDimPx)?.let {
                        extractedTexturePaths.add(it)
                    }
                }
            } else if (child.name == "Texture" && texturesOutDir != null) {
                val rel = child.children.firstOrNull { it.name == "RelativeFilename" }?.props?.firstOrNull() as? String
                    ?: child.children.firstOrNull { it.name == "FileName" }?.props?.firstOrNull() as? String
                if (!rel.isNullOrBlank()) {
                    findRelativeFile(rel, fbxFile.parentFile, baseSearchDir)?.let { resolved ->
                        val outPng = File(texturesOutDir, "fbx_tex_${extractedTexturePaths.size}_${resolved.nameWithoutExtension}.png")
                        WorldProjectRepository.saveDownsampledTextureBytes(resolved.readBytes(), outPng, maxTexDimPx)?.let {
                            extractedTexturePaths.add(it)
                        }
                    }
                }
            }
        }

        for (child in objectsNode.children) {
            if (child.name == "Material") {
                val rawName = (child.props.getOrNull(1) as? String)?.substringAfter("Material::")?.substringBefore('\u0000')
                    ?: "FBX_Material_${matSpecs.size}"
                val props70 = child.children.firstOrNull { it.name == "Properties70" }
                var col = 0xFFE2E8F0L
                props70?.children?.forEach { p ->
                    if (p.props.firstOrNull() == "DiffuseColor" && p.props.size >= 7) {
                        val r = (((p.props[4] as? Double)?.toFloat() ?: 0.8f).coerceIn(0f, 1f) * 255f).toInt()
                        val g = (((p.props[5] as? Double)?.toFloat() ?: 0.8f).coerceIn(0f, 1f) * 255f).toInt()
                        val b = (((p.props[6] as? Double)?.toFloat() ?: 0.8f).coerceIn(0f, 1f) * 255f).toInt()
                        col = ((0xFFL shl 24) or ((r.toLong() and 0xFFL) shl 16) or ((g.toLong() and 0xFFL) shl 8) or (b.toLong() and 0xFFL))
                    }
                }
                val tex = extractedTexturePaths.getOrNull(matSpecs.size) ?: extractedTexturePaths.firstOrNull()
                matSpecs.add(
                    PbrMaterialSpec(
                        id = "fbx_mat_${matSpecs.size}",
                        name = rawName,
                        baseColorArgb = col,
                        texturePath = tex
                    )
                )
            }
        }
        if (matSpecs.isEmpty()) {
            matSpecs.add(
                PbrMaterialSpec(
                    id = "fbx_default",
                    name = "FBX_Default",
                    baseColorArgb = 0xFFD9E2EC,
                    texturePath = extractedTexturePaths.firstOrNull()
                )
            )
        }

        val subMeshes = mutableListOf<WorldSubMeshData>()
        var totalVerts = 0
        var geoCounter = 0
        for (child in objectsNode.children) {
            if (child.name != "Geometry" || totalVerts >= maxVertices) continue
            val geoName = (child.props.getOrNull(1) as? String)?.substringAfter("Geometry::")?.substringBefore('\u0000')
                ?.ifBlank { "FBX_Mesh_$geoCounter" } ?: "FBX_Mesh_$geoCounter"
            val verts = child.children.firstOrNull { it.name == "Vertices" }?.props?.firstOrNull() as? DoubleArray ?: continue
            val polyIdx = child.children.firstOrNull { it.name == "PolygonVertexIndex" }?.props?.firstOrNull() as? IntArray ?: continue
            val uvLayer = child.children.firstOrNull { it.name == "LayerElementUV" }
            val uvCoords = uvLayer?.children?.firstOrNull { it.name == "UV" }?.props?.firstOrNull() as? DoubleArray ?: DoubleArray(0)
            val uvIdx = uvLayer?.children?.firstOrNull { it.name == "UVIndex" }?.props?.firstOrNull() as? IntArray ?: IntArray(0)
            val normLayer = child.children.firstOrNull { it.name == "LayerElementNormal" }
            val norms = normLayer?.children?.firstOrNull { it.name == "Normals" }?.props?.firstOrNull() as? DoubleArray ?: DoubleArray(0)

            val sm = triangulateFbxGeometry(
                name = geoName,
                matIdx = geoCounter.coerceAtMost(matSpecs.lastIndex),
                verts = verts,
                polyIndices = polyIdx,
                uvCoords = uvCoords,
                uvIndices = uvIdx,
                normals = norms,
                maxRemainVerts = maxVertices - totalVerts
            )
            if (sm != null) {
                subMeshes.add(sm)
                totalVerts += sm.vertexCount
            }
            geoCounter++
        }

        if (subMeshes.isEmpty()) return null
        return MeshDiagnosticsHelper.auditAndNormalize(fbxFile.name, subMeshes, matSpecs)
    }

    private fun triangulateFbxGeometry(
        name: String,
        matIdx: Int,
        verts: DoubleArray,
        polyIndices: IntArray,
        uvCoords: DoubleArray,
        uvIndices: IntArray,
        normals: DoubleArray,
        maxRemainVerts: Int
    ): WorldSubMeshData? {
        val out = ArrayList<Float>(4096)
        val polygon = ArrayList<Pair<Int, Int>>(6)
        var polyVertCursor = 0
        var hasUvs = false

        fun emitTri(v0: Pair<Int, Int>, v1: Pair<Int, Int>, v2: Pair<Int, Int>) {
            val a = v0.first * 3; val b = v1.first * 3; val c = v2.first * 3
            if (a + 2 >= verts.size || b + 2 >= verts.size || c + 2 >= verts.size) return
            val ax = verts[a].toFloat(); val ay = verts[a + 1].toFloat(); val az = verts[a + 2].toFloat()
            val bx = verts[b].toFloat(); val by = verts[b + 1].toFloat(); val bz = verts[b + 2].toFloat()
            val cx = verts[c].toFloat(); val cy = verts[c + 1].toFloat(); val cz = verts[c + 2].toFloat()
            val ux = bx - ax; val uy = by - ay; val uz = bz - az
            val vx = cx - ax; val vy = cy - ay; val vz = cz - az
            var nx = uy * vz - uz * vy
            var ny = uz * vx - ux * vz
            var nz = ux * vy - uy * vx
            val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-5f)
            nx /= len; ny /= len; nz /= len

            for (pt in arrayOf(v0, v1, v2)) {
                val p = pt.first * 3
                out.add(verts[p].toFloat()); out.add(verts[p + 1].toFloat()); out.add(verts[p + 2].toFloat())
                val nPos = pt.second * 3
                if (nPos + 2 < normals.size) {
                    out.add(normals[nPos].toFloat()); out.add(normals[nPos + 1].toFloat()); out.add(normals[nPos + 2].toFloat())
                } else {
                    out.add(nx); out.add(ny); out.add(nz)
                }
                val uvIdxResolved = if (pt.second < uvIndices.size) uvIndices[pt.second] else pt.second
                val uPos = uvIdxResolved * 2
                if (uPos >= 0 && uPos + 1 < uvCoords.size) {
                    out.add(uvCoords[uPos].toFloat())
                    out.add(1f - uvCoords[uPos + 1].toFloat())
                    hasUvs = true
                } else {
                    out.add(0f); out.add(0f)
                }
                out.add(1f); out.add(1f); out.add(1f); out.add(1f)
            }
        }

        for (rawIdx in polyIndices) {
            if ((out.size / 12) >= maxRemainVerts) break
            val isEnd = rawIdx < 0
            val idx = if (isEnd) -rawIdx - 1 else rawIdx
            polygon.add(idx to polyVertCursor)
            polyVertCursor++
            if (isEnd) {
                if (polygon.size >= 3) {
                    for (k in 1 until polygon.size - 1) {
                        emitTri(polygon[0], polygon[k], polygon[k + 1])
                    }
                }
                polygon.clear()
            }
        }
        if (out.isEmpty()) return null
        return WorldSubMeshData(
            name = name,
            nodeName = name,
            materialIndex = matIdx,
            interleavedVertices = out.toFloatArray(),
            vertexCount = out.size / 12,
            boundsMin = floatArrayOf(0f, 0f, 0f),
            boundsMax = floatArrayOf(0f, 0f, 0f),
            categoryHint = MeshDiagnosticsHelper.classifyCategory(name),
            hasValidUvs = hasUvs
        )
    }

    private fun extractAsciiFbxDoubleArray(body: String, key: String): DoubleArray {
        val idx = body.indexOf(key)
        if (idx < 0) return DoubleArray(0)
        val openBrace = body.indexOf("a:", idx)
        if (openBrace < 0) return DoubleArray(0)
        val closeBrace = body.indexOf('}', openBrace)
        if (closeBrace < 0) return DoubleArray(0)
        val nums = body.substring(openBrace + 2, closeBrace).trim()
        if (nums.isEmpty()) return DoubleArray(0)
        return nums.split(',').mapNotNull { it.trim().toDoubleOrNull() }.toDoubleArray()
    }

    private fun extractAsciiFbxIntArray(body: String, key: String): IntArray {
        val idx = body.indexOf(key)
        if (idx < 0) return IntArray(0)
        val openBrace = body.indexOf("a:", idx)
        if (openBrace < 0) return IntArray(0)
        val closeBrace = body.indexOf('}', openBrace)
        if (closeBrace < 0) return IntArray(0)
        val nums = body.substring(openBrace + 2, closeBrace).trim()
        if (nums.isEmpty()) return IntArray(0)
        return nums.split(',').mapNotNull { it.trim().toIntOrNull() }.toIntArray()
    }

    fun findRelativeFile(ref: String, vararg searchDirs: File?): File? {
        val clean = ref.replace('\\', '/').trimStart('/')
        val justName = clean.substringAfterLast('/')
        for (dir in searchDirs) {
            if (dir == null || !dir.exists()) continue
            val direct = File(dir, clean)
            if (direct.exists() && direct.isFile) return direct
            val byName = File(dir, justName)
            if (byName.exists() && byName.isFile) return byName
            val found = dir.walkTopDown().maxDepth(4).firstOrNull {
                it.isFile && (it.name.equals(justName, ignoreCase = true) || it.path.replace('\\', '/').endsWith(clean, ignoreCase = true))
            }
            if (found != null) return found
        }
        return null
    }
}
