package com.example.vr.world

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.vr.model.AlphaMode
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.TextureQuality
import com.example.vr.model.WorldEntry
import com.example.vr.model.WorldProjectState
import com.example.vr.model.WorldSubMeshData
import com.example.vr.model.WorldType
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.zip.ZipInputStream
import kotlin.math.min
import kotlin.math.sqrt

sealed class ImportResult {
    data class Success(
        val worldEntry: WorldEntry,
        val mesh: ImportedMeshData,
        val projectState: WorldProjectState
    ) : ImportResult()
    data class Rejected(val reasonEn: String, val reasonAr: String) : ImportResult()
}

data class AdditionalModelImportResult(
    val nodeName: String,
    val assetPath: String,
    val mesh: ImportedMeshData
)

object WorldAssetImporter {

    const val MAX_FILE_BYTES = 1024L * 1024L * 1024L // 1 GB limit
    const val MAX_VERTICES = 600_000

    fun importFromUri(
        context: Context,
        uri: Uri,
        textureQuality: TextureQuality = TextureQuality.MEDIUM_1024
    ): ImportResult {
        val (fileName, fileSizeBytes) = queryUriMeta(context, uri)
        if (fileSizeBytes > MAX_FILE_BYTES) {
            return ImportResult.Rejected(
                reasonEn = "File exceeds 1 GB limit (${fileSizeBytes / (1024 * 1024)} MB).",
                reasonAr = "حجم الملف يتجاوز الحد الأقصى المسموح به (1 جيجابايت)."
            )
        }

        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("glb", "gltf", "obj", "zip", "fbx")) {
            return ImportResult.Rejected(
                reasonEn = "Unsupported file format '.$ext'. Supported: GLB, glTF, OBJ, FBX, and ZIP packs.",
                reasonAr = "صيغة غير مدعومة (.$ext). الصيغ المدعومة هي: GLB, glTF, OBJ, FBX, ZIP."
            )
        }

        val dir = File(context.filesDir, "custom_worlds").apply { mkdirs() }
        val id = "custom_${UUID.randomUUID().toString().take(8)}"
        val savedFile = File(dir, "$id.$ext")

        val copiedBytes = streamUriToFile(context, uri, savedFile)
            ?: return ImportResult.Rejected("Unable to read or copy selected file.", "تعذر قراءة أو نسخ الملف المحدد.")

        if (copiedBytes <= 0L) {
            savedFile.delete()
            return ImportResult.Rejected("Selected file is empty (0 bytes).", "الملف المحدد فارغ (0 بايت).")
        }

        val texturesDir = WorldProjectRepository.texturesDir(context, id)
        val unpackedDir = if (ext == "zip") WorldProjectRepository.unpackedDir(context, id) else null

        val parsedMesh = try {
            loadCachedCustomMesh(
                path = savedFile.absolutePath,
                texturesOutDir = texturesDir,
                unpackedOutDir = unpackedDir,
                maxTexDimPx = textureQuality.maxDimensionPx
            )
        } catch (_: OutOfMemoryError) {
            savedFile.delete()
            WorldProjectRepository.deleteProjectDir(context, id)
            return ImportResult.Rejected(
                reasonEn = "Not enough device RAM to unpack this 3D geometry. Try Medium/Low texture quality or fewer polygons.",
                reasonAr = "ذاكرة الهاتف غير كافية لفك هذا المجسم الضخم. جرّب جودة خامات متوسطة/منخفضة أو ملفاً بأقل مضلعات."
            )
        }

        if (parsedMesh == null) {
            savedFile.delete()
            WorldProjectRepository.deleteProjectDir(context, id)
            val fbxHint = if (ext == "fbx") {
                " Binary/encrypted FBX variants without extractable mesh tables should be exported as GLB from Blender."
            } else ""
            val fbxHintAr = if (ext == "fbx") {
                " إذا كان ملف FBX مشفراً أو غير قياسي، صدّره بصيغة GLB من Blender."
            } else ""
            return ImportResult.Rejected(
                reasonEn = "Invalid or unreadable 3D geometry inside '$fileName'.$fbxHint",
                reasonAr = "الملف '$fileName' لا يحتوي على مجسمات ثلاثية الأبعاد مقروءة.$fbxHintAr"
            )
        }

        if (parsedMesh.vertexCount < 3) {
            savedFile.delete()
            WorldProjectRepository.deleteProjectDir(context, id)
            return ImportResult.Rejected(
                reasonEn = "Mesh contains too few vertices (${parsedMesh.vertexCount}).",
                reasonAr = "عدد نقاط المجسم قليل جداً (${parsedMesh.vertexCount})."
            )
        }
        if (parsedMesh.vertexCount > MAX_VERTICES) {
            savedFile.delete()
            WorldProjectRepository.deleteProjectDir(context, id)
            return ImportResult.Rejected(
                reasonEn = "Polygon count (${parsedMesh.vertexCount} vertices) exceeds mobile VR limit ($MAX_VERTICES).",
                reasonAr = "عدد المضلعات مرتفع جداً (${parsedMesh.vertexCount} نقطة) وقد يسبب هبوط الإطارات."
            )
        }

        val sizeMb = (copiedBytes / (1024f * 1024f)).coerceAtLeast(0.05f)
        val cleanTitle = fileName.substringBeforeLast('.').replace('_', ' ').replace('-', ' ')
        val entry = WorldEntry(
            id = id,
            type = WorldType.CUSTOM_IMPORTED,
            titleEn = cleanTitle,
            titleAr = "عالم مستورد: $cleanTitle",
            descEn = "${parsedMesh.subMeshes.size} meshes · ${parsedMesh.vertexCount} verts · ${parsedMesh.diagnostics.texturesExtracted}/${parsedMesh.materials.size} textures",
            descAr = "${parsedMesh.subMeshes.size} مجسم · ${parsedMesh.vertexCount} نقطة · ${parsedMesh.diagnostics.texturesExtracted}/${parsedMesh.materials.size} خامة",
            fileSizeMb = sizeMb,
            rating = 5.0f,
            isBuiltIn = false,
            isDownloaded = true,
            isCustomImported = true,
            sourceLabel = "Imported File",
            formatLabel = ext.uppercase(),
            customAssetPath = savedFile.absolutePath,
            vertexCount = parsedMesh.vertexCount,
            thumbnailKey = "mall"
        )

        val initialProject = WorldProjectRepository.buildInitialProject(entry, parsedMesh)
        val savedProject = WorldProjectRepository.saveProject(context, initialProject, saveAsOriginalIfMissing = true)
        return ImportResult.Success(entry, parsedMesh, savedProject)
    }

    fun importAdditionalModelFromUri(
        context: Context,
        worldId: String,
        uri: Uri,
        textureQuality: TextureQuality = TextureQuality.MEDIUM_1024
    ): Result<AdditionalModelImportResult> {
        val (fileName, fileSizeBytes) = queryUriMeta(context, uri)
        if (fileSizeBytes > MAX_FILE_BYTES) {
            return Result.failure(IllegalArgumentException("File exceeds 1 GB limit"))
        }
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("glb", "gltf", "obj", "zip", "fbx")) {
            return Result.failure(IllegalArgumentException("Unsupported format .$ext"))
        }

        val modelId = "prop_${UUID.randomUUID().toString().take(8)}"
        val modelsDir = WorldProjectRepository.modelsDir(context, worldId)
        val savedFile = File(modelsDir, "$modelId.$ext")
        val copied = streamUriToFile(context, uri, savedFile)
            ?: return Result.failure(IllegalStateException("Failed to copy model file"))
        if (copied <= 0L) {
            savedFile.delete()
            return Result.failure(IllegalStateException("Empty file"))
        }

        val texDir = WorldProjectRepository.texturesDir(context, worldId)
        val unpackDir = if (ext == "zip") File(WorldProjectRepository.unpackedDir(context, worldId), modelId).apply { mkdirs() } else null
        val parsed = loadCachedCustomMesh(savedFile.absolutePath, texDir, unpackDir, textureQuality.maxDimensionPx)
        if (parsed == null || parsed.vertexCount < 3) {
            savedFile.delete()
            return Result.failure(IllegalStateException("No readable 3D geometry in $fileName"))
        }

        val cleanName = fileName.substringBeforeLast('.').replace('_', ' ').replace('-', ' ')
        return Result.success(
            AdditionalModelImportResult(
                nodeName = cleanName,
                assetPath = savedFile.absolutePath,
                mesh = parsed
            )
        )
    }

    fun loadCachedCustomMesh(
        path: String?,
        texturesOutDir: File? = null,
        unpackedOutDir: File? = null,
        maxTexDimPx: Int = 1024
    ): ImportedMeshData? {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.exists() || !file.canRead()) return null
        return runCatching {
            when (file.extension.lowercase()) {
                "obj" -> FbxAndObjParser.parseObjFile(file, file.parentFile, texturesOutDir, maxTexDimPx, MAX_VERTICES)
                "fbx" -> FbxAndObjParser.parseFbxFile(file, file.parentFile, texturesOutDir, maxTexDimPx, MAX_VERTICES)
                "glb" -> parseGlbFile(file, texturesOutDir, maxTexDimPx)
                "gltf" -> parseGltfFile(file, file.parentFile, texturesOutDir, maxTexDimPx)
                "zip" -> parseZipPackFile(file, texturesOutDir, unpackedOutDir, maxTexDimPx)
                else -> null
            }
        }.getOrNull()
    }

    fun deleteCustomFile(path: String?) {
        if (!path.isNullOrBlank()) {
            runCatching { File(path).delete() }
        }
    }

    /** Exposed for unit tests & standalone GLB memory parsing without Context. */
    fun parseGlbBytes(
        name: String,
        glbBytes: ByteArray,
        texturesOutDir: File? = null,
        maxTexDimPx: Int = 1024
    ): ImportedMeshData? {
        if (glbBytes.size < 20) return null
        val hbb = ByteBuffer.wrap(glbBytes).order(ByteOrder.LITTLE_ENDIAN)
        if (hbb.int != 0x46546C67 || hbb.int != 2) return null
        hbb.int // total length

        var jsonText: String? = null
        var binSlice: ByteBuffer? = null
        while (hbb.remaining() >= 8) {
            val chunkLen = hbb.int
            val chunkType = hbb.int
            if (chunkLen < 0 || chunkLen > hbb.remaining()) break
            val pos = hbb.position()
            when (chunkType) {
                0x4E4F534A -> jsonText = String(glbBytes, pos, chunkLen)
                0x004E4942 -> binSlice = ByteBuffer.wrap(glbBytes, pos, chunkLen).slice().order(ByteOrder.LITTLE_ENDIAN)
            }
            hbb.position(pos + chunkLen)
        }
        if (jsonText == null || binSlice == null) return null
        val root = runCatching { JSONObject(jsonText) }.getOrNull() ?: return null
        return extractGltfScene(name, root, listOf(binSlice), null, texturesOutDir, maxTexDimPx)
    }

    private fun parseZipPackFile(
        zipFile: File,
        texturesOutDir: File?,
        unpackedOutDir: File?,
        maxTexDimPx: Int
    ): ImportedMeshData? {
        val unpackTarget = unpackedOutDir ?: File(zipFile.parentFile, "${zipFile.nameWithoutExtension}_unpacked").apply { mkdirs() }
        val canonicalRoot = unpackTarget.canonicalPath
        var totalUnpacked = 0L

        // Safely unpack ZIP entries so relative glTF .bin/textures and OBJ .mtl/textures resolve accurately!
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile), 64 * 1024)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val cleanName = entry.name.replace('\\', '/').trimStart('/')
                    val outFile = File(unpackTarget, cleanName)
                    if (outFile.canonicalPath.startsWith(canonicalRoot)) {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = zis.read(buf)
                                if (r <= 0) break
                                totalUnpacked += r
                                if (totalUnpacked > MAX_FILE_BYTES) break
                                fos.write(buf, 0, r)
                            }
                        }
                    }
                }
                zis.closeEntry()
                if (totalUnpacked > MAX_FILE_BYTES) break
                entry = zis.nextEntry
            }
        }

        val allFiles = unpackTarget.walkTopDown().filter { it.isFile }.toList()
        val glbFile = allFiles.firstOrNull { it.extension.equals("glb", true) }
        if (glbFile != null) return parseGlbFile(glbFile, texturesOutDir, maxTexDimPx)

        val gltfFile = allFiles.firstOrNull { it.extension.equals("gltf", true) }
        if (gltfFile != null) return parseGltfFile(gltfFile, unpackTarget, texturesOutDir, maxTexDimPx)

        val objFile = allFiles.firstOrNull { it.extension.equals("obj", true) }
        if (objFile != null) return FbxAndObjParser.parseObjFile(objFile, unpackTarget, texturesOutDir, maxTexDimPx, MAX_VERTICES)

        val fbxFile = allFiles.firstOrNull { it.extension.equals("fbx", true) }
        if (fbxFile != null) return FbxAndObjParser.parseFbxFile(fbxFile, unpackTarget, texturesOutDir, maxTexDimPx, MAX_VERTICES)

        return null
    }

    private fun parseGltfFile(
        gltfFile: File,
        baseDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int
    ): ImportedMeshData? {
        val text = runCatching { gltfFile.readText() }.getOrNull() ?: return null
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return null
        val buffersJson = root.optJSONArray("buffers") ?: return null
        val buffers = ArrayList<ByteBuffer>(buffersJson.length())

        for (i in 0 until buffersJson.length()) {
            val uri = buffersJson.getJSONObject(i).optString("uri")
            val bytes = when {
                uri.startsWith("data:") -> {
                    val b64 = uri.substringAfter("base64,", "")
                    runCatching { android.util.Base64.decode(b64, android.util.Base64.DEFAULT) }.getOrNull()
                }
                uri.isNotBlank() -> {
                    FbxAndObjParser.findRelativeFile(uri, gltfFile.parentFile, baseDir)?.readBytes()
                }
                else -> null
            }
            if (bytes != null) {
                buffers.add(ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN))
            } else {
                buffers.add(ByteBuffer.allocate(0).order(ByteOrder.LITTLE_ENDIAN))
            }
        }
        return extractGltfScene(gltfFile.name, root, buffers, gltfFile.parentFile ?: baseDir, texturesOutDir, maxTexDimPx)
    }

    private fun parseGlbFile(
        file: File,
        texturesOutDir: File?,
        maxTexDimPx: Int
    ): ImportedMeshData? {
        val fileLen = file.length()
        if (fileLen < 20L) return null
        RandomAccessFile(file, "r").use { raf ->
            val header = ByteArray(12)
            raf.readFully(header)
            val hbb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            if (hbb.int != 0x46546C67 || hbb.int != 2) return null

            var jsonText: String? = null
            var binFileOffset = -1L
            var binLength = 0L
            val chunkHdr = ByteArray(8)

            while (raf.filePointer + 8 <= fileLen) {
                raf.readFully(chunkHdr)
                val cbb = ByteBuffer.wrap(chunkHdr).order(ByteOrder.LITTLE_ENDIAN)
                val chunkLen = cbb.int.toLong() and 0xFFFFFFFFL
                val chunkType = cbb.int
                val dataPos = raf.filePointer
                if (chunkLen < 0 || dataPos + chunkLen > fileLen) break

                when (chunkType) {
                    0x4E4F534A -> {
                        if (chunkLen > 64L * 1024L * 1024L) return null
                        val jsonBytes = ByteArray(chunkLen.toInt())
                        raf.readFully(jsonBytes)
                        jsonText = jsonBytes.decodeToString()
                    }
                    0x004E4942 -> {
                        binFileOffset = dataPos
                        binLength = chunkLen
                        raf.seek(dataPos + chunkLen)
                    }
                    else -> raf.seek(dataPos + chunkLen)
                }
            }

            if (jsonText == null || binFileOffset < 0L) return null
            val root = runCatching { JSONObject(jsonText) }.getOrNull() ?: return null
            val mapped = runCatching {
                raf.channel.map(java.nio.channels.FileChannel.MapMode.READ_ONLY, binFileOffset, binLength)
                    .order(ByteOrder.LITTLE_ENDIAN)
            }.getOrNull() ?: return null

            return extractGltfScene(file.name, root, listOf(mapped), file.parentFile, texturesOutDir, maxTexDimPx)
        }
    }

    private fun extractGltfScene(
        name: String,
        root: JSONObject,
        buffers: List<ByteBuffer>,
        baseDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int
    ): ImportedMeshData? {
        val meshes = root.optJSONArray("meshes") ?: return null
        val accessors = root.optJSONArray("accessors") ?: return null
        val bufferViews = root.optJSONArray("bufferViews") ?: return null
        if (meshes.length() == 0) return null

        // 1. Extract all glTF materials + embedded/linked textures
        val matSpecs = extractGltfMaterials(root, buffers, bufferViews, baseDir, texturesOutDir, maxTexDimPx)

        // 2. Walk glTF nodes to collect world transforms for each mesh instance!
        val meshInstances = collectGltfMeshInstances(root, meshes.length())
        val subMeshes = mutableListOf<WorldSubMeshData>()
        var totalVerts = 0

        for ((meshIdx, nodeName, nodeMat) in meshInstances) {
            if (totalVerts >= MAX_VERTICES) break
            val meshObj = meshes.optJSONObject(meshIdx) ?: continue
            val meshTitle = meshObj.optString("name", nodeName).ifBlank { nodeName }
            val prims = meshObj.optJSONArray("primitives") ?: continue

            for (p in 0 until prims.length()) {
                if (totalVerts >= MAX_VERTICES) break
                val prim = prims.getJSONObject(p)
                val mode = prim.optInt("mode", 4)
                if (mode != 4) continue // TRIANGLES only
                val attrs = prim.optJSONObject("attributes") ?: continue
                val posAccIdx = attrs.optInt("POSITION", -1)
                if (posAccIdx < 0) continue

                val rawPositions = readFloatVecAccessor(accessors, bufferViews, buffers, posAccIdx, 3) ?: continue
                val rawNormals = attrs.optInt("NORMAL", -1).let { idx ->
                    if (idx >= 0) readFloatVecAccessor(accessors, bufferViews, buffers, idx, 3) else null
                }
                val rawUvs = attrs.optInt("TEXCOORD_0", -1).let { idx ->
                    if (idx >= 0) readUvAccessor(accessors, bufferViews, buffers, idx) else null
                }
                val rawColors = attrs.optInt("COLOR_0", -1).let { idx ->
                    if (idx >= 0) readColorAccessor(accessors, bufferViews, buffers, idx) else null
                }
                val indices = if (prim.has("indices")) {
                    readIndicesAccessor(accessors, bufferViews, buffers, prim.getInt("indices"))
                } else {
                    IntArray(rawPositions.size / 3) { it }
                }

                val vertCountRaw = rawPositions.size / 3
                val transformedPos = FloatArray(rawPositions.size)
                val tmpIn = FloatArray(4)
                val tmpOut = FloatArray(4)
                for (vi in 0 until vertCountRaw) {
                    tmpIn[0] = rawPositions[vi * 3]
                    tmpIn[1] = rawPositions[vi * 3 + 1]
                    tmpIn[2] = rawPositions[vi * 3 + 2]
                    tmpIn[3] = 1f
                    matMulVec4(tmpOut, nodeMat, tmpIn)
                    transformedPos[vi * 3] = tmpOut[0]
                    transformedPos[vi * 3 + 1] = tmpOut[1]
                    transformedPos[vi * 3 + 2] = tmpOut[2]
                }

                val out = ArrayList<Float>(min(indices.size, 8192) * 12)
                var i = 0
                while (i + 2 < indices.size && totalVerts < MAX_VERTICES) {
                    val idx0 = indices[i]; val idx1 = indices[i + 1]; val idx2 = indices[i + 2]
                    val a = idx0 * 3; val b = idx1 * 3; val c = idx2 * 3
                    if (a + 2 < transformedPos.size && b + 2 < transformedPos.size && c + 2 < transformedPos.size) {
                        val ax = transformedPos[a]; val ay = transformedPos[a + 1]; val az = transformedPos[a + 2]
                        val bx = transformedPos[b]; val by = transformedPos[b + 1]; val bz = transformedPos[b + 2]
                        val cx = transformedPos[c]; val cy = transformedPos[c + 1]; val cz = transformedPos[c + 2]
                        val ux = bx - ax; val uy = by - ay; val uz = bz - az
                        val vx = cx - ax; val vy = cy - ay; val vz = cz - az
                        var fnx = uy * vz - uz * vy
                        var fny = uz * vx - ux * vz
                        var fnz = ux * vy - uy * vx
                        val fLen = sqrt(fnx * fnx + fny * fny + fnz * fnz).coerceAtLeast(1e-5f)
                        fnx /= fLen; fny /= fLen; fnz /= fLen

                        for (vIdx in intArrayOf(idx0, idx1, idx2)) {
                            val vp = vIdx * 3
                            out.add(transformedPos[vp]); out.add(transformedPos[vp + 1]); out.add(transformedPos[vp + 2])
                            if (rawNormals != null && vp + 2 < rawNormals.size) {
                                // Rotate normal by upper 3x3 of nodeMat
                                val nx = rawNormals[vp]; val ny = rawNormals[vp + 1]; val nz = rawNormals[vp + 2]
                                val rnx = nodeMat[0] * nx + nodeMat[4] * ny + nodeMat[8] * nz
                                val rny = nodeMat[1] * nx + nodeMat[5] * ny + nodeMat[9] * nz
                                val rnz = nodeMat[2] * nx + nodeMat[6] * ny + nodeMat[10] * nz
                                val rLen = sqrt(rnx * rnx + rny * rny + rnz * rnz).coerceAtLeast(1e-5f)
                                out.add(rnx / rLen); out.add(rny / rLen); out.add(rnz / rLen)
                            } else {
                                out.add(fnx); out.add(fny); out.add(fnz)
                            }
                            val uvBase = vIdx * 2
                            if (rawUvs != null && uvBase + 1 < rawUvs.size) {
                                out.add(rawUvs[uvBase]); out.add(rawUvs[uvBase + 1])
                            } else {
                                out.add(0f); out.add(0f)
                            }
                            val cBase = vIdx * 4
                            if (rawColors != null && cBase + 3 < rawColors.size) {
                                out.add(rawColors[cBase]); out.add(rawColors[cBase + 1])
                                out.add(rawColors[cBase + 2]); out.add(rawColors[cBase + 3])
                            } else {
                                out.add(1f); out.add(1f); out.add(1f); out.add(1f)
                            }
                            totalVerts++
                        }
                    }
                    i += 3
                }

                if (out.isNotEmpty()) {
                    val matIdx = prim.optInt("material", 0).coerceIn(0, matSpecs.lastIndex.coerceAtLeast(0))
                    val partName = if (prims.length() > 1) "${meshTitle}_part$p" else meshTitle
                    subMeshes.add(
                        WorldSubMeshData(
                            name = partName,
                            nodeName = meshTitle,
                            materialIndex = matIdx,
                            interleavedVertices = out.toFloatArray(),
                            vertexCount = out.size / 12,
                            boundsMin = floatArrayOf(0f, 0f, 0f),
                            boundsMax = floatArrayOf(0f, 0f, 0f),
                            categoryHint = MeshDiagnosticsHelper.classifyCategory(meshTitle),
                            hasValidUvs = rawUvs != null
                        )
                    )
                }
            }
        }

        if (subMeshes.isEmpty()) return null
        return MeshDiagnosticsHelper.auditAndNormalize(name, subMeshes, matSpecs)
    }

    private fun extractGltfMaterials(
        root: JSONObject,
        buffers: List<ByteBuffer>,
        bufferViews: JSONArray,
        baseDir: File?,
        texturesOutDir: File?,
        maxTexDimPx: Int
    ): List<PbrMaterialSpec> {
        val matsJson = root.optJSONArray("materials")
        val texturesJson = root.optJSONArray("textures")
        val imagesJson = root.optJSONArray("images")

        fun extractImagePath(texInfoObj: JSONObject?, prefix: String): Pair<String?, String?> {
            if (texInfoObj == null || texturesJson == null || imagesJson == null) return null to null
            val texIdx = texInfoObj.optInt("index", -1)
            if (texIdx !in 0 until texturesJson.length()) return null to null
            val imgIdx = texturesJson.getJSONObject(texIdx).optInt("source", -1)
            if (imgIdx !in 0 until imagesJson.length()) return null to null
            val imgObj = imagesJson.getJSONObject(imgIdx)
            val imgName = imgObj.optString("name").ifBlank { imgObj.optString("uri").ifBlank { "${prefix}_$imgIdx.png" } }

            val bytes: ByteArray? = when {
                imgObj.has("bufferView") -> {
                    val bvIdx = imgObj.getInt("bufferView")
                    if (bvIdx in 0 until bufferViews.length()) {
                        val bv = bufferViews.getJSONObject(bvIdx)
                        val bufIdx = bv.optInt("buffer", 0)
                        val buf = buffers.getOrNull(bufIdx)
                        val offset = bv.optInt("byteOffset", 0)
                        val len = bv.optInt("byteLength", 0)
                        if (buf != null && offset >= 0 && len > 0 && offset + len <= buf.capacity()) {
                            ByteArray(len).also { arr ->
                                val dup = buf.duplicate()
                                dup.position(offset)
                                dup.get(arr, 0, len)
                            }
                        } else null
                    } else null
                }
                imgObj.has("uri") -> {
                    val uri = imgObj.getString("uri")
                    when {
                        uri.startsWith("data:") -> {
                            val b64 = uri.substringAfter("base64,", "")
                            runCatching { android.util.Base64.decode(b64, android.util.Base64.DEFAULT) }.getOrNull()
                        }
                        else -> FbxAndObjParser.findRelativeFile(uri, baseDir)?.readBytes()
                    }
                }
                else -> null
            }

            if (bytes == null || texturesOutDir == null) {
                return null to imgName
            }
            val outFile = File(texturesOutDir, "${prefix}_img_${imgIdx}.png")
            val savedPath = WorldProjectRepository.saveDownsampledTextureBytes(bytes, outFile, maxTexDimPx)
            return savedPath to (if (savedPath == null) imgName else null)
        }

        if (matsJson == null || matsJson.length() == 0) {
            return listOf(
                PbrMaterialSpec(
                    id = "gltf_default_0",
                    name = "DefaultMaterial",
                    baseColorArgb = 0xFFD9E2EC,
                    isOriginalIntact = false
                )
            )
        }

        val result = mutableListOf<PbrMaterialSpec>()
        for (i in 0 until matsJson.length()) {
            val mat = matsJson.getJSONObject(i)
            val matName = mat.optString("name", "Material_$i")
            val pbr = mat.optJSONObject("pbrMetallicRoughness")

            val baseFactor = pbr?.optJSONArray("baseColorFactor")
            val r = (((baseFactor?.optDouble(0, 1.0) ?: 1.0).toFloat()).coerceIn(0f, 1f) * 255f).toInt()
            val g = (((baseFactor?.optDouble(1, 1.0) ?: 1.0).toFloat()).coerceIn(0f, 1f) * 255f).toInt()
            val b = (((baseFactor?.optDouble(2, 1.0) ?: 1.0).toFloat()).coerceIn(0f, 1f) * 255f).toInt()
            val a = ((baseFactor?.optDouble(3, 1.0) ?: 1.0).toFloat()).coerceIn(0.05f, 1f)
            val baseColorArgb = ((255 shl 24) or (r shl 16) or (g shl 8) or b).toLong() and 0xFFFFFFFFL

            val metallic = (pbr?.optDouble("metallicFactor", 0.05) ?: 0.05).toFloat().coerceIn(0f, 1f)
            val roughness = (pbr?.optDouble("roughnessFactor", 0.72) ?: 0.72).toFloat().coerceIn(0.08f, 1f)

            val alphaModeStr = mat.optString("alphaMode", "OPAQUE").uppercase()
            val alphaMode = when (alphaModeStr) {
                "MASK" -> AlphaMode.MASK
                "BLEND" -> AlphaMode.BLEND
                else -> if (a < 0.98f) AlphaMode.BLEND else AlphaMode.OPAQUE
            }
            val alphaCutoff = mat.optDouble("alphaCutoff", 0.45).toFloat().coerceIn(0.05f, 0.95f)

            val emissiveFactor = mat.optJSONArray("emissiveFactor")
            val er = ((emissiveFactor?.optDouble(0, 0.0) ?: 0.0).toFloat()).coerceIn(0f, 1f)
            val eg = ((emissiveFactor?.optDouble(1, 0.0) ?: 0.0).toFloat()).coerceIn(0f, 1f)
            val eb = ((emissiveFactor?.optDouble(2, 0.0) ?: 0.0).toFloat()).coerceIn(0f, 1f)
            val emissiveStr = maxOf(er, eg, eb)
            val emissiveArgb = ((255 shl 24) or ((er * 255).toInt() shl 16) or ((eg * 255).toInt() shl 8) or (eb * 255).toInt()).toLong() and 0xFFFFFFFFL

            val (baseTexPath, missingBaseTex) = extractImagePath(pbr?.optJSONObject("baseColorTexture"), "base_$i")
            val (normTexPath, _) = extractImagePath(mat.optJSONObject("normalTexture"), "norm_$i")
            val (aoTexPath, _) = extractImagePath(mat.optJSONObject("occlusionTexture"), "ao_$i")
            val (emisTexPath, _) = extractImagePath(mat.optJSONObject("emissiveTexture"), "emis_$i")

            result.add(
                PbrMaterialSpec(
                    id = "gltf_mat_$i",
                    name = matName,
                    baseColorArgb = baseColorArgb,
                    metallic = metallic,
                    roughness = roughness,
                    alpha = a,
                    alphaMode = alphaMode,
                    alphaCutoff = alphaCutoff,
                    emissiveStrength = emissiveStr,
                    emissiveColorArgb = emissiveArgb,
                    reflectivity = (1f - roughness) * 0.65f,
                    texturePath = baseTexPath,
                    normalTexturePath = normTexPath,
                    aoTexturePath = aoTexPath,
                    emissiveTexturePath = emisTexPath,
                    missingTextureName = missingBaseTex,
                    isOriginalIntact = missingBaseTex == null
                )
            )
        }
        return result
    }

    private fun collectGltfMeshInstances(root: JSONObject, meshCount: Int): List<Triple<Int, String, FloatArray>> {
        val nodes = root.optJSONArray("nodes")
        if (nodes == null || nodes.length() == 0) {
            return (0 until min(meshCount, 128)).map { mIdx ->
                val id = FloatArray(16).also { matSetIdentity(it) }
                Triple(mIdx, "Mesh_$mIdx", id)
            }
        }

        val out = mutableListOf<Triple<Int, String, FloatArray>>()

        fun buildLocalMatrix(node: JSONObject): FloatArray {
            val mat = FloatArray(16)
            val matArr = node.optJSONArray("matrix")
            if (matArr != null && matArr.length() == 16) {
                for (i in 0 until 16) mat[i] = matArr.optDouble(i, if (i % 5 == 0) 1.0 else 0.0).toFloat()
                return mat
            }
            matSetIdentity(mat)
            node.optJSONArray("translation")?.let { t ->
                mat[12] += t.optDouble(0, 0.0).toFloat()
                mat[13] += t.optDouble(1, 0.0).toFloat()
                mat[14] += t.optDouble(2, 0.0).toFloat()
            }
            node.optJSONArray("rotation")?.let { q ->
                val qx = q.optDouble(0, 0.0).toFloat()
                val qy = q.optDouble(1, 0.0).toFloat()
                val qz = q.optDouble(2, 0.0).toFloat()
                val qw = q.optDouble(3, 1.0).toFloat()
                val rotMat = FloatArray(16)
                quatToMatrix(qx, qy, qz, qw, rotMat)
                val tmp = FloatArray(16)
                matMul4x4(tmp, mat, rotMat)
                System.arraycopy(tmp, 0, mat, 0, 16)
            }
            node.optJSONArray("scale")?.let { s ->
                val sx = s.optDouble(0, 1.0).toFloat()
                val sy = s.optDouble(1, 1.0).toFloat()
                val sz = s.optDouble(2, 1.0).toFloat()
                for (row in 0..3) {
                    mat[row] *= sx
                    mat[4 + row] *= sy
                    mat[8 + row] *= sz
                }
            }
            return mat
        }

        fun visit(nodeIdx: Int, parentMat: FloatArray, depth: Int) {
            if (depth > 32 || out.size >= 160 || nodeIdx !in 0 until nodes.length()) return
            val node = nodes.getJSONObject(nodeIdx)
            val localMat = buildLocalMatrix(node)
            val worldMat = FloatArray(16)
            matMul4x4(worldMat, parentMat, localMat)

            val mIdx = node.optInt("mesh", -1)
            val nodeName = node.optString("name", "Node_$nodeIdx")
            if (mIdx in 0 until meshCount) {
                out.add(Triple(mIdx, nodeName, worldMat))
            }
            val children = node.optJSONArray("children")
            if (children != null) {
                for (c in 0 until children.length()) {
                    visit(children.optInt(c, -1), worldMat, depth + 1)
                }
            }
        }

        val scenes = root.optJSONArray("scenes")
        val sceneIdx = root.optInt("scene", 0)
        val rootNodes = scenes?.optJSONObject(sceneIdx)?.optJSONArray("nodes")
        val identity = FloatArray(16).also { matSetIdentity(it) }
        if (rootNodes != null && rootNodes.length() > 0) {
            for (r in 0 until rootNodes.length()) {
                visit(rootNodes.optInt(r, -1), identity, 0)
            }
        } else {
            for (mIdx in 0 until min(meshCount, 128)) {
                out.add(Triple(mIdx, "Mesh_$mIdx", identity))
            }
        }
        return out
    }

    private fun matSetIdentity(m: FloatArray) {
        for (i in 0 until 16) m[i] = if (i % 5 == 0) 1f else 0f
    }

    private fun matMul4x4(out: FloatArray, a: FloatArray, b: FloatArray) {
        for (c in 0..3) {
            for (r in 0..3) {
                out[c * 4 + r] =
                    a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3]
            }
        }
    }

    private fun matMulVec4(out: FloatArray, m: FloatArray, v: FloatArray) {
        out[0] = m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3]
        out[1] = m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3]
        out[2] = m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3]
        out[3] = m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3]
    }

    private fun quatToMatrix(x: Float, y: Float, z: Float, w: Float, m: FloatArray) {
        val xx = x * x; val yy = y * y; val zz = z * z
        val xy = x * y; val xz = x * z; val yz = y * z
        val wx = w * x; val wy = w * y; val wz = w * z
        m[0] = 1f - 2f * (yy + zz); m[4] = 2f * (xy - wz); m[8] = 2f * (xz + wy); m[12] = 0f
        m[1] = 2f * (xy + wz); m[5] = 1f - 2f * (xx + zz); m[9] = 2f * (yz - wx); m[13] = 0f
        m[2] = 2f * (xz - wy); m[6] = 2f * (yz + wx); m[10] = 1f - 2f * (xx + yy); m[14] = 0f
        m[3] = 0f; m[7] = 0f; m[11] = 0f; m[15] = 1f
    }

    private fun readFloatVecAccessor(
        accessors: JSONArray,
        bufferViews: JSONArray,
        buffers: List<ByteBuffer>,
        accIdx: Int,
        comps: Int
    ): FloatArray? {
        val acc = accessors.optJSONObject(accIdx) ?: return null
        val viewIdx = acc.optInt("bufferView", -1)
        if (viewIdx !in 0 until bufferViews.length()) return null
        val view = bufferViews.getJSONObject(viewIdx)
        val buf = buffers.getOrNull(view.optInt("buffer", 0)) ?: return null
        val count = acc.optInt("count", 0)
        if (count <= 0) return null
        val byteOffset = view.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val stride = view.optInt("byteStride", comps * 4).coerceAtLeast(comps * 4)
        if (byteOffset < 0 || byteOffset.toLong() + count.toLong() * stride > buf.capacity()) return null
        val out = FloatArray(count * comps)
        for (i in 0 until count) {
            val base = byteOffset + i * stride
            for (c in 0 until comps) {
                out[i * comps + c] = buf.getFloat(base + c * 4)
            }
        }
        return out
    }

    private fun readUvAccessor(
        accessors: JSONArray,
        bufferViews: JSONArray,
        buffers: List<ByteBuffer>,
        accIdx: Int
    ): FloatArray? {
        val acc = accessors.optJSONObject(accIdx) ?: return null
        val compType = acc.optInt("componentType", 5126)
        val viewIdx = acc.optInt("bufferView", -1)
        if (viewIdx !in 0 until bufferViews.length()) return null
        val view = bufferViews.getJSONObject(viewIdx)
        val buf = buffers.getOrNull(view.optInt("buffer", 0)) ?: return null
        val count = acc.optInt("count", 0)
        if (count <= 0) return null
        val byteOffset = view.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val defaultStride = when (compType) { 5121 -> 2; 5123 -> 4; else -> 8 }
        val stride = view.optInt("byteStride", defaultStride).coerceAtLeast(defaultStride)
        if (byteOffset < 0 || byteOffset.toLong() + count.toLong() * stride > buf.capacity()) return null

        val out = FloatArray(count * 2)
        for (i in 0 until count) {
            val base = byteOffset + i * stride
            when (compType) {
                5126 -> {
                    out[i * 2] = buf.getFloat(base)
                    out[i * 2 + 1] = buf.getFloat(base + 4)
                }
                5121 -> {
                    out[i * 2] = (buf.get(base).toInt() and 0xFF) / 255f
                    out[i * 2 + 1] = (buf.get(base + 1).toInt() and 0xFF) / 255f
                }
                5123 -> {
                    out[i * 2] = (buf.getShort(base).toInt() and 0xFFFF) / 65535f
                    out[i * 2 + 1] = (buf.getShort(base + 2).toInt() and 0xFFFF) / 65535f
                }
            }
        }
        return out
    }

    private fun readColorAccessor(
        accessors: JSONArray,
        bufferViews: JSONArray,
        buffers: List<ByteBuffer>,
        accIdx: Int
    ): FloatArray? {
        val acc = accessors.optJSONObject(accIdx) ?: return null
        val typeStr = acc.optString("type", "VEC4")
        val numComps = if (typeStr == "VEC3") 3 else 4
        val compType = acc.optInt("componentType", 5126)
        val viewIdx = acc.optInt("bufferView", -1)
        if (viewIdx !in 0 until bufferViews.length()) return null
        val view = bufferViews.getJSONObject(viewIdx)
        val buf = buffers.getOrNull(view.optInt("buffer", 0)) ?: return null
        val count = acc.optInt("count", 0)
        if (count <= 0) return null
        val elemBytes = when (compType) { 5121 -> numComps; 5123 -> numComps * 2; else -> numComps * 4 }
        val stride = view.optInt("byteStride", elemBytes).coerceAtLeast(elemBytes)
        val byteOffset = view.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        if (byteOffset < 0 || byteOffset.toLong() + count.toLong() * stride > buf.capacity()) return null

        val out = FloatArray(count * 4)
        for (i in 0 until count) {
            val base = byteOffset + i * stride
            for (c in 0 until numComps) {
                val v = when (compType) {
                    5126 -> buf.getFloat(base + c * 4)
                    5121 -> (buf.get(base + c).toInt() and 0xFF) / 255f
                    5123 -> (buf.getShort(base + c * 2).toInt() and 0xFFFF) / 65535f
                    else -> 1f
                }
                out[i * 4 + c] = v.coerceIn(0f, 1f)
            }
            if (numComps == 3) out[i * 4 + 3] = 1f
        }
        return out
    }

    private fun readIndicesAccessor(
        accessors: JSONArray,
        bufferViews: JSONArray,
        buffers: List<ByteBuffer>,
        accIdx: Int
    ): IntArray {
        val acc = accessors.optJSONObject(accIdx) ?: return IntArray(0)
        val viewIdx = acc.optInt("bufferView", -1)
        if (viewIdx !in 0 until bufferViews.length()) return IntArray(0)
        val view = bufferViews.getJSONObject(viewIdx)
        val buf = buffers.getOrNull(view.optInt("buffer", 0)) ?: return IntArray(0)
        val count = acc.optInt("count", 0)
        if (count <= 0) return IntArray(0)
        val compType = acc.optInt("componentType", 5123)
        val byteOffset = view.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val out = IntArray(count)
        when (compType) {
            5121 -> for (i in 0 until count) {
                val p = byteOffset + i
                if (p < buf.capacity()) out[i] = buf.get(p).toInt() and 0xFF
            }
            5123 -> for (i in 0 until count) {
                val p = byteOffset + i * 2
                if (p + 1 < buf.capacity()) out[i] = buf.getShort(p).toInt() and 0xFFFF
            }
            5125 -> for (i in 0 until count) {
                val p = byteOffset + i * 4
                if (p + 3 < buf.capacity()) out[i] = buf.getInt(p)
            }
        }
        return out
    }

    private fun queryUriMeta(context: Context, uri: Uri): Pair<String, Long> {
        var fileName = "imported_world"
        var fileSizeBytes = -1L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                    if (sizeIdx >= 0) fileSizeBytes = cursor.getLong(sizeIdx)
                }
            }
        return fileName to fileSizeBytes
    }

    private fun streamUriToFile(context: Context, uri: Uri, dest: File): Long? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dest).use { output ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        total += read
                        if (total > MAX_FILE_BYTES) {
                            dest.delete()
                            return null
                        }
                        output.write(buf, 0, read)
                    }
                    total
                }
            }
        } catch (_: Throwable) {
            dest.delete()
            null
        }
    }
}
