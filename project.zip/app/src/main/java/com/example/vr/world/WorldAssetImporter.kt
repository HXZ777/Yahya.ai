package com.example.vr.world

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.WorldEntry
import com.example.vr.model.WorldType
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.zip.ZipInputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

sealed class ImportResult {
    data class Success(val worldEntry: WorldEntry, val mesh: ImportedMeshData) : ImportResult()
    data class Rejected(val reasonEn: String, val reasonAr: String) : ImportResult()
}

object WorldAssetImporter {

    private const val MAX_FILE_BYTES = 45L * 1024L * 1024L // 45 MB limit for mid-range phones
    private const val MAX_VERTICES = 150_000

    fun importFromUri(context: Context, uri: Uri): ImportResult {
        val resolver = context.contentResolver
        var fileName = "imported_world"
        var fileSizeBytes = -1L

        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                    if (sizeIdx >= 0) fileSizeBytes = cursor.getLong(sizeIdx)
                }
            }

        if (fileSizeBytes > MAX_FILE_BYTES) {
            return ImportResult.Rejected(
                reasonEn = "File exceeds 45 MB mobile VR memory budget (${fileSizeBytes / (1024 * 1024)} MB).",
                reasonAr = "حجم الملف يتجاوز حد 45 ميجابايت المناسب لأداء الهواتف المتوسطة."
            )
        }

        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "fbx") {
            return ImportResult.Rejected(
                reasonEn = "FBX is a proprietary Autodesk format without a native Android converter. Please export as GLB, glTF, or OBJ (e.g., via Blender).",
                reasonAr = "صيغة FBX تتطلب محولاً خاصاً غير متوفر على الهاتف. يرجى تصدير الملف بصيغة GLB أو glTF أو OBJ من Blender."
            )
        }
        if (ext !in setOf("glb", "gltf", "obj", "zip")) {
            return ImportResult.Rejected(
                reasonEn = "Unsupported file format '.$ext'. Supported: GLB, glTF, OBJ, and game-compatible ZIP packs.",
                reasonAr = "صيغة غير مدعومة (.$ext). الصيغ المدعومة هي: GLB, glTF, OBJ, ZIP."
            )
        }

        val bytes = runCatching {
            resolver.openInputStream(uri)?.use { input ->
                val raw = input.readBytes()
                if (raw.size > MAX_FILE_BYTES) return ImportResult.Rejected(
                    "File too large for mobile VR memory.",
                    "حجم الملف كبير جداً على ذاكرة الهاتف."
                )
                raw
            }
        }.getOrNull() ?: return ImportResult.Rejected(
            "Unable to read selected file stream.",
            "تعذر قراءة الملف المحدد."
        )

        if (bytes.isEmpty()) {
            return ImportResult.Rejected("Selected file is empty (0 bytes).", "الملف المحدد فارغ (0 بايت).")
        }

        val parsedMesh = when (ext) {
            "obj" -> parseObj(fileName, bytes.decodeToString())
            "glb" -> parseGlb(fileName, bytes)
            "gltf" -> parseGltfJson(fileName, bytes.decodeToString())
            "zip" -> parseZipPack(fileName, bytes)
            else -> null
        } ?: return ImportResult.Rejected(
            reasonEn = "Invalid or incompatible 3D geometry inside '$fileName'. No readable triangle mesh found.",
            reasonAr = "الملف '$fileName' لا يحتوي على مجسمات ثلاثية الأبعاد صالحة أو أن بنيته غير متوافقة."
        )

        if (parsedMesh.vertexCount < 3) {
            return ImportResult.Rejected(
                reasonEn = "Mesh contains too few vertices (${parsedMesh.vertexCount}) to render a world.",
                reasonAr = "عدد نقاط المجسم قليل جداً (${parsedMesh.vertexCount}) ولا يكفي لبناء عالم."
            )
        }
        if (parsedMesh.vertexCount > MAX_VERTICES) {
            return ImportResult.Rejected(
                reasonEn = "Polygon count (${parsedMesh.vertexCount} vertices) exceeds mobile VR limit ($MAX_VERTICES) to protect frame rate.",
                reasonAr = "عدد المضلعات مرتفع جداً (${parsedMesh.vertexCount} نقطة) وقد يسبب هبوط الإطارات على الهاتف."
            )
        }

        // Persist validated file inside app filesDir/custom_worlds
        val dir = File(context.filesDir, "custom_worlds").apply { mkdirs() }
        val id = "custom_${UUID.randomUUID().toString().take(8)}"
        val savedFile = File(dir, "$id.$ext")
        savedFile.writeBytes(bytes)

        val sizeMb = (bytes.size / (1024f * 1024f)).coerceAtLeast(0.05f)
        val cleanTitle = fileName.substringBeforeLast('.').replace('_', ' ').replace('-', ' ')
        val entry = WorldEntry(
            id = id,
            type = WorldType.GRAND_SUPERMARKET,
            titleEn = cleanTitle,
            titleAr = "عالم مستورد: $cleanTitle",
            descEn = "Validated external $ext asset (${parsedMesh.vertexCount} vertices) staged inside VR environment.",
            descAr = "ملف خارجي مفحوص بصيغة $ext (${parsedMesh.vertexCount} نقطة) جاهز للاستكشاف في VR.",
            fileSizeMb = sizeMb,
            rating = 5.0f,
            isBuiltIn = false,
            isDownloaded = true,
            isCustomImported = true,
            sourceLabel = "Imported File",
            formatLabel = ext.uppercase(),
            customAssetPath = savedFile.absolutePath,
            vertexCount = parsedMesh.vertexCount,
            thumbnailKey = "mall"
        )
        return ImportResult.Success(entry, parsedMesh)
    }

    fun loadCachedCustomMesh(path: String?): ImportedMeshData? {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.exists() || !file.canRead()) return null
        val bytes = runCatching { FileInputStream(file).use { it.readBytes() } }.getOrNull() ?: return null
        return when (file.extension.lowercase()) {
            "obj" -> parseObj(file.name, bytes.decodeToString())
            "glb" -> parseGlb(file.name, bytes)
            "gltf" -> parseGltfJson(file.name, bytes.decodeToString())
            "zip" -> parseZipPack(file.name, bytes)
            else -> null
        }
    }

    fun deleteCustomFile(path: String?) {
        if (!path.isNullOrBlank()) {
            runCatching { File(path).delete() }
        }
    }

    private fun parseZipPack(name: String, bytes: ByteArray): ImportedMeshData? {
        var foundObj: ImportedMeshData? = null
        var foundGlb: ImportedMeshData? = null
        runCatching {
            ZipInputStream(BufferedInputStream(bytes.inputStream())).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val lower = entry.name.lowercase()
                        if (lower.endsWith(".glb") && foundGlb == null) {
                            foundGlb = parseGlb(entry.name, zis.readBytes())
                        } else if (lower.endsWith(".obj") && foundObj == null) {
                            foundObj = parseObj(entry.name, zis.readBytes().decodeToString())
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        return foundGlb ?: foundObj
    }

    private fun parseGltfJson(name: String, text: String): ImportedMeshData? {
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return null
        if (!root.has("meshes") || !root.has("accessors")) return null
        // Check for embedded base64 data URI in buffer 0
        val buffers = root.optJSONArray("buffers") ?: return null
        if (buffers.length() == 0) return null
        val uri = buffers.getJSONObject(0).optString("uri")
        if (!uri.startsWith("data:")) return null
        val base64Part = uri.substringAfter("base64,", "")
        if (base64Part.isEmpty()) return null
        val bin = runCatching { android.util.Base64.decode(base64Part, android.util.Base64.DEFAULT) }.getOrNull()
            ?: return null
        return extractFirstGltfMesh(name, root, bin)
    }

    private fun parseGlb(name: String, bytes: ByteArray): ImportedMeshData? {
        if (bytes.size < 20) return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = bb.int
        if (magic != 0x46546C67) return null // "glTF"
        val version = bb.int
        if (version != 2) return null
        val totalLen = bb.int
        if (totalLen > bytes.size) return null

        var jsonText: String? = null
        var binChunk: ByteArray? = null
        while (bb.remaining() >= 8) {
            val chunkLen = bb.int
            val chunkType = bb.int
            if (chunkLen < 0 || chunkLen > bb.remaining()) break
            val chunkBytes = ByteArray(chunkLen)
            bb.get(chunkBytes)
            when (chunkType) {
                0x4E4F534A -> jsonText = chunkBytes.decodeToString() // JSON
                0x004E4942 -> binChunk = chunkBytes // BIN
            }
        }
        if (jsonText == null || binChunk == null) return null
        val root = runCatching { JSONObject(jsonText) }.getOrNull() ?: return null
        return extractFirstGltfMesh(name, root, binChunk)
    }

    private fun extractFirstGltfMesh(name: String, root: JSONObject, bin: ByteArray): ImportedMeshData? {
        val meshes = root.optJSONArray("meshes") ?: return null
        val accessors = root.optJSONArray("accessors") ?: return null
        val bufferViews = root.optJSONArray("bufferViews") ?: return null
        if (meshes.length() == 0) return null

        val posOut = ArrayList<Float>(1024)
        val normOut = ArrayList<Float>(1024)

        for (m in 0 until min(meshes.length(), 16)) {
            val prims = meshes.getJSONObject(m).optJSONArray("primitives") ?: continue
            for (p in 0 until prims.length()) {
                val prim = prims.getJSONObject(p)
                val attrs = prim.optJSONObject("attributes") ?: continue
                val posAccIdx = attrs.optInt("POSITION", -1)
                if (posAccIdx < 0) continue

                val rawPositions = readVec3Accessor(accessors, bufferViews, bin, posAccIdx) ?: continue
                val indices = if (prim.has("indices")) {
                    readIndicesAccessor(accessors, bufferViews, bin, prim.getInt("indices"))
                } else {
                    IntArray(rawPositions.size / 3) { it }
                }

                var i = 0
                while (i + 2 < indices.size && (posOut.size / 3) < MAX_VERTICES) {
                    val i0 = indices[i] * 3
                    val i1 = indices[i + 1] * 3
                    val i2 = indices[i + 2] * 3
                    if (i0 + 2 < rawPositions.size && i1 + 2 < rawPositions.size && i2 + 2 < rawPositions.size) {
                        val ax = rawPositions[i0]; val ay = rawPositions[i0 + 1]; val az = rawPositions[i0 + 2]
                        val bx = rawPositions[i1]; val by = rawPositions[i1 + 1]; val bz = rawPositions[i1 + 2]
                        val cx = rawPositions[i2]; val cy = rawPositions[i2 + 1]; val cz = rawPositions[i2 + 2]
                        val ux = bx - ax; val uy = by - ay; val uz = bz - az
                        val vx = cx - ax; val vy = cy - ay; val vz = cz - az
                        var nx = uy * vz - uz * vy
                        var ny = uz * vx - ux * vz
                        var nz = ux * vy - uy * vx
                        val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-5f)
                        nx /= len; ny /= len; nz /= len
                        posOut.add(ax); posOut.add(ay); posOut.add(az)
                        posOut.add(bx); posOut.add(by); posOut.add(bz)
                        posOut.add(cx); posOut.add(cy); posOut.add(cz)
                        repeat(3) { normOut.add(nx); normOut.add(ny); normOut.add(nz) }
                    }
                    i += 3
                }
            }
        }

        if (posOut.isEmpty()) return null
        return buildNormalizedMesh(name, posOut.toFloatArray(), normOut.toFloatArray())
    }

    private fun readVec3Accessor(
        accessors: org.json.JSONArray,
        bufferViews: org.json.JSONArray,
        bin: ByteArray,
        accIdx: Int
    ): FloatArray? {
        val acc = accessors.getJSONObject(accIdx)
        val viewIdx = acc.optInt("bufferView", -1)
        if (viewIdx < 0) return null
        val view = bufferViews.getJSONObject(viewIdx)
        val count = acc.getInt("count")
        val byteOffset = view.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val stride = view.optInt("byteStride", 12).coerceAtLeast(12)
        if (byteOffset + count * stride > bin.size) return null
        val bb = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
        val out = FloatArray(count * 3)
        for (i in 0 until count) {
            val base = byteOffset + i * stride
            out[i * 3] = bb.getFloat(base)
            out[i * 3 + 1] = bb.getFloat(base + 4)
            out[i * 3 + 2] = bb.getFloat(base + 8)
        }
        return out
    }

    private fun readIndicesAccessor(
        accessors: org.json.JSONArray,
        bufferViews: org.json.JSONArray,
        bin: ByteArray,
        accIdx: Int
    ): IntArray {
        val acc = accessors.getJSONObject(accIdx)
        val viewIdx = acc.optInt("bufferView", -1)
        if (viewIdx < 0) return IntArray(0)
        val view = bufferViews.getJSONObject(viewIdx)
        val count = acc.getInt("count")
        val compType = acc.getInt("componentType")
        val byteOffset = view.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val bb = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
        val out = IntArray(count)
        when (compType) {
            5121 -> for (i in 0 until count) if (byteOffset + i < bin.size) out[i] = bin[byteOffset + i].toInt() and 0xFF
            5123 -> for (i in 0 until count) if (byteOffset + i * 2 + 1 < bin.size) out[i] = bb.getShort(byteOffset + i * 2).toInt() and 0xFFFF
            5125 -> for (i in 0 until count) if (byteOffset + i * 4 + 3 < bin.size) out[i] = bb.getInt(byteOffset + i * 4)
        }
        return out
    }

    private fun parseObj(name: String, text: String): ImportedMeshData? {
        val verts = ArrayList<Float>(1024)
        val posOut = ArrayList<Float>(2048)
        val normOut = ArrayList<Float>(2048)

        text.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            if (line.startsWith("v ")) {
                val parts = line.split(Regex("\\s+"))
                if (parts.size >= 4) {
                    val x = parts[1].toFloatOrNull() ?: 0f
                    val y = parts[2].toFloatOrNull() ?: 0f
                    val z = parts[3].toFloatOrNull() ?: 0f
                    verts.add(x); verts.add(y); verts.add(z)
                }
            } else if (line.startsWith("f ") && (posOut.size / 3) < MAX_VERTICES) {
                val parts = line.split(Regex("\\s+")).drop(1)
                if (parts.size >= 3) {
                    val idxList = parts.mapNotNull { token ->
                        val rawIdx = token.substringBefore('/').toIntOrNull() ?: return@mapNotNull null
                        val total = verts.size / 3
                        val resolved = if (rawIdx < 0) total + rawIdx else rawIdx - 1
                        if (resolved in 0 until total) resolved else null
                    }
                    for (k in 1 until idxList.size - 1) {
                        val a = idxList[0] * 3
                        val b = idxList[k] * 3
                        val c = idxList[k + 1] * 3
                        val ax = verts[a]; val ay = verts[a + 1]; val az = verts[a + 2]
                        val bx = verts[b]; val by = verts[b + 1]; val bz = verts[b + 2]
                        val cx = verts[c]; val cy = verts[c + 1]; val cz = verts[c + 2]
                        val ux = bx - ax; val uy = by - ay; val uz = bz - az
                        val vx = cx - ax; val vy = cy - ay; val vz = cz - az
                        var nx = uy * vz - uz * vy
                        var ny = uz * vx - ux * vz
                        var nz = ux * vy - uy * vx
                        val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-5f)
                        nx /= len; ny /= len; nz /= len
                        posOut.add(ax); posOut.add(ay); posOut.add(az)
                        posOut.add(bx); posOut.add(by); posOut.add(bz)
                        posOut.add(cx); posOut.add(cy); posOut.add(cz)
                        repeat(3) { normOut.add(nx); normOut.add(ny); normOut.add(nz) }
                    }
                }
            }
        }
        if (posOut.isEmpty()) return null
        return buildNormalizedMesh(name, posOut.toFloatArray(), normOut.toFloatArray())
    }

    private fun buildNormalizedMesh(name: String, pos: FloatArray, norm: FloatArray): ImportedMeshData {
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
        var i = 0
        while (i + 2 < pos.size) {
            minX = min(minX, pos[i]); maxX = max(maxX, pos[i])
            minY = min(minY, pos[i + 1]); maxY = max(maxY, pos[i + 1])
            minZ = min(minZ, pos[i + 2]); maxZ = max(maxZ, pos[i + 2])
            i += 3
        }
        val span = max(maxX - minX, max(maxY - minY, maxZ - minZ)).coerceAtLeast(0.001f)
        val scale = 2.6f / span
        val cx = (minX + maxX) * 0.5f
        val cz = (minZ + maxZ) * 0.5f
        i = 0
        while (i + 2 < pos.size) {
            pos[i] = (pos[i] - cx) * scale
            pos[i + 1] = (pos[i + 1] - minY) * scale
            pos[i + 2] = (pos[i + 2] - cz) * scale
            i += 3
        }
        return ImportedMeshData(
            name = name,
            positions = pos,
            normals = norm,
            vertexCount = pos.size / 3,
            boundsMin = floatArrayOf((minX - cx) * scale, 0f, (minZ - cz) * scale),
            boundsMax = floatArrayOf((maxX - cx) * scale, (maxY - minY) * scale, (maxZ - cz) * scale)
        )
    }
}
