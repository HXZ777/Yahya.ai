package com.example.vr.world

import com.example.vr.engine.Aabb
import com.example.vr.model.ItemContainer
import com.example.vr.model.NpcEntity
import com.example.vr.model.NpcRole
import com.example.vr.model.ProductCategory
import com.example.vr.model.ProductItem
import com.example.vr.model.ProductMeshShape
import com.example.vr.model.WorldType

enum class BlockMeshKind {
    CUBE,
    CYLINDER,
    SPHERE
}

enum class BlockMaterialTag {
    STANDARD,
    FLOOR_TILE,
    FLOOR_ASPHALT,
    GLASS,
    EMISSIVE,
    WOOD,
    METAL
}

data class StaticBlock(
    val x: Float,
    val y: Float,
    val z: Float,
    val sx: Float,
    val sy: Float,
    val sz: Float,
    val colorArgb: Long,
    val kind: BlockMeshKind = BlockMeshKind.CUBE,
    val tag: BlockMaterialTag = BlockMaterialTag.STANDARD,
    val alpha: Float = 1f,
    val castsShadow: Boolean = false
)

data class WorldStations(
    val doorCenterX: Float = 0f,
    val doorZ: Float = 12.0f,
    val cartBay: Aabb = Aabb(-5.2f, 0f, 8.6f, -3.2f, 1.4f, 10.6f),
    val basketBay: Aabb = Aabb(3.2f, 0f, 8.8f, 4.9f, 1.2f, 10.4f),
    val checkoutBelt: Aabb = Aabb(4.8f, 0.7f, 6.2f, 7.6f, 1.35f, 8.8f),
    val scannerZone: Aabb = Aabb(5.6f, 0.8f, 6.6f, 6.8f, 1.55f, 7.8f),
    val posTerminal: Aabb = Aabb(7.1f, 0.8f, 5.8f, 8.3f, 1.65f, 7.0f),
    val baggingZone: Aabb = Aabb(7.2f, 0.7f, 7.4f, 8.6f, 1.45f, 8.8f)
)

data class WorldSceneData(
    val worldType: WorldType,
    val blocks: List<StaticBlock>,
    val solidColliders: List<Aabb>,
    val products: MutableList<ProductItem>,
    val npcs: MutableList<NpcEntity>,
    val stations: WorldStations,
    val spawnX: Float,
    val spawnZ: Float,
    val spawnYawDeg: Float
)

object SupermarketWorldBuilder {

    fun buildWorld(type: WorldType): WorldSceneData {
        val blocks = ArrayList<StaticBlock>(280)
        val colliders = ArrayList<Aabb>(90)
        val products = ArrayList<ProductItem>(40)
        val npcs = ArrayList<NpcEntity>(10)

        fun addSolidBox(
            x: Float, y: Float, z: Float,
            sx: Float, sy: Float, sz: Float,
            color: Long,
            tag: BlockMaterialTag = BlockMaterialTag.STANDARD,
            alpha: Float = 1f,
            collide: Boolean = true,
            shadow: Boolean = false
        ) {
            blocks.add(StaticBlock(x, y, z, sx, sy, sz, color, BlockMeshKind.CUBE, tag, alpha, shadow))
            if (collide) {
                colliders.add(
                    Aabb(
                        x - sx * 0.5f, y - sy * 0.5f, z - sz * 0.5f,
                        x + sx * 0.5f, y + sy * 0.5f, z + sz * 0.5f
                    )
                )
            }
        }

        // Theme palette overrides per world type so each of the 10 worlds feels distinct
        val wallColor: Long
        val floorColor: Long
        val accentSignColor: Long
        when (type) {
            WorldType.MINI_MARKET -> {
                wallColor = 0xFFE8EEF5; floorColor = 0xFFD9E2EC; accentSignColor = 0xFF10B981
            }
            WorldType.SHOPPING_MALL -> {
                wallColor = 0xFFF3EFEA; floorColor = 0xFFEAE2D6; accentSignColor = 0xFF38BDF8
            }
            WorldType.ELECTRONICS_STORE -> {
                wallColor = 0xFF1E293B; floorColor = 0xFF0F172A; accentSignColor = 0xFF00E5FF
            }
            WorldType.FAST_FOOD_DINER -> {
                wallColor = 0xFFFEF3C7; floorColor = 0xFFE5D3B3; accentSignColor = 0xFFEF4444
            }
            WorldType.GAS_STATION_MART -> {
                wallColor = 0xFFE2E8F0; floorColor = 0xFFCBD5E1; accentSignColor = 0xFFF59E0B
            }
            WorldType.CLOTHING_STORE -> {
                wallColor = 0xFFFAF5FF; floorColor = 0xFFE9E2D8; accentSignColor = 0xFFA855F7
            }
            WorldType.CARGO_WAREHOUSE -> {
                wallColor = 0xFF475569; floorColor = 0xFF64748B; accentSignColor = 0xFFF97316
            }
            WorldType.TOY_STORE -> {
                wallColor = 0xFFFDF2F8; floorColor = 0xFFE0F2FE; accentSignColor = 0xFFEC4899
            }
            WorldType.SMALL_TOWN -> {
                wallColor = 0xFFF1F5F9; floorColor = 0xFFCBD5E1; accentSignColor = 0xFF22D3EE
            }
            else -> {
                wallColor = 0xFFF1F5F9; floorColor = 0xFFE2E8F0; accentSignColor = 0xFF0EA5E9
            }
        }

        // 1. Interior Tiled Floor & Ceiling
        blocks.add(StaticBlock(0f, -0.05f, -1f, 27f, 0.1f, 26f, floorColor, BlockMeshKind.CUBE, BlockMaterialTag.FLOOR_TILE))
        val ceilingHeight = if (type == WorldType.SHOPPING_MALL || type == WorldType.CARGO_WAREHOUSE) 6.0f else 4.6f
        blocks.add(StaticBlock(0f, ceilingHeight, -1f, 27f, 0.2f, 26f, 0xFFCBD5E1))
        // Ceiling light strips
        for (lx in listOf(-8f, -2.5f, 3f, 8.5f)) {
            for (lz in listOf(-7f, 0f, 7f)) {
                blocks.add(StaticBlock(lx, ceilingHeight - 0.14f, lz, 0.45f, 0.08f, 3.8f, 0xFFFFFFFF, tag = BlockMaterialTag.EMISSIVE))
            }
        }

        // 2. Exterior Ground: Sidewalk, Parking Lot, Street & Surrounding City Buildings
        blocks.add(StaticBlock(0f, -0.04f, 13.5f, 36f, 0.08f, 3.2f, 0xFF94A3B8)) // Sidewalk
        blocks.add(StaticBlock(0f, -0.06f, 23f, 56f, 0.08f, 20f, 0xFF334155, tag = BlockMaterialTag.FLOOR_ASPHALT)) // Parking & Street
        // White parking bay stripes
        for (px in listOf(-12f, -8f, -4f, 4f, 8f, 12f)) {
            blocks.add(StaticBlock(px, 0.0f, 18.2f, 0.14f, 0.02f, 4.2f, 0xFFF8FAFC))
        }
        // Road yellow dashed center line
        for (rx in -24..24 step 4) {
            blocks.add(StaticBlock(rx.toFloat(), 0.0f, 25.5f, 2.0f, 0.02f, 0.2f, 0xFFFACC15))
        }
        // Parked 3D Cars outside
        addParkedCar(blocks, colliders, -10f, 18.2f, 0xFF3B82F6)
        addParkedCar(blocks, colliders, 6f, 18.2f, 0xFFEF4444)
        addParkedCar(blocks, colliders, 10f, 18.2f, 0xFF10B981)

        // Street Lamps & Trees
        for (tx in listOf(-15.5f, -6.5f, 6.5f, 15.5f)) {
            // Tree trunk + canopy
            blocks.add(StaticBlock(tx, 1.1f, 14.3f, 0.35f, 2.2f, 0.35f, 0xFF78350F, BlockMeshKind.CYLINDER, BlockMaterialTag.WOOD, castsShadow = true))
            blocks.add(StaticBlock(tx, 2.7f, 14.3f, 2.0f, 2.0f, 2.0f, 0xFF15803D, BlockMeshKind.SPHERE, castsShadow = true))
            // Street lamp
            blocks.add(StaticBlock(tx + 1.4f, 2.2f, 15.0f, 0.14f, 4.4f, 0.14f, 0xFF475569, BlockMeshKind.CYLINDER, BlockMaterialTag.METAL))
            blocks.add(StaticBlock(tx + 1.4f, 4.45f, 15.0f, 0.55f, 0.18f, 0.35f, 0xFFFEF08A, tag = BlockMaterialTag.EMISSIVE))
        }

        // Surrounding City Buildings across the street (explorable exterior skyline)
        addSolidBox(-18f, 4.5f, 34f, 12f, 9f, 8f, 0xFF475569, shadow = true)
        addSolidBox(-4f, 6.0f, 35f, 11f, 12f, 8f, 0xFF64748B, shadow = true)
        addSolidBox(12f, 5.0f, 34f, 13f, 10f, 8f, 0xFF334155, shadow = true)
        // Gas canopy extra landmark if GAS_STATION_MART or SMALL_TOWN
        if (type == WorldType.GAS_STATION_MART || type == WorldType.SMALL_TOWN) {
            addSolidBox(0f, 3.6f, 20.5f, 9.5f, 0.45f, 5.5f, accentSignColor, collide = false)
            addSolidBox(-3.8f, 1.8f, 20.5f, 0.4f, 3.6f, 0.4f, 0xFFE2E8F0)
            addSolidBox(3.8f, 1.8f, 20.5f, 0.4f, 3.6f, 0.4f, 0xFFE2E8F0)
            addSolidBox(-1.6f, 0.9f, 20.5f, 0.7f, 1.8f, 0.6f, 0xFFEF4444)
            addSolidBox(1.6f, 0.9f, 20.5f, 0.7f, 1.8f, 0.6f, 0xFF0EA5E9)
        }

        // Exterior boundary invisible/curb walls so player stays in playable neighborhood [-24..24, -14.5..30]
        colliders.add(Aabb(-25f, 0f, -15f, -24f, 4f, 31f))
        colliders.add(Aabb(24f, 0f, -15f, 25f, 4f, 31f))
        colliders.add(Aabb(-25f, 0f, 30f, 25f, 4f, 31f))

        // 3. Store Perimeter Walls
        // Left & Right outer walls
        addSolidBox(-13.5f, ceilingHeight * 0.5f, -1f, 0.35f, ceilingHeight, 26f, wallColor)
        addSolidBox(13.5f, ceilingHeight * 0.5f, -1f, 0.35f, ceilingHeight, 26f, wallColor)
        // Back outer wall (behind warehouse & office)
        addSolidBox(0f, ceilingHeight * 0.5f, -14f, 27f, ceilingHeight, 0.35f, wallColor)

        // Front Glass Facade (with 5.2m wide Automatic Entrance Door gap at X in [-2.6, 2.6], Z = 12.0)
        addSolidBox(-8.1f, ceilingHeight * 0.5f, 12f, 10.8f, ceilingHeight, 0.25f, 0xFFBAE6FD, BlockMaterialTag.GLASS, alpha = 0.45f)
        addSolidBox(8.1f, ceilingHeight * 0.5f, 12f, 10.8f, ceilingHeight, 0.25f, 0xFFBAE6FD, BlockMaterialTag.GLASS, alpha = 0.45f)
        // Overhead fascia & glowing Supermarket Sign above doors
        addSolidBox(0f, ceilingHeight - 0.6f, 12f, 5.4f, 1.2f, 0.35f, 0xFF0F172A, collide = false)
        blocks.add(StaticBlock(0f, ceilingHeight - 0.55f, 12.22f, 4.6f, 0.65f, 0.08f, accentSignColor, tag = BlockMaterialTag.EMISSIVE))

        // 4. Back Warehouse & Staff Office Partition (Z = -11.2)
        // Left partition leaving archway X in [-8.2, -5.8]
        addSolidBox(-10.8f, ceilingHeight * 0.5f, -11.2f, 5.2f, ceilingHeight, 0.28f, 0xFFCBD5E1)
        addSolidBox(-0.6f, ceilingHeight * 0.5f, -11.2f, 10.4f, ceilingHeight, 0.28f, 0xFFCBD5E1)
        // Staff Office glass partition (X in [4.6, 13.4], Z = -11.2 with doorway X in [4.8, 6.2])
        addSolidBox(9.8f, ceilingHeight * 0.5f, -11.2f, 7.2f, ceilingHeight, 0.25f, 0xFF93C5FD, BlockMaterialTag.GLASS, alpha = 0.45f)
        addSolidBox(4.5f, ceilingHeight * 0.5f, -12.6f, 0.25f, ceilingHeight, 2.8f, 0xFFCBD5E1)
        // Office desk & monitor
        addSolidBox(9.2f, 0.42f, -12.8f, 2.2f, 0.84f, 1.0f, 0xFF78350F, BlockMaterialTag.WOOD, shadow = true)
        addSolidBox(9.2f, 1.15f, -13.0f, 0.75f, 0.48f, 0.08f, 0xFF0EA5E9, BlockMaterialTag.EMISSIVE)
        // Backroom warehouse pallet shelves & cargo boxes
        addSolidBox(-11.2f, 1.3f, -13.0f, 2.8f, 2.6f, 1.1f, 0xFF94A3B8, BlockMaterialTag.METAL, shadow = true)
        addSolidBox(-3.5f, 1.3f, -13.0f, 3.2f, 2.6f, 1.1f, 0xFF94A3B8, BlockMaterialTag.METAL, shadow = true)
        addSolidBox(-1.2f, 0.45f, -12.6f, 0.9f, 0.9f, 0.9f, 0xFFD97706, BlockMaterialTag.WOOD, shadow = true)

        // 5. Dairy & Cold Beverage Refrigerators along Z = -10.5 (Back interior wall)
        for (fx in listOf(-4.5f, -1.5f, 1.5f, 4.5f)) {
            addSolidBox(fx, 1.35f, -10.5f, 2.4f, 2.7f, 0.95f, 0xFF1E293B, BlockMaterialTag.METAL, shadow = true)
            // Illuminated interior back panel + translucent glass doors
            blocks.add(StaticBlock(fx, 1.45f, -10.12f, 2.15f, 2.1f, 0.05f, 0xFFE0F2FE, tag = BlockMaterialTag.EMISSIVE))
            blocks.add(StaticBlock(fx, 1.45f, -9.98f, 2.2f, 2.2f, 0.06f, 0xFFBAE6FD, tag = BlockMaterialTag.GLASS, alpha = 0.35f))
        }

        // 6. Produce Wooden Crates (Front-Left X = -9.6, Z in [2.5, 6.5])
        addSolidBox(-9.6f, 0.45f, 4.5f, 2.4f, 0.9f, 4.6f, 0xFF92400E, BlockMaterialTag.WOOD, shadow = true)

        // 7. Bakery Counter (Mid-Left X = -11.4, Z = -1.5)
        addSolidBox(-11.4f, 0.52f, -1.5f, 1.6f, 1.04f, 4.4f, 0xFFB45309, BlockMaterialTag.WOOD, shadow = true)
        blocks.add(StaticBlock(-11.0f, 1.35f, -1.5f, 1.0f, 0.65f, 4.1f, 0xFFBAE6FD, tag = BlockMaterialTag.GLASS, alpha = 0.32f))

        // 8. Meat & Poultry Chiller (Back-Left X = -11.4, Z = -7.2)
        addSolidBox(-11.4f, 0.52f, -7.2f, 1.6f, 1.04f, 4.0f, 0xFFE2E8F0, shadow = true)
        blocks.add(StaticBlock(-10.8f, 1.25f, -7.2f, 0.8f, 0.45f, 3.8f, 0xFFFCA5A5, tag = BlockMaterialTag.GLASS, alpha = 0.38f))

        // 9. Center Gondola Aisles (Pantry & Sweets)
        // Aisle Rack 1 (X = -4.2) & Aisle Rack 2 (X = 1.6)
        for (rx in listOf(-4.2f, 1.6f)) {
            addSolidBox(rx, 1.05f, -2.5f, 1.25f, 2.1f, 7.2f, 0xFF334155, BlockMaterialTag.METAL, shadow = true)
            // Shelf planks
            for (sy in listOf(0.55f, 1.15f, 1.75f)) {
                blocks.add(StaticBlock(rx, sy, -2.5f, 1.38f, 0.06f, 7.25f, 0xFFE2E8F0))
            }
            // Overhead aisle marker sign
            blocks.add(StaticBlock(rx, 2.45f, -2.5f, 0.9f, 0.35f, 0.12f, accentSignColor, tag = BlockMaterialTag.EMISSIVE))
        }

        // Sweets & Chocolate Display Island (X = -1.3, Z = 4.2)
        addSolidBox(-1.3f, 0.55f, 4.2f, 2.2f, 1.1f, 2.2f, 0xFFEC4899, shadow = true)

        // 10. Electronics & Home Appliances Showcase (Right Wall X = 11.4, Z in [-4.5, 4.0])
        addSolidBox(11.4f, 0.55f, -0.5f, 1.7f, 1.1f, 8.2f, 0xFF1E293B, BlockMaterialTag.METAL, shadow = true)
        blocks.add(StaticBlock(11.4f, 1.13f, -0.5f, 1.75f, 0.06f, 8.25f, 0xFF00E5FF, tag = BlockMaterialTag.EMISSIVE))

        // 11. Cart & Basket Bays (Inside Entrance)
        addSolidBox(-4.2f, 0.45f, 9.6f, 1.8f, 0.9f, 1.6f, 0xFF94A3B8, BlockMaterialTag.METAL, shadow = true)
        addSolidBox(4.0f, 0.35f, 9.6f, 1.3f, 0.7f, 1.2f, 0xFF0EA5E9, shadow = true)

        // 12. Traditional & Self-Checkout Counters
        // Main Interactive Checkout Belt (X = 6.2, Z = 7.5)
        addSolidBox(6.2f, 0.45f, 7.5f, 2.8f, 0.9f, 1.4f, 0xFF1E293B, BlockMaterialTag.METAL, shadow = true)
        blocks.add(StaticBlock(5.8f, 0.92f, 7.5f, 1.9f, 0.05f, 0.9f, 0xFF0F172A)) // Conveyor rubber belt
        // Laser Scanner Arch + Red Scanner Beam
        blocks.add(StaticBlock(6.2f, 1.25f, 7.5f, 0.25f, 0.65f, 1.05f, 0xFF334155))
        blocks.add(StaticBlock(6.2f, 1.18f, 7.5f, 0.08f, 0.35f, 0.85f, 0xFFEF4444, tag = BlockMaterialTag.EMISSIVE))
        // POS Card Terminal
        blocks.add(StaticBlock(7.5f, 1.12f, 6.7f, 0.35f, 0.42f, 0.35f, 0xFF0EA5E9, tag = BlockMaterialTag.EMISSIVE))
        // Bagging counter
        addSolidBox(8.2f, 0.45f, 7.8f, 1.1f, 0.9f, 1.2f, 0xFF475569, shadow = true)

        // Secondary Self-Checkout Kiosk (X = 9.8, Z = 7.5)
        addSolidBox(9.8f, 0.65f, 7.5f, 1.1f, 1.3f, 1.1f, 0xFF334155, shadow = true)
        blocks.add(StaticBlock(9.8f, 1.35f, 7.5f, 0.5f, 0.55f, 0.12f, 0xFF38BDF8, tag = BlockMaterialTag.EMISSIVE))

        // 13. Populate Interactive 3D Products across all 7 departments
        fun addProduct(
            id: String, nameEn: String, nameAr: String, cat: ProductCategory,
            price: Float, discount: Int, barcode: String, grams: Int,
            ingEn: String, ingAr: String, shape: ProductMeshShape,
            c1: Long, c2: Long, x: Float, y: Float, z: Float,
            aisleEn: String, aisleAr: String
        ) {
            products.add(
                ProductItem(
                    id = id, nameEn = nameEn, nameAr = nameAr, category = cat,
                    price = price, discountPercent = discount, barcode = barcode, weightGrams = grams,
                    ingredientsEn = ingEn, ingredientsAr = ingAr, meshShape = shape,
                    primaryColorArgb = c1, accentColorArgb = c2, x = x, y = y, z = z,
                    aisleLabelEn = aisleEn, aisleLabelAr = aisleAr
                )
            )
        }

        // Produce (on table y=1.08)
        addProduct("p_apple", "Red Apples (1kg)", "تفاح أحمر (1 كغ)", ProductCategory.PRODUCE, 3.49f, 15, "629104150001", 1000, "100% Fresh Organic Apples, Vitamin C", "تفاح عضوي طازج 100%، غني بفيتامين C", ProductMeshShape.SPHERE_FRUIT, 0xFFDC2626, 0xFF16A34A, -9.3f, 1.08f, 3.2f, "Produce Front-Left", "قسم الخضار والفواكه (أمام يسار)")
        addProduct("p_orange", "Valencia Oranges", "برتقال فالنسيا", ProductCategory.PRODUCE, 2.99f, 0, "629104150002", 1000, "Fresh Citrus Oranges, Natural Fiber", "برتقال طازج غني بالألياف وفيتامين C", ProductMeshShape.SPHERE_FRUIT, 0xFFF97316, 0xFF15803D, -9.8f, 1.08f, 4.4f, "Produce Front-Left", "قسم الخضار والفواكه (أمام يسار)")
        addProduct("p_banana", "Yellow Bananas", "موز طازج", ProductCategory.PRODUCE, 2.25f, 10, "629104150003", 850, "Sweet Bananas, Rich in Potassium", "موز حلو طازج، مصدر ممتاز للبوتاسيوم", ProductMeshShape.LOAF, 0xFFFACC15, 0xFF713F12, -9.3f, 1.06f, 5.6f, "Produce Front-Left", "قسم الخضار والفواكه (أمام يسار)")
        addProduct("p_avocado", "Hass Avocados", "أفوكادو هاس", ProductCategory.PRODUCE, 4.50f, 0, "629104150004", 500, "Creamy Avocados, Healthy Fats", "أفوكادو كريمي غني بالدهون الصحية", ProductMeshShape.SPHERE_FRUIT, 0xFF166534, 0xFF84CC16, -10.1f, 1.08f, 5.8f, "Produce Front-Left", "قسم الخضار والفواكه (أمام يسار)")

        // Dairy & Drinks (in coolers Z=-9.8, y=0.95 / 1.55)
        addProduct("p_milk", "Fresh Whole Milk", "حليب طازج كامل الدسم", ProductCategory.DAIRY_DRINKS, 2.80f, 0, "629104150011", 1000, "Pasteurized Cow Milk, Vitamin D3", "حليب بقري مبستر، مدعم بفيتامين D3", ProductMeshShape.BOTTLE, 0xFFF8FAFC, 0xFF2563EB, -4.8f, 1.15f, -9.8f, "Coolers Back Wall", "ثلاجات المشروبات (الجدار الخلفي)")
        addProduct("p_oj", "100% Orange Juice", "عصير برتقال طبيعي", ProductCategory.DAIRY_DRINKS, 3.90f, 20, "629104150012", 1000, "Cold-Pressed Oranges, No Added Sugar", "عصير برتقال معصور على البارد بدون سكر مضاف", ProductMeshShape.BOTTLE, 0xFFFB923C, 0xFFEA580C, -1.8f, 1.15f, -9.8f, "Coolers Back Wall", "ثلاجات المشروبات (الجدار الخلفي)")
        addProduct("p_water", "Sparkling Mineral Water", "مياه معدنية فوارة", ProductCategory.DAIRY_DRINKS, 1.50f, 0, "629104150013", 750, "Natural Carbonated Spring Water", "مياه ينابيع طبيعية فوارة", ProductMeshShape.BOTTLE, 0xFF38BDF8, 0xFFE0F2FE, 1.3f, 1.15f, -9.8f, "Coolers Back Wall", "ثلاجات المشروبات (الجدار الخلفي)")
        addProduct("p_cola", "Classic Cola Can", "مشروب غازي كولا", ProductCategory.DAIRY_DRINKS, 1.25f, 0, "629104150014", 330, "Carbonated Water, Caramel Color, Caffeine", "مياه غازية، نكهة طبيعية، كافيين", ProductMeshShape.CAN, 0xFFDC2626, 0xFFF8FAFC, 4.3f, 1.15f, -9.8f, "Coolers Back Wall", "ثلاجات المشروبات (الجدار الخلفي)")

        // Meat & Poultry (X=-10.8, Z=-7.2, y=1.18)
        addProduct("p_chicken", "Chicken Breast Fillet", "صدور دجاج طازجة", ProductCategory.MEAT_POULTRY, 7.50f, 10, "629104150021", 700, "100% Halal Fresh Chicken Breast, High Protein", "صدور دجاج حلال طازجة، بروتين عالي", ProductMeshShape.BOX, 0xFFFECACA, 0xFFEF4444, -10.9f, 1.18f, -6.4f, "Meat Counter Back-Left", "قسم اللحوم والدواجن (خلف يسار)")
        addProduct("p_steak", "Prime Beef Steak", "شرائح لحم بقري", ProductCategory.MEAT_POULTRY, 14.90f, 0, "629104150022", 500, "Grass-Fed Prime Beef Sirloin", "لحم بقري فاخر طازج", ProductMeshShape.BOX, 0xFF991B1B, 0xFFFCA5A5, -10.9f, 1.18f, -8.0f, "Meat Counter Back-Left", "قسم اللحوم والدواجن (خلف يسار)")

        // Bakery (X=-10.9, Z=-1.5, y=1.18)
        addProduct("p_bread", "Artisan Sourdough Loaf", "خبز مخبوز طازج", ProductCategory.BAKERY, 3.20f, 0, "629104150031", 550, "Stone-Ground Wheat Flour, Sea Salt, Yeast", "دقيق قمح طبيعي، ملح بحري، خميرة", ProductMeshShape.LOAF, 0xFFD97706, 0xFFFEF3C7, -10.9f, 1.18f, -0.5f, "Bakery Mid-Left", "قسم المخبوزات (وسط يسار)")
        addProduct("p_croissant", "Butter Croissants (4pc)", "كرواسون بالزبدة (4 قطع)", ProductCategory.BAKERY, 4.10f, 25, "629104150032", 320, "French Butter, Wheat Flour, Milk", "زبدة فرنسية طبيعية، دقيق قمح، حليب", ProductMeshShape.LOAF, 0xFFF59E0B, 0xFF78350F, -10.9f, 1.18f, -2.5f, "Bakery Mid-Left", "قسم المخبوزات (وسط يسار)")

        // Pantry & Grocery on Aisle 1 (X=-4.2)
        addProduct("p_olive_oil", "Extra Virgin Olive Oil", "زيت زيتون بكر ممتاز", ProductCategory.GROCERY_PANTRY, 9.80f, 10, "629104150041", 750, "100% Cold-Pressed Mediterranean Olives", "زيتون معصور على البارد 100%", ProductMeshShape.BOTTLE, 0xFF65A30D, 0xFFFEF08A, -3.55f, 1.35f, -4.6f, "Aisle 1 Left", "الممر الأول (يسار)")
        addProduct("p_rice", "Basmati Jasmine Rice", "أرز بسمتي فاخر", ProductCategory.GROCERY_PANTRY, 6.40f, 0, "629104150042", 2000, "Aged Long-Grain Aromatic Basmati Rice", "أرز بسمتي طويل الحبة فاخر", ProductMeshShape.BOX, 0xFFFEF9C3, 0xFF15803D, -3.55f, 0.75f, -2.5f, "Aisle 1 Left", "الممر الأول (يسار)")
        addProduct("p_coffee", "Arabica Espresso Beans", "قهوة إسبريسو عربية", ProductCategory.GROCERY_PANTRY, 11.20f, 15, "629104150043", 500, "100% Roasted Arabica Coffee Beans", "بن أرابيكا محمص 100%", ProductMeshShape.CAN, 0xFF451A03, 0xFFF59E0B, -4.85f, 1.35f, -1.0f, "Aisle 1 Left", "الممر الأول (يسار)")
        addProduct("p_pasta", "Italian Tomato Sauce", "صلصة طماطم إيطالية", ProductCategory.GROCERY_PANTRY, 3.10f, 0, "629104150044", 420, "Vine-Ripened Tomatoes, Fresh Basil, Garlic", "طماطم ناضجة، ريحان طازج، ثوم", ProductMeshShape.BOTTLE, 0xFFB91C1C, 0xFF22C55E, -4.85f, 1.35f, -4.2f, "Aisle 1 Left", "الممر الأول (يسار)")

        // Sweets & Chocolate (Island X=-1.3, Z=4.2 & Aisle 2 X=1.6)
        addProduct("p_choco", "Swiss Dark Chocolate 70%", "شوكولاتة داكنة سويسرية", ProductCategory.SWEETS_CHOCOLATE, 4.20f, 20, "629104150051", 150, "70% Cocoa Solids, Cane Sugar, Cocoa Butter", "كاكاو 70%، زبدة كاكاو طبيعية", ProductMeshShape.BAR, 0xFF451A03, 0xFFFBBF24, -1.7f, 1.22f, 3.8f, "Sweets Island Center", "جزيرة الحلويات والشوكولاتة")
        addProduct("p_cookies", "Salted Caramel Cookies", "بسكويت بالكراميل المملح", ProductCategory.SWEETS_CHOCOLATE, 3.60f, 0, "629104150052", 250, "Wheat Flour, Caramel Bits, Butter", "دقيق قمح، قطع كراميل، زبدة", ProductMeshShape.BOX, 0xFFD97706, 0xFFFEF3C7, -0.8f, 1.22f, 4.6f, "Sweets Island Center", "جزيرة الحلويات والشوكولاتة")
        addProduct("p_cereal", "Honey Crunch Cereal", "رقائق إفطار بالعسل", ProductCategory.SWEETS_CHOCOLATE, 4.90f, 0, "629104150053", 450, "Whole Grain Oats, Pure Wildflower Honey", "شوفان كامل الحبة، عسل طبيعي", ProductMeshShape.BOX, 0xFFFACC15, 0xFFEA580C, 0.95f, 1.35f, -2.5f, "Aisle 2 Center", "الممر الثاني (الوسط)")

        // Electronics & Home (Right Wall X=10.8)
        addProduct("p_headphones", "Wireless ANC Headphones", "سماعات لاسلكية عازلة للضوضاء", ProductCategory.ELECTRONICS_HOME, 49.00f, 20, "629104150061", 280, "Bluetooth 5.3, 40h Battery, Active Noise Canceling", "بلوتوث 5.3، بطارية 40 ساعة، عزل ضوضاء", ProductMeshShape.DEVICE, 0xFF0F172A, 0xFF00E5FF, 10.75f, 1.30f, -3.2f, "Electronics Right Wall", "قسم الإلكترونيات (يمين)")
        addProduct("p_kettle", "Smart Glass Kettle", "غلاية زجاجية ذكية", ProductCategory.ELECTRONICS_HOME, 29.50f, 10, "629104150062", 1100, "1800W Fast Boil, Borosilicate Glass, Auto-Shutoff", "1800 واط، زجاج حراري، إيقاف تلقائي", ProductMeshShape.BOTTLE, 0xFF38BDF8, 0xFF1E293B, 10.75f, 1.30f, -0.5f, "Electronics Right Wall", "قسم الإلكترونيات (يمين)")
        addProduct("p_speaker", "Portable Bluetooth Speaker", "مكبر صوت بلوتوث محمول", ProductCategory.ELECTRONICS_HOME, 34.00f, 0, "629104150063", 520, "IPX7 Waterproof, Deep Bass, USB-C Fast Charge", "مقاوم للماء، صوت عميق، شحن سريع", ProductMeshShape.CAN, 0xFF334155, 0xFF10B981, 10.75f, 1.30f, 2.2f, "Electronics Right Wall", "قسم الإلكترونيات (يمين)")

        // 14. NPC Characters
        npcs.add(
            NpcEntity(
                id = "npc_cashier",
                role = NpcRole.CASHIER,
                nameEn = "Omar (Cashier)",
                nameAr = "عمر (الكاشير)",
                x = 6.2f, z = 5.6f, yawDeg = 0f, speed = 0f,
                targetX = 6.2f, targetZ = 5.6f,
                shirtColorArgb = 0xFF0EA5E9,
                dialogEn = "Welcome! Place your groceries on the conveyor belt to scan and pay by card or cash.",
                dialogAr = "أهلاً بك! ضع مشترياتك على السير أمامك للمسح الضوئي ثم اختر الدفع بالبطاقة أو النقد."
            )
        )
        npcs.add(
            NpcEntity(
                id = "npc_info",
                role = NpcRole.INFO_STAFF,
                nameEn = "Sara (Store Guide)",
                nameAr = "سارة (مرشدة المتجر)",
                x = 2.6f, z = 8.4f, yawDeg = 180f, speed = 0f,
                targetX = 2.6f, targetZ = 8.4f,
                shirtColorArgb = 0xFF10B981,
                dialogEn = "Need help? Produce & Bakery are left, Drinks at the back coolers, Electronics on the right!",
                dialogAr = "أهلاً! الخضار والمخبز على اليسار، الثلاجات في الخلف، والإلكترونيات على اليمين!"
            )
        )
        npcs.add(
            NpcEntity(
                id = "npc_clerk",
                role = NpcRole.STOCK_CLERK,
                nameEn = "Tariq (Stock Clerk)",
                nameAr = "طارق (موظف الترتيب)",
                x = -6.8f, z = -7.8f, yawDeg = 90f, speed = 0.85f,
                targetX = -6.8f, targetZ = -1.5f,
                shirtColorArgb = 0xFFF59E0B,
                dialogEn = "Just restocking the shelves and back warehouse pallets.",
                dialogAr = "أقوم بترتيب البضائع بين المستودع الخلفي والرفوف."
            )
        )
        npcs.add(
            NpcEntity(
                id = "npc_shopper_1",
                role = NpcRole.CART_SHOPPER,
                nameEn = "Shopper Lina",
                nameAr = "المتسوقة لينا",
                x = -1.3f, z = -4.5f, yawDeg = 0f, speed = 0.95f,
                targetX = -1.3f, targetZ = 1.5f,
                shirtColorArgb = 0xFFA855F7,
                hasCart = true,
                dialogEn = "The fresh croissants and dark chocolate are on sale today!",
                dialogAr = "توجد عروض رائعة اليوم على الكرواسون والشوكولاتة!"
            )
        )
        npcs.add(
            NpcEntity(
                id = "npc_shopper_2",
                role = NpcRole.SHOPPER,
                nameEn = "Shopper Karim",
                nameAr = "المتسوق كريم",
                x = 5.2f, z = -2.0f, yawDeg = 180f, speed = 0.9f,
                targetX = 5.2f, targetZ = -7.0f,
                shirtColorArgb = 0xFFEC4899,
                dialogEn = "Checking out the wireless headphones in the electronics aisle.",
                dialogAr = "أتفقد السماعات والأجهزة الذكية في قسم الإلكترونيات."
            )
        )

        return WorldSceneData(
            worldType = type,
            blocks = blocks,
            solidColliders = colliders,
            products = products,
            npcs = npcs,
            stations = WorldStations(),
            spawnX = 0f,
            spawnZ = 15.6f, // Start right outside the automatic glass doors so player sees exterior & enters!
            spawnYawDeg = 0f
        )
    }

    private fun addParkedCar(blocks: MutableList<StaticBlock>, colliders: MutableList<Aabb>, cx: Float, cz: Float, bodyColor: Long) {
        // Car body
        blocks.add(StaticBlock(cx, 0.52f, cz, 1.9f, 0.65f, 3.8f, bodyColor, castsShadow = true))
        // Cabin
        blocks.add(StaticBlock(cx, 1.05f, cz + 0.15f, 1.6f, 0.55f, 2.0f, 0xFFBAE6FD, tag = BlockMaterialTag.GLASS, alpha = 0.72f))
        // Wheels
        for (wx in listOf(-0.92f, 0.92f)) {
            for (wz in listOf(-1.2f, 1.2f)) {
                blocks.add(StaticBlock(cx + wx, 0.28f, cz + wz, 0.22f, 0.55f, 0.55f, 0xFF0F172A, BlockMeshKind.CYLINDER))
            }
        }
        colliders.add(Aabb(cx - 1.05f, 0f, cz - 2.0f, cx + 1.05f, 1.6f, cz + 2.0f))
    }
}
