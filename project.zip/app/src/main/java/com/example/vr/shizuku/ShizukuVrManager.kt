package com.example.vr.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import com.example.BuildConfig
import com.example.vr.bridge.HeadLookBridgeMath
import com.example.vr.capture.MinecraftIntegrationManager
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.ShizukuBridgeState
import com.example.vr.model.ShizukuStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * Coordinates Shizuku binder discovery, runtime permission flow, UserService lifecycle (UID 2000),
 * off-screen VirtualDisplay creation, Minecraft launch onto that isolated displayId,
 * PlayStation controller forwarding, and low-latency head-look touch injection.
 *
 * Strictly zero Root (`su`) usage—operates exclusively within Shizuku's official Shell permissions.
 */
class ShizukuVrManager(private val context: Context) {

    private data class PendingVirtualDisplayRequest(
        val surface: Surface,
        val width: Int,
        val height: Int,
        val dpi: Int,
        val packageName: String
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val binderExecutor = Executors.newSingleThreadExecutor()

    private val _state = MutableStateFlow(ShizukuBridgeState())
    val state: StateFlow<ShizukuBridgeState> = _state.asStateFlow()

    @Volatile
    private var userService: IShizukuVrService? = null

    @Volatile
    private var pendingRequest: PendingVirtualDisplayRequest? = null

    @Volatile
    private var activeTargetPackage: String = MinecraftIntegrationManager.MINECRAFT_BEDROCK_PACKAGE

    private var monitorJob: Job? = null
    private var listenersRegistered = false
    private var userServiceBindRequested = false

    // Head-look touch injection state (runs on binderExecutor)
    private var fingerDown = false
    private var fingerDownTimeMs = 0L
    private var fingerX: Float? = null
    private var fingerY: Float? = null
    private var lastHeadDispatchMs = 0L
    private var lastIdleResetMs = 0L
    private var accumYawDeg = 0f
    private var accumPitchDeg = 0f

    // Frame rate counters
    private var fpsWindowStartMs = 0L
    private var fpsFrameCount = 0

    private val userServiceArgs: Shizuku.UserServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(context, ShizukuVrUserService::class.java))
            .daemon(false)
            .processNameSuffix("vr_service")
            .debuggable(BuildConfig.DEBUG)
            .version(1)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            userServiceBindRequested = false
            if (binder == null || !binder.pingBinder()) {
                userService = null
                _state.value = _state.value.copy(
                    status = ShizukuStatus.ERROR,
                    isUserServiceConnected = false,
                    lastErrorMessage = "Shizuku UserService binder unavailable"
                )
                return
            }
            val svc = IShizukuVrService.Stub.asInterface(binder)
            userService = svc
            val uid = runCatching { svc.uid }.getOrDefault(-1)
            _state.value = _state.value.copy(
                status = if (_state.value.virtualDisplayId > 0) ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE else ShizukuStatus.READY,
                isUserServiceConnected = true,
                serviceUid = uid,
                lastErrorMessage = null
            )

            val pending = pendingRequest
            if (pending != null) {
                pendingRequest = null
                createAndLaunchOnService(svc, pending)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            userServiceBindRequested = false
            userService = null
            monitorJob?.cancel()
            fingerDown = false
            fingerX = null
            fingerY = null
            _state.value = _state.value.copy(
                isUserServiceConnected = false,
                virtualDisplayId = -1,
                isMinecraftRunningOnDisplay = false,
                isReceivingFrames = false,
                status = if (isBinderAliveSafe() && hasShizukuPermissionSafe()) {
                    ShizukuStatus.READY
                } else {
                    computeNonConnectedStatus()
                }
            )
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        userService = null
        userServiceBindRequested = false
        pendingRequest = null
        monitorJob?.cancel()
        _state.value = _state.value.copy(
            isBinderAlive = false,
            isUserServiceConnected = false,
            virtualDisplayId = -1,
            isMinecraftRunningOnDisplay = false,
            isReceivingFrames = false,
            status = if (isShizukuAppInstalled()) ShizukuStatus.NOT_RUNNING else ShizukuStatus.NOT_INSTALLED
        )
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            if (granted) {
                refreshStatus()
                if (pendingRequest != null) {
                    ensureUserServiceBound()
                }
            } else {
                val rationale = runCatching { Shizuku.shouldShowRequestPermissionRationale() }.getOrDefault(false)
                _state.value = _state.value.copy(
                    hasPermission = false,
                    status = if (rationale) ShizukuStatus.PERMISSION_REQUIRED else ShizukuStatus.PERMISSION_DENIED,
                    lastErrorMessage = "Shizuku permission was denied by user"
                )
            }
        }
    }

    fun initialize() {
        if (!listenersRegistered) {
            listenersRegistered = true
            runCatching { Shizuku.addBinderReceivedListenerSticky(binderReceivedListener) }
            runCatching { Shizuku.addBinderDeadListener(binderDeadListener) }
            runCatching { Shizuku.addRequestPermissionResultListener(permissionResultListener) }
        }
        refreshStatus()
    }

    fun refreshStatus() {
        val installed = isShizukuAppInstalled()
        val binderAlive = isBinderAliveSafe()
        val hasPerm = if (binderAlive) hasShizukuPermissionSafe() else false
        val svcConnected = userService?.asBinder()?.pingBinder() == true
        val vdId = if (svcConnected) _state.value.virtualDisplayId else -1

        val currentStatus = _state.value.status
        val nextStatus = when {
            !installed -> ShizukuStatus.NOT_INSTALLED
            !binderAlive -> ShizukuStatus.NOT_RUNNING
            !hasPerm && currentStatus == ShizukuStatus.PERMISSION_DENIED -> ShizukuStatus.PERMISSION_DENIED
            !hasPerm -> ShizukuStatus.PERMISSION_REQUIRED
            vdId > 0 -> ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE
            userServiceBindRequested && !svcConnected -> ShizukuStatus.BINDING_SERVICE
            svcConnected -> ShizukuStatus.READY
            else -> ShizukuStatus.READY
        }

        _state.value = _state.value.copy(
            status = nextStatus,
            isShizukuInstalled = installed,
            isBinderAlive = binderAlive,
            hasPermission = hasPerm,
            isUserServiceConnected = svcConnected,
            virtualDisplayId = vdId
        )
    }

    fun requestPermission() {
        refreshStatus()
        if (!isBinderAliveSafe()) {
            openShizukuApp()
            return
        }
        if (hasShizukuPermissionSafe()) {
            ensureUserServiceBound()
            return
        }
        runCatching {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        }.onFailure { err ->
            _state.value = _state.value.copy(
                status = ShizukuStatus.ERROR,
                lastErrorMessage = err.message ?: "Unable to request Shizuku permission"
            )
        }
    }

    fun openShizukuApp(): Boolean {
        val launch = context.packageManager.getLaunchIntentForPackage(SHIZUKU_MANAGER_PACKAGE) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            context.startActivity(launch)
            true
        }.getOrDefault(false)
    }

    fun startVirtualDisplaySession(
        surface: Surface?,
        width: Int,
        height: Int,
        dpi: Int,
        targetPackage: String
    ) {
        if (surface == null || !surface.isValid) {
            _state.value = _state.value.copy(
                status = ShizukuStatus.ERROR,
                lastErrorMessage = "OpenGL render surface is not ready yet"
            )
            return
        }
        activeTargetPackage = targetPackage
        refreshStatus()
        val snap = _state.value
        if (!snap.isShizukuInstalled || !snap.isBinderAlive || !snap.hasPermission) {
            pendingRequest = PendingVirtualDisplayRequest(surface, width, height, dpi, targetPackage)
            return
        }

        val svc = userService
        if (svc != null && svc.asBinder().pingBinder()) {
            pendingRequest = null
            createAndLaunchOnService(svc, PendingVirtualDisplayRequest(surface, width, height, dpi, targetPackage))
        } else {
            pendingRequest = PendingVirtualDisplayRequest(surface, width, height, dpi, targetPackage)
            ensureUserServiceBound()
        }
    }

    fun relaunchTargetOnVirtualDisplay(targetPackage: String) {
        val displayId = _state.value.virtualDisplayId
        val svc = userService ?: return
        if (displayId <= 0 || !svc.asBinder().pingBinder()) return
        activeTargetPackage = targetPackage
        binderExecutor.execute {
            val component = MinecraftIntegrationManager.resolveLaunchComponent(context, targetPackage)
            val err = runCatching {
                svc.launchPackageOnDisplay(targetPackage, component, displayId)
            }.getOrElse { it.message ?: "Launch failed" }
            if (err.isBlank()) {
                _state.value = _state.value.copy(
                    isMinecraftLaunchedOnDisplay = true,
                    isMinecraftRunningOnDisplay = true,
                    lastErrorMessage = null
                )
            } else {
                _state.value = _state.value.copy(
                    status = ShizukuStatus.ERROR,
                    lastErrorMessage = err
                )
            }
        }
    }

    fun stopVirtualDisplaySession() {
        pendingRequest = null
        monitorJob?.cancel()
        monitorJob = null
        releaseHeadLookFingerAsync()

        val svc = userService
        if (svc != null && svc.asBinder().pingBinder()) {
            binderExecutor.execute {
                runCatching { svc.releaseVirtualDisplay() }
            }
        }

        fpsWindowStartMs = 0L
        fpsFrameCount = 0

        val ready = isBinderAliveSafe() && hasShizukuPermissionSafe()
        _state.value = _state.value.copy(
            status = if (ready) ShizukuStatus.READY else computeNonConnectedStatus(),
            virtualDisplayId = -1,
            virtualWidth = 0,
            virtualHeight = 0,
            isMinecraftLaunchedOnDisplay = false,
            isMinecraftRunningOnDisplay = false,
            isReceivingFrames = false,
            estimatedFps = 0
        )
    }

    fun reportVirtualDisplayFrame() {
        if (_state.value.virtualDisplayId <= 0) return
        val now = SystemClock.uptimeMillis()
        if (fpsWindowStartMs == 0L) fpsWindowStartMs = now
        fpsFrameCount++
        var currentFps = _state.value.estimatedFps
        if (now - fpsWindowStartMs >= 1000L) {
            currentFps = fpsFrameCount
            fpsFrameCount = 0
            fpsWindowStartMs = now
        }
        if (!_state.value.isReceivingFrames || currentFps != _state.value.estimatedFps) {
            _state.value = _state.value.copy(
                isReceivingFrames = true,
                estimatedFps = currentFps
            )
        }
    }

    /**
     * Forwards PlayStation DualShock 4 / DualSense KeyEvents to Minecraft inside the isolated
     * VirtualDisplay without losing standard controls, while keeping MineVR-local actions local.
     */
    fun forwardControllerKey(event: KeyEvent, controls: ControlsSettingsState): Boolean {
        val displayId = _state.value.virtualDisplayId
        val svc = userService ?: return false
        if (displayId <= 0 || !svc.asBinder().pingBinder()) return false

        val resolvedKeyCode = PlayStationControllerManager.resolveForwardKeyCode(event.keyCode, controls)
            ?: return false // Consumed locally by MineVR (Recenter / Pause VR)

        val outbound = if (resolvedKeyCode == event.keyCode) {
            KeyEvent(event)
        } else {
            KeyEvent(
                event.downTime,
                event.eventTime,
                event.action,
                resolvedKeyCode,
                event.repeatCount,
                event.metaState,
                event.deviceId,
                event.scanCode,
                event.flags,
                event.source
            )
        }
        binderExecutor.execute {
            runCatching { svc.injectKeyEvent(outbound, displayId) }
        }
        return true
    }

    fun forwardControllerMotion(event: MotionEvent): Boolean {
        val displayId = _state.value.virtualDisplayId
        val svc = userService ?: return false
        if (displayId <= 0 || !svc.asBinder().pingBinder()) return false

        val copy = MotionEvent.obtain(event)
        binderExecutor.execute {
            try {
                runCatching { svc.injectMotionEvent(copy, displayId) }
            } finally {
                copy.recycle()
            }
        }
        return true
    }

    /**
     * Forwards direct screen taps inside the eye viewport (when HUD "Game Touch" mode is toggled on)
     * onto Minecraft's UI inside the VirtualDisplay.
     */
    fun forwardNormalizedTouch(normX: Float, normY: Float, action: Int, downTimeMs: Long) {
        val st = _state.value
        val svc = userService ?: return
        if (st.virtualDisplayId <= 0 || st.virtualWidth <= 0 || st.virtualHeight <= 0) return
        val x = (normX.coerceIn(0f, 1f) * st.virtualWidth.toFloat())
        val y = (normY.coerceIn(0f, 1f) * st.virtualHeight.toFloat())
        val eventTime = SystemClock.uptimeMillis()
        binderExecutor.execute {
            runCatching {
                svc.injectTouchEvent(st.virtualDisplayId, action, x, y, downTimeMs, eventTime)
            }
        }
    }

    /**
     * Converts gyroscope head movement deltas into smooth continuous touchscreen drag events
     * injected directly onto the off-screen Minecraft VirtualDisplay (no AccessibilityService required).
     */
    fun submitHeadLookDelta(
        deltaYawDeg: Float,
        deltaPitchDeg: Float,
        sensitivity: Float,
        invertY: Boolean,
        enabled: Boolean
    ) {
        val st = _state.value
        val svc = userService ?: return
        if (!enabled || st.virtualDisplayId <= 0 || st.virtualWidth <= 0 || st.virtualHeight <= 0) {
            if (fingerDown) {
                releaseHeadLookFingerAsync()
            }
            return
        }

        accumYawDeg += deltaYawDeg
        accumPitchDeg += deltaPitchDeg
        val now = SystemClock.uptimeMillis()
        if (now - lastHeadDispatchMs < 14L) return

        val dY = accumYawDeg
        val dP = accumPitchDeg
        accumYawDeg = 0f
        accumPitchDeg = 0f
        lastHeadDispatchMs = now

        val vdId = st.virtualDisplayId
        val vdW = st.virtualWidth
        val vdH = st.virtualHeight

        binderExecutor.execute {
            val step = HeadLookBridgeMath.computeContinuousStep(
                screenWidthPx = vdW,
                screenHeightPx = vdH,
                curX = fingerX,
                curY = fingerY,
                deltaYawDeg = dY,
                deltaPitchDeg = dP,
                sensitivity = sensitivity,
                invertY = invertY
            )
            if (step == null) {
                if (fingerDown && now - lastIdleResetMs > 280L) {
                    releaseFingerOnExecutor(svc, vdId)
                }
                return@execute
            }
            lastIdleResetMs = now

            if (step.needsReanchor && fingerDown) {
                releaseFingerOnExecutor(svc, vdId)
            }

            val ts = SystemClock.uptimeMillis()
            if (!fingerDown) {
                fingerDownTimeMs = ts
                fingerDown = true
                svc.injectTouchEvent(vdId, MotionEvent.ACTION_DOWN, step.startX, step.startY, fingerDownTimeMs, ts)
            }
            svc.injectTouchEvent(vdId, MotionEvent.ACTION_MOVE, step.endX, step.endY, fingerDownTimeMs, ts)
            fingerX = step.endX
            fingerY = step.endY
        }
    }

    fun release() {
        stopVirtualDisplaySession()
        if (listenersRegistered) {
            listenersRegistered = false
            runCatching { Shizuku.removeBinderReceivedListener(binderReceivedListener) }
            runCatching { Shizuku.removeBinderDeadListener(binderDeadListener) }
            runCatching { Shizuku.removeRequestPermissionResultListener(permissionResultListener) }
        }
        runCatching { Shizuku.unbindUserService(userServiceArgs, serviceConnection, true) }
        userService = null
        binderExecutor.shutdownNow()
    }

    private fun ensureUserServiceBound() {
        if (userService?.asBinder()?.pingBinder() == true || userServiceBindRequested) return
        userServiceBindRequested = true
        _state.value = _state.value.copy(status = ShizukuStatus.BINDING_SERVICE, lastErrorMessage = null)
        runCatching {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        }.onFailure { err ->
            userServiceBindRequested = false
            _state.value = _state.value.copy(
                status = ShizukuStatus.ERROR,
                lastErrorMessage = err.message ?: "Failed to bind Shizuku UserService"
            )
        }
    }

    private fun createAndLaunchOnService(svc: IShizukuVrService, req: PendingVirtualDisplayRequest) {
        binderExecutor.execute {
            val vdId = runCatching {
                svc.createVirtualDisplay(req.surface, req.width, req.height, req.dpi)
            }.getOrElse { -1 }

            if (vdId <= 0) {
                val err = runCatching { svc.lastError }.getOrNull().orEmpty()
                    .ifBlank { "VirtualDisplay creation rejected by Android ROM (displayId=$vdId)" }
                _state.value = _state.value.copy(
                    status = ShizukuStatus.ERROR,
                    virtualDisplayId = -1,
                    isMinecraftLaunchedOnDisplay = false,
                    isMinecraftRunningOnDisplay = false,
                    lastErrorMessage = err
                )
                return@execute
            }

            val component = MinecraftIntegrationManager.resolveLaunchComponent(context, req.packageName)
            val launchErr = runCatching {
                svc.launchPackageOnDisplay(req.packageName, component, vdId)
            }.getOrElse { it.message ?: "Failed to launch Minecraft on VirtualDisplay" }

            if (launchErr.isNotBlank()) {
                _state.value = _state.value.copy(
                    status = ShizukuStatus.ERROR,
                    virtualDisplayId = vdId,
                    virtualWidth = req.width,
                    virtualHeight = req.height,
                    isMinecraftLaunchedOnDisplay = false,
                    isMinecraftRunningOnDisplay = false,
                    lastErrorMessage = launchErr
                )
            } else {
                _state.value = _state.value.copy(
                    status = ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE,
                    virtualDisplayId = vdId,
                    virtualWidth = req.width,
                    virtualHeight = req.height,
                    isMinecraftLaunchedOnDisplay = true,
                    isMinecraftRunningOnDisplay = true,
                    lastErrorMessage = null
                )
                startMinecraftLivenessMonitor(svc, req.packageName, vdId)
            }
        }
    }

    private fun startMinecraftLivenessMonitor(svc: IShizukuVrService, pkg: String, displayId: Int) {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            delay(2500L)
            while (isActive && _state.value.virtualDisplayId == displayId) {
                val alive = runCatching {
                    svc.asBinder().pingBinder() && svc.isPackageRunningOnDisplay(pkg, displayId)
                }.getOrDefault(false)
                if (_state.value.virtualDisplayId == displayId &&
                    _state.value.isMinecraftRunningOnDisplay != alive
                ) {
                    _state.value = _state.value.copy(isMinecraftRunningOnDisplay = alive)
                }
                delay(2500L)
            }
        }
    }

    private fun releaseHeadLookFingerAsync() {
        val vdId = _state.value.virtualDisplayId
        val svc = userService ?: return
        if (!fingerDown || vdId <= 0) {
            fingerDown = false
            fingerX = null
            fingerY = null
            return
        }
        binderExecutor.execute {
            releaseFingerOnExecutor(svc, vdId)
        }
    }

    private fun releaseFingerOnExecutor(svc: IShizukuVrService, displayId: Int) {
        val x = fingerX
        val y = fingerY
        if (fingerDown && x != null && y != null && displayId > 0) {
            runCatching {
                svc.injectTouchEvent(displayId, MotionEvent.ACTION_UP, x, y, fingerDownTimeMs, SystemClock.uptimeMillis())
            }
        }
        fingerDown = false
        fingerX = null
        fingerY = null
    }

    private fun computeNonConnectedStatus(): ShizukuStatus = when {
        !isShizukuAppInstalled() -> ShizukuStatus.NOT_INSTALLED
        !isBinderAliveSafe() -> ShizukuStatus.NOT_RUNNING
        !hasShizukuPermissionSafe() -> ShizukuStatus.PERMISSION_REQUIRED
        else -> ShizukuStatus.READY
    }

    private fun isShizukuAppInstalled(): Boolean {
        val pm = context.packageManager
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(SHIZUKU_MANAGER_PACKAGE, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(SHIZUKU_MANAGER_PACKAGE, 0)
            }
            true
        }.getOrDefault(false)
    }

    private fun isBinderAliveSafe(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    private fun hasShizukuPermissionSafe(): Boolean = runCatching {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    companion object {
        const val SHIZUKU_MANAGER_PACKAGE = "moe.shizuku.privileged.api"
        private const val SHIZUKU_PERMISSION_REQUEST_CODE = 4201
    }
}
