package com.example.vr.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES30
import android.opengl.GLUtils
import android.opengl.Matrix
import com.example.vr.model.TextureQuality
import com.example.vr.model.Transform3D
import java.io.File

class GlTextureCache {
    private val cache = HashMap<String, Int>()
    private var lastQuality: TextureQuality = TextureQuality.MEDIUM_1024

    fun setTextureQuality(quality: TextureQuality) {
        if (quality != lastQuality) {
            lastQuality = quality
            clear()
        }
    }

    fun getOrLoadTexture(path: String?): Int {
        if (path.isNullOrBlank()) return 0
        cache[path]?.let { return it }

        val file = File(path)
        if (!file.exists() || !file.canRead()) {
            cache[path] = 0
            return 0
        }

        val texId = loadBitmapTexture(file, lastQuality.maxDimensionPx)
        cache[path] = texId
        return texId
    }

    fun clear() {
        val ids = cache.values.filter { it > 0 }.toIntArray()
        if (ids.isNotEmpty()) {
            GLES30.glDeleteTextures(ids.size, ids, 0)
        }
        cache.clear()
    }

    private fun loadBitmapTexture(file: File, maxDim: Int): Int {
        val optsBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, optsBounds)
        if (optsBounds.outWidth <= 0 || optsBounds.outHeight <= 0) return 0

        var sample = 1
        while (optsBounds.outWidth / sample > maxDim || optsBounds.outHeight / sample > maxDim) {
            sample *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bmp = BitmapFactory.decodeFile(file.absolutePath, decodeOpts) ?: return 0
        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        val texId = tex[0]
        if (texId != 0) {
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texId)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
        }
        bmp.recycle()
        return texId
    }
}

object GlTextureAndShaderHelper {

    fun buildTransformMatrix(out: FloatArray, t: Transform3D) {
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, t.posX, t.posY, t.posZ)
        if (t.rotY != 0f) Matrix.rotateM(out, 0, t.rotY, 0f, 1f, 0f)
        if (t.rotX != 0f) Matrix.rotateM(out, 0, t.rotX, 1f, 0f, 0f)
        if (t.rotZ != 0f) Matrix.rotateM(out, 0, t.rotZ, 0f, 0f, 1f)
        Matrix.scaleM(out, 0, t.scaleX.coerceAtLeast(0.02f), t.scaleY.coerceAtLeast(0.02f), t.scaleZ.coerceAtLeast(0.02f))
    }

    fun composeWorldAndNodeMatrix(out: FloatArray, world: Transform3D, node: Transform3D, tmpWorld: FloatArray, tmpNode: FloatArray) {
        buildTransformMatrix(tmpWorld, world)
        buildTransformMatrix(tmpNode, node)
        Matrix.multiplyMM(out, 0, tmpWorld, 0, tmpNode, 0)
    }

    fun createProgram(vsSource: String, fsSource: String): Int {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vsSource)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, src)
        GLES30.glCompileShader(shader)
        return shader
    }

    const val SCENE_VS = """#version 300 es
        layout(location = 0) in vec3 aPos;
        layout(location = 1) in vec3 aNorm;
        layout(location = 2) in vec2 aUv;
        layout(location = 3) in vec4 aColor;
        uniform mat4 uMvp;
        uniform mat4 uModel;
        out vec3 vWorldPos;
        out vec3 vNormal;
        out vec2 vUv;
        out vec4 vColor;
        void main() {
            vec4 wp = uModel * vec4(aPos, 1.0);
            vWorldPos = wp.xyz;
            vNormal = normalize(transpose(inverse(mat3(uModel))) * aNorm);
            vUv = aUv;
            vColor = aColor;
            gl_Position = uMvp * vec4(aPos, 1.0);
        }
    """

    const val SCENE_FS = """#version 300 es
        precision mediump float;
        in vec3 vWorldPos;
        in vec3 vNormal;
        in vec2 vUv;
        in vec4 vColor;
        uniform vec3 uColor;
        uniform float uAlpha;
        uniform int uTag;
        uniform float uHighlight;
        uniform vec3 uLightDir;
        uniform vec3 uCamPos;
        uniform vec3 uFogColor;
        uniform float uFogDensity;
        uniform int uReflect;
        uniform sampler2D uBaseTex;
        uniform int uHasBaseTex;
        uniform sampler2D uNormalTex;
        uniform int uHasNormalTex;
        uniform int uAlphaMode;
        uniform float uAlphaCutoff;
        uniform float uMetallic;
        uniform float uRoughness;
        uniform float uExposure;
        uniform float uDirIntensity;
        uniform float uAmbientIntensity;
        uniform float uEmissive;
        out vec4 fragColor;

        void main() {
            vec3 N = normalize(vNormal);
            if (uHasNormalTex == 1) {
                vec3 nmap = texture(uNormalTex, vUv).xyz * 2.0 - 1.0;
                N = normalize(N + nmap * 0.35);
            }
            vec3 L = normalize(uLightDir);
            vec3 V = normalize(uCamPos - vWorldPos);
            vec3 H = normalize(L + V);

            vec4 texSample = (uHasBaseTex == 1) ? texture(uBaseTex, vUv) : vec4(1.0);
            float effectiveAlpha = uAlpha * vColor.a * texSample.a;

            if (uAlphaMode == 1 && texSample.a < uAlphaCutoff) {
                discard;
            }

            vec3 baseCol = uColor * vColor.rgb * texSample.rgb;

            if (uTag == 1) {
                vec2 grid = abs(fract(vWorldPos.xz * 0.85) - 0.5);
                float line = step(0.47, max(grid.x, grid.y));
                baseCol = mix(baseCol, baseCol * 0.82, line);
            } else if (uTag == 2) {
                float grain = fract(sin(dot(floor(vWorldPos.xz * 12.0), vec2(12.9898, 78.233))) * 43758.5453);
                baseCol *= (0.90 + 0.16 * grain);
            }

            float twoSidedNdotL = (uTag == 4) ? abs(dot(N, L)) : max(dot(N, L), 0.0);
            float diff = twoSidedNdotL * uDirIntensity;
            float hemi = uAmbientIntensity * (0.85 + 0.25 * N.y);

            float shininess = mix(96.0, 8.0, clamp(uRoughness, 0.05, 1.0));
            float specBase = (uTag == 1 && uReflect == 1) ? 0.35 : mix(0.06, 0.55, 1.0 - uRoughness) * (0.4 + 0.6 * uMetallic);
            float spec = pow(max(dot(N, H), 0.0), shininess) * specBase * uDirIntensity;

            vec3 lit = baseCol * (hemi + diff * 0.72) + vec3(spec) * mix(vec3(1.0), baseCol, uMetallic);

            if (uTag == 3 || uEmissive > 0.01) {
                lit += baseCol * max(uEmissive, (uTag == 3 ? 0.35 : 0.0));
            }

            // Soft Reinhard tone mapping prevents bright exposure from blowing textures to white
            lit *= clamp(uExposure, 0.35, 2.2);
            lit = lit / (lit + vec3(0.75)) * 1.45;

            if (uHighlight > 0.01) {
                float rim = pow(1.0 - max(abs(dot(N, V)), 0.0), 2.0);
                lit = mix(lit, vec3(0.0, 0.90, 1.0), uHighlight * (0.32 + 0.55 * rim));
            }

            float dist = length(uCamPos - vWorldPos);
            float fogFactor = 1.0 - exp(-dist * uFogDensity);
            vec3 finalRgb = mix(lit, uFogColor, clamp(fogFactor, 0.0, 0.85));

            fragColor = vec4(finalRgb, clamp(effectiveAlpha, 0.0, 1.0));
        }
    """

    const val POST_VS = """#version 300 es
        layout(location = 0) in vec2 aPos;
        layout(location = 1) in vec2 aUv;
        out vec2 vUv;
        void main() {
            vUv = aUv;
            gl_Position = vec4(aPos, 0.0, 1.0);
        }
    """

    const val POST_FS = """#version 300 es
        precision mediump float;
        in vec2 vUv;
        uniform sampler2D uTex;
        uniform float uK1;
        uniform float uChromatic;
        uniform float uImageScale;
        uniform float uEyeOffset;
        uniform float uVignette;
        out vec4 fragColor;

        vec2 distort(vec2 centered, float k) {
            float r2 = dot(centered, centered);
            return centered * (1.0 + k * r2);
        }

        void main() {
            vec2 c = (vUv - vec2(0.5 + uEyeOffset, 0.5)) / max(uImageScale, 0.5);
            vec2 uvR = distort(c, uK1 + uChromatic) + 0.5;
            vec2 uvG = distort(c, uK1) + 0.5;
            vec2 uvB = distort(c, uK1 - uChromatic) + 0.5;

            if (uvG.x < 0.0 || uvG.x > 1.0 || uvG.y < 0.0 || uvG.y > 1.0) {
                fragColor = vec4(0.0, 0.0, 0.0, 1.0);
                return;
            }

            float r = texture(uTex, clamp(uvR, 0.0, 1.0)).r;
            float g = texture(uTex, clamp(uvG, 0.0, 1.0)).g;
            float b = texture(uTex, clamp(uvB, 0.0, 1.0)).b;

            float rDist = length(c);
            float vig = 1.0 - smoothstep(0.47, 0.55, rDist) * uVignette;
            fragColor = vec4(vec3(r, g, b) * vig, 1.0);
        }
    """
}
