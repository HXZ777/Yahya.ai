package com.example.vr.engine

import com.example.audio.VrAudioEngine
import com.example.vr.camera.HeadTracker
import com.example.vr.input.XboxControllerManager
import com.example.vr.model.AllSettingsState
import com.example.vr.model.ControlScheme
import com.example.vr.model.FlySpeed
import com.example.vr.model.GameMode
import com.example.vr.model.HandGesture
import com.example.vr.model.HandTrackingState
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.ItemContainer
import com.example.vr.model.MissionEntry
import com.example.vr.model.MovementMode
import com.example.vr.model.NpcEntity
import com.example.vr.model.NpcRole
import com.example.vr.model.ProductItem
import com.example.vr.model.SaveGameState
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.WorldProjectState
import com.example.vr.model.WorldType
import com.example.vr.model.XboxAction
import com.example.vr.world.SupermarketWorldBuilder
import com.example.vr.world.WorldCatalog
import com.example.vr.world.WorldSceneData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

enum class TargetStationType {
    NONE,
    CART_BAY,
    BASKET_BAY,
    CHECKOUT_BELT,
    LASER_SCANNER,
    POS_TERMINAL,
    BAGGING_ZONE
}

data class ReceiptSummary(
    val items: List<ProductItem>,
    val subtotal: Float,
    val discountSaved: Float,
    val paymentMethodLabelEn: String,
    val paymentMethodLabelAr: String
)

data class SimulationSnapshot(
    val worldType: WorldType = WorldType.GRAND_SUPERMARKET,
    val playerX: Float = 0f,
    val playerY: Float = 1.65f,
    val playerZ: Float = 15.6f,
    val yawDeg: Float = 0f,
    val pitchDeg: Float = 0f,
    val rollDeg: Float = 0f,
    val isCrouching: Boolean = false,
    val isSprinting: Boolean = false,
    val isFlyMode: Boolean = false,
    val flySpeed: FlySpeed = FlySpeed.NORMAL,
    val doorOpenAmount: Float = 0f,
    val targetedProduct: ProductItem? = null,
    val targetedStation: TargetStationType = TargetStationType.NONE,
    val targetedNpc: NpcEntity? = null,
    val gazeDwellProgress: Float = 0f,
    val heldProduct: ProductItem? = null,
    val inspectYawDeg: Float = 0f,
    val inspectPitchDeg: Float = 0f,
    val isInspectingDetails: Boolean = false,
    val hasCart: Boolean = false,
    val hasBasket: Boolean = false,
    val hasPaidBag: Boolean = false,
    val cartItems: List<ProductItem> = emptyList(),
    val beltItems: List<ProductItem> = emptyList(),
    val scannedItems: List<ProductItem> = emptyList(),
    val walletBalance: Float = 250.0f,
    val budgetLimit: Float = 85.0f,
    val gameMode: GameMode = GameMode.SANDBOX,
    val receipt: ReceiptSummary? = null,
    val activeNpcDialogEn: String? = null,
    val activeNpcDialogAr: String? = null,
    val showShoppingListOverlay: Boolean = false,
    val showMissionsOverlay: Boolean = false,
    val missions: List<MissionEntry> = WorldCatalog.defaultMissions,
    val teleportActive: Boolean = false,
    val teleportTargetX: Float = 0f,
    val teleportTargetZ: Float = 0f,
    val feedbackEn: String? = null,
    val feedbackAr: String? = null,
    val feedbackIsError: Boolean = false,
    val measuredFps: Int = 60,
    val totalCheckoutsCompleted: Int = 0
)

class GameSimulationController(
    private val headTracker: HeadTracker,
    private val xboxManager: XboxControllerManager,
    private val audioEngine: VrAudioEngine,
    private val onAutoSave: (SaveGameState) -> Unit
) {
    private val _snapshot = MutableStateFlow(SimulationSnapshot())
    val snapshot: StateFlow<SimulationSnapshot> = _snapshot.asStateFlow()

    @Volatile
    var worldData: WorldSceneData = SupermarketWorldBuilder.buildWorld(WorldType.GRAND_SUPERMARKET)
        private set

    @Volatile
    var activeWorldId: String = "world_grand_supermarket"
        private set

    private var settings = AllSettingsState()
    private var handState = HandTrackingState()

    // Player runtime physics
    private var playerX = 0f
    private var playerFeetY = 0f
    private var playerZ = 15.6f
    private var manualYawDeg = 0f
    private var manualPitchDeg = 0f
    private var isCrouching = false
    private var isSprinting = false
    private var isFlyMode = false
    private var flySpeed = FlySpeed.NORMAL
    private var doorOpenAmount = 0f
    private var doorChimePlayed = false

    // Interaction & Gaze Dwell
    private var heldProductId: String? = null
    private var inspectYawDeg = 20f
    private var inspectPitchDeg = 10f
    private var isInspectingDetails = false
    private var lastDwellTargetKey = ""
    private var dwellTimerSec = 0f
    private var dwellTriggered = false
    private var lastHandGesture = HandGesture.NONE

    // Virtual touch joystick & fly buttons state
    @Volatile var touchMoveForward = 0f
    @Volatile var touchMoveRight = 0f
    @Volatile var touchLookDeltaYaw = 0f
    @Volatile var touchLookDeltaPitch = 0f
    @Volatile var touchFlyAscend = false
    @Volatile var touchFlyDescend = false
    @Volatile var touchSprintHeld = false

    // Shopping & Checkout state
    private var hasCart = false
    private var hasBasket = false
    private var hasPaidBag = false
    private var walletBalance = 250f
    private var budgetLimit = 85f
    private var totalCheckouts = 0
    private var currentReceipt: ReceiptSummary? = null
    private var completedMissions = mutableSetOf<String>()
    private var activeNpcDialogEn: String? = null
    private var activeNpcDialogAr: String? = null
    private var feedbackEn: String? = null
    private var feedbackAr: String? = null
    private var feedbackError = false
    private var feedbackTimerSec = 0f
    private var autoSaveAccumSec = 0f

    private var lastXboxActionListener: ((XboxAction) -> Unit)? = null
    private var lastFlyToggleListener: (() -> Unit)? = null

    init {
        val listener: (XboxAction) -> Unit = { action -> handleXboxAction(action) }
        lastXboxActionListener = listener
        xboxManager.addActionListener(listener)

        val flyListener: () -> Unit = { toggleFlyMode() }
        lastFlyToggleListener = flyListener
        xboxManager.addFlyToggleListener(flyListener)
    }

    fun updateSettings(newSettings: AllSettingsState) {
        settings = newSettings
        flySpeed = newSettings.controls.defaultFlySpeed
        xboxManager.updateMapping(newSettings.controls.xboxMapping, newSettings.controls.flyToggleButton)
        audioEngine.updateSettings(newSettings.graphics.sfxEnabled, newSettings.graphics.musicEnabled)
        _snapshot.value = _snapshot.value.copy(gameMode = newSettings.gameMode, flySpeed = flySpeed)
    }

    fun updateHandTrackingState(state: HandTrackingState) {
        handState = state
        if (settings.controls.activeScheme == ControlScheme.HAND_TRACKING &&
            state.gesture != lastHandGesture
        ) {
            when (state.gesture) {
                HandGesture.FIST, HandGesture.INDEX_PRESS, HandGesture.PINCH_SELECT -> {
                    if (lastHandGesture == HandGesture.OPEN_HAND || lastHandGesture == HandGesture.POINT_INDEX || lastHandGesture == HandGesture.NONE) {
                        performPrimaryInteraction()
                    }
                }
                HandGesture.OPEN_HAND -> {
                    if (lastHandGesture == HandGesture.FIST && heldProductId != null) {
                        dropHeldProductToShelfOrCart()
                    }
                }
                HandGesture.PUSH_FORWARD -> {
                    if (hasCart) nudgeCartForward()
                }
                else -> Unit
            }
            lastHandGesture = state.gesture
        }
    }

    fun loadCustomWorld(
        worldId: String,
        mesh: ImportedMeshData?,
        saved: SaveGameState?,
        project: WorldProjectState? = null,
        overrideSpawn: SpawnPointEntry? = null
    ) {
        activeWorldId = worldId
        worldData = SupermarketWorldBuilder.buildCustomImportedWorld(mesh, project)
        heldProductId = null
        currentReceipt = null
        activeNpcDialogEn = null
        activeNpcDialogAr = null
        hasCart = false
        hasBasket = false
        hasPaidBag = false
        isFlyMode = false
        isCrouching = saved?.isCrouching ?: false

        if (overrideSpawn != null) {
            val (sx, sy, sz) = SupermarketWorldBuilder.resolveSafeSpawnPoint(
                overrideSpawn.x,
                (overrideSpawn.y + overrideSpawn.elevationOffset).coerceAtLeast(0f),
                overrideSpawn.z,
                worldData.solidColliders
            )
            playerX = sx
            playerFeetY = sy
            playerZ = sz
            manualYawDeg = overrideSpawn.yawDeg
        } else if (saved != null && saved.activeWorldId == worldId) {
            playerX = saved.playerX
            playerFeetY = worldData.spawnY
            playerZ = saved.playerZ
            manualYawDeg = saved.playerYawDeg
        } else {
            playerX = worldData.spawnX
            playerFeetY = worldData.spawnY
            playerZ = worldData.spawnZ
            manualYawDeg = worldData.spawnYawDeg
        }
        publishSnapshot(null, TargetStationType.NONE, null, 0f, false, 0f, 0f, 60)
    }

    fun loadWorld(worldId: String, type: WorldType, saved: SaveGameState?) {
        activeWorldId = worldId
        worldData = SupermarketWorldBuilder.buildWorld(type)
        heldProductId = null
        currentReceipt = null
        activeNpcDialogEn = null
        activeNpcDialogAr = null
        isFlyMode = false

        if (saved != null && saved.activeWorldId == worldId) {
            playerX = saved.playerX
            playerFeetY = 0f
            playerZ = saved.playerZ
            manualYawDeg = saved.playerYawDeg
            isCrouching = saved.isCrouching
            hasCart = saved.hasCart
            hasBasket = saved.hasBasket
            hasPaidBag = saved.hasPaidBag
            walletBalance = saved.walletBalance
            budgetLimit = saved.budgetLimit
            totalCheckouts = saved.totalCheckoutsCompleted
            completedMissions = saved.completedMissions.toMutableSet()

            worldData.products.forEachIndexed { idx, p ->
                if (p.id in saved.cartProductIds) {
                    worldData.products[idx] = p.copy(
                        container = if (hasBasket && !hasCart) ItemContainer.BASKET else ItemContainer.CART
                    )
                } else if (p.id in saved.scannedProductIds) {
                    worldData.products[idx] = p.copy(container = ItemContainer.BELT, isScanned = true)
                }
            }
        } else {
            playerX = worldData.spawnX
            playerFeetY = 0f
            playerZ = worldData.spawnZ
            manualYawDeg = worldData.spawnYawDeg
            isCrouching = false
            hasCart = false
            hasBasket = false
            hasPaidBag = false
            walletBalance = 250f
            budgetLimit = 85f
            completedMissions = mutableSetOf()
        }
        publishSnapshot(null, TargetStationType.NONE, null, 0f, false, 0f, 0f, 60)
    }

    fun tick(dtRaw: Float, measuredFps: Int) {
        val dt = dtRaw.coerceIn(0.004f, 0.08f)
        val xbox = xboxManager.snapshot.value

        // 1. Head + Stick + Touch Orientation
        if (touchLookDeltaYaw != 0f || touchLookDeltaPitch != 0f) {
            manualYawDeg += touchLookDeltaYaw
            manualPitchDeg = (manualPitchDeg + touchLookDeltaPitch).coerceIn(-75f, 75f)
            touchLookDeltaYaw = 0f
            touchLookDeltaPitch = 0f
        }
        val turnSens = settings.controls.turnSensitivity * 95f
        if (xbox.rightX != 0f) manualYawDeg -= xbox.rightX * turnSens * dt
        if (xbox.rightY != 0f) manualPitchDeg = (manualPitchDeg - xbox.rightY * turnSens * 0.7f * dt).coerceIn(-75f, 75f)

        val headYaw = if (headTracker.hasSensorData) headTracker.getCalibratedYawDeg() else 0f
        val headPitch = if (headTracker.hasSensorData) headTracker.pitchDeg else 0f
        val totalYaw = (headYaw + manualYawDeg)
        val totalPitch = (headPitch + manualPitchDeg).coerceIn(-80f, 80f)
        val rollDeg = if (headTracker.hasSensorData) headTracker.rollDeg else 0f

        // 2. Movement (Fly Mode vs Ground Walk / Teleport)
        val moveInX = (xbox.leftX + touchMoveRight).coerceIn(-1f, 1f)
        val moveInFwd = (-xbox.leftY + touchMoveForward).coerceIn(-1f, 1f)
        val fwd = GlMath.forwardVectorXZ(totalYaw)
        val right = GlMath.rightVectorXZ(totalYaw)
        val sprintActive = isSprinting || xbox.isSprintHeld || touchSprintHeld

        if (isFlyMode) {
            val flyMult = if (sprintActive) 1.85f else 1.0f
            val fSpd = flySpeed.metersPerSec * flyMult
            val vx = (fwd[0] * moveInFwd + right[0] * moveInX) * fSpd * dt
            val vz = (fwd[2] * moveInFwd + right[2] * moveInX) * fSpd * dt
            playerX = (playerX + vx).coerceIn(-140f, 140f)
            playerZ = (playerZ + vz).coerceIn(-140f, 140f)

            val ascend = xbox.isAscendHeld || touchFlyAscend
            val descend = xbox.isDescendHeld || touchFlyDescend
            val vy = when {
                ascend && !descend -> fSpd * 0.85f * dt
                descend && !ascend -> -fSpd * 0.85f * dt
                else -> 0f
            }
            playerFeetY = (playerFeetY + vy).coerceIn(0f, 85f)
        } else if (settings.controls.movementMode == MovementMode.SMOOTH) {
            val speedMult = (if (sprintActive) 1.6f else 1f) * (if (isCrouching) 0.6f else 1f)
            val spd = settings.controls.moveSpeed * speedMult
            val vx = (fwd[0] * moveInFwd + right[0] * moveInX) * spd * dt
            val vz = (fwd[2] * moveInFwd + right[2] * moveInX) * spd * dt
            if (hypot(vx.toDouble(), vz.toDouble()) > 0.002) {
                movePlayerWithCollisions(vx, vz)
                if (hasCart) audioEngine.playCartRoll() else audioEngine.playFootstep()
            }
            // Gently settle back to world ground elevation if exiting Fly Mode mid-air
            val groundY = worldData.spawnY
            if (playerFeetY > groundY + 0.02f) {
                playerFeetY = (playerFeetY - 7.5f * dt).coerceAtLeast(groundY)
            }
        } else {
            val vx = right[0] * moveInX * 2.2f * dt
            val vz = right[2] * moveInX * 2.2f * dt
            if (hypot(vx.toDouble(), vz.toDouble()) > 0.002) movePlayerWithCollisions(vx, vz)
            playerFeetY = worldData.spawnY
        }

        // 3. Automatic Sliding Glass Door (only for supermarket worlds)
        if (worldData.worldType != WorldType.CUSTOM_IMPORTED) {
            val distToDoor = hypot((playerX - worldData.stations.doorCenterX).toDouble(), (playerZ - worldData.stations.doorZ).toDouble()).toFloat()
            val targetOpen = if (distToDoor < 3.6f) 1f else 0f
            if (targetOpen > 0.5f && !doorChimePlayed && doorOpenAmount < 0.2f) {
                audioEngine.playDoorWhoosh()
                doorChimePlayed = true
            } else if (targetOpen < 0.5f) {
                doorChimePlayed = false
            }
            doorOpenAmount += (targetOpen - doorOpenAmount) * (dt * 4.5f).coerceAtMost(1f)
        } else {
            doorOpenAmount = 1f
        }

        // Check mission completion when exiting outside with paid bag!
        if (hasPaidBag && playerZ > 13.5f) {
            completeMission("mission_checkout_exit", 50f)
        }

        // 4. Update NPC Patrol & Collision Avoidance
        updateNpcs(dt)

        // 5. Raycast for Targeted Product / Station / NPC
        val eyeY = playerFeetY + (if (isCrouching && !isFlyMode) 1.05f else 1.65f)
        val lookDir = if (settings.controls.activeScheme == ControlScheme.HAND_TRACKING &&
            handState.landmarks.isNotEmpty()
        ) {
            // Offset ray subtly by index finger pointing coordinates
            val offYaw = (0.5f - handState.pointerX) * 36f
            val offPitch = (0.5f - handState.pointerY) * 26f
            GlMath.forwardVector(totalYaw + offYaw, totalPitch + offPitch)
        } else {
            GlMath.forwardVector(totalYaw, totalPitch)
        }

        var bestDist = 4.2f
        var hitProduct: ProductItem? = null
        var hitStation = TargetStationType.NONE
        var hitNpc: NpcEntity? = null

        for (p in worldData.products) {
            if (p.container == ItemContainer.HAND || p.container == ItemContainer.BAG) continue
            val px: Float
            val py: Float
            val pz: Float
            if (p.container == ItemContainer.CART || p.container == ItemContainer.BASKET) {
                val cartOffset = if (hasCart) 1.15f else 0.75f
                val idx = worldData.products.filter { it.container == p.container }.indexOf(p).coerceAtLeast(0)
                px = playerX + fwd[0] * cartOffset + right[0] * ((idx % 3 - 1) * 0.14f)
                py = 0.72f + (idx / 3) * 0.14f
                pz = playerZ + fwd[2] * cartOffset + right[2] * ((idx % 3 - 1) * 0.14f)
            } else {
                px = p.x; py = p.y; pz = p.z
            }
            val box = Aabb(px - 0.22f, py - 0.22f, pz - 0.22f, px + 0.22f, py + 0.22f, pz + 0.22f)
            val hit = GlMath.rayIntersectsAabb(playerX, eyeY, playerZ, lookDir[0], lookDir[1], lookDir[2], box, bestDist)
            if (hit != null && hit < bestDist) {
                bestDist = hit
                hitProduct = p
                hitStation = TargetStationType.NONE
                hitNpc = null
            }
        }

        // Stations raycast
        val stationBoxes = listOf(
            TargetStationType.CART_BAY to worldData.stations.cartBay,
            TargetStationType.BASKET_BAY to worldData.stations.basketBay,
            TargetStationType.CHECKOUT_BELT to worldData.stations.checkoutBelt,
            TargetStationType.LASER_SCANNER to worldData.stations.scannerZone,
            TargetStationType.POS_TERMINAL to worldData.stations.posTerminal,
            TargetStationType.BAGGING_ZONE to worldData.stations.baggingZone
        )
        for ((st, box) in stationBoxes) {
            val hit = GlMath.rayIntersectsAabb(playerX, eyeY, playerZ, lookDir[0], lookDir[1], lookDir[2], box, bestDist)
            if (hit != null && hit < bestDist) {
                bestDist = hit
                hitStation = st
                hitProduct = null
                hitNpc = null
            }
        }

        // NPC raycast
        for (npc in worldData.npcs) {
            val box = Aabb(npc.x - 0.35f, 0.1f, npc.z - 0.35f, npc.x + 0.35f, 1.8f, npc.z + 0.35f)
            val hit = GlMath.rayIntersectsAabb(playerX, eyeY, playerZ, lookDir[0], lookDir[1], lookDir[2], box, bestDist)
            if (hit != null && hit < bestDist) {
                bestDist = hit
                hitNpc = npc
                hitProduct = null
                hitStation = TargetStationType.NONE
            }
        }

        // 6. Gaze Dwell Progression (when Gaze Control is active)
        val targetKey = hitProduct?.id ?: hitNpc?.id ?: if (hitStation != TargetStationType.NONE) hitStation.name else ""
        var dwellProgress = 0f
        if (settings.controls.activeScheme == ControlScheme.GAZE && targetKey.isNotEmpty()) {
            if (targetKey == lastDwellTargetKey) {
                dwellTimerSec += dt
                val threshold = settings.controls.gazeDwellSeconds.coerceIn(0.6f, 2.5f)
                dwellProgress = (dwellTimerSec / threshold).coerceIn(0f, 1f)
                if (dwellTimerSec >= threshold && !dwellTriggered) {
                    dwellTriggered = true
                    performPrimaryInteraction(hitProduct, hitStation, hitNpc)
                }
            } else {
                lastDwellTargetKey = targetKey
                dwellTimerSec = 0f
                dwellTriggered = false
            }
        } else {
            lastDwellTargetKey = targetKey
            dwellTimerSec = 0f
            dwellTriggered = false
        }

        // 7. Teleport Floor Raycast
        var teleValid = false
        var teleX = playerX
        var teleZ = playerZ
        if (settings.controls.movementMode == MovementMode.TELEPORT && lookDir[1] < -0.08f) {
            val tFloor = -eyeY / lookDir[1]
            if (tFloor in 0.8f..14.0f) {
                val maxBound = if (worldData.worldType == WorldType.CUSTOM_IMPORTED) 60f else 12.8f
                val maxZ = if (worldData.worldType == WorldType.CUSTOM_IMPORTED) 60f else 28.0f
                val minZ = if (worldData.worldType == WorldType.CUSTOM_IMPORTED) -60f else -13.2f
                val candX = (playerX + lookDir[0] * tFloor).coerceIn(-maxBound, maxBound)
                val candZ = (playerZ + lookDir[2] * tFloor).coerceIn(minZ, maxZ)
                teleX = candX
                teleZ = candZ
                teleValid = true
            }
        }

        // 8. Held product inspect auto-subtle rotation when inspecting
        if (heldProductId != null && isInspectingDetails) {
            inspectYawDeg = (inspectYawDeg + 28f * dt) % 360f
        }

        // 9. Feedback toast timer & Periodic Auto-save
        if (feedbackTimerSec > 0f) {
            feedbackTimerSec -= dt
            if (feedbackTimerSec <= 0f) {
                feedbackEn = null
                feedbackAr = null
            }
        }
        autoSaveAccumSec += dt
        if (autoSaveAccumSec >= 5.0f) {
            autoSaveAccumSec = 0f
            emitAutoSave()
        }

        publishSnapshot(
            targetedProduct = hitProduct,
            targetedStation = hitStation,
            targetedNpc = hitNpc,
            gazeProgress = dwellProgress,
            teleportActive = teleValid,
            teleportX = teleX,
            teleportZ = teleZ,
            measuredFps = measuredFps
        )
    }

    fun performPrimaryInteraction(
        explicitProduct: ProductItem? = _snapshot.value.targetedProduct,
        explicitStation: TargetStationType = _snapshot.value.targetedStation,
        explicitNpc: NpcEntity? = _snapshot.value.targetedNpc
    ) {
        // If holding a product and looking at Checkout Belt, place it on the belt!
        if (heldProductId != null && explicitStation == TargetStationType.CHECKOUT_BELT) {
            placeHeldItemOnBelt()
            return
        }

        // If holding a product and looking at Cart/Basket or pressing Put in Cart
        if (heldProductId != null && explicitProduct == null && explicitStation == TargetStationType.NONE) {
            if (hasCart || hasBasket) {
                putHeldItemInCartOrBasket()
            } else {
                dropHeldProductToShelfOrCart()
            }
            return
        }

        if (explicitProduct != null) {
            when (explicitProduct.container) {
                ItemContainer.CART, ItemContainer.BASKET -> {
                    // Remove from cart back to hand
                    setProductContainer(explicitProduct.id, ItemContainer.HAND)
                    heldProductId = explicitProduct.id
                    audioEngine.playGrabClick()
                    showFeedback("Picked up ${explicitProduct.nameEn} from cart", "أخرجت ${explicitProduct.nameAr} من العربة")
                }
                ItemContainer.BELT -> {
                    if (!explicitProduct.isScanned) {
                        scanProductOnBelt(explicitProduct.id)
                    } else {
                        showFeedback("Already scanned: ${explicitProduct.nameEn}", "تم مسح ${explicitProduct.nameAr} مسبقاً")
                    }
                }
                else -> {
                    // Grab from shelf
                    if (heldProductId != null) {
                        // Swap: return previous held item to shelf or cart
                        if (hasCart || hasBasket) putHeldItemInCartOrBasket() else dropHeldProductToShelfOrCart()
                    }
                    setProductContainer(explicitProduct.id, ItemContainer.HAND)
                    heldProductId = explicitProduct.id
                    isInspectingDetails = true
                    audioEngine.playGrabClick()
                    completeMission("mission_first_grab", 15f)
                    showFeedback("Grabbed ${explicitProduct.nameEn}", "أمسكت بـ ${explicitProduct.nameAr}")
                }
            }
            return
        }

        when (explicitStation) {
            TargetStationType.CART_BAY -> {
                hasCart = !hasCart
                if (hasCart) hasBasket = false
                audioEngine.playGrabClick()
                showFeedback(
                    if (hasCart) "Pushing Shopping Cart" else "Parked Shopping Cart",
                    if (hasCart) "أنت تدفع عربة التسوق الآن" else "أعدت عربة التسوق"
                )
            }
            TargetStationType.BASKET_BAY -> {
                hasBasket = !hasBasket
                if (hasBasket) hasCart = false
                audioEngine.playGrabClick()
                showFeedback(
                    if (hasBasket) "Carrying Hand Basket" else "Returned Hand Basket",
                    if (hasBasket) "أنت تحمل سلة تسوق يدوية" else "أعدت السلة اليدوية"
                )
            }
            TargetStationType.CHECKOUT_BELT -> {
                if (heldProductId != null) {
                    placeHeldItemOnBelt()
                } else {
                    moveAllCartItemsToBelt()
                }
            }
            TargetStationType.LASER_SCANNER -> {
                scanNextBeltItem()
            }
            TargetStationType.POS_TERMINAL -> {
                payAtCheckout(byCard = true)
            }
            TargetStationType.BAGGING_ZONE -> {
                bagScannedItems()
            }
            TargetStationType.NONE -> {
                if (explicitNpc != null) {
                    interactWithNpc(explicitNpc)
                }
            }
        }
    }

    fun putHeldItemInCartOrBasket() {
        val id = heldProductId ?: return
        if (!hasCart && !hasBasket) {
            hasBasket = true
        }
        val target = if (hasCart) ItemContainer.CART else ItemContainer.BASKET
        setProductContainer(id, target)
        heldProductId = null
        isInspectingDetails = false
        audioEngine.playPlaceThud()
        val countInCart = worldData.products.count { it.container == ItemContainer.CART || it.container == ItemContainer.BASKET }
        if (countInCart >= 3) {
            completeMission("mission_use_cart", 25f)
        }
        showFeedback("Added to ${if (hasCart) "Cart" else "Basket"} ($countInCart items)", "أضيف إلى ${if (hasCart) "العربة" else "السلة"} ($countInCart)")
    }

    fun removeLastCartItem() {
        val inCart = worldData.products.lastOrNull { it.container == ItemContainer.CART || it.container == ItemContainer.BASKET }
            ?: return
        setProductContainer(inCart.id, ItemContainer.SHELF)
        audioEngine.playGrabClick()
        showFeedback("Removed ${inCart.nameEn} from cart", "أُخرج ${inCart.nameAr} من العربة")
    }

    fun dropHeldProductToShelfOrCart() {
        val id = heldProductId ?: return
        setProductContainer(id, ItemContainer.SHELF)
        heldProductId = null
        isInspectingDetails = false
        audioEngine.playPlaceThud()
    }

    fun placeHeldItemOnBelt() {
        val id = heldProductId ?: return
        val beltCount = worldData.products.count { it.container == ItemContainer.BELT }
        val idx = worldData.products.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val p = worldData.products[idx]
            worldData.products[idx] = p.copy(
                container = ItemContainer.BELT,
                isScanned = false,
                x = 5.2f + (beltCount % 4) * 0.28f,
                y = 1.05f,
                z = 7.3f + (beltCount / 4) * 0.25f
            )
        }
        heldProductId = null
        isInspectingDetails = false
        audioEngine.playPlaceThud()
        showFeedback("Placed on checkout belt — tap Scan!", "وُضع على سير الكاشير — امسحه بالليزر!")
    }

    fun moveAllCartItemsToBelt() {
        val cartItems = worldData.products.filter { it.container == ItemContainer.CART || it.container == ItemContainer.BASKET }
        if (cartItems.isEmpty()) {
            showFeedback("Cart is empty. Grab products first!", "العربة فارغة — التقط منتجات أولاً!", isError = true)
            return
        }
        var offset = worldData.products.count { it.container == ItemContainer.BELT }
        worldData.products.forEachIndexed { idx, p ->
            if (p.container == ItemContainer.CART || p.container == ItemContainer.BASKET) {
                worldData.products[idx] = p.copy(
                    container = ItemContainer.BELT,
                    isScanned = false,
                    x = 5.15f + (offset % 4) * 0.28f,
                    y = 1.05f,
                    z = 7.25f + (offset / 4) * 0.28f
                )
                offset++
            }
        }
        audioEngine.playPlaceThud()
        showFeedback("Placed ${cartItems.size} items on conveyor belt", "تم وضع ${cartItems.size} منتجات على سير الكاشير")
    }

    fun scanNextBeltItem() {
        val unscanned = worldData.products.firstOrNull { it.container == ItemContainer.BELT && !it.isScanned }
        if (unscanned == null) {
            val scannedCount = worldData.products.count { it.container == ItemContainer.BELT && it.isScanned }
            if (scannedCount > 0) {
                showFeedback("All $scannedCount items scanned! Ready to Pay.", "تم مسح جميع المنتجات ($scannedCount)! جاهز للدفع.")
            } else {
                showFeedback("Place items on conveyor belt first", "ضع المنتجات على سير الكاشير أولاً", isError = true)
            }
            return
        }
        scanProductOnBelt(unscanned.id)
    }

    private fun scanProductOnBelt(productId: String) {
        val idx = worldData.products.indexOfFirst { it.id == productId }
        if (idx < 0) return
        val p = worldData.products[idx]
        worldData.products[idx] = p.copy(isScanned = true, x = 6.2f, y = 1.05f, z = 7.5f)
        audioEngine.playBarcodeBeep()
        showFeedback(
            "Scanned: ${p.nameEn} ($${String.format("%.2f", p.effectivePrice)})",
            "تم المسح: ${p.nameAr} ($${String.format("%.2f", p.effectivePrice)})"
        )
    }

    fun payAtCheckout(byCard: Boolean) {
        // Auto-scan any remaining items on belt for smooth VR usability, or require at least 1 belt/cart item
        if (worldData.products.none { it.container == ItemContainer.BELT }) {
            moveAllCartItemsToBelt()
        }
        val beltItems = worldData.products.filter { it.container == ItemContainer.BELT }
        if (beltItems.isEmpty()) {
            audioEngine.playErrorBuzz()
            showFeedback("No items to pay for!", "لا توجد منتجات للدفع!", isError = true)
            return
        }
        // Mark any unscanned belt items scanned with a quick beep
        worldData.products.forEachIndexed { idx, p ->
            if (p.container == ItemContainer.BELT && !p.isScanned) {
                worldData.products[idx] = p.copy(isScanned = true)
            }
        }

        val scanned = worldData.products.filter { it.container == ItemContainer.BELT }
        val total = scanned.sumOf { it.effectivePrice.toDouble() }.toFloat()
        val saved = scanned.sumOf { (it.price - it.effectivePrice).toDouble() }.toFloat()

        if (settings.gameMode == GameMode.BUDGET_CHALLENGE && total > budgetLimit) {
            audioEngine.playErrorBuzz()
            showFeedback(
                "Budget exceeded! Total $${String.format("%.2f", total)} > $${String.format("%.2f", budgetLimit)}",
                "تجاوزت الميزانية! المجموع $${String.format("%.2f", total)} أكبر من $${String.format("%.2f", budgetLimit)}",
                isError = true
            )
            return
        }

        if (total > walletBalance) {
            audioEngine.playErrorBuzz()
            showFeedback("Insufficient wallet funds!", "رصيد المحفظة غير كافٍ!", isError = true)
            return
        }

        walletBalance -= total
        totalCheckouts++
        currentReceipt = ReceiptSummary(
            items = scanned,
            subtotal = total,
            discountSaved = saved,
            paymentMethodLabelEn = if (byCard) "Contactless Card" else "Virtual Cash",
            paymentMethodLabelAr = if (byCard) "بطاقة إلكترونية" else "نقد افتراضي"
        )
        bagScannedItems()
        audioEngine.playPaymentSuccess()
        showFeedback(
            "Paid $${String.format("%.2f", total)}! Exit through glass doors.",
            "تم الدفع $${String.format("%.2f", total)}! خذ الكيس واخرج من الأبواب."
        )
        emitAutoSave()
    }

    fun bagScannedItems() {
        var bagged = 0
        worldData.products.forEachIndexed { idx, p ->
            if (p.container == ItemContainer.BELT && p.isScanned) {
                worldData.products[idx] = p.copy(container = ItemContainer.BAG)
                bagged++
            }
        }
        if (bagged > 0) {
            hasPaidBag = true
            hasCart = false
            hasBasket = false
            audioEngine.playGrabClick()
        }
    }

    fun interactWithNpc(npc: NpcEntity) {
        activeNpcDialogEn = "${npc.nameEn}: ${npc.dialogEn}"
        activeNpcDialogAr = "${npc.nameAr}: ${npc.dialogAr}"
        if (npc.role == NpcRole.INFO_STAFF) {
            completeMission("mission_ask_staff", 15f)
        }
        audioEngine.playGrabClick()
    }

    fun askStaffForProduct(product: ProductItem) {
        activeNpcDialogEn = "Guide: '${product.nameEn}' is located in ${product.aisleLabelEn}."
        activeNpcDialogAr = "المرشدة: تجد '${product.nameAr}' في ${product.aisleLabelAr}."
        completeMission("mission_ask_staff", 15f)
        audioEngine.playGrabClick()
    }

    fun dismissNpcDialog() {
        activeNpcDialogEn = null
        activeNpcDialogAr = null
    }

    fun rotateHeldProduct(deltaYaw: Float, deltaPitch: Float = 0f) {
        inspectYawDeg = (inspectYawDeg + deltaYaw) % 360f
        inspectPitchDeg = (inspectPitchDeg + deltaPitch).coerceIn(-65f, 65f)
    }

    fun toggleInspectDetails() {
        isInspectingDetails = !isInspectingDetails
    }

    fun toggleCartHold() {
        hasCart = !hasCart
        if (hasCart) hasBasket = false
        audioEngine.playGrabClick()
    }

    fun toggleBasketHold() {
        hasBasket = !hasBasket
        if (hasBasket) hasCart = false
        audioEngine.playGrabClick()
    }

    fun toggleFlyMode(enabled: Boolean = !isFlyMode) {
        isFlyMode = enabled
        if (isFlyMode) {
            isCrouching = false
            showFeedback("Fly Mode ON (${flySpeed.name})", "تم تفعيل وضع الطيران (${flySpeedLabelAr(flySpeed)})")
        } else {
            showFeedback("Fly Mode OFF", "تم إيقاف وضع الطيران")
        }
        audioEngine.playGrabClick()
        _snapshot.value = _snapshot.value.copy(isFlyMode = isFlyMode, flySpeed = flySpeed)
    }

    fun cycleFlySpeed() {
        flySpeed = when (flySpeed) {
            FlySpeed.SLOW -> FlySpeed.NORMAL
            FlySpeed.NORMAL -> FlySpeed.FAST
            FlySpeed.FAST -> FlySpeed.SLOW
        }
        showFeedback("Fly Speed: ${flySpeed.name}", "سرعة الطيران: ${flySpeedLabelAr(flySpeed)}")
        _snapshot.value = _snapshot.value.copy(flySpeed = flySpeed)
    }

    private fun flySpeedLabelAr(s: FlySpeed): String = when (s) {
        FlySpeed.SLOW -> "بطيء"
        FlySpeed.NORMAL -> "متوسط"
        FlySpeed.FAST -> "سريع"
    }

    fun toggleCrouch() {
        isCrouching = !isCrouching
    }

    fun toggleSprint() {
        isSprinting = !isSprinting
    }

    fun resetManualLook() {
        manualYawDeg = worldData.spawnYawDeg
        manualPitchDeg = 0f
        showFeedback("View centered", "تم توسيط الرؤية للأمام")
    }

    fun executeTeleportIfReady() {
        val snap = _snapshot.value
        if (snap.teleportActive) {
            playerX = snap.teleportTargetX
            playerZ = snap.teleportTargetZ
            audioEngine.playFootstep()
        }
    }

    fun toggleShoppingList() {
        _snapshot.value = _snapshot.value.copy(
            showShoppingListOverlay = !_snapshot.value.showShoppingListOverlay,
            showMissionsOverlay = false
        )
    }

    fun toggleMissionsOverlay() {
        _snapshot.value = _snapshot.value.copy(
            showMissionsOverlay = !_snapshot.value.showMissionsOverlay,
            showShoppingListOverlay = false
        )
    }

    fun dismissReceipt() {
        currentReceipt = null
    }

    private fun nudgeCartForward() {
        val fwd = GlMath.forwardVectorXZ(manualYawDeg + if (headTracker.hasSensorData) headTracker.getCalibratedYawDeg() else 0f)
        movePlayerWithCollisions(fwd[0] * 0.45f, fwd[2] * 0.45f)
        audioEngine.playCartRoll()
    }

    private fun handleXboxAction(action: XboxAction) {
        // When Fly Mode is active, A (Cross) & B (Circle) are held to ascend/descend without hijacking held items
        if (isFlyMode && (action == XboxAction.INTERACT_GRAB || action == XboxAction.CANCEL_BACK)) {
            return
        }
        when (action) {
            XboxAction.INTERACT_GRAB -> {
                if (settings.controls.movementMode == MovementMode.TELEPORT && _snapshot.value.teleportActive &&
                    _snapshot.value.targetedProduct == null && _snapshot.value.targetedStation == TargetStationType.NONE
                ) {
                    executeTeleportIfReady()
                } else {
                    performPrimaryInteraction()
                }
            }
            XboxAction.CANCEL_BACK -> {
                when {
                    activeNpcDialogEn != null -> dismissNpcDialog()
                    currentReceipt != null -> dismissReceipt()
                    heldProductId != null -> dropHeldProductToShelfOrCart()
                }
            }
            XboxAction.USE_INSPECT -> {
                if (heldProductId != null) {
                    if (hasCart || hasBasket) putHeldItemInCartOrBasket() else toggleInspectDetails()
                } else {
                    scanNextBeltItem()
                }
            }
            XboxAction.INVENTORY_LIST -> toggleShoppingList()
            XboxAction.CART_HOLD_PUSH -> toggleCartHold()
            XboxAction.SPRINT_CROUCH -> toggleCrouch()
        }
    }

    private fun movePlayerWithCollisions(dx: Float, dz: Float) {
        val activeColliders = ArrayList<Aabb>(worldData.solidColliders)
        if (worldData.worldType != WorldType.CUSTOM_IMPORTED && doorOpenAmount < 0.65f) {
            // Closed glass doors block entrance
            activeColliders.add(Aabb(-2.6f, 0f, 11.85f, 2.6f, 3.0f, 12.15f))
        }
        val (nx, nz) = GlMath.resolveCircleAabbXZ(playerX + dx, playerZ + dz, 0.42f, activeColliders)
        playerX = nx
        playerZ = nz
    }

    private fun updateNpcs(dt: Float) {
        val npcs = worldData.npcs
        for (i in npcs.indices) {
            val npc = npcs[i]
            if (npc.speed <= 0.01f) continue

            val dx = npc.targetX - npc.x
            val dz = npc.targetZ - npc.z
            val dist = hypot(dx.toDouble(), dz.toDouble()).toFloat()
            if (dist < 0.35f) {
                // Swap patrol target
                val nextTarget = when (npc.role) {
                    NpcRole.STOCK_CLERK -> if (npc.targetZ < -5f) (-6.8f to -1.5f) else (-6.8f to -12.0f)
                    NpcRole.CART_SHOPPER -> if (npc.targetZ > 0f) (-1.3f to -7.2f) else (-1.3f to 2.2f)
                    else -> if (npc.targetZ < -4f) (5.2f to 2.5f) else (5.2f to -7.2f)
                }
                npc.targetX = nextTarget.first
                npc.targetZ = nextTarget.second
            } else {
                var vx = (dx / dist) * npc.speed
                var vz = (dz / dist) * npc.speed

                // Avoid player and other NPCs
                val pdx = npc.x - playerX
                val pdz = npc.z - playerZ
                val pDist = hypot(pdx.toDouble(), pdz.toDouble()).toFloat()
                if (pDist in 0.05f..1.25f) {
                    vx += (pdx / pDist) * 0.9f
                    vz += (pdz / pDist) * 0.9f
                }
                for (j in npcs.indices) {
                    if (i == j) continue
                    val other = npcs[j]
                    val odx = npc.x - other.x
                    val odz = npc.z - other.z
                    val oDist = hypot(odx.toDouble(), odz.toDouble()).toFloat()
                    if (oDist in 0.05f..1.1f) {
                        vx += (odx / oDist) * 0.8f
                        vz += (odz / oDist) * 0.8f
                    }
                }
                val vLen = sqrt(vx * vx + vz * vz).coerceAtLeast(1e-4f)
                npc.x += (vx / vLen) * npc.speed * dt
                npc.z += (vz / vLen) * npc.speed * dt
                npc.yawDeg = Math.toDegrees(atan2(-vx.toDouble(), -vz.toDouble())).toFloat()
            }
        }
    }

    private fun setProductContainer(id: String, container: ItemContainer) {
        val idx = worldData.products.indexOfFirst { it.id == id }
        if (idx >= 0) {
            worldData.products[idx] = worldData.products[idx].copy(container = container)
        }
    }

    private fun completeMission(missionId: String, reward: Float) {
        if (completedMissions.add(missionId)) {
            walletBalance += reward
            audioEngine.playPaymentSuccess()
            emitAutoSave()
        }
    }

    private fun showFeedback(en: String, ar: String, isError: Boolean = false) {
        feedbackEn = en
        feedbackAr = ar
        feedbackError = isError
        feedbackTimerSec = 3.2f
    }

    fun emitAutoSave() {
        val cartIds = worldData.products
            .filter { it.container == ItemContainer.CART || it.container == ItemContainer.BASKET }
            .map { it.id }
        val scannedIds = worldData.products
            .filter { it.container == ItemContainer.BELT && it.isScanned }
            .map { it.id }
        onAutoSave(
            SaveGameState(
                activeWorldId = activeWorldId,
                gameMode = settings.gameMode,
                walletBalance = walletBalance,
                budgetLimit = budgetLimit,
                playerX = playerX,
                playerZ = playerZ,
                playerYawDeg = manualYawDeg,
                isCrouching = isCrouching,
                hasCart = hasCart,
                hasBasket = hasBasket,
                hasPaidBag = hasPaidBag,
                cartProductIds = cartIds,
                scannedProductIds = scannedIds,
                completedMissions = completedMissions.toList(),
                totalCheckoutsCompleted = totalCheckouts
            )
        )
    }

    private fun publishSnapshot(
        targetedProduct: ProductItem?,
        targetedStation: TargetStationType,
        targetedNpc: NpcEntity?,
        gazeProgress: Float,
        teleportActive: Boolean,
        teleportX: Float,
        teleportZ: Float,
        measuredFps: Int
    ) {
        val headYaw = if (headTracker.hasSensorData) headTracker.getCalibratedYawDeg() else 0f
        val headPitch = if (headTracker.hasSensorData) headTracker.pitchDeg else 0f
        val roll = if (headTracker.hasSensorData) headTracker.rollDeg else 0f
        val held = heldProductId?.let { id -> worldData.products.find { it.id == id } }
        val cartList = worldData.products.filter { it.container == ItemContainer.CART || it.container == ItemContainer.BASKET }
        val beltList = worldData.products.filter { it.container == ItemContainer.BELT }
        val scannedList = beltList.filter { it.isScanned }
        val missionList = WorldCatalog.defaultMissions.map { it.copy(isCompleted = it.id in completedMissions) }

        _snapshot.value = _snapshot.value.copy(
            worldType = worldData.worldType,
            playerX = playerX,
            playerY = playerFeetY + (if (isCrouching && !isFlyMode) 1.05f else 1.65f),
            playerZ = playerZ,
            yawDeg = headYaw + manualYawDeg,
            pitchDeg = (headPitch + manualPitchDeg).coerceIn(-80f, 80f),
            rollDeg = roll,
            isCrouching = isCrouching,
            isSprinting = isSprinting || xboxManager.snapshot.value.isSprintHeld || touchSprintHeld,
            isFlyMode = isFlyMode,
            flySpeed = flySpeed,
            doorOpenAmount = doorOpenAmount,
            targetedProduct = targetedProduct,
            targetedStation = targetedStation,
            targetedNpc = targetedNpc,
            gazeDwellProgress = gazeProgress,
            heldProduct = held,
            inspectYawDeg = inspectYawDeg,
            inspectPitchDeg = inspectPitchDeg,
            isInspectingDetails = isInspectingDetails,
            hasCart = hasCart,
            hasBasket = hasBasket,
            hasPaidBag = hasPaidBag,
            cartItems = cartList,
            beltItems = beltList,
            scannedItems = scannedList,
            walletBalance = walletBalance,
            budgetLimit = budgetLimit,
            gameMode = settings.gameMode,
            receipt = currentReceipt,
            activeNpcDialogEn = activeNpcDialogEn,
            activeNpcDialogAr = activeNpcDialogAr,
            missions = missionList,
            teleportActive = teleportActive,
            teleportTargetX = teleportX,
            teleportTargetZ = teleportZ,
            feedbackEn = feedbackEn,
            feedbackAr = feedbackAr,
            feedbackIsError = feedbackError,
            measuredFps = measuredFps,
            totalCheckoutsCompleted = totalCheckouts
        )
    }

    fun release() {
        lastXboxActionListener?.let { xboxManager.removeActionListener(it) }
        lastFlyToggleListener?.let { xboxManager.removeFlyToggleListener(it) }
    }
}
