package com.example.vr.model

import kotlinx.serialization.Serializable

@Serializable
enum class ControlScheme {
    GAZE,
    XBOX_CONTROLLER,
    HAND_TRACKING
}

@Serializable
enum class MovementMode {
    SMOOTH,
    TELEPORT
}

@Serializable
enum class GraphicsQuality {
    LOW,
    MEDIUM,
    HIGH
}

@Serializable
enum class TargetFps(val fps: Int) {
    FPS_30(30),
    FPS_45(45),
    FPS_60(60)
}

@Serializable
enum class AppLanguage {
    ARABIC,
    ENGLISH
}

@Serializable
enum class TimeOfDay {
    MORNING,
    NOON,
    SUNSET,
    NIGHT
}

@Serializable
enum class WeatherType {
    CLEAR,
    RAIN,
    FOG
}

@Serializable
enum class GameMode {
    SANDBOX,
    BUDGET_CHALLENGE
}

@Serializable
enum class TextureQuality(val maxDimensionPx: Int) {
    LOW_512(512),
    MEDIUM_1024(1024),
    HIGH_2048(2048)
}

@Serializable
enum class FlySpeed(val metersPerSec: Float) {
    SLOW(2.6f),
    NORMAL(6.0f),
    FAST(13.0f)
}

@Serializable
enum class FlyToggleButton {
    DOUBLE_A_CROSS,
    DOUBLE_Y_TRIANGLE,
    LB_L1,
    RB_R1
}

@Serializable
enum class XboxAction {
    INTERACT_GRAB,
    CANCEL_BACK,
    USE_INSPECT,
    INVENTORY_LIST,
    CART_HOLD_PUSH,
    SPRINT_CROUCH
}

@Serializable
data class XboxButtonMapping(
    val buttonA: XboxAction = XboxAction.INTERACT_GRAB,
    val buttonB: XboxAction = XboxAction.CANCEL_BACK,
    val buttonX: XboxAction = XboxAction.USE_INSPECT,
    val buttonY: XboxAction = XboxAction.INVENTORY_LIST,
    val leftTrigger: XboxAction = XboxAction.CART_HOLD_PUSH,
    val rightTrigger: XboxAction = XboxAction.SPRINT_CROUCH
)

@Serializable
data class VrSettingsState(
    val fovDegrees: Float = 80f,
    val ipdMm: Float = 63f,
    val lensDistortionEnabled: Boolean = true,
    val distortionK1: Float = 0.14f,
    val chromaticAberrationEnabled: Boolean = true,
    val imageScale: Float = 0.94f,
    val eyeSeparationOffset: Float = 0.0f,
    val sideBySideEnabled: Boolean = true,
    val fixedVrBoxMode: Boolean = true,
    val horizonLockEnabled: Boolean = true,
    val yawZeroOffsetDeg: Float = 0f
)

@Serializable
data class GraphicsSettingsState(
    val quality: GraphicsQuality = GraphicsQuality.MEDIUM,
    val textureQuality: TextureQuality = TextureQuality.MEDIUM_1024,
    val targetFps: TargetFps = TargetFps.FPS_60,
    val shadowsEnabled: Boolean = true,
    val reflectionsEnabled: Boolean = true,
    val hudScale: Float = 1.0f,
    val hudVerticalOffset: Float = 0.0f,
    val sfxEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val timeOfDay: TimeOfDay = TimeOfDay.NOON,
    val weather: WeatherType = WeatherType.CLEAR
)

@Serializable
data class ControlsSettingsState(
    val activeScheme: ControlScheme = ControlScheme.GAZE,
    val movementMode: MovementMode = MovementMode.SMOOTH,
    val moveSpeed: Float = 3.2f,
    val turnSensitivity: Float = 1.1f,
    val gazeDwellSeconds: Float = 1.3f,
    val handTrackingSensitivity: Float = 0.72f,
    val handUseFrontCamera: Boolean = false,
    val handCalibrationScale: Float = 1.0f,
    val flyToggleButton: FlyToggleButton = FlyToggleButton.DOUBLE_A_CROSS,
    val defaultFlySpeed: FlySpeed = FlySpeed.NORMAL,
    val xboxMapping: XboxButtonMapping = XboxButtonMapping()
)

@Serializable
data class AllSettingsState(
    val language: AppLanguage = AppLanguage.ARABIC,
    val vr: VrSettingsState = VrSettingsState(),
    val graphics: GraphicsSettingsState = GraphicsSettingsState(),
    val controls: ControlsSettingsState = ControlsSettingsState(),
    val gameMode: GameMode = GameMode.SANDBOX
)

@Serializable
enum class ProductCategory {
    PRODUCE,
    DAIRY_DRINKS,
    MEAT_POULTRY,
    BAKERY,
    SWEETS_CHOCOLATE,
    ELECTRONICS_HOME,
    GROCERY_PANTRY
}

@Serializable
enum class ProductMeshShape {
    BOX,
    BOTTLE,
    CAN,
    SPHERE_FRUIT,
    LOAF,
    BAR,
    DEVICE
}

@Serializable
enum class ItemContainer {
    SHELF,
    HAND,
    CART,
    BASKET,
    BELT,
    BAG
}

@Serializable
data class ProductItem(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val category: ProductCategory,
    val price: Float,
    val discountPercent: Int = 0,
    val barcode: String,
    val weightGrams: Int,
    val ingredientsEn: String,
    val ingredientsAr: String,
    val meshShape: ProductMeshShape,
    val primaryColorArgb: Long,
    val accentColorArgb: Long,
    val x: Float,
    val y: Float,
    val z: Float,
    val aisleLabelEn: String,
    val aisleLabelAr: String,
    val isScanned: Boolean = false,
    val container: ItemContainer = ItemContainer.SHELF
) {
    val effectivePrice: Float
        get() = if (discountPercent > 0) price * (1f - discountPercent / 100f) else price
}

@Serializable
enum class WorldType {
    GRAND_SUPERMARKET,
    MINI_MARKET,
    SHOPPING_MALL,
    ELECTRONICS_STORE,
    FAST_FOOD_DINER,
    GAS_STATION_MART,
    CLOTHING_STORE,
    CARGO_WAREHOUSE,
    TOY_STORE,
    SMALL_TOWN,
    CUSTOM_IMPORTED
}

@Serializable
data class WorldEntry(
    val id: String,
    val type: WorldType,
    val titleEn: String,
    val titleAr: String,
    val descEn: String,
    val descAr: String,
    val fileSizeMb: Float,
    val rating: Float,
    val isBuiltIn: Boolean = false,
    val isDownloaded: Boolean = false,
    val isCustomImported: Boolean = false,
    val sourceLabel: String = "Built-in",
    val formatLabel: String = "VR-3D",
    val customAssetPath: String? = null,
    val vertexCount: Int = 0,
    val thumbnailKey: String = "supermarket"
)

@Serializable
enum class NpcRole {
    CASHIER,
    STOCK_CLERK,
    SHOPPER,
    CART_SHOPPER,
    INFO_STAFF
}

data class NpcEntity(
    val id: String,
    val role: NpcRole,
    val nameEn: String,
    val nameAr: String,
    var x: Float,
    var z: Float,
    var yawDeg: Float,
    val speed: Float,
    var targetX: Float,
    var targetZ: Float,
    val shirtColorArgb: Long,
    val hasCart: Boolean = false,
    val dialogEn: String,
    val dialogAr: String
)

@Serializable
data class MissionEntry(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val rewardCoins: Float,
    val isCompleted: Boolean = false
)

@Serializable
data class SaveGameState(
    val activeWorldId: String = "world_grand_supermarket",
    val gameMode: GameMode = GameMode.SANDBOX,
    val walletBalance: Float = 250.0f,
    val budgetLimit: Float = 85.0f,
    val playerX: Float = 0f,
    val playerZ: Float = 15.5f,
    val playerYawDeg: Float = 0f,
    val isCrouching: Boolean = false,
    val hasCart: Boolean = false,
    val hasBasket: Boolean = false,
    val hasPaidBag: Boolean = false,
    val cartProductIds: List<String> = emptyList(),
    val scannedProductIds: List<String> = emptyList(),
    val completedMissions: List<String> = emptyList(),
    val totalCheckoutsCompleted: Int = 0,
    val timestampMs: Long = 0L
)

enum class HandGesture {
    NONE,
    OPEN_HAND,
    FIST,
    POINT_INDEX,
    PINCH_SELECT,
    INDEX_PRESS,
    PUSH_FORWARD
}

enum class HandTrackingHealth {
    INACTIVE,
    PERMISSION_REQUIRED,
    MODEL_MISSING,
    VR_BOX_OCCLUDED,
    NO_HAND_VISIBLE,
    TRACKING_ACTIVE
}

data class HandLandmarkPoint(
    val x: Float,
    val y: Float,
    val z: Float
)

data class HandTrackingState(
    val health: HandTrackingHealth = HandTrackingHealth.INACTIVE,
    val gesture: HandGesture = HandGesture.NONE,
    val pointerX: Float = 0.5f,
    val pointerY: Float = 0.5f,
    val averageLuma: Float = 0f,
    val modelDownloaded: Boolean = false,
    val modelDownloadProgress: Float? = null,
    val landmarks: List<HandLandmarkPoint> = emptyList(),
    val statusNoteEn: String = "",
    val statusNoteAr: String = ""
)

@Serializable
data class Transform3D(
    val posX: Float = 0f,
    val posY: Float = 0f,
    val posZ: Float = 0f,
    val rotX: Float = 0f,
    val rotY: Float = 0f,
    val rotZ: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val scaleZ: Float = 1f
)

@Serializable
enum class WorldObjectCategory {
    BUILDINGS,
    ENVIRONMENT,
    FURNITURE,
    LIGHTS,
    SPAWN_POINTS,
    IMPORTED_MODELS,
    GROUP
}

@Serializable
enum class AlphaMode {
    OPAQUE,
    MASK,
    BLEND
}

@Serializable
data class PbrMaterialSpec(
    val id: String,
    val name: String,
    val baseColorArgb: Long = 0xFFFFFFFF,
    val metallic: Float = 0.05f,
    val roughness: Float = 0.72f,
    val alpha: Float = 1.0f,
    val alphaMode: AlphaMode = AlphaMode.OPAQUE,
    val alphaCutoff: Float = 0.45f,
    val emissiveStrength: Float = 0.0f,
    val emissiveColorArgb: Long = 0xFF000000,
    val reflectivity: Float = 0.25f,
    val texturePath: String? = null,
    val normalTexturePath: String? = null,
    val aoTexturePath: String? = null,
    val emissiveTexturePath: String? = null,
    val missingTextureName: String? = null,
    val isOriginalIntact: Boolean = true,
    val userModified: Boolean = false
)

@Serializable
data class ImportDiagnosticReport(
    val totalSubMeshes: Int = 0,
    val totalVertices: Int = 0,
    val totalMaterials: Int = 0,
    val texturesExtracted: Int = 0,
    val missingTextures: List<String> = emptyList(),
    val missingMtlFiles: List<String> = emptyList(),
    val invalidUvMeshNames: List<String> = emptyList(),
    val invertedNormalMeshNames: List<String> = emptyList(),
    val abnormalScaleNotes: List<String> = emptyList(),
    val outOfBoundsMeshNames: List<String> = emptyList(),
    val fixesApplied: List<String> = emptyList(),
    val summaryEn: String = "",
    val summaryAr: String = ""
)

data class WorldSubMeshData(
    val name: String,
    val nodeName: String,
    val materialIndex: Int,
    /** Interleaved 12 floats per vertex: pos(3), norm(3), uv(2), color(4) */
    val interleavedVertices: FloatArray,
    val vertexCount: Int,
    val boundsMin: FloatArray,
    val boundsMax: FloatArray,
    val categoryHint: WorldObjectCategory = WorldObjectCategory.IMPORTED_MODELS,
    val hasValidUvs: Boolean = true
)

data class ImportedMeshData(
    val name: String,
    val positions: FloatArray,
    val normals: FloatArray,
    val vertexCount: Int,
    val boundsMin: FloatArray,
    val boundsMax: FloatArray,
    val subMeshes: List<WorldSubMeshData> = emptyList(),
    val materials: List<PbrMaterialSpec> = emptyList(),
    val diagnostics: ImportDiagnosticReport = ImportDiagnosticReport(),
    val normalizationScale: Float = 1f
)

@Serializable
data class SpawnPointEntry(
    val id: String,
    val name: String,
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 10f,
    val yawDeg: Float = 0f,
    val elevationOffset: Float = 0f,
    val isPrimary: Boolean = false
)

@Serializable
data class WorldLightingConfig(
    val directionalIntensity: Float = 1.0f,
    val directionalAngleDeg: Float = 42f,
    val ambientIntensity: Float = 0.48f,
    val timeOfDay: TimeOfDay = TimeOfDay.NOON,
    val fogEnabled: Boolean = true,
    val fogDensity: Float = 0.008f,
    val shadowsEnabled: Boolean = true,
    val reflectionsEnabled: Boolean = true,
    val exposure: Float = 1.0f
)

@Serializable
data class WorldNodeEntry(
    val id: String,
    val name: String,
    val parentId: String? = null,
    val category: WorldObjectCategory = WorldObjectCategory.IMPORTED_MODELS,
    val assetPath: String? = null,
    val subMeshStartIdx: Int = -1,
    val subMeshEndIdx: Int = -1,
    val transform: Transform3D = Transform3D(),
    val materialOverrides: Map<String, PbrMaterialSpec> = emptyMap(),
    val collisionEnabled: Boolean = true,
    val visible: Boolean = true,
    val isGroup: Boolean = false,
    val localMinX: Float = -1f,
    val localMinY: Float = 0f,
    val localMinZ: Float = -1f,
    val localMaxX: Float = 1f,
    val localMaxY: Float = 2f,
    val localMaxZ: Float = 1f
)

@Serializable
data class WorldProjectState(
    val worldId: String,
    val titleEn: String,
    val titleAr: String,
    val rootAssetPath: String = "",
    val worldTransform: Transform3D = Transform3D(),
    val nodes: List<WorldNodeEntry> = emptyList(),
    val materials: List<PbrMaterialSpec> = emptyList(),
    val spawnPoints: List<SpawnPointEntry> = listOf(
        SpawnPointEntry(
            id = "spawn_main",
            name = "Main Entrance",
            x = 0f,
            y = 0f,
            z = 12f,
            yawDeg = 0f,
            elevationOffset = 0f,
            isPrimary = true
        )
    ),
    val lighting: WorldLightingConfig = WorldLightingConfig(),
    val collisionEnabled: Boolean = true,
    val diagnostics: ImportDiagnosticReport = ImportDiagnosticReport(),
    val lastModifiedMs: Long = 0L
)
