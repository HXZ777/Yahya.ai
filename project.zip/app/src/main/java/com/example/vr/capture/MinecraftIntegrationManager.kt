package com.example.vr.capture

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.example.vr.model.MinecraftAppStatus

object MinecraftIntegrationManager {

    const val MINECRAFT_BEDROCK_PACKAGE = "com.mojang.minecraftpe"
    const val MINECRAFT_TRIAL_PACKAGE = "com.mojang.minecrafttrialpe"

    fun inspectInstallation(context: Context): MinecraftAppStatus {
        val pm = context.packageManager
        val fullInfo = getPackageInfoSafe(pm, MINECRAFT_BEDROCK_PACKAGE)
        if (fullInfo != null) {
            return MinecraftAppStatus(
                isInstalled = true,
                isTrialOnly = false,
                packageName = MINECRAFT_BEDROCK_PACKAGE,
                versionName = fullInfo.versionName ?: "Installed"
            )
        }
        val trialInfo = getPackageInfoSafe(pm, MINECRAFT_TRIAL_PACKAGE)
        if (trialInfo != null) {
            return MinecraftAppStatus(
                isInstalled = true,
                isTrialOnly = true,
                packageName = MINECRAFT_TRIAL_PACKAGE,
                versionName = trialInfo.versionName ?: "Trial"
            )
        }
        return MinecraftAppStatus(isInstalled = false)
    }

    fun launchMinecraft(context: Context, splitScreenAdjacent: Boolean = false): Boolean {
        val status = inspectInstallation(context)
        if (!status.isInstalled) return false
        val launchIntent = context.packageManager.getLaunchIntentForPackage(status.packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (splitScreenAdjacent && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
        }
        return runCatching {
            context.startActivity(launchIntent)
            true
        }.getOrDefault(false)
    }

    fun resolveLaunchComponent(context: Context, packageName: String): String? {
        if (packageName.isBlank()) return null
        val launchIntent = runCatching {
            context.packageManager.getLaunchIntentForPackage(packageName)
        }.getOrNull() ?: return null
        return launchIntent.component?.flattenToShortString()
    }

    @Suppress("DEPRECATION")
    private fun getPackageInfoSafe(pm: PackageManager, pkg: String) = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
        } else {
            pm.getPackageInfo(pkg, 0)
        }
    }.getOrNull()
}
