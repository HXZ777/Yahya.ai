package com.example.vr.world

import com.example.vr.model.MissionEntry
import com.example.vr.model.WorldEntry
import com.example.vr.model.WorldType

data class OpenAssetSourceInfo(
    val name: String,
    val licenseNoteEn: String,
    val licenseNoteAr: String,
    val supportedFormats: String,
    val url: String
)

object WorldCatalog {

    val openSources: List<OpenAssetSourceInfo> = listOf(
        OpenAssetSourceInfo(
            name = "Sketchfab",
            licenseNoteEn = "Creative Commons 3D models — export as GLB / glTF",
            licenseNoteAr = "نماذج ثلاثية الأبعاد بترخيص المشاع الإبداعي — صدّر بصيغة GLB / glTF",
            supportedFormats = "GLB, glTF",
            url = "https://sketchfab.com/features/gltf"
        ),
        OpenAssetSourceInfo(
            name = "Poly Haven",
            licenseNoteEn = "CC0 public domain 3D assets & PBR environments",
            licenseNoteAr = "أصول وخامات مجانية بالكامل (CC0)",
            supportedFormats = "GLB, glTF, OBJ",
            url = "https://polyhaven.com/models"
        ),
        OpenAssetSourceInfo(
            name = "Kenney",
            licenseNoteEn = "CC0 modular game packs (City, Food, Furniture)",
            licenseNoteAr = "حزم ألعاب مجانية (أطعمة، مدن، أثاث)",
            supportedFormats = "GLB, OBJ, ZIP",
            url = "https://kenney.nl/assets"
        ),
        OpenAssetSourceInfo(
            name = "OpenGameArt",
            licenseNoteEn = "Community CC-BY / CC0 3D props and scenes",
            licenseNoteAr = "أصول ألعاب متنوعة مفتوحة الترخيص",
            supportedFormats = "OBJ, glTF, ZIP",
            url = "https://opengameart.org"
        ),
        OpenAssetSourceInfo(
            name = "ambientCG",
            licenseNoteEn = "CC0 PBR materials & architectural surfaces",
            licenseNoteAr = "خامات ومواد واقعية عالية الدقة CC0",
            supportedFormats = "ZIP, PBR",
            url = "https://ambientcg.com"
        ),
        OpenAssetSourceInfo(
            name = "itch.io",
            licenseNoteEn = "Indie 3D asset packs & compatible world ZIPs",
            licenseNoteAr = "حزم أصول وألعاب مستقلة جاهزة للاستيراد",
            supportedFormats = "GLB, OBJ, ZIP",
            url = "https://itch.io/game-assets/free"
        ),
        OpenAssetSourceInfo(
            name = "OpenStreetMap",
            licenseNoteEn = "ODbL map geometry exported via OSM2World / glTF",
            licenseNoteAr = "بيانات جغرافية لبناء شوارع ومدن حقيقية",
            supportedFormats = "OBJ, glTF",
            url = "https://www.openstreetmap.org"
        )
    )

    val builtInWorlds: List<WorldEntry> = listOf(
        WorldEntry(
            id = "world_grand_supermarket",
            type = WorldType.GRAND_SUPERMARKET,
            titleEn = "Grand VR Supermarket",
            titleAr = "السوبر ماركت الكبير",
            descEn = "Full hypermarket with automatic glass doors, produce, coolers, bakery, meat, sweets, electronics, backroom, office, checkouts, and parking street.",
            descAr = "سوبر ماركت متكامل بأبواب زجاجية تلقائية، خضروات، ثلاجات، مخبوزات، لحوم، حلويات، إلكترونيات، مستودع خلفي، مكتب، كاشيرات ومواقف سيارات.",
            fileSizeMb = 18.4f,
            rating = 4.9f,
            isBuiltIn = true,
            isDownloaded = true,
            sourceLabel = "Core World",
            formatLabel = "VR-3D",
            thumbnailKey = "supermarket"
        ),
        WorldEntry(
            id = "world_mini_market",
            type = WorldType.MINI_MARKET,
            titleEn = "Neighborhood Mini Market",
            titleAr = "متجر الحي الصغير",
            descEn = "Cozy 24/7 corner grocery with compact snack aisles, chilled drinks, express cashier counter, and sidewalk exterior.",
            descAr = "متجر حي دافئ بممرات مدمجة، ثلاجات مشروبات، كاشير سريع وشارع جانبي.",
            fileSizeMb = 7.8f,
            rating = 4.7f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "supermarket"
        ),
        WorldEntry(
            id = "world_shopping_mall",
            type = WorldType.SHOPPING_MALL,
            titleEn = "Grand Atrium Shopping Mall",
            titleAr = "المول التجاري المركزي",
            descEn = "Spacious sunlit commercial atrium with boutique storefronts, central fountain plaza, and multi-shop checkout counters.",
            descAr = "مول تجاري واسع بساحة مضيئة وواجهات متاجر زجاجية ونقاط دفع متعددة.",
            fileSizeMb = 24.2f,
            rating = 4.8f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "mall"
        ),
        WorldEntry(
            id = "world_electronics_store",
            type = WorldType.ELECTRONICS_STORE,
            titleEn = "Nova Electronics Boutique",
            titleAr = "متجر الإلكترونيات",
            descEn = "Interactive tech showroom featuring laptops, VR headsets, audio speakers, smartphones, and smart home checkout.",
            descAr = "معرض تقني تفاعلي للحواسيب، السماعات، الهواتف والأجهزة الذكية.",
            fileSizeMb = 11.5f,
            rating = 4.8f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "mall"
        ),
        WorldEntry(
            id = "world_fast_food_diner",
            type = WorldType.FAST_FOOD_DINER,
            titleEn = "Metro Fast Food Diner",
            titleAr = "مطعم الوجبات السريعة",
            descEn = "Order burgers, fries, drinks and fresh combo boxes at the counter, pick up trays, and dine inside or outside.",
            descAr = "مطعم وجبات سريعة مع كاونتر طلبات، صواني طعام، وجلسات داخلية وخارجية.",
            fileSizeMb = 9.4f,
            rating = 4.6f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "town"
        ),
        WorldEntry(
            id = "world_gas_station_mart",
            type = WorldType.GAS_STATION_MART,
            titleEn = "Highway Gas Station & Mart",
            titleAr = "محطة الوقود والمتجر",
            descEn = "Explore outdoor fuel pumps, canopy lights, parked cars, and the attached travel convenience mart.",
            descAr = "مضخات وقود خارجية ومظلة مضيئة وسيارات ومتجر مسافرين متكامل.",
            fileSizeMb = 12.1f,
            rating = 4.7f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "town"
        ),
        WorldEntry(
            id = "world_clothing_store",
            type = WorldType.CLOTHING_STORE,
            titleEn = "Urban Apparel Store",
            titleAr = "متجر الملابس والأزياء",
            descEn = "Display racks, folded apparel boxes, footwear stands, and boutique checkout desk.",
            descAr = "منصات عرض الأزياء، صناديق الأحذية، ورفوف الملابس مع كاشير أنيق.",
            fileSizeMb = 10.2f,
            rating = 4.5f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "mall"
        ),
        WorldEntry(
            id = "world_cargo_warehouse",
            type = WorldType.CARGO_WAREHOUSE,
            titleEn = "Logistics Cargo Warehouse",
            titleAr = "مستودع البضائع الكبير",
            descEn = "Industrial high-bay pallet racks, bulk crates, dispatch scanner desk, and loading bay doors.",
            descAr = "مستودع صناعي ضخم برفوف شحن عالية وصناديق جملة ومحطة جرد.",
            fileSizeMb = 14.0f,
            rating = 4.6f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "supermarket"
        ),
        WorldEntry(
            id = "world_toy_store",
            type = WorldType.TOY_STORE,
            titleEn = "Wonderland Toy Store",
            titleAr = "متجر الألعاب",
            descEn = "Colorful shelves stocked with collectible boxes, board games, plush blocks, and gift checkout.",
            descAr = "رفوف ملونة مليئة بصناديق الألعاب والهدايا ومنضدة تغليف ودفع.",
            fileSizeMb = 9.9f,
            rating = 4.8f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "mall"
        ),
        WorldEntry(
            id = "world_small_town",
            type = WorldType.SMALL_TOWN,
            titleEn = "Explorable VR Small Town",
            titleAr = "مدينة صغيرة قابلة للاستكشاف",
            descEn = "Open street block linking a corner store, fuel pumps, cafe stalls, street lamps, trees, and day/night weather.",
            descAr = "حي مدينة مفتوح يربط بين متجر ومحطة وقود ومقهى وأشجار وإنارة شوارع مع دعم الليل والنهار.",
            fileSizeMb = 26.8f,
            rating = 4.9f,
            isBuiltIn = false,
            sourceLabel = "Official Pack",
            formatLabel = "VR-3D",
            thumbnailKey = "town"
        )
    )

    val defaultMissions: List<MissionEntry> = listOf(
        MissionEntry(
            id = "mission_first_grab",
            titleEn = "Inspect & pick up any 3D product",
            titleAr = "افحص والتقط أي منتج ثلاثي الأبعاد",
            rewardCoins = 15f
        ),
        MissionEntry(
            id = "mission_use_cart",
            titleEn = "Grab a shopping cart or basket & add 3 items",
            titleAr = "استخدم عربة تسوق أو سلة وضع 3 منتجات بداخلها",
            rewardCoins = 25f
        ),
        MissionEntry(
            id = "mission_ask_staff",
            titleEn = "Ask the store assistant for aisle directions",
            titleAr = "اسأل موظف المتجر عن مكان أحد المنتجات",
            rewardCoins = 15f
        ),
        MissionEntry(
            id = "mission_checkout_exit",
            titleEn = "Scan items, complete payment & exit to the parking lot",
            titleAr = "امسح المنتجات وأكمل الدفع واخرج إلى المواقف",
            rewardCoins = 50f
        )
    )
}
