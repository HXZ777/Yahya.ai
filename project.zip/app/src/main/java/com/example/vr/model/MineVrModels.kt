package com.example.vr.model

import kotlinx.serialization.Serializable

@Serializable
enum class AppLanguage {
    ARABIC,
    ENGLISH
}

@Serializable
enum class VrRenderMode {
    SHIZUKU_VIRTUAL_DISPLAY,
    MINECRAFT_LIVE_CAPTURE,
    STEREO_VOXEL_SANDBOX
}

@Serializable
enum class ControllerKind {
    NONE,
    DUALSHOCK_4,
    DUALSENSE,
    XBOX_OR_GENERIC
}

@Serializable
enum class ControllerTransport {
    NONE,
    BLUETOOTH,
    USB
}

@Serializable
enum class PsButton(val defaultLabelEn: String, val defaultLabelAr: String) {
    CROSS("Cross (×)", "إكس (×)"),
    CIRCLE("Circle (○)", "دائرة (○)"),
    SQUARE("Square (□)", "مربع (□)"),
    TRIANGLE("Triangle (△)", "مثلث (△)"),
    L1("L1", "L1"),
    R1("R1", "R1"),
    L2("L2", "L2"),
    R2("R2", "R2"),
    L3("L3", "L3"),
    R3("R3", "R3"),
    OPTIONS("Options", "Options"),
    SHARE_CREATE("Share / Create", "Share / Create"),
    DPAD_UP("D-Pad Up", "أسهم أعلى"),
    DPAD_DOWN("D-Pad Down", "أسهم أسفل"),
    DPAD_LEFT("D-Pad Left", "أسهم يسار"),
    DPAD_RIGHT("D-Pad Right", "أسهم يمين")
}

@Serializable
enum class GameAction(val labelEn: String, val labelAr: String) {
    JUMP("Jump", "القفز"),
    CROUCH_SNEAK("Crouch / Sneak", "الانحناء / التسلل"),
    INTERACT_RELOAD("Interact / Craft", "التفاعل / الاستخدام"),
    BREAK_ATTACK("Break / Attack", "التكسير / الضرب"),
    PLACE_USE_SECONDARY("Build / Secondary Use", "البناء / الاستخدام الثانوي"),
    HOTBAR_PREV("Previous Hotbar Slot", "الأداة السابقة"),
    HOTBAR_NEXT("Next Hotbar Slot", "الأداة التالية"),
    PAUSE_MENU("Pause Menu", "قائمة الإيقاف"),
    SPRINT("Sprint", "الجري السريع"),
    RECENTER_HEAD("Recenter VR Head", "إعادة ضبط اتجاه الرأس"),
    TOGGLE_VR_PAUSE("Pause / Resume VR", "إيقاف / استئناف VR"),
    INVENTORY("Inventory", "الحقيبة"),
    DROP_ITEM("Drop Item", "رمي العنصر"),
    PERSPECTIVE("Switch Camera View", "تبديل زاوية الكاميرا")
}

@Serializable
data class PsButtonMapping(
    val cross: GameAction = GameAction.JUMP,
    val circle: GameAction = GameAction.CROUCH_SNEAK,
    val square: GameAction = GameAction.INTERACT_RELOAD,
    val triangle: GameAction = GameAction.INVENTORY,
    val l1: GameAction = GameAction.HOTBAR_PREV,
    val r1: GameAction = GameAction.HOTBAR_NEXT,
    val l2: GameAction = GameAction.PLACE_USE_SECONDARY,
    val r2: GameAction = GameAction.BREAK_ATTACK,
    val l3: GameAction = GameAction.SPRINT,
    val r3: GameAction = GameAction.PERSPECTIVE,
    val options: GameAction = GameAction.PAUSE_MENU,
    val shareCreate: GameAction = GameAction.RECENTER_HEAD,
    val dpadUp: GameAction = GameAction.TOGGLE_VR_PAUSE,
    val dpadDown: GameAction = GameAction.DROP_ITEM,
    val dpadLeft: GameAction = GameAction.HOTBAR_PREV,
    val dpadRight: GameAction = GameAction.HOTBAR_NEXT
) {
    fun actionFor(button: PsButton): GameAction = when (button) {
        PsButton.CROSS -> cross
        PsButton.CIRCLE -> circle
        PsButton.SQUARE -> square
        PsButton.TRIANGLE -> triangle
        PsButton.L1 -> l1
        PsButton.R1 -> r1
        PsButton.L2 -> l2
        PsButton.R2 -> r2
        PsButton.L3 -> l3
        PsButton.R3 -> r3
        PsButton.OPTIONS -> options
        PsButton.SHARE_CREATE -> shareCreate
        PsButton.DPAD_UP -> dpadUp
        PsButton.DPAD_DOWN -> dpadDown
        PsButton.DPAD_LEFT -> dpadLeft
        PsButton.DPAD_RIGHT -> dpadRight
    }

    fun withAction(button: PsButton, action: GameAction): PsButtonMapping = when (button) {
        PsButton.CROSS -> copy(cross = action)
        PsButton.CIRCLE -> copy(circle = action)
        PsButton.SQUARE -> copy(square = action)
        PsButton.TRIANGLE -> copy(triangle = action)
        PsButton.L1 -> copy(l1 = action)
        PsButton.R1 -> copy(r1 = action)
        PsButton.L2 -> copy(l2 = action)
        PsButton.R2 -> copy(r2 = action)
        PsButton.L3 -> copy(l3 = action)
        PsButton.R3 -> copy(r3 = action)
        PsButton.OPTIONS -> copy(options = action)
        PsButton.SHARE_CREATE -> copy(shareCreate = action)
        PsButton.DPAD_UP -> copy(dpadUp = action)
        PsButton.DPAD_DOWN -> copy(dpadDown = action)
        PsButton.DPAD_LEFT -> copy(dpadLeft = action)
        PsButton.DPAD_RIGHT -> copy(dpadRight = action)
    }
}

@Serializable
data class VrSettingsState(
    val sideBySideEnabled: Boolean = true,
    val fixedVrBoxMode: Boolean = true,
    val ipdMm: Float = 63f,
    val barrelDistortionK1: Float = 0.24f,
    val barrelDistortionK2: Float = 0.06f,
    val chromaticAberration: Float = 0.008f,
    val alignXOffset: Float = 0f,
    val alignYOffset: Float = 0f,
    val vrScale: Float = 0.94f,
    val fovDegrees: Float = 96f,
    val brightness: Float = 1.0f,
    val flipOrientation: Boolean = false,
    val headSensitivity: Float = 1.15f,
    val headSmoothing: Float = 0.35f,
    val horizonLockEnabled: Boolean = true,
    val zeroYawOffsetDeg: Float = 0f,
    val accessibilityHeadLookEnabled: Boolean = false,
    val accessibilityLookSensitivity: Float = 1.0f,
    val accessibilityInvertY: Boolean = false,
    val shizukuHeadLookEnabled: Boolean = true
)

@Serializable
data class ControlsSettingsState(
    val leftStickMovesPlayer: Boolean = true,
    val rightStickMovesCamera: Boolean = true,
    val stickDeadzone: Float = 0.14f,
    val rightStickSensitivity: Float = 1.1f,
    val invertRightY: Boolean = false,
    val mapping: PsButtonMapping = PsButtonMapping()
)

@Serializable
data class MineVrSettingsState(
    val language: AppLanguage = AppLanguage.ARABIC,
    val preferredRenderMode: VrRenderMode = VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY,
    val vr: VrSettingsState = VrSettingsState(),
    val controls: ControlsSettingsState = ControlsSettingsState()
)

data class MinecraftAppStatus(
    val isInstalled: Boolean = false,
    val isTrialOnly: Boolean = false,
    val packageName: String = "",
    val versionName: String = "",
    val isRunningInBackground: Boolean = false
)

data class ProjectionCaptureState(
    val hasPermissionConsent: Boolean = false,
    val isServiceRunning: Boolean = false,
    val isReceivingFrames: Boolean = false,
    val isCapturedContentVisible: Boolean = true,
    val isSelfMirrorWarning: Boolean = false,
    val captureWidth: Int = 0,
    val captureHeight: Int = 0,
    val frameCount: Long = 0L,
    val estimatedFps: Int = 0,
    val errorMessage: String? = null
)

data class HeadTrackingSnapshot(
    val isGyroSupported: Boolean = false,
    val activeSensorName: String = "None",
    val hasSensorData: Boolean = false,
    val rawYawDeg: Float = 0f,
    val calibratedYawDeg: Float = 0f,
    val pitchDeg: Float = 0f,
    val rollDeg: Float = 0f,
    val sampleRateHz: Int = 0,
    val jitterDeg: Float = 0f
)

data class AccessibilityBridgeSnapshot(
    val isServiceEnabled: Boolean = false,
    val isDispatchingGestures: Boolean = false,
    val gesturesDispatchedCount: Long = 0L,
    val lastGestureMs: Long = 0L,
    val lastError: String? = null
)

enum class ShizukuStatus {
    NOT_INSTALLED,
    NOT_RUNNING,
    PERMISSION_REQUIRED,
    PERMISSION_DENIED,
    BINDING_SERVICE,
    READY,
    VIRTUAL_DISPLAY_ACTIVE,
    ERROR
}

data class ShizukuBridgeState(
    val status: ShizukuStatus = ShizukuStatus.NOT_RUNNING,
    val isShizukuInstalled: Boolean = false,
    val isBinderAlive: Boolean = false,
    val hasPermission: Boolean = false,
    val isUserServiceConnected: Boolean = false,
    val serviceUid: Int = -1,
    val virtualDisplayId: Int = -1,
    val virtualWidth: Int = 0,
    val virtualHeight: Int = 0,
    val isMinecraftLaunchedOnDisplay: Boolean = false,
    val isMinecraftRunningOnDisplay: Boolean = false,
    val isReceivingFrames: Boolean = false,
    val estimatedFps: Int = 0,
    val lastErrorMessage: String? = null
)
