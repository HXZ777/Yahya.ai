package com.example.vr.input

import android.content.Context
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.example.vr.model.ControllerKind
import com.example.vr.model.ControllerTransport
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GameAction
import com.example.vr.model.PsButton
import com.example.vr.model.PsButtonMapping
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

data class PlayStationControllerSnapshot(
    val isConnected: Boolean = false,
    val deviceName: String = "",
    val controllerKind: ControllerKind = ControllerKind.NONE,
    val transport: ControllerTransport = ControllerTransport.NONE,
    val vendorId: Int = 0,
    val productId: Int = 0,
    val leftX: Float = 0f,
    val leftY: Float = 0f,
    val rightX: Float = 0f,
    val rightY: Float = 0f,
    val l2Trigger: Float = 0f,
    val r2Trigger: Float = 0f,
    val dpadX: Float = 0f,
    val dpadY: Float = 0f,
    val pressedButtons: Set<PsButton> = emptySet(),
    val lastButtonPressed: PsButton? = null,
    val lastDispatchedAction: GameAction? = null,
    val lastResponseLatencyMs: Long = 0L,
    val inputEventCount: Long = 0L
)

class PlayStationControllerManager(context: Context? = null) : InputManager.InputDeviceListener {

    private val inputManager = context?.getSystemService(Context.INPUT_SERVICE) as? InputManager
    private val _snapshot = MutableStateFlow(PlayStationControllerSnapshot())
    val snapshot: StateFlow<PlayStationControllerSnapshot> = _snapshot.asStateFlow()

    private var config = ControlsSettingsState()
    private val actionListeners = mutableListOf<(GameAction) -> Unit>()
    private var l2Triggered = false
    private var r2Triggered = false

    companion object {
        const val SONY_VENDOR_ID = 0x054C
        private val DUALSHOCK_4_PIDS = setOf(0x05C4, 0x09CC, 0x0BA0)
        private val DUALSENSE_PIDS = setOf(0x0CE6, 0x0DF2)

        fun classifyController(vendorId: Int, productId: Int, name: String): ControllerKind {
            if (vendorId == SONY_VENDOR_ID) {
                return when (productId) {
                    in DUALSENSE_PIDS -> ControllerKind.DUALSENSE
                    in DUALSHOCK_4_PIDS -> ControllerKind.DUALSHOCK_4
                    else -> if (name.contains("DualSense", ignoreCase = true)) {
                        ControllerKind.DUALSENSE
                    } else {
                        ControllerKind.DUALSHOCK_4
                    }
                }
            }
            val lower = name.lowercase()
            return when {
                "xbox" in lower -> ControllerKind.XBOX_OR_GENERIC
                "dualsense" in lower || "ps5" in lower -> ControllerKind.DUALSENSE
                "dualshock" in lower || "ps4" in lower || lower == "wireless controller" -> ControllerKind.DUALSHOCK_4
                else -> ControllerKind.XBOX_OR_GENERIC
            }
        }

        fun mapKeyCodeToPsButton(keyCode: Int): PsButton? = when (keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> PsButton.CROSS
            KeyEvent.KEYCODE_BUTTON_B -> PsButton.CIRCLE
            KeyEvent.KEYCODE_BUTTON_X -> PsButton.SQUARE
            KeyEvent.KEYCODE_BUTTON_Y -> PsButton.TRIANGLE
            KeyEvent.KEYCODE_BUTTON_L1 -> PsButton.L1
            KeyEvent.KEYCODE_BUTTON_R1 -> PsButton.R1
            KeyEvent.KEYCODE_BUTTON_L2 -> PsButton.L2
            KeyEvent.KEYCODE_BUTTON_R2 -> PsButton.R2
            KeyEvent.KEYCODE_BUTTON_THUMBL -> PsButton.L3
            KeyEvent.KEYCODE_BUTTON_THUMBR -> PsButton.R3
            KeyEvent.KEYCODE_BUTTON_START -> PsButton.OPTIONS
            KeyEvent.KEYCODE_BUTTON_SELECT,
            KeyEvent.KEYCODE_BUTTON_MODE -> PsButton.SHARE_CREATE
            KeyEvent.KEYCODE_DPAD_UP -> PsButton.DPAD_UP
            KeyEvent.KEYCODE_DPAD_DOWN -> PsButton.DPAD_DOWN
            KeyEvent.KEYCODE_DPAD_LEFT -> PsButton.DPAD_LEFT
            KeyEvent.KEYCODE_DPAD_RIGHT -> PsButton.DPAD_RIGHT
            else -> null
        }

        fun applyDeadzone(v: Float, threshold: Float): Float {
            val t = threshold.coerceIn(0.02f, 0.45f)
            return if (abs(v) < t) 0f else ((abs(v) - t) / (1f - t)) * if (v > 0) 1f else -1f
        }
    }

    fun startListening() {
        inputManager?.registerInputDeviceListener(this, Handler(Looper.getMainLooper()))
        refreshConnectedDevices()
    }

    fun stopListening() {
        inputManager?.unregisterInputDeviceListener(this)
    }

    fun updateSettings(newSettings: ControlsSettingsState) {
        config = newSettings
    }

    fun addActionListener(listener: (GameAction) -> Unit) {
        actionListeners.add(listener)
    }

    fun removeActionListener(listener: (GameAction) -> Unit) {
        actionListeners.remove(listener)
    }

    fun refreshConnectedDevices() {
        val ids = InputDevice.getDeviceIds()
        var bestDevice: InputDevice? = null
        var bestKind = ControllerKind.NONE
        for (id in ids) {
            val dev = InputDevice.getDevice(id) ?: continue
            val src = dev.sources
            val isGamepad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
            val isJoystick = (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            if (isGamepad || isJoystick) {
                val kind = classifyController(dev.vendorId, dev.productId, dev.name ?: "")
                if (bestDevice == null || kind == ControllerKind.DUALSENSE || kind == ControllerKind.DUALSHOCK_4) {
                    bestDevice = dev
                    bestKind = kind
                    if (kind == ControllerKind.DUALSENSE || kind == ControllerKind.DUALSHOCK_4) break
                }
            }
        }
        if (bestDevice != null) {
            val transport = detectTransport(bestDevice)
            _snapshot.value = _snapshot.value.copy(
                isConnected = true,
                deviceName = bestDevice.name ?: "PlayStation Controller",
                controllerKind = bestKind,
                transport = transport,
                vendorId = bestDevice.vendorId,
                productId = bestDevice.productId
            )
        } else {
            _snapshot.value = PlayStationControllerSnapshot()
        }
    }

    private fun detectTransport(device: InputDevice): ControllerTransport {
        val desc = device.descriptor.lowercase()
        val name = device.name.lowercase()
        return when {
            "usb" in desc || "usb" in name -> ControllerTransport.USB
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && device.isExternal -> ControllerTransport.BLUETOOTH
            else -> ControllerTransport.BLUETOOTH
        }
    }

    fun onGenericMotionEvent(event: MotionEvent): Boolean {
        val src = event.source
        if ((src and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK &&
            (src and InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD
        ) {
            return false
        }

        val dev = event.device
        val name = dev?.name ?: _snapshot.value.deviceName.ifEmpty { "Controller" }
        val kind = if (dev != null) classifyController(dev.vendorId, dev.productId, name) else _snapshot.value.controllerKind
        val transport = if (dev != null) detectTransport(dev) else _snapshot.value.transport

        val dz = config.stickDeadzone
        val lx = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_X), dz)
        val ly = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Y), dz)
        val rx = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Z), dz)
        val ryRaw = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_RZ), dz)
        val ry = if (config.invertRightY) -ryRaw else ryRaw

        // DualShock 4 / DualSense expose L2/R2 on AXIS_LTRIGGER/AXIS_RTRIGGER or AXIS_BRAKE/AXIS_GAS
        val l2 = maxOf(
            event.getAxisValue(MotionEvent.AXIS_LTRIGGER),
            event.getAxisValue(MotionEvent.AXIS_BRAKE)
        ).coerceIn(0f, 1f)
        val r2 = maxOf(
            event.getAxisValue(MotionEvent.AXIS_RTRIGGER),
            event.getAxisValue(MotionEvent.AXIS_GAS)
        ).coerceIn(0f, 1f)

        val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)

        val latency = (System.currentTimeMillis() - event.eventTime).coerceIn(0L, 250L)

        if (l2 > 0.65f && !l2Triggered) {
            l2Triggered = true
            dispatchButton(PsButton.L2, latency)
        } else if (l2 < 0.25f) {
            l2Triggered = false
        }

        if (r2 > 0.65f && !r2Triggered) {
            r2Triggered = true
            dispatchButton(PsButton.R2, latency)
        } else if (r2 < 0.25f) {
            r2Triggered = false
        }

        val curPressed = _snapshot.value.pressedButtons.toMutableSet()
        if (l2 > 0.5f) curPressed.add(PsButton.L2) else curPressed.remove(PsButton.L2)
        if (r2 > 0.5f) curPressed.add(PsButton.R2) else curPressed.remove(PsButton.R2)
        if (hatX < -0.5f) curPressed.add(PsButton.DPAD_LEFT) else curPressed.remove(PsButton.DPAD_LEFT)
        if (hatX > 0.5f) curPressed.add(PsButton.DPAD_RIGHT) else curPressed.remove(PsButton.DPAD_RIGHT)
        if (hatY < -0.5f) curPressed.add(PsButton.DPAD_UP) else curPressed.remove(PsButton.DPAD_UP)
        if (hatY > 0.5f) curPressed.add(PsButton.DPAD_DOWN) else curPressed.remove(PsButton.DPAD_DOWN)

        _snapshot.value = _snapshot.value.copy(
            isConnected = true,
            deviceName = name,
            controllerKind = kind,
            transport = transport,
            vendorId = dev?.vendorId ?: _snapshot.value.vendorId,
            productId = dev?.productId ?: _snapshot.value.productId,
            leftX = lx,
            leftY = ly,
            rightX = rx,
            rightY = ry,
            l2Trigger = l2,
            r2Trigger = r2,
            dpadX = hatX,
            dpadY = hatY,
            pressedButtons = curPressed,
            lastResponseLatencyMs = latency,
            inputEventCount = _snapshot.value.inputEventCount + 1
        )
        return true
    }

    fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (!isControllerEvent(event)) return false
        val dev = event.device
        val name = dev?.name ?: _snapshot.value.deviceName.ifEmpty { "PlayStation Controller" }
        val kind = if (dev != null) classifyController(dev.vendorId, dev.productId, name) else _snapshot.value.controllerKind
        val latency = (System.currentTimeMillis() - event.eventTime).coerceIn(0L, 250L)
        return processGamepadKeyDown(
            keyCode = keyCode,
            isRepeat = event.repeatCount > 0,
            deviceName = name,
            kind = kind,
            latencyMs = latency
        )
    }

    fun processGamepadKeyDown(
        keyCode: Int,
        isRepeat: Boolean = false,
        deviceName: String = "DualSense Wireless Controller",
        kind: ControllerKind = ControllerKind.DUALSENSE,
        latencyMs: Long = 2L
    ): Boolean {
        val btn = mapKeyCodeToPsButton(keyCode) ?: return false
        val nextPressed = _snapshot.value.pressedButtons + btn
        _snapshot.value = _snapshot.value.copy(
            isConnected = true,
            deviceName = deviceName,
            controllerKind = kind,
            pressedButtons = nextPressed,
            lastButtonPressed = btn,
            lastResponseLatencyMs = latencyMs,
            inputEventCount = _snapshot.value.inputEventCount + 1
        )
        if (!isRepeat) {
            dispatchButton(btn, latencyMs)
        }
        return true
    }

    fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (!isControllerEvent(event)) return false
        return processGamepadKeyUp(keyCode)
    }

    fun processGamepadKeyUp(keyCode: Int): Boolean {
        val btn = mapKeyCodeToPsButton(keyCode) ?: return false
        _snapshot.value = _snapshot.value.copy(
            pressedButtons = _snapshot.value.pressedButtons - btn
        )
        return true
    }

    private fun dispatchButton(btn: PsButton, latencyMs: Long) {
        val action = config.mapping.actionFor(btn)
        _snapshot.value = _snapshot.value.copy(
            lastButtonPressed = btn,
            lastDispatchedAction = action,
            lastResponseLatencyMs = latencyMs
        )
        actionListeners.forEach { it(action) }
    }

    private fun isControllerEvent(event: KeyEvent): Boolean {
        val src = event.source
        return (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            KeyEvent.isGamepadButton(event.keyCode)
    }

    override fun onInputDeviceAdded(deviceId: Int) {
        refreshConnectedDevices()
    }

    override fun onInputDeviceRemoved(deviceId: Int) {
        refreshConnectedDevices()
    }

    override fun onInputDeviceChanged(deviceId: Int) {
        refreshConnectedDevices()
    }
}
