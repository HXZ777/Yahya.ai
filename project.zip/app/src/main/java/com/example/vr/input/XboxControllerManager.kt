package com.example.vr.input

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.example.vr.model.FlyToggleButton
import com.example.vr.model.XboxAction
import com.example.vr.model.XboxButtonMapping
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

data class XboxControllerSnapshot(
    val isConnected: Boolean = false,
    val deviceName: String = "",
    val leftX: Float = 0f,
    val leftY: Float = 0f,
    val rightX: Float = 0f,
    val rightY: Float = 0f,
    val leftTrigger: Float = 0f,
    val rightTrigger: Float = 0f,
    val dpadX: Float = 0f,
    val dpadY: Float = 0f,
    val pressedButtons: Set<String> = emptySet(),
    val isAscendHeld: Boolean = false,
    val isDescendHeld: Boolean = false,
    val isSprintHeld: Boolean = false
)

class XboxControllerManager {

    private val _snapshot = MutableStateFlow(XboxControllerSnapshot())
    val snapshot: StateFlow<XboxControllerSnapshot> = _snapshot.asStateFlow()

    private val actionListeners = mutableListOf<(XboxAction) -> Unit>()
    private val flyToggleListeners = mutableListOf<() -> Unit>()
    private var mapping = XboxButtonMapping()
    private var flyToggleButton = FlyToggleButton.DOUBLE_A_CROSS
    private var ltTriggered = false
    private var rtTriggered = false

    private var lastPrimaryTapMs = 0L
    private var lastSecondaryTapMs = 0L

    companion object {
        const val DOUBLE_TAP_WINDOW_MS = 380L
    }

    fun updateMapping(newMapping: XboxButtonMapping, flyToggle: FlyToggleButton = flyToggleButton) {
        mapping = newMapping
        flyToggleButton = flyToggle
    }

    fun addActionListener(listener: (XboxAction) -> Unit) {
        actionListeners.add(listener)
    }

    fun removeActionListener(listener: (XboxAction) -> Unit) {
        actionListeners.remove(listener)
    }

    fun addFlyToggleListener(listener: () -> Unit) {
        flyToggleListeners.add(listener)
    }

    fun removeFlyToggleListener(listener: () -> Unit) {
        flyToggleListeners.remove(listener)
    }

    fun refreshConnectedDevices() {
        val ids = InputDevice.getDeviceIds()
        var foundName = ""
        for (id in ids) {
            val dev = InputDevice.getDevice(id) ?: continue
            val src = dev.sources
            val isGamepad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
            val isJoystick = (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            if (isGamepad || isJoystick) {
                foundName = dev.name ?: "Xbox / PlayStation Controller"
                break
            }
        }
        _snapshot.value = _snapshot.value.copy(
            isConnected = foundName.isNotEmpty(),
            deviceName = foundName
        )
    }

    fun onGenericMotionEvent(event: MotionEvent): Boolean {
        val src = event.source
        if ((src and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK &&
            (src and InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD
        ) {
            return false
        }

        val devName = event.device?.name ?: _snapshot.value.deviceName.ifEmpty { "Gamepad" }
        val lx = deadzone(event.getAxisValue(MotionEvent.AXIS_X))
        val ly = deadzone(event.getAxisValue(MotionEvent.AXIS_Y))
        val rx = deadzone(event.getAxisValue(MotionEvent.AXIS_Z))
        val ry = deadzone(event.getAxisValue(MotionEvent.AXIS_RZ))
        val lt = maxOf(
            event.getAxisValue(MotionEvent.AXIS_LTRIGGER),
            event.getAxisValue(MotionEvent.AXIS_BRAKE)
        ).coerceIn(0f, 1f)
        val rt = maxOf(
            event.getAxisValue(MotionEvent.AXIS_RTRIGGER),
            event.getAxisValue(MotionEvent.AXIS_GAS)
        ).coerceIn(0f, 1f)
        val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)

        if (lt > 0.65f && !ltTriggered) {
            ltTriggered = true
            dispatchAction(mapping.leftTrigger)
        } else if (lt < 0.25f) {
            ltTriggered = false
        }

        if (rt > 0.65f && !rtTriggered) {
            rtTriggered = true
            dispatchAction(mapping.rightTrigger)
        } else if (rt < 0.25f) {
            rtTriggered = false
        }

        val curPressed = _snapshot.value.pressedButtons
        _snapshot.value = _snapshot.value.copy(
            isConnected = true,
            deviceName = devName,
            leftX = lx,
            leftY = ly,
            rightX = rx,
            rightY = ry,
            leftTrigger = lt,
            rightTrigger = rt,
            dpadX = hatX,
            dpadY = hatY,
            isSprintHeld = rt > 0.45f || "L3" in curPressed || "RB" in curPressed
        )
        return true
    }

    fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (!isControllerEvent(event)) return false
        val devName = event.device?.name ?: _snapshot.value.deviceName.ifEmpty { "Gamepad" }
        return processGamepadKeyDown(
            keyCode = keyCode,
            nowMs = System.currentTimeMillis(),
            isRepeat = event.repeatCount > 0,
            deviceName = devName
        )
    }

    /** Pure Kotlin method so double-press Fly Mode & PlayStation/Xbox keys can be unit-tested cleanly. */
    fun processGamepadKeyDown(
        keyCode: Int,
        nowMs: Long,
        isRepeat: Boolean = false,
        deviceName: String = "Gamepad"
    ): Boolean {
        val label = keyLabel(keyCode)
        val nextPressed = _snapshot.value.pressedButtons + label
        _snapshot.value = _snapshot.value.copy(
            isConnected = true,
            deviceName = deviceName,
            pressedButtons = nextPressed,
            isAscendHeld = "A" in nextPressed,
            isDescendHeld = "B" in nextPressed,
            isSprintHeld = _snapshot.value.rightTrigger > 0.45f || "L3" in nextPressed || "RB" in nextPressed
        )
        if (!isRepeat) {
            // Check Fly Mode toggle trigger (supports Xbox A & PlayStation Cross = KEYCODE_BUTTON_A, plus customizable options)
            val flyTriggered = when (flyToggleButton) {
                FlyToggleButton.DOUBLE_A_CROSS -> {
                    if (keyCode == KeyEvent.KEYCODE_BUTTON_A) {
                        val hit = (nowMs - lastPrimaryTapMs) in 1L..DOUBLE_TAP_WINDOW_MS
                        lastPrimaryTapMs = if (hit) 0L else nowMs
                        hit
                    } else false
                }
                FlyToggleButton.DOUBLE_Y_TRIANGLE -> {
                    if (keyCode == KeyEvent.KEYCODE_BUTTON_Y) {
                        val hit = (nowMs - lastSecondaryTapMs) in 1L..DOUBLE_TAP_WINDOW_MS
                        lastSecondaryTapMs = if (hit) 0L else nowMs
                        hit
                    } else false
                }
                FlyToggleButton.LB_L1 -> keyCode == KeyEvent.KEYCODE_BUTTON_L1
                FlyToggleButton.RB_R1 -> keyCode == KeyEvent.KEYCODE_BUTTON_R1
            }

            if (flyTriggered) {
                flyToggleListeners.forEach { it() }
            }

            when (keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> dispatchAction(mapping.buttonA)
                KeyEvent.KEYCODE_BUTTON_B -> dispatchAction(mapping.buttonB)
                KeyEvent.KEYCODE_BUTTON_X -> dispatchAction(mapping.buttonX)
                KeyEvent.KEYCODE_BUTTON_Y -> dispatchAction(mapping.buttonY)
                KeyEvent.KEYCODE_BUTTON_L2 -> dispatchAction(mapping.leftTrigger)
                KeyEvent.KEYCODE_BUTTON_R2 -> dispatchAction(mapping.rightTrigger)
                KeyEvent.KEYCODE_BUTTON_L1 -> dispatchAction(XboxAction.CART_HOLD_PUSH)
                KeyEvent.KEYCODE_BUTTON_R1 -> dispatchAction(XboxAction.USE_INSPECT)
                KeyEvent.KEYCODE_DPAD_LEFT -> _snapshot.value = _snapshot.value.copy(dpadX = -1f)
                KeyEvent.KEYCODE_DPAD_RIGHT -> _snapshot.value = _snapshot.value.copy(dpadX = 1f)
                KeyEvent.KEYCODE_DPAD_UP -> _snapshot.value = _snapshot.value.copy(dpadY = -1f)
                KeyEvent.KEYCODE_DPAD_DOWN -> _snapshot.value = _snapshot.value.copy(dpadY = 1f)
            }
        }
        return true
    }

    fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (!isControllerEvent(event)) return false
        return processGamepadKeyUp(keyCode)
    }

    fun processGamepadKeyUp(keyCode: Int): Boolean {
        val label = keyLabel(keyCode)
        val nextPressed = _snapshot.value.pressedButtons - label
        _snapshot.value = _snapshot.value.copy(
            pressedButtons = nextPressed,
            isAscendHeld = "A" in nextPressed,
            isDescendHeld = "B" in nextPressed,
            isSprintHeld = _snapshot.value.rightTrigger > 0.45f || "L3" in nextPressed || "RB" in nextPressed,
            dpadX = if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 0f else _snapshot.value.dpadX,
            dpadY = if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) 0f else _snapshot.value.dpadY
        )
        return true
    }

    private fun dispatchAction(action: XboxAction) {
        actionListeners.forEach { it(action) }
    }

    private fun isControllerEvent(event: KeyEvent): Boolean {
        val src = event.source
        return (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            KeyEvent.isGamepadButton(event.keyCode)
    }

    private fun deadzone(v: Float, threshold: Float = 0.14f): Float {
        return if (abs(v) < threshold) 0f else ((abs(v) - threshold) / (1f - threshold)) * if (v > 0) 1f else -1f
    }

    private fun keyLabel(keyCode: Int): String = when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_A -> "A"
        KeyEvent.KEYCODE_BUTTON_B -> "B"
        KeyEvent.KEYCODE_BUTTON_X -> "X"
        KeyEvent.KEYCODE_BUTTON_Y -> "Y"
        KeyEvent.KEYCODE_BUTTON_L1 -> "LB"
        KeyEvent.KEYCODE_BUTTON_R1 -> "RB"
        KeyEvent.KEYCODE_BUTTON_L2 -> "LT"
        KeyEvent.KEYCODE_BUTTON_R2 -> "RT"
        KeyEvent.KEYCODE_BUTTON_THUMBL -> "L3"
        KeyEvent.KEYCODE_BUTTON_THUMBR -> "R3"
        else -> KeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_")
    }
}
