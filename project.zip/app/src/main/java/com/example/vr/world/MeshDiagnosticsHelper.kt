package com.example.vr.world

import com.example.vr.model.ImportDiagnosticReport
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.WorldObjectCategory
import com.example.vr.model.WorldSubMeshData
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object MeshDiagnosticsHelper {

    fun classifyCategory(name: String): WorldObjectCategory {
        val lower = name.lowercase()
        return when {
            listOf("wall", "roof", "building", "house", "store", "shop", "market", "facade", "door", "window", "pillar", "column", "floor").any { it in lower } ->
                WorldObjectCategory.BUILDINGS
            listOf("tree", "leaf", "leaves", "foliage", "bush", "grass", "rock", "terrain", "ground", "road", "street", "sky", "plant", "flower", "cloud").any { it in lower } ->
                WorldObjectCategory.ENVIRONMENT
            listOf("table", "chair", "shelf", "rack", "desk", "bed", "sofa", "couch", "cabinet", "bench", "counter", "fridge", "cart").any { it in lower } ->
                WorldObjectCategory.FURNITURE
            listOf("light", "lamp", "bulb", "neon", "glow", "sun").any { it in lower } ->
                WorldObjectCategory.LIGHTS
            else -> WorldObjectCategory.IMPORTED_MODELS
        }
    }

    /**
     * Finalizes raw submeshes:
     * - Audits UVs, inverted normals, scale, out-of-bounds clusters
     * - Normalizes overall world scale safely onto ground Y=0 centered on XZ=(0,0)
     * - Repairs inverted normals if detected
     * - Produces a complete bilingual ImportDiagnosticReport
     */
    fun auditAndNormalize(
        worldName: String,
        rawSubMeshes: MutableList<WorldSubMeshData>,
        materials: List<PbrMaterialSpec>,
        missingMtlFiles: List<String> = emptyList(),
        extraNotes: List<String> = emptyList()
    ): ImportedMeshData? {
        if (rawSubMeshes.isEmpty()) return null

        var globalMinX = Float.MAX_VALUE
        var globalMinY = Float.MAX_VALUE
        var globalMinZ = Float.MAX_VALUE
        var globalMaxX = -Float.MAX_VALUE
        var globalMaxY = -Float.MAX_VALUE
        var globalMaxZ = -Float.MAX_VALUE

        var totalVerts = 0
        for (sm in rawSubMeshes) {
            val arr = sm.interleavedVertices
            var i = 0
            while (i + 11 < arr.size) {
                val x = arr[i]; val y = arr[i + 1]; val z = arr[i + 2]
                if (x.isFinite() && y.isFinite() && z.isFinite()) {
                    globalMinX = min(globalMinX, x); globalMaxX = max(globalMaxX, x)
                    globalMinY = min(globalMinY, y); globalMaxY = max(globalMaxY, y)
                    globalMinZ = min(globalMinZ, z); globalMaxZ = max(globalMaxZ, z)
                }
                i += 12
            }
            totalVerts += sm.vertexCount
        }
        if (totalVerts < 3 || globalMinX == Float.MAX_VALUE) return null

        val rawSpan = max(globalMaxX - globalMinX, max(globalMaxY - globalMinY, globalMaxZ - globalMinZ))
            .coerceAtLeast(0.001f)
        val abnormalScaleNotes = mutableListOf<String>()
        val fixesApplied = mutableListOf<String>()

        val scale = when {
            rawSpan < 0.2f -> {
                abnormalScaleNotes.add("Microscopic export scale (${String.format("%.3f", rawSpan)}m)")
                fixesApplied.add("Auto-scaled microscopic model up to 18m VR scale")
                18.0f / rawSpan
            }
            rawSpan < 8.0f -> {
                fixesApplied.add("Scaled compact asset (${String.format("%.1f", rawSpan)}m) to walkable VR size")
                20.0f / rawSpan
            }
            rawSpan > 260f -> {
                abnormalScaleNotes.add("Oversized export scale (${String.format("%.1f", rawSpan)}m)")
                fixesApplied.add("Auto-normalized oversized mm/cm export to 52m VR bounds")
                52.0f / rawSpan
            }
            else -> 1.0f
        }

        val cx = (globalMinX + globalMaxX) * 0.5f
        val cz = (globalMinZ + globalMaxZ) * 0.5f

        val invalidUvNames = mutableListOf<String>()
        val invertedNormalNames = mutableListOf<String>()
        val outOfBoundsNames = mutableListOf<String>()

        val allPositions = FloatArray(totalVerts * 3)
        val allNormals = FloatArray(totalVerts * 3)
        var flatCursor = 0

        for (idx in rawSubMeshes.indices) {
            val sm = rawSubMeshes[idx]
            val arr = sm.interleavedVertices
            var smMinX = Float.MAX_VALUE; var smMinY = Float.MAX_VALUE; var smMinZ = Float.MAX_VALUE
            var smMaxX = -Float.MAX_VALUE; var smMaxY = -Float.MAX_VALUE; var smMaxZ = -Float.MAX_VALUE

            var anyNonZeroUv = false
            var anyInvalidUv = false
            var v = 0
            while (v + 11 < arr.size) {
                var px = (arr[v] - cx) * scale
                var py = (arr[v + 1] - globalMinY) * scale
                var pz = (arr[v + 2] - cz) * scale
                if (!px.isFinite()) px = 0f
                if (!py.isFinite()) py = 0f
                if (!pz.isFinite()) pz = 0f
                arr[v] = px; arr[v + 1] = py; arr[v + 2] = pz

                smMinX = min(smMinX, px); smMaxX = max(smMaxX, px)
                smMinY = min(smMinY, py); smMaxY = max(smMaxY, py)
                smMinZ = min(smMinZ, pz); smMaxZ = max(smMaxZ, pz)

                val u = arr[v + 6]
                val tv = arr[v + 7]
                if (!u.isFinite() || !tv.isFinite()) {
                    anyInvalidUv = true
                    arr[v + 6] = 0f; arr[v + 7] = 0f
                } else if (abs(u) > 1e-4f || abs(tv) > 1e-4f) {
                    anyNonZeroUv = true
                }

                // Ensure valid unit normal
                var nx = arr[v + 3]; var ny = arr[v + 4]; var nz = arr[v + 5]
                val nLen = sqrt(nx * nx + ny * ny + nz * nz)
                if (!nLen.isFinite() || nLen < 1e-4f) {
                    arr[v + 3] = 0f; arr[v + 4] = 1f; arr[v + 5] = 0f
                } else {
                    arr[v + 3] = nx / nLen; arr[v + 4] = ny / nLen; arr[v + 5] = nz / nLen
                }
                v += 12
            }

            // Check & repair inverted normals on closed/convex submesh using center-outward dot test
            val subCx = (smMinX + smMaxX) * 0.5f
            val subCy = (smMinY + smMaxY) * 0.5f
            val subCz = (smMinZ + smMaxZ) * 0.5f
            var outwardDots = 0f
            var sampleCount = 0
            v = 0
            while (v + 35 < arr.size) {
                val mx = (arr[v] + arr[v + 12] + arr[v + 24]) / 3f - subCx
                val my = (arr[v + 1] + arr[v + 13] + arr[v + 25]) / 3f - subCy
                val mz = (arr[v + 2] + arr[v + 14] + arr[v + 26]) / 3f - subCz
                val dot = mx * arr[v + 3] + my * arr[v + 4] + mz * arr[v + 5]
                outwardDots += dot
                sampleCount++
                v += 36
            }
            if (sampleCount >= 12 && outwardDots < -0.5f) {
                invertedNormalNames.add(sm.name)
                fixesApplied.add("Flipped inward normals on '${sm.name}'")
                v = 0
                while (v + 11 < arr.size) {
                    arr[v + 3] = -arr[v + 3]
                    arr[v + 4] = -arr[v + 4]
                    arr[v + 5] = -arr[v + 5]
                    v += 12
                }
            }

            val hasUvs = sm.hasValidUvs && anyNonZeroUv && !anyInvalidUv
            if (!hasUvs) {
                invalidUvNames.add(sm.name)
            }

            if (abs(subCx) > 160f || abs(subCz) > 160f || subCy < -40f) {
                outOfBoundsNames.add(sm.name)
            }

            v = 0
            while (v + 11 < arr.size && flatCursor + 2 < allPositions.size) {
                allPositions[flatCursor] = arr[v]
                allPositions[flatCursor + 1] = arr[v + 1]
                allPositions[flatCursor + 2] = arr[v + 2]
                allNormals[flatCursor] = arr[v + 3]
                allNormals[flatCursor + 1] = arr[v + 4]
                allNormals[flatCursor + 2] = arr[v + 5]
                flatCursor += 3
                v += 12
            }

            rawSubMeshes[idx] = sm.copy(
                boundsMin = floatArrayOf(smMinX, smMinY, smMinZ),
                boundsMax = floatArrayOf(smMaxX, smMaxY, smMaxZ),
                hasValidUvs = hasUvs
            )
        }

        val missingTexList = materials.mapNotNull { mat ->
            if (mat.texturePath == null && !mat.missingTextureName.isNullOrBlank()) {
                "${mat.name}: ${mat.missingTextureName}"
            } else null
        }
        val texturesExtracted = materials.count { !it.texturePath.isNullOrBlank() }

        val summaryEn = buildString {
            append("${rawSubMeshes.size} meshes · $totalVerts verts · $texturesExtracted/${materials.size} textures loaded.")
            if (missingTexList.isNotEmpty()) append(" Missing textures: ${missingTexList.size}.")
            if (missingMtlFiles.isNotEmpty()) append(" Missing MTL: ${missingMtlFiles.size}.")
            if (fixesApplied.isNotEmpty()) append(" Auto-fixes: ${fixesApplied.size}.")
        }
        val summaryAr = buildString {
            append("${rawSubMeshes.size} مجسمات · $totalVerts نقطة · تم استخراج $texturesExtracted من أصل ${materials.size} خامة.")
            if (missingTexList.isNotEmpty()) append(" خامات مفقودة: ${missingTexList.size}.")
            if (missingMtlFiles.isNotEmpty()) append(" ملفات MTL مفقودة: ${missingMtlFiles.size}.")
            if (fixesApplied.isNotEmpty()) append(" إصلاحات تلقائية: ${fixesApplied.size}.")
        }

        val report = ImportDiagnosticReport(
            totalSubMeshes = rawSubMeshes.size,
            totalVertices = totalVerts,
            totalMaterials = materials.size,
            texturesExtracted = texturesExtracted,
            missingTextures = missingTexList,
            missingMtlFiles = missingMtlFiles,
            invalidUvMeshNames = invalidUvNames.take(12),
            invertedNormalMeshNames = invertedNormalNames.take(12),
            abnormalScaleNotes = abnormalScaleNotes,
            outOfBoundsMeshNames = outOfBoundsNames.take(12),
            fixesApplied = fixesApplied + extraNotes,
            summaryEn = summaryEn,
            summaryAr = summaryAr
        )

        return ImportedMeshData(
            name = worldName,
            positions = allPositions,
            normals = allNormals,
            vertexCount = totalVerts,
            boundsMin = floatArrayOf(
                (globalMinX - cx) * scale,
                0f,
                (globalMinZ - cz) * scale
            ),
            boundsMax = floatArrayOf(
                (globalMaxX - cx) * scale,
                (globalMaxY - globalMinY) * scale,
                (globalMaxZ - cz) * scale
            ),
            subMeshes = rawSubMeshes.toList(),
            materials = materials,
            diagnostics = report,
            normalizationScale = scale
        )
    }
}
