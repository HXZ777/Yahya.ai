package com.example.vr.engine

import android.opengl.GLES30
import com.example.vr.model.ImportedMeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class GlMesh(
    val vboId: Int,
    val vertexCount: Int
) {
    fun draw(posAttr: Int, normAttr: Int) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboId)
        val stride = 6 * 4
        GLES30.glEnableVertexAttribArray(posAttr)
        GLES30.glVertexAttribPointer(posAttr, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(normAttr)
        GLES30.glVertexAttribPointer(normAttr, 3, GLES30.GL_FLOAT, false, stride, 3 * 4)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, vertexCount)
    }

    fun delete() {
        GLES30.glDeleteBuffers(1, intArrayOf(vboId), 0)
    }
}

object MeshBuilder {

    fun createUnitCube(): GlMesh {
        val v = floatArrayOf(
            // Front (+Z)
            -0.5f, -0.5f,  0.5f,  0f,  0f,  1f,
             0.5f, -0.5f,  0.5f,  0f,  0f,  1f,
             0.5f,  0.5f,  0.5f,  0f,  0f,  1f,
            -0.5f, -0.5f,  0.5f,  0f,  0f,  1f,
             0.5f,  0.5f,  0.5f,  0f,  0f,  1f,
            -0.5f,  0.5f,  0.5f,  0f,  0f,  1f,
            // Back (-Z)
             0.5f, -0.5f, -0.5f,  0f,  0f, -1f,
            -0.5f, -0.5f, -0.5f,  0f,  0f, -1f,
            -0.5f,  0.5f, -0.5f,  0f,  0f, -1f,
             0.5f, -0.5f, -0.5f,  0f,  0f, -1f,
            -0.5f,  0.5f, -0.5f,  0f,  0f, -1f,
             0.5f,  0.5f, -0.5f,  0f,  0f, -1f,
            // Left (-X)
            -0.5f, -0.5f, -0.5f, -1f,  0f,  0f,
            -0.5f, -0.5f,  0.5f, -1f,  0f,  0f,
            -0.5f,  0.5f,  0.5f, -1f,  0f,  0f,
            -0.5f, -0.5f, -0.5f, -1f,  0f,  0f,
            -0.5f,  0.5f,  0.5f, -1f,  0f,  0f,
            -0.5f,  0.5f, -0.5f, -1f,  0f,  0f,
            // Right (+X)
             0.5f, -0.5f,  0.5f,  1f,  0f,  0f,
             0.5f, -0.5f, -0.5f,  1f,  0f,  0f,
             0.5f,  0.5f, -0.5f,  1f,  0f,  0f,
             0.5f, -0.5f,  0.5f,  1f,  0f,  0f,
             0.5f,  0.5f, -0.5f,  1f,  0f,  0f,
             0.5f,  0.5f,  0.5f,  1f,  0f,  0f,
            // Top (+Y)
            -0.5f,  0.5f,  0.5f,  0f,  1f,  0f,
             0.5f,  0.5f,  0.5f,  0f,  1f,  0f,
             0.5f,  0.5f, -0.5f,  0f,  1f,  0f,
            -0.5f,  0.5f,  0.5f,  0f,  1f,  0f,
             0.5f,  0.5f, -0.5f,  0f,  1f,  0f,
            -0.5f,  0.5f, -0.5f,  0f,  1f,  0f,
            // Bottom (-Y)
            -0.5f, -0.5f, -0.5f,  0f, -1f,  0f,
             0.5f, -0.5f, -0.5f,  0f, -1f,  0f,
             0.5f, -0.5f,  0.5f,  0f, -1f,  0f,
            -0.5f, -0.5f, -0.5f,  0f, -1f,  0f,
             0.5f, -0.5f,  0.5f,  0f, -1f,  0f,
            -0.5f, -0.5f,  0.5f,  0f, -1f,  0f
        )
        return uploadInterleaved(v)
    }

    fun createCylinder(segments: Int = 16): GlMesh {
        val data = ArrayList<Float>(segments * 12 * 6)
        val step = (2.0 * PI) / segments
        for (i in 0 until segments) {
            val a0 = i * step
            val a1 = (i + 1) * step
            val x0 = (cos(a0) * 0.5).toFloat()
            val z0 = (sin(a0) * 0.5).toFloat()
            val x1 = (cos(a1) * 0.5).toFloat()
            val z1 = (sin(a1) * 0.5).toFloat()
            val nx0 = cos(a0).toFloat()
            val nz0 = sin(a0).toFloat()
            val nx1 = cos(a1).toFloat()
            val nz1 = sin(a1).toFloat()

            // Side quad
            addVert(data, x0, -0.5f, z0, nx0, 0f, nz0)
            addVert(data, x1, -0.5f, z1, nx1, 0f, nz1)
            addVert(data, x1,  0.5f, z1, nx1, 0f, nz1)
            addVert(data, x0, -0.5f, z0, nx0, 0f, nz0)
            addVert(data, x1,  0.5f, z1, nx1, 0f, nz1)
            addVert(data, x0,  0.5f, z0, nx0, 0f, nz0)

            // Top cap
            addVert(data, 0f, 0.5f, 0f, 0f, 1f, 0f)
            addVert(data, x0, 0.5f, z0, 0f, 1f, 0f)
            addVert(data, x1, 0.5f, z1, 0f, 1f, 0f)

            // Bottom cap
            addVert(data, 0f, -0.5f, 0f, 0f, -1f, 0f)
            addVert(data, x1, -0.5f, z1, 0f, -1f, 0f)
            addVert(data, x0, -0.5f, z0, 0f, -1f, 0f)
        }
        return uploadInterleaved(data.toFloatArray())
    }

    fun createSphere(latSteps: Int = 10, lonSteps: Int = 14): GlMesh {
        val data = ArrayList<Float>(latSteps * lonSteps * 6 * 6)
        for (i in 0 until latSteps) {
            val t0 = PI * (-0.5 + i.toDouble() / latSteps)
            val t1 = PI * (-0.5 + (i + 1).toDouble() / latSteps)
            for (j in 0 until lonSteps) {
                val p0 = 2.0 * PI * j.toDouble() / lonSteps
                val p1 = 2.0 * PI * (j + 1).toDouble() / lonSteps

                val v00 = spherePoint(t0, p0)
                val v10 = spherePoint(t1, p0)
                val v11 = spherePoint(t1, p1)
                val v01 = spherePoint(t0, p1)

                addVert(data, v00[0] * 0.5f, v00[1] * 0.5f, v00[2] * 0.5f, v00[0], v00[1], v00[2])
                addVert(data, v10[0] * 0.5f, v10[1] * 0.5f, v10[2] * 0.5f, v10[0], v10[1], v10[2])
                addVert(data, v11[0] * 0.5f, v11[1] * 0.5f, v11[2] * 0.5f, v11[0], v11[1], v11[2])

                addVert(data, v00[0] * 0.5f, v00[1] * 0.5f, v00[2] * 0.5f, v00[0], v00[1], v00[2])
                addVert(data, v11[0] * 0.5f, v11[1] * 0.5f, v11[2] * 0.5f, v11[0], v11[1], v11[2])
                addVert(data, v01[0] * 0.5f, v01[1] * 0.5f, v01[2] * 0.5f, v01[0], v01[1], v01[2])
            }
        }
        return uploadInterleaved(data.toFloatArray())
    }

    fun createImportedMesh(mesh: ImportedMeshData): GlMesh {
        val count = mesh.vertexCount
        val interleaved = FloatArray(count * 6)
        for (i in 0 until count) {
            val pIdx = i * 3
            val outIdx = i * 6
            interleaved[outIdx] = mesh.positions[pIdx]
            interleaved[outIdx + 1] = mesh.positions[pIdx + 1]
            interleaved[outIdx + 2] = mesh.positions[pIdx + 2]
            interleaved[outIdx + 3] = mesh.normals[pIdx]
            interleaved[outIdx + 4] = mesh.normals[pIdx + 1]
            interleaved[outIdx + 5] = mesh.normals[pIdx + 2]
        }
        return uploadInterleaved(interleaved)
    }

    private fun spherePoint(theta: Double, phi: Double): FloatArray {
        val x = (cos(theta) * cos(phi)).toFloat()
        val y = sin(theta).toFloat()
        val z = (cos(theta) * sin(phi)).toFloat()
        return floatArrayOf(x, y, z)
    }

    private fun addVert(list: ArrayList<Float>, x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) {
        list.add(x); list.add(y); list.add(z)
        list.add(nx); list.add(ny); list.add(nz)
    }

    private fun uploadInterleaved(array: FloatArray): GlMesh {
        val buf: FloatBuffer = ByteBuffer.allocateDirect(array.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(array)
        buf.position(0)
        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, array.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        return GlMesh(vbo[0], array.size / 6)
    }
}
