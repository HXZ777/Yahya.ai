package com.example.vr.engine

import android.opengl.GLES30
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.WorldSubMeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Interleaved 12-float vertex buffer:
 * pos(3), norm(3), uv(2), color(4) => stride = 48 bytes.
 */
class GlMesh(
    val vboId: Int,
    val vertexCount: Int
) {
    fun draw(posAttr: Int, normAttr: Int, uvAttr: Int = -1, colorAttr: Int = -1) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboId)
        val stride = 12 * 4
        GLES30.glEnableVertexAttribArray(posAttr)
        GLES30.glVertexAttribPointer(posAttr, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(normAttr)
        GLES30.glVertexAttribPointer(normAttr, 3, GLES30.GL_FLOAT, false, stride, 3 * 4)
        if (uvAttr >= 0) {
            GLES30.glEnableVertexAttribArray(uvAttr)
            GLES30.glVertexAttribPointer(uvAttr, 2, GLES30.GL_FLOAT, false, stride, 6 * 4)
        }
        if (colorAttr >= 0) {
            GLES30.glEnableVertexAttribArray(colorAttr)
            GLES30.glVertexAttribPointer(colorAttr, 4, GLES30.GL_FLOAT, false, stride, 8 * 4)
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, vertexCount)
    }

    fun delete() {
        if (vboId != 0) {
            GLES30.glDeleteBuffers(1, intArrayOf(vboId), 0)
        }
    }
}

class SubMeshGl(
    val name: String,
    val fullMesh: GlMesh,
    val lodMesh: GlMesh?,
    val materialIndex: Int,
    val boundsMin: FloatArray,
    val boundsMax: FloatArray
) {
    val centerX: Float = (boundsMin[0] + boundsMax[0]) * 0.5f
    val centerY: Float = (boundsMin[1] + boundsMax[1]) * 0.5f
    val centerZ: Float = (boundsMin[2] + boundsMax[2]) * 0.5f
    val radius: Float = run {
        val dx = (boundsMax[0] - boundsMin[0]) * 0.5f
        val dy = (boundsMax[1] - boundsMin[1]) * 0.5f
        val dz = (boundsMax[2] - boundsMin[2]) * 0.5f
        kotlin.math.sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1f)
    }

    fun delete() {
        fullMesh.delete()
        lodMesh?.delete()
    }
}

class UploadedWorldBundle(
    val subMeshes: List<SubMeshGl>,
    val fallbackMesh: GlMesh?
) {
    fun delete() {
        subMeshes.forEach { it.delete() }
        fallbackMesh?.delete()
    }
}

object MeshBuilder {

    fun createUnitCube(): GlMesh {
        val data = ArrayList<Float>(36 * 12)
        // Front (+Z)
        addQuad(data, -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0f, 0f, 1f)
        // Back (-Z)
        addQuad(data, 0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0f, 0f, -1f)
        // Left (-X)
        addQuad(data, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, -0.5f, -1f, 0f, 0f)
        // Right (+X)
        addQuad(data, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 1f, 0f, 0f)
        // Top (+Y)
        addQuad(data, -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0f, 1f, 0f)
        // Bottom (-Y)
        addQuad(data, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, -0.5f, -0.5f, 0.5f, 0f, -1f, 0f)
        return uploadInterleaved12(data.toFloatArray())
    }

    fun createCylinder(segments: Int = 16): GlMesh {
        val data = ArrayList<Float>(segments * 12 * 12)
        val step = (2.0 * PI) / segments
        for (i in 0 until segments) {
            val a0 = i * step
            val a1 = (i + 1) * step
            val x0 = (cos(a0) * 0.5).toFloat()
            val z0 = (sin(a0) * 0.5).toFloat()
            val x1 = (cos(a1) * 0.5).toFloat()
            val z1 = (sin(a1) * 0.5).toFloat()
            val nx0 = cos(a0).toFloat()
            val nz0 = sin(a0).toFloat()
            val nx1 = cos(a1).toFloat()
            val nz1 = sin(a1).toFloat()

            addVert12(data, x0, -0.5f, z0, nx0, 0f, nz0, i.toFloat() / segments, 1f)
            addVert12(data, x1, -0.5f, z1, nx1, 0f, nz1, (i + 1).toFloat() / segments, 1f)
            addVert12(data, x1, 0.5f, z1, nx1, 0f, nz1, (i + 1).toFloat() / segments, 0f)
            addVert12(data, x0, -0.5f, z0, nx0, 0f, nz0, i.toFloat() / segments, 1f)
            addVert12(data, x1, 0.5f, z1, nx1, 0f, nz1, (i + 1).toFloat() / segments, 0f)
            addVert12(data, x0, 0.5f, z0, nx0, 0f, nz0, i.toFloat() / segments, 0f)

            addVert12(data, 0f, 0.5f, 0f, 0f, 1f, 0f, 0.5f, 0.5f)
            addVert12(data, x0, 0.5f, z0, 0f, 1f, 0f, 0.5f + x0, 0.5f + z0)
            addVert12(data, x1, 0.5f, z1, 0f, 1f, 0f, 0.5f + x1, 0.5f + z1)

            addVert12(data, 0f, -0.5f, 0f, 0f, -1f, 0f, 0.5f, 0.5f)
            addVert12(data, x1, -0.5f, z1, 0f, -1f, 0f, 0.5f + x1, 0.5f + z1)
            addVert12(data, x0, -0.5f, z0, 0f, -1f, 0f, 0.5f + x0, 0.5f + z0)
        }
        return uploadInterleaved12(data.toFloatArray())
    }

    fun createCone(segments: Int = 12): GlMesh {
        val data = ArrayList<Float>(segments * 6 * 12)
        val step = (2.0 * PI) / segments
        for (i in 0 until segments) {
            val a0 = i * step
            val a1 = (i + 1) * step
            val x0 = (cos(a0) * 0.5).toFloat()
            val z0 = (sin(a0) * 0.5).toFloat()
            val x1 = (cos(a1) * 0.5).toFloat()
            val z1 = (sin(a1) * 0.5).toFloat()
            val nx = cos((a0 + a1) * 0.5).toFloat()
            val nz = sin((a0 + a1) * 0.5).toFloat()
            addVert12(data, 0f, 0.5f, 0f, nx, 0.45f, nz, 0.5f, 0f)
            addVert12(data, x0, -0.5f, z0, nx, 0.45f, nz, 0f, 1f)
            addVert12(data, x1, -0.5f, z1, nx, 0.45f, nz, 1f, 1f)

            addVert12(data, 0f, -0.5f, 0f, 0f, -1f, 0f, 0.5f, 0.5f)
            addVert12(data, x1, -0.5f, z1, 0f, -1f, 0f, 1f, 1f)
            addVert12(data, x0, -0.5f, z0, 0f, -1f, 0f, 0f, 1f)
        }
        return uploadInterleaved12(data.toFloatArray())
    }

    fun createSphere(latSteps: Int = 10, lonSteps: Int = 14): GlMesh {
        val data = ArrayList<Float>(latSteps * lonSteps * 6 * 12)
        for (i in 0 until latSteps) {
            val t0 = PI * (-0.5 + i.toDouble() / latSteps)
            val t1 = PI * (-0.5 + (i + 1).toDouble() / latSteps)
            for (j in 0 until lonSteps) {
                val p0 = 2.0 * PI * j.toDouble() / lonSteps
                val p1 = 2.0 * PI * (j + 1).toDouble() / lonSteps

                val v00 = spherePoint(t0, p0)
                val v10 = spherePoint(t1, p0)
                val v11 = spherePoint(t1, p1)
                val v01 = spherePoint(t0, p1)

                addVert12(data, v00[0] * 0.5f, v00[1] * 0.5f, v00[2] * 0.5f, v00[0], v00[1], v00[2], j.toFloat() / lonSteps, i.toFloat() / latSteps)
                addVert12(data, v10[0] * 0.5f, v10[1] * 0.5f, v10[2] * 0.5f, v10[0], v10[1], v10[2], j.toFloat() / lonSteps, (i + 1).toFloat() / latSteps)
                addVert12(data, v11[0] * 0.5f, v11[1] * 0.5f, v11[2] * 0.5f, v11[0], v11[1], v11[2], (j + 1).toFloat() / lonSteps, (i + 1).toFloat() / latSteps)

                addVert12(data, v00[0] * 0.5f, v00[1] * 0.5f, v00[2] * 0.5f, v00[0], v00[1], v00[2], j.toFloat() / lonSteps, i.toFloat() / latSteps)
                addVert12(data, v11[0] * 0.5f, v11[1] * 0.5f, v11[2] * 0.5f, v11[0], v11[1], v11[2], (j + 1).toFloat() / lonSteps, (i + 1).toFloat() / latSteps)
                addVert12(data, v01[0] * 0.5f, v01[1] * 0.5f, v01[2] * 0.5f, v01[0], v01[1], v01[2], (j + 1).toFloat() / lonSteps, i.toFloat() / latSteps)
            }
        }
        return uploadInterleaved12(data.toFloatArray())
    }

    fun createImportedWorldBundle(mesh: ImportedMeshData): UploadedWorldBundle {
        if (mesh.subMeshes.isNotEmpty()) {
            val list = mesh.subMeshes.map { sm -> createSubMeshGl(sm) }
            return UploadedWorldBundle(list, null)
        }
        val count = mesh.vertexCount
        val interleaved = FloatArray(count * 12)
        for (i in 0 until count) {
            val pIdx = i * 3
            val outIdx = i * 12
            interleaved[outIdx] = mesh.positions[pIdx]
            interleaved[outIdx + 1] = mesh.positions[pIdx + 1]
            interleaved[outIdx + 2] = mesh.positions[pIdx + 2]
            interleaved[outIdx + 3] = mesh.normals[pIdx]
            interleaved[outIdx + 4] = mesh.normals[pIdx + 1]
            interleaved[outIdx + 5] = mesh.normals[pIdx + 2]
            interleaved[outIdx + 6] = 0f
            interleaved[outIdx + 7] = 0f
            interleaved[outIdx + 8] = 1f
            interleaved[outIdx + 9] = 1f
            interleaved[outIdx + 10] = 1f
            interleaved[outIdx + 11] = 1f
        }
        return UploadedWorldBundle(emptyList(), uploadInterleaved12(interleaved))
    }

    private fun createSubMeshGl(sm: WorldSubMeshData): SubMeshGl {
        val full = uploadInterleaved12(sm.interleavedVertices)
        val lod = if (sm.vertexCount > 12_000) {
            // Simple 50% triangle-stride LOD for distant meshes
            val triCount = sm.vertexCount / 3
            val keepTris = (triCount + 1) / 2
            val lodArr = FloatArray(keepTris * 3 * 12)
            var outPtr = 0
            for (t in 0 until triCount step 2) {
                val srcOffset = t * 3 * 12
                val copyLen = 36
                if (srcOffset + copyLen <= sm.interleavedVertices.size && outPtr + copyLen <= lodArr.size) {
                    System.arraycopy(sm.interleavedVertices, srcOffset, lodArr, outPtr, copyLen)
                    outPtr += copyLen
                }
            }
            if (outPtr > 0) uploadInterleaved12(lodArr.copyOf(outPtr)) else null
        } else null

        return SubMeshGl(
            name = sm.name,
            fullMesh = full,
            lodMesh = lod,
            materialIndex = sm.materialIndex,
            boundsMin = sm.boundsMin,
            boundsMax = sm.boundsMax
        )
    }

    private fun addQuad(
        data: ArrayList<Float>,
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        nx: Float, ny: Float, nz: Float
    ) {
        addVert12(data, x0, y0, z0, nx, ny, nz, 0f, 1f)
        addVert12(data, x1, y1, z1, nx, ny, nz, 1f, 1f)
        addVert12(data, x2, y2, z2, nx, ny, nz, 1f, 0f)
        addVert12(data, x0, y0, z0, nx, ny, nz, 0f, 1f)
        addVert12(data, x2, y2, z2, nx, ny, nz, 1f, 0f)
        addVert12(data, x3, y3, z3, nx, ny, nz, 0f, 0f)
    }

    private fun spherePoint(theta: Double, phi: Double): FloatArray {
        val x = (cos(theta) * cos(phi)).toFloat()
        val y = sin(theta).toFloat()
        val z = (cos(theta) * sin(phi)).toFloat()
        return floatArrayOf(x, y, z)
    }

    private fun addVert12(
        list: ArrayList<Float>,
        x: Float, y: Float, z: Float,
        nx: Float, ny: Float, nz: Float,
        u: Float, v: Float
    ) {
        list.add(x); list.add(y); list.add(z)
        list.add(nx); list.add(ny); list.add(nz)
        list.add(u); list.add(v)
        list.add(1f); list.add(1f); list.add(1f); list.add(1f)
    }

    private fun uploadInterleaved12(array: FloatArray): GlMesh {
        val buf: FloatBuffer = ByteBuffer.allocateDirect(array.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(array)
        buf.position(0)
        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, array.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        return GlMesh(vbo[0], array.size / 12)
    }
}
