package com.example.vr.capture

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.example.ui.i18n.MineVrStrings
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.MineVrRenderer
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class VrOverlayController(
    private val context: Context,
    private val headTracker: HeadTracker,
    private val controllerManager: PlayStationControllerManager
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var vrSurfaceContainer: FrameLayout? = null
    private var vrGlView: GLSurfaceView? = null
    private var overlayRenderer: MineVrRenderer? = null
    private var controlBarView: LinearLayout? = null
    private var onOverlayClosedCallback: (() -> Unit)? = null

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    private var isPaused = false
    private var isLensLayerHidden = false

    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)

    fun updateSettings(vrSettings: VrSettingsState) {
        overlayRenderer?.vrSettings = vrSettings
    }

    fun showOverlay(
        vrSettings: VrSettingsState,
        strings: MineVrStrings,
        onRecenter: () -> Unit,
        onExitOverlay: () -> Unit,
        onOverlayDetached: () -> Unit = {}
    ): Boolean {
        if (!canDrawOverlays()) return false
        if (_isOverlayActive.value) return true

        isPaused = false
        isLensLayerHidden = false
        onOverlayClosedCallback = onOverlayDetached

        val renderer = MineVrRenderer(context, headTracker, controllerManager).apply {
            isPreviewMode = false
            isOverlayMode = true
            renderMode = VrRenderMode.MINECRAFT_LIVE_CAPTURE
            this.vrSettings = vrSettings
        }
        overlayRenderer = renderer
        VrProjectionService.setResizeListener { w, h ->
            renderer.onCapturedContentResized(w, h)
        }

        val glView = GLSurfaceView(context).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        vrGlView = glView

        val container = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                glView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            if (vrSettings.sideBySideEnabled) {
                val divider = View(context).apply {
                    setBackgroundColor(0x55FFFFFF)
                }
                addView(
                    divider,
                    FrameLayout.LayoutParams(4, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER_HORIZONTAL)
                )
            }
        }
        vrSurfaceContainer = container

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val surfaceParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Compact touchable control pill at bottom center so user can Recenter / Hide VR / Pause / Exit
        val bar = buildControlBar(strings, onRecenter, onExitOverlay)
        controlBarView = bar
        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 20
        }

        return runCatching {
            windowManager.addView(container, surfaceParams)
            windowManager.addView(bar, barParams)
            headTracker.start()
            _isOverlayActive.value = true
            true
        }.onFailure {
            hideOverlay()
        }.getOrDefault(false)
    }

    fun hideOverlay() {
        vrGlView?.onPause()
        overlayRenderer?.release()
        vrSurfaceContainer?.let { runCatching { windowManager.removeViewImmediate(it) } }
        controlBarView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        vrGlView = null
        overlayRenderer = null
        vrSurfaceContainer = null
        controlBarView = null
        _isOverlayActive.value = false
        onOverlayClosedCallback?.invoke()
        onOverlayClosedCallback = null
    }

    private fun buildControlBar(
        strings: MineVrStrings,
        onRecenter: () -> Unit,
        onExitOverlay: () -> Unit
    ): LinearLayout {
        val bg = GradientDrawable().apply {
            setColor(0xD912171E.toInt())
            cornerRadius = 48f
            setStroke(2, 0xFF2B3848.toInt())
        }

        fun makeBtn(label: String, textColor: Int, onClick: () -> Unit): Button =
            Button(context).apply {
                text = label
                textSize = 11f
                setTextColor(textColor)
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(18, 6, 18, 6)
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                setOnClickListener { onClick() }
            }

        lateinit var toggleLayerBtn: Button
        toggleLayerBtn = makeBtn(strings.hideVrLayer, 0xFFF59E0B.toInt()) {
            isLensLayerHidden = !isLensLayerHidden
            if (isLensLayerHidden) {
                vrSurfaceContainer?.visibility = View.GONE
                vrGlView?.onPause()
                toggleLayerBtn.text = strings.showVrLayer
            } else {
                vrSurfaceContainer?.visibility = View.VISIBLE
                vrGlView?.onResume()
                toggleLayerBtn.text = strings.hideVrLayer
            }
        }

        lateinit var pauseBtn: Button
        pauseBtn = makeBtn(strings.pauseVr, 0xFF38BDF8.toInt()) {
            isPaused = !isPaused
            overlayRenderer?.isPaused = isPaused
            pauseBtn.text = if (isPaused) strings.resumeVr else strings.pauseVr
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = bg
            setPadding(12, 2, 12, 2)
            addView(makeBtn(strings.recenterHead, 0xFF34D058.toInt(), onRecenter))
            addView(toggleLayerBtn)
            addView(pauseBtn)
            addView(makeBtn(strings.exitVr, 0xFFEF4444.toInt()) {
                hideOverlay()
                onExitOverlay()
            })
        }
    }
}
