package com.example.vr.capture

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.example.ui.i18n.MineVrStrings
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.MineVrRenderer
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class VrOverlayController(
    private val context: Context,
    private val headTracker: HeadTracker,
    private val controllerManager: PlayStationControllerManager
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var vrSurfaceContainer: FrameLayout? = null
    private var vrGlView: GLSurfaceView? = null
    private var overlayRenderer: MineVrRenderer? = null
    private var controlBarView: LinearLayout? = null

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    private var isPaused = false

    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)

    fun updateSettings(vrSettings: VrSettingsState) {
        overlayRenderer?.vrSettings = vrSettings
    }

    fun showOverlay(
        vrSettings: VrSettingsState,
        strings: MineVrStrings,
        onRecenter: () -> Unit,
        onExitOverlay: () -> Unit
    ): Boolean {
        if (!canDrawOverlays()) return false
        if (_isOverlayActive.value) return true

        isPaused = false
        val renderer = MineVrRenderer(context, headTracker, controllerManager).apply {
            isPreviewMode = false
            isOverlayMode = true
            renderMode = VrRenderMode.MINECRAFT_LIVE_CAPTURE
            this.vrSettings = vrSettings
        }
        overlayRenderer = renderer

        val glView = GLSurfaceView(context).apply {
            setEGLContextClientVersion(3)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        vrGlView = glView

        val container = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                glView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            if (vrSettings.sideBySideEnabled) {
                val divider = View(context).apply {
                    setBackgroundColor(0x55FFFFFF)
                }
                addView(
                    divider,
                    FrameLayout.LayoutParams(4, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER_HORIZONTAL)
                )
            }
        }
        vrSurfaceContainer = container

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val surfaceParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Compact touchable control pill at bottom center so user can always Recenter / Pause / Exit
        val bar = buildControlBar(strings, onRecenter, onExitOverlay)
        controlBarView = bar
        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 24
        }

        return runCatching {
            windowManager.addView(container, surfaceParams)
            windowManager.addView(bar, barParams)
            headTracker.start()
            _isOverlayActive.value = true
            true
        }.onFailure {
            hideOverlay()
        }.getOrDefault(false)
    }

    fun hideOverlay() {
        vrGlView?.onPause()
        overlayRenderer?.release()
        vrSurfaceContainer?.let { runCatching { windowManager.removeViewImmediate(it) } }
        controlBarView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        vrGlView = null
        overlayRenderer = null
        vrSurfaceContainer = null
        controlBarView = null
        _isOverlayActive.value = false
    }

    private fun buildControlBar(
        strings: MineVrStrings,
        onRecenter: () -> Unit,
        onExitOverlay: () -> Unit
    ): LinearLayout {
        val bg = GradientDrawable().apply {
            setColor(0xCC12171E.toInt())
            cornerRadius = 48f
            setStroke(2, 0xFF2B3848.toInt())
        }

        fun makeBtn(label: String, textColor: Int, onClick: () -> Unit): Button =
            Button(context).apply {
                text = label
                textSize = 11f
                setTextColor(textColor)
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(24, 8, 24, 8)
                minHeight = 0
                minimumHeight = 0
                setOnClickListener { onClick() }
            }

        lateinit var pauseBtn: Button
        pauseBtn = makeBtn(strings.pauseVr, 0xFF38BDF8.toInt()) {
            isPaused = !isPaused
            overlayRenderer?.isPaused = isPaused
            pauseBtn.text = if (isPaused) strings.resumeVr else strings.pauseVr
        }

        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = bg
            setPadding(16, 4, 16, 4)
            addView(makeBtn(strings.recenterHead, 0xFF34D058.toInt(), onRecenter))
            addView(pauseBtn)
            addView(makeBtn(strings.exitVr, 0xFFEF4444.toInt()) {
                hideOverlay()
                onExitOverlay()
            })
        }
    }
}
