package com.example.vr.engine

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.Surface
import com.example.vr.camera.HeadTracker
import com.example.vr.capture.VrProjectionService
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class MineVrRenderer(
    private val context: Context,
    private val headTracker: HeadTracker,
    private val controllerManager: PlayStationControllerManager
) : GLSurfaceView.Renderer {

    @Volatile
    var vrSettings: VrSettingsState = VrSettingsState()

    @Volatile
    var renderMode: VrRenderMode = VrRenderMode.STEREO_VOXEL_SANDBOX

    @Volatile
    var isPaused: Boolean = false

    @Volatile
    var isPreviewMode: Boolean = false

    @Volatile
    var isOverlayMode: Boolean = false

    @Volatile
    var isInMultiWindowMode: Boolean = false

    @Volatile
    var hasLiveCaptureFrame: Boolean = false
        private set

    private var surfaceWidth = 1280
    private var surfaceHeight = 720

    // Shaders & VAOs
    private var voxelProgram = 0
    private var distort2dProgram = 0
    private var distortOesProgram = 0

    private var quadVbo = 0
    private var voxelVbo = 0
    private var voxelVertexCount = 0

    // FBO for true 3D stereoscopic eye rendering -> barrel distortion pass
    private var fboId = 0
    private var fboColorTex = 0
    private var fboDepthRbo = 0
    private var fboWidth = 0
    private var fboHeight = 0

    // OES External Texture for zero-copy MediaProjection capture
    private var oesTexId = 0
    private var captureSurfaceTexture: SurfaceTexture? = null
    private var captureSurface: Surface? = null
    private val frameAvailable = AtomicBoolean(false)
    private val texMatrix = FloatArray(16).apply { Matrix.setIdentityM(this, 0) }

    // 3D Voxel player state (used in STEREO_VOXEL_SANDBOX mode)
    private var playerX = 0f
    private var playerY = 2.6f
    private var playerZ = 6f
    private var controllerYawOffset = 0f
    private var controllerPitchOffset = 0f
    private var lastFrameNs = 0L

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.02f, 0.03f, 0.04f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)

        voxelProgram = MineVrShaders.createProgram(MineVrShaders.VOXEL_VS, MineVrShaders.VOXEL_FS)
        distort2dProgram = MineVrShaders.createProgram(MineVrShaders.DISTORT_VS, MineVrShaders.DISTORT_2D_FS)
        distortOesProgram = MineVrShaders.createProgram(MineVrShaders.DISTORT_VS, MineVrShaders.DISTORT_OES_FS)

        setupQuadBuffer()
        setupVoxelWorldMesh()
        setupExternalCaptureTexture()
        lastFrameNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(2)
        surfaceHeight = height.coerceAtLeast(2)
        ensureFboSize((surfaceWidth / 2).coerceIn(480, 1280), surfaceHeight.coerceIn(480, 1280))
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        val dt = ((nowNs - lastFrameNs) * 1e-9f).coerceIn(0.001f, 0.05f)
        lastFrameNs = nowNs

        if (frameAvailable.compareAndSet(true, false)) {
            runCatching {
                captureSurfaceTexture?.updateTexImage()
                captureSurfaceTexture?.getTransformMatrix(texMatrix)
                hasLiveCaptureFrame = true
                if (!isPreviewMode) {
                    VrProjectionService.reportCapturedFrame(
                        isAppInForegroundFullscreen = !isOverlayMode && !isInMultiWindowMode
                    )
                }
            }
        }

        if (!isPaused && renderMode == VrRenderMode.STEREO_VOXEL_SANDBOX) {
            updateSandboxPlayer(dt)
        }

        GLES30.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val settings = vrSettings
        val layout = VrBoxOptics.computeLayout(
            surfaceWidthPx = surfaceWidth,
            surfaceHeightPx = surfaceHeight,
            metrics = context.resources.displayMetrics,
            vr = settings
        )

        val useCapture = renderMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE && hasLiveCaptureFrame && !isPreviewMode

        if (useCapture) {
            renderEyeCaptureOes(layout.leftEye, settings)
            if (settings.sideBySideEnabled) {
                renderEyeCaptureOes(layout.rightEye, settings)
            }
        } else {
            // Render genuine left-eye and right-eye 3D perspectives separated by IPD
            val ipdMeters = (settings.ipdMm / 1000f).coerceIn(0.055f, 0.072f)
            renderEyeVoxel3D(layout.leftEye, eyeOffsetMeters = -ipdMeters * 0.5f, settings = settings)
            if (settings.sideBySideEnabled) {
                renderEyeVoxel3D(layout.rightEye, eyeOffsetMeters = ipdMeters * 0.5f, settings = settings)
            }
        }
    }

    fun release() {
        if (!isPreviewMode) {
            VrProjectionService.attachRenderSurface(null)
        }
        runCatching { captureSurface?.release() }
        runCatching { captureSurfaceTexture?.release() }
        captureSurface = null
        captureSurfaceTexture = null
        hasLiveCaptureFrame = false
    }

    private fun updateSandboxPlayer(dt: Float) {
        val snap = controllerManager.snapshot.value
        val lookSpeed = 95f
        controllerYawOffset -= snap.rightX * lookSpeed * dt
        controllerPitchOffset = (controllerPitchOffset - snap.rightY * lookSpeed * dt).coerceIn(-65f, 65f)

        val totalYawDeg = headTracker.getCalibratedYawDeg() + controllerYawOffset
        val yawRad = Math.toRadians(totalYawDeg.toDouble())
        val fwdX = (-sin(yawRad)).toFloat()
        val fwdZ = (-cos(yawRad)).toFloat()
        val rightX = cos(yawRad).toFloat()
        val rightZ = (-sin(yawRad)).toFloat()

        val speed = 4.5f * dt
        playerX += (fwdX * (-snap.leftY) + rightX * snap.leftX) * speed
        playerZ += (fwdZ * (-snap.leftY) + rightZ * snap.leftX) * speed
        playerX = playerX.coerceIn(-12f, 12f)
        playerZ = playerZ.coerceIn(-12f, 12f)
    }

    private fun renderEyeVoxel3D(
        viewport: EyeViewportPx,
        eyeOffsetMeters: Float,
        settings: VrSettingsState
    ) {
        // Pass 1: Render 3D scene into FBO
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glViewport(0, 0, fboWidth, fboHeight)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glClearColor(0.44f, 0.72f, 0.96f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val yawDeg = headTracker.getCalibratedYawDeg() + controllerYawOffset
        val pitchDeg = (headTracker.getScaledPitchDeg() + controllerPitchOffset).coerceIn(-82f, 82f)
        val rollDeg = if (settings.horizonLockEnabled) 0f else headTracker.rollDeg

        val aspect = (viewport.width.toFloat() / viewport.height.coerceAtLeast(1).toFloat()).coerceIn(0.6f, 2.2f)
        Matrix.perspectiveM(projMatrix, 0, settings.fovDegrees.coerceIn(60f, 120f), aspect, 0.1f, 80f)

        val yawRad = Math.toRadians(yawDeg.toDouble())
        val pitchRad = Math.toRadians(pitchDeg.toDouble())
        val fx = (-sin(yawRad) * cos(pitchRad)).toFloat()
        val fy = sin(pitchRad).toFloat()
        val fz = (-cos(yawRad) * cos(pitchRad)).toFloat()

        val rx = cos(yawRad).toFloat()
        val rz = (-sin(yawRad)).toFloat()
        val camX = playerX + rx * eyeOffsetMeters
        val camY = playerY
        val camZ = playerZ + rz * eyeOffsetMeters

        val rollRad = Math.toRadians(rollDeg.toDouble())
        val upX = (-rx * sin(rollRad)).toFloat()
        val upY = cos(rollRad).toFloat()
        val upZ = (-rz * sin(rollRad)).toFloat()

        Matrix.setLookAtM(
            viewMatrix, 0,
            camX, camY, camZ,
            camX + fx, camY + fy, camZ + fz,
            upX, upY, upZ
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

        GLES30.glUseProgram(voxelProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(voxelProgram, "uMvp"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(voxelProgram, "uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(voxelProgram, "uSunDir"), 0.55f, 0.85f, 0.35f)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(voxelProgram, "uCamPos"), camX, camY, camZ)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(voxelProgram, "uBrightness"), settings.brightness.coerceIn(0.4f, 1.5f))

        drawVoxelBuffers()

        // Pass 2: Barrel-distort FBO into eye viewport
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(viewport.x, viewport.y, viewport.width, viewport.height)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)

        GLES30.glUseProgram(distort2dProgram)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(distort2dProgram, "uTex"), 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distort2dProgram, "uK1"), settings.barrelDistortionK1)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distort2dProgram, "uK2"), settings.barrelDistortionK2)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distort2dProgram, "uChromatic"), settings.chromaticAberration)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distort2dProgram, "uBrightness"), settings.brightness)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distort2dProgram, "uFlip"), if (settings.flipOrientation) 1f else 0f)

        drawFullscreenQuad()
    }

    private fun renderEyeCaptureOes(viewport: EyeViewportPx, settings: VrSettingsState) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(viewport.x, viewport.y, viewport.width, viewport.height)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)

        GLES30.glUseProgram(distortOesProgram)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(distortOesProgram, "uExtTex"), 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(distortOesProgram, "uTexMatrix"), 1, false, texMatrix, 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distortOesProgram, "uK1"), settings.barrelDistortionK1)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distortOesProgram, "uK2"), settings.barrelDistortionK2)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distortOesProgram, "uChromatic"), settings.chromaticAberration)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distortOesProgram, "uBrightness"), settings.brightness)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(distortOesProgram, "uFlip"), if (settings.flipOrientation) 1f else 0f)

        drawFullscreenQuad()
    }

    private fun setupExternalCaptureTexture() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        oesTexId = ids[0]
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(oesTexId).apply {
            setDefaultBufferSize(1280, 720)
            setOnFrameAvailableListener {
                frameAvailable.set(true)
            }
        }
        captureSurfaceTexture = st
        val s = Surface(st)
        captureSurface = s
        if (!isPreviewMode) {
            VrProjectionService.attachRenderSurface(s)
        }
    }

    private fun ensureFboSize(w: Int, h: Int) {
        if (w == fboWidth && h == fboHeight && fboId != 0) return
        if (fboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(fboId), 0)
            GLES30.glDeleteTextures(1, intArrayOf(fboColorTex), 0)
            GLES30.glDeleteRenderbuffers(1, intArrayOf(fboDepthRbo), 0)
        }
        fboWidth = w
        fboHeight = h

        val fbos = IntArray(1)
        val texs = IntArray(1)
        val rbos = IntArray(1)
        GLES30.glGenFramebuffers(1, fbos, 0)
        GLES30.glGenTextures(1, texs, 0)
        GLES30.glGenRenderbuffers(1, rbos, 0)
        fboId = fbos[0]
        fboColorTex = texs[0]
        fboDepthRbo = rbos[0]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, w, h, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, fboDepthRbo)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, w, h)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, fboColorTex, 0)
        GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, fboDepthRbo)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun setupQuadBuffer() {
        val quad = floatArrayOf(
            -1f, -1f, 0f, 0f,
            1f, -1f, 1f, 0f,
            -1f, 1f, 0f, 1f,
            1f, -1f, 1f, 0f,
            1f, 1f, 1f, 1f,
            -1f, 1f, 0f, 1f
        )
        val buf = toFloatBuffer(quad)
        val vbos = IntArray(1)
        GLES30.glGenBuffers(1, vbos, 0)
        quadVbo = vbos[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun drawFullscreenQuad() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 16, 8)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun setupVoxelWorldMesh() {
        val verts = ArrayList<Float>(16000)
        // Build a bright Minecraft-style grassy terrain with oak trees, stone pillars, and diamond ore
        for (gx in -10..10) {
            for (gz in -10..10) {
                val h = if ((gx * gx + gz * gz) > 55) 1f else 0f
                val isPath = kotlin.math.abs(gx) <= 1 && gz in -8..8
                if (isPath) {
                    addBlock(verts, gx.toFloat(), 0f, gz.toFloat(), 0.56f, 0.55f, 0.54f) // cobblestone path
                } else {
                    addGrassBlock(verts, gx.toFloat(), h, gz.toFloat())
                }
            }
        }
        // Oak trees
        addTree(verts, -5f, 1f, -4f)
        addTree(verts, 5f, 1f, -5f)
        addTree(verts, -6f, 1f, 5f)
        addTree(verts, 6f, 1f, 4f)
        // Crafting house / landmark tower ahead
        for (y in 1..3) {
            addBlock(verts, -2f, y.toFloat(), -5f, 0.65f, 0.45f, 0.25f)
            addBlock(verts, 2f, y.toFloat(), -5f, 0.65f, 0.45f, 0.25f)
        }
        // Diamond block beacon in the center plaza
        addBlock(verts, 0f, 1f, -5f, 0.24f, 0.85f, 0.94f)
        addBlock(verts, 0f, 2f, -5f, 0.22f, 0.78f, 0.90f)

        val arr = verts.toFloatArray()
        voxelVertexCount = arr.size / 9
        val buf = toFloatBuffer(arr)
        val vbos = IntArray(1)
        GLES30.glGenBuffers(1, vbos, 0)
        voxelVbo = vbos[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, voxelVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, arr.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun drawVoxelBuffers() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, voxelVbo)
        val stride = 9 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, stride, 24)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, voxelVertexCount)
        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)
        GLES30.glDisableVertexAttribArray(2)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun addTree(out: MutableList<Float>, x: Float, baseY: Float, z: Float) {
        for (y in 0..2) addBlock(out, x, baseY + y, z, 0.42f, 0.28f, 0.16f)
        for (dx in -1..1) {
            for (dz in -1..1) {
                addBlock(out, x + dx, baseY + 3f, z + dz, 0.16f, 0.56f, 0.20f)
                if (kotlin.math.abs(dx) + kotlin.math.abs(dz) <= 1) {
                    addBlock(out, x + dx, baseY + 4f, z + dz, 0.20f, 0.64f, 0.24f)
                }
            }
        }
    }

    private fun addGrassBlock(out: MutableList<Float>, x: Float, y: Float, z: Float) {
        // Top grass green, sides dirt brown
        addBlockFaces(out, x, y, z, topR = 0.27f, topG = 0.72f, topB = 0.22f, sideR = 0.45f, sideG = 0.30f, sideB = 0.18f)
    }

    private fun addBlock(out: MutableList<Float>, x: Float, y: Float, z: Float, r: Float, g: Float, b: Float) {
        addBlockFaces(out, x, y, z, r, g, b, r * 0.9f, g * 0.9f, b * 0.9f)
    }

    private fun addBlockFaces(
        out: MutableList<Float>,
        bx: Float, by: Float, bz: Float,
        topR: Float, topG: Float, topB: Float,
        sideR: Float, sideG: Float, sideB: Float
    ) {
        val x0 = bx - 0.5f; val x1 = bx + 0.5f
        val y0 = by - 0.5f; val y1 = by + 0.5f
        val z0 = bz - 0.5f; val z1 = bz + 0.5f
        // Top (+Y)
        addQuad(out, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0f, 1f, 0f, topR, topG, topB)
        // Front (+Z)
        addQuad(out, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0f, 0f, 1f, sideR, sideG, sideB)
        // Back (-Z)
        addQuad(out, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0f, 0f, -1f, sideR, sideG, sideB)
        // Left (-X)
        addQuad(out, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1f, 0f, 0f, sideR, sideG, sideB)
        // Right (+X)
        addQuad(out, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1f, 0f, 0f, sideR, sideG, sideB)
    }

    private fun addQuad(
        out: MutableList<Float>,
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        pushVert(out, x0, y0, z0, nx, ny, nz, r, g, b)
        pushVert(out, x1, y1, z1, nx, ny, nz, r, g, b)
        pushVert(out, x2, y2, z2, nx, ny, nz, r, g, b)
        pushVert(out, x0, y0, z0, nx, ny, nz, r, g, b)
        pushVert(out, x2, y2, z2, nx, ny, nz, r, g, b)
        pushVert(out, x3, y3, z3, nx, ny, nz, r, g, b)
    }

    private fun pushVert(
        out: MutableList<Float>,
        x: Float, y: Float, z: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        out.add(x); out.add(y); out.add(z)
        out.add(nx); out.add(ny); out.add(nz)
        out.add(r); out.add(g); out.add(b)
    }

    private fun toFloatBuffer(arr: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(arr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(arr)
            position(0)
        }
}
