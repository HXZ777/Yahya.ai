package com.example.vr.engine

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.DisplayMetrics
import com.example.vr.model.AllSettingsState
import com.example.vr.model.AlphaMode
import com.example.vr.model.ControlScheme
import com.example.vr.model.GraphicsQuality
import com.example.vr.model.HandTrackingState
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.ItemContainer
import com.example.vr.model.MovementMode
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.ProductItem
import com.example.vr.model.ProductMeshShape
import com.example.vr.model.TimeOfDay
import com.example.vr.model.Transform3D
import com.example.vr.model.WeatherType
import com.example.vr.model.WorldLightingConfig
import com.example.vr.model.WorldNodeEntry
import com.example.vr.model.WorldProjectState
import com.example.vr.model.WorldType
import com.example.vr.world.BlockMaterialTag
import com.example.vr.world.BlockMeshKind
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.ConcurrentHashMap
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class EditorCameraState(
    val targetX: Float = 0f,
    val targetY: Float = 1.6f,
    val targetZ: Float = 0f,
    val yawDeg: Float = 28f,
    val pitchDeg: Float = 24f,
    val distance: Float = 22f
)

class VrRenderer(
    private val controller: GameSimulationController
) : GLSurfaceView.Renderer {

    @Volatile var settings: AllSettingsState = AllSettingsState()
    @Volatile var handState: HandTrackingState = HandTrackingState()
    @Volatile var displayMetrics: DisplayMetrics = DisplayMetrics().apply { xdpi = 400f; ydpi = 400f }

    // World Editor live state
    @Volatile var editorMode: Boolean = false
    @Volatile var editorCamera: EditorCameraState = EditorCameraState()
    @Volatile var activeProject: WorldProjectState? = null
    @Volatile var editorSelectedNodeId: String? = null
    @Volatile var editorSelectedSpawnId: String? = null
    @Volatile var editorWholeWorldSelected: Boolean = false
    @Volatile var editorAxisHighlight: Int = -1 // 0=X, 1=Y, 2=Z

    @Volatile private var activeCustomMeshData: ImportedMeshData? = null
    @Volatile private var customMeshDirty: Boolean = false
    private val extraMeshData = ConcurrentHashMap<String, ImportedMeshData>()
    @Volatile private var extraMeshesDirty: Boolean = false

    private var uploadedRootBundle: UploadedWorldBundle? = null
    private val uploadedExtraBundles = HashMap<String, UploadedWorldBundle>()
    private val textureCache = GlTextureCache()

    private var sceneProgram = 0
    private var postProgram = 0

    // Scene uniforms & attributes
    private var uMvpLoc = 0
    private var uModelLoc = 0
    private var uColorLoc = 0
    private var uAlphaLoc = 0
    private var uTagLoc = 0
    private var uHighlightLoc = 0
    private var uLightDirLoc = 0
    private var uCamPosLoc = 0
    private var uFogColorLoc = 0
    private var uFogDensityLoc = 0
    private var uReflectLoc = 0
    private var uBaseTexLoc = 0
    private var uHasBaseTexLoc = 0
    private var uNormalTexLoc = 0
    private var uHasNormalTexLoc = 0
    private var uAlphaModeLoc = 0
    private var uAlphaCutoffLoc = 0
    private var uMetallicLoc = 0
    private var uRoughnessLoc = 0
    private var uExposureLoc = 0
    private var uDirIntensityLoc = 0
    private var uAmbientIntensityLoc = 0
    private var uEmissiveLoc = 0
    private var aPosLoc = 0
    private var aNormLoc = 0
    private var aUvLoc = 0
    private var aColorLoc = 0

    // Post-process uniforms
    private var uPostTexLoc = 0
    private var uDistortionK1Loc = 0
    private var uChromaticLoc = 0
    private var uImageScaleLoc = 0
    private var uEyeOffsetLoc = 0
    private var uVignetteLoc = 0
    private var aPostPosLoc = 0
    private var aPostUvLoc = 0

    // Primitive meshes
    private lateinit var cubeMesh: GlMesh
    private lateinit var cylMesh: GlMesh
    private lateinit var coneMesh: GlMesh
    private lateinit var sphereMesh: GlMesh
    private var quadVbo = 0

    private var fboId = 0
    private var fboColorTex = 0
    private var fboDepthRb = 0
    private var fboWidth = 0
    private var fboHeight = 0

    private var surfaceWidth = 1280
    private var surfaceHeight = 720

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val tmpWorldMatrix = FloatArray(16)
    private val tmpNodeMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private var lastFrameNs = System.nanoTime()
    private var fpsAccumSec = 0f
    private var fpsFrameCount = 0
    private var currentFps = 60
    private var animTimeSec = 0f

    fun setCustomImportedMesh(mesh: ImportedMeshData?) {
        activeCustomMeshData = mesh
        customMeshDirty = true
    }

    fun registerExtraModelMesh(assetPath: String, mesh: ImportedMeshData) {
        extraMeshData[assetPath] = mesh
        extraMeshesDirty = true
    }

    fun clearExtraModelMeshes() {
        extraMeshData.clear()
        extraMeshesDirty = true
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        uploadedRootBundle = null
        uploadedExtraBundles.clear()
        textureCache.clear()
        customMeshDirty = activeCustomMeshData != null
        extraMeshesDirty = extraMeshData.isNotEmpty()

        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

        sceneProgram = GlTextureAndShaderHelper.createProgram(
            GlTextureAndShaderHelper.SCENE_VS,
            GlTextureAndShaderHelper.SCENE_FS
        )
        uMvpLoc = GLES30.glGetUniformLocation(sceneProgram, "uMvp")
        uModelLoc = GLES30.glGetUniformLocation(sceneProgram, "uModel")
        uColorLoc = GLES30.glGetUniformLocation(sceneProgram, "uColor")
        uAlphaLoc = GLES30.glGetUniformLocation(sceneProgram, "uAlpha")
        uTagLoc = GLES30.glGetUniformLocation(sceneProgram, "uTag")
        uHighlightLoc = GLES30.glGetUniformLocation(sceneProgram, "uHighlight")
        uLightDirLoc = GLES30.glGetUniformLocation(sceneProgram, "uLightDir")
        uCamPosLoc = GLES30.glGetUniformLocation(sceneProgram, "uCamPos")
        uFogColorLoc = GLES30.glGetUniformLocation(sceneProgram, "uFogColor")
        uFogDensityLoc = GLES30.glGetUniformLocation(sceneProgram, "uFogDensity")
        uReflectLoc = GLES30.glGetUniformLocation(sceneProgram, "uReflect")
        uBaseTexLoc = GLES30.glGetUniformLocation(sceneProgram, "uBaseTex")
        uHasBaseTexLoc = GLES30.glGetUniformLocation(sceneProgram, "uHasBaseTex")
        uNormalTexLoc = GLES30.glGetUniformLocation(sceneProgram, "uNormalTex")
        uHasNormalTexLoc = GLES30.glGetUniformLocation(sceneProgram, "uHasNormalTex")
        uAlphaModeLoc = GLES30.glGetUniformLocation(sceneProgram, "uAlphaMode")
        uAlphaCutoffLoc = GLES30.glGetUniformLocation(sceneProgram, "uAlphaCutoff")
        uMetallicLoc = GLES30.glGetUniformLocation(sceneProgram, "uMetallic")
        uRoughnessLoc = GLES30.glGetUniformLocation(sceneProgram, "uRoughness")
        uExposureLoc = GLES30.glGetUniformLocation(sceneProgram, "uExposure")
        uDirIntensityLoc = GLES30.glGetUniformLocation(sceneProgram, "uDirIntensity")
        uAmbientIntensityLoc = GLES30.glGetUniformLocation(sceneProgram, "uAmbientIntensity")
        uEmissiveLoc = GLES30.glGetUniformLocation(sceneProgram, "uEmissive")

        aPosLoc = GLES30.glGetAttribLocation(sceneProgram, "aPos")
        aNormLoc = GLES30.glGetAttribLocation(sceneProgram, "aNorm")
        aUvLoc = GLES30.glGetAttribLocation(sceneProgram, "aUv")
        aColorLoc = GLES30.glGetAttribLocation(sceneProgram, "aColor")

        postProgram = GlTextureAndShaderHelper.createProgram(
            GlTextureAndShaderHelper.POST_VS,
            GlTextureAndShaderHelper.POST_FS
        )
        uPostTexLoc = GLES30.glGetUniformLocation(postProgram, "uTex")
        uDistortionK1Loc = GLES30.glGetUniformLocation(postProgram, "uK1")
        uChromaticLoc = GLES30.glGetUniformLocation(postProgram, "uChromatic")
        uImageScaleLoc = GLES30.glGetUniformLocation(postProgram, "uImageScale")
        uEyeOffsetLoc = GLES30.glGetUniformLocation(postProgram, "uEyeOffset")
        uVignetteLoc = GLES30.glGetUniformLocation(postProgram, "uVignette")
        aPostPosLoc = GLES30.glGetAttribLocation(postProgram, "aPos")
        aPostUvLoc = GLES30.glGetAttribLocation(postProgram, "aUv")

        cubeMesh = MeshBuilder.createUnitCube()
        cylMesh = MeshBuilder.createCylinder(14)
        coneMesh = MeshBuilder.createCone(12)
        sphereMesh = MeshBuilder.createSphere(8, 12)
        quadVbo = createFullscreenQuadVbo()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(2)
        surfaceHeight = height.coerceAtLeast(2)
        fboWidth = 0
        fboHeight = 0
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        val minFrameMs = 1000L / settings.graphics.targetFps.fps
        val elapsedMs = (nowNs - lastFrameNs) / 1_000_000L
        if (elapsedMs < minFrameMs) {
            runCatching { Thread.sleep(minFrameMs - elapsedMs) }
        }
        val afterSleepNs = System.nanoTime()
        val dt = ((afterSleepNs - lastFrameNs) / 1_000_000_000.0).toFloat().coerceIn(0.004f, 0.08f)
        lastFrameNs = afterSleepNs

        animTimeSec += dt
        fpsAccumSec += dt
        fpsFrameCount++
        if (fpsAccumSec >= 0.5f) {
            currentFps = (fpsFrameCount / fpsAccumSec).toInt().coerceIn(1, 120)
            fpsAccumSec = 0f
            fpsFrameCount = 0
        }

        textureCache.setTextureQuality(settings.graphics.textureQuality)

        if (customMeshDirty) {
            customMeshDirty = false
            uploadedRootBundle?.delete()
            textureCache.clear()
            val data = activeCustomMeshData
            uploadedRootBundle = if (data != null) MeshBuilder.createImportedWorldBundle(data) else null
        }

        if (extraMeshesDirty) {
            extraMeshesDirty = false
            for ((path, meshData) in extraMeshData) {
                if (!uploadedExtraBundles.containsKey(path)) {
                    uploadedExtraBundles[path] = MeshBuilder.createImportedWorldBundle(meshData)
                }
            }
        }

        val projLighting = activeProject?.lighting ?: WorldLightingConfig(
            timeOfDay = settings.graphics.timeOfDay,
            shadowsEnabled = settings.graphics.shadowsEnabled,
            reflectionsEnabled = settings.graphics.reflectionsEnabled,
            fogDensity = when (settings.graphics.weather) {
                WeatherType.CLEAR -> 0.007f
                WeatherType.RAIN -> 0.020f
                WeatherType.FOG -> 0.042f
            }
        )

        val effectiveTimeOfDay = if (activeProject != null) projLighting.timeOfDay else settings.graphics.timeOfDay
        val (skyR, skyG, skyB) = when (effectiveTimeOfDay) {
            TimeOfDay.MORNING -> Triple(0.55f, 0.76f, 0.94f)
            TimeOfDay.NOON -> Triple(0.45f, 0.72f, 0.96f)
            TimeOfDay.SUNSET -> Triple(0.86f, 0.48f, 0.32f)
            TimeOfDay.NIGHT -> Triple(0.05f, 0.08f, 0.16f)
        }
        val fogDensity = if (projLighting.fogEnabled) projLighting.fogDensity else 0f

        if (editorMode) {
            renderEditorViewport(skyR, skyG, skyB, fogDensity, projLighting)
            return
        }

        controller.tick(dt, currentFps)
        val snap = controller.snapshot.value

        val vr = settings.vr
        val isStereo = vr.sideBySideEnabled
        val layout = VrBoxOptics.computeLayout(surfaceWidth, surfaceHeight, displayMetrics, vr)
        val qualityScale = when (settings.graphics.quality) {
            GraphicsQuality.LOW -> 0.70f
            GraphicsQuality.MEDIUM -> 0.88f
            GraphicsQuality.HIGH -> 1.0f
        }
        val eyeTargetW = (layout.leftEye.width * qualityScale).toInt().coerceAtLeast(128)
        val eyeTargetH = (layout.leftEye.height * qualityScale).toInt().coerceAtLeast(128)
        val usePostProcess = isStereo && (vr.lensDistortionEnabled || vr.chromaticAberrationEnabled)
        if (usePostProcess) ensureFbo(eyeTargetW, eyeTargetH)

        if (isStereo) {
            GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
            GLES30.glClearColor(0f, 0f, 0f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

            val virtualEyeBaselineM = (vr.ipdMm * 0.48f) / 1000f
            val eyes = arrayOf(layout.leftEye, layout.rightEye)

            for (eye in 0..1) {
                val vp = eyes[eye]
                val eyeSign = if (eye == 0) -0.5f else 0.5f
                val aspect = (vp.width.toFloat() / vp.height.toFloat()).coerceAtLeast(0.45f)

                if (usePostProcess) {
                    GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
                    GLES30.glViewport(0, 0, fboWidth, fboHeight)
                    GLES30.glClearColor(skyR, skyG, skyB, 1f)
                    GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

                    renderEyeScene(snap, eyeSign * virtualEyeBaselineM, aspect, skyR, skyG, skyB, fogDensity, projLighting)

                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                    GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
                    GLES30.glScissor(vp.x, vp.y, vp.width, vp.height)
                    GLES30.glViewport(vp.x, vp.y, vp.width, vp.height)
                    drawPostEyeQuad(
                        k1 = if (vr.lensDistortionEnabled) vr.distortionK1 else 0f,
                        chromatic = if (vr.chromaticAberrationEnabled) 0.008f else 0f,
                        imageScale = vr.imageScale,
                        eyeOffset = if (eye == 0) -vr.eyeSeparationOffset else vr.eyeSeparationOffset
                    )
                    GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                } else {
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                    GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
                    GLES30.glScissor(vp.x, vp.y, vp.width, vp.height)
                    GLES30.glViewport(vp.x, vp.y, vp.width, vp.height)
                    GLES30.glClearColor(skyR, skyG, skyB, 1f)
                    GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

                    renderEyeScene(snap, eyeSign * virtualEyeBaselineM, aspect, skyR, skyG, skyB, fogDensity, projLighting)
                    GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                }
            }
        } else {
            GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
            GLES30.glClearColor(skyR, skyG, skyB, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            val aspect = (surfaceWidth.toFloat() / surfaceHeight.toFloat()).coerceAtLeast(0.5f)
            renderEyeScene(snap, 0f, aspect, skyR, skyG, skyB, fogDensity, projLighting)
        }
    }

    private fun renderEditorViewport(
        skyR: Float, skyG: Float, skyB: Float,
        fogDensity: Float,
        lighting: WorldLightingConfig
    ) {
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
        GLES30.glClearColor(skyR * 0.85f, skyG * 0.85f, skyB * 0.90f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val aspect = (surfaceWidth.toFloat() / surfaceHeight.toFloat()).coerceAtLeast(0.5f)
        Matrix.perspectiveM(projMatrix, 0, 62f, aspect, 0.1f, 320f)

        val cam = editorCamera
        val yawRad = Math.toRadians(cam.yawDeg.toDouble())
        val pitchRad = Math.toRadians(cam.pitchDeg.toDouble().coerceIn(-80.0, 80.0))
        val dist = cam.distance.coerceIn(2.5f, 120f)
        val eyeX = cam.targetX + (sin(yawRad) * cos(pitchRad) * dist).toFloat()
        val eyeY = cam.targetY + (sin(pitchRad) * dist).toFloat()
        val eyeZ = cam.targetZ + (cos(yawRad) * cos(pitchRad) * dist).toFloat()

        Matrix.setLookAtM(viewMatrix, 0, eyeX, eyeY, eyeZ, cam.targetX, cam.targetY, cam.targetZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        setupSceneUniforms(eyeX, eyeY, eyeZ, skyR, skyG, skyB, fogDensity, lighting)

        // Editor floor reference grid
        drawSimplePrimitive(cubeMesh, 0f, -0.06f, 0f, 120f, 0.08f, 120f, 0f, 0f, 0xFF334155, 1f, 1, 0f)

        // Render world project nodes + materials + textures
        renderCustomWorldProject(eyeX, eyeY, eyeZ, highlightSelected = true)

        // Render Spawn Point 3D Markers & Look Direction Arrows
        activeProject?.spawnPoints?.forEach { sp ->
            val isSel = sp.id == editorSelectedSpawnId
            val baseCol = if (sp.isPrimary) 0xFF10B981 else 0xFF00E5FF
            val hl = if (isSel) 0.75f else 0.15f
            val baseY = sp.y + sp.elevationOffset
            // Pedestal ring
            drawSimplePrimitive(cylMesh, sp.x, baseY + 0.05f, sp.z, 1.1f, 0.10f, 1.1f, sp.yawDeg, 0f, baseCol, 0.9f, 3, hl)
            // Capsule body representing player height (~1.65m)
            drawSimplePrimitive(cylMesh, sp.x, baseY + 0.90f, sp.z, 0.46f, 1.55f, 0.46f, sp.yawDeg, 0f, baseCol, 0.85f, 3, hl)
            drawSimplePrimitive(sphereMesh, sp.x, baseY + 1.72f, sp.z, 0.38f, 0.38f, 0.38f, sp.yawDeg, 0f, 0xFFFDE047, 0.95f, 3, hl)
            // Forward direction cone
            val fwd = GlMath.forwardVectorXZ(sp.yawDeg)
            drawSimplePrimitive(coneMesh, sp.x + fwd[0] * 0.85f, baseY + 1.0f, sp.z + fwd[2] * 0.85f, 0.28f, 0.65f, 0.28f, sp.yawDeg, -90f, 0xFFFACC15, 0.95f, 3, hl)
        }

        // Render 3D XYZ Axis Gizmo on selected target
        val gizmoCenter = resolveSelectedGizmoCenter()
        if (gizmoCenter != null) {
            drawAxisGizmo(gizmoCenter[0], gizmoCenter[1], gizmoCenter[2])
        }
    }

    private fun resolveSelectedGizmoCenter(): FloatArray? {
        val proj = activeProject ?: return null
        val wt = proj.worldTransform
        editorSelectedSpawnId?.let { sId ->
            proj.spawnPoints.find { it.id == sId }?.let { sp ->
                return floatArrayOf(sp.x, sp.y + sp.elevationOffset + 0.9f, sp.z)
            }
        }
        if (editorWholeWorldSelected) {
            return floatArrayOf(wt.posX, wt.posY + 1.5f, wt.posZ)
        }
        val node = proj.nodes.find { it.id == editorSelectedNodeId } ?: return null
        val cx = (node.localMinX + node.localMaxX) * 0.5f * node.transform.scaleX + node.transform.posX
        val cy = (node.localMinY + node.localMaxY) * 0.5f * node.transform.scaleY + node.transform.posY
        val cz = (node.localMinZ + node.localMaxZ) * 0.5f * node.transform.scaleZ + node.transform.posZ
        return floatArrayOf(
            wt.posX + cx * wt.scaleX,
            wt.posY + cy * wt.scaleY,
            wt.posZ + cz * wt.scaleZ
        )
    }

    private fun drawAxisGizmo(x: Float, y: Float, z: Float) {
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        val xHl = if (editorAxisHighlight == 0) 0.9f else 0.1f
        val yHl = if (editorAxisHighlight == 1) 0.9f else 0.1f
        val zHl = if (editorAxisHighlight == 2) 0.9f else 0.1f
        // X Axis (Red)
        drawSimplePrimitive(cylMesh, x + 1.1f, y, z, 0.08f, 2.2f, 0.08f, 0f, 0f, 0xFFEF4444, 0.95f, 3, xHl, rotZDeg = -90f)
        drawSimplePrimitive(coneMesh, x + 2.35f, y, z, 0.26f, 0.5f, 0.26f, 0f, 0f, 0xFFEF4444, 0.95f, 3, xHl, rotZDeg = -90f)
        // Y Axis (Green)
        drawSimplePrimitive(cylMesh, x, y + 1.1f, z, 0.08f, 2.2f, 0.08f, 0f, 0f, 0xFF22C55E, 0.95f, 3, yHl)
        drawSimplePrimitive(coneMesh, x, y + 2.35f, z, 0.26f, 0.5f, 0.26f, 0f, 0f, 0xFF22C55E, 0.95f, 3, yHl)
        // Z Axis (Blue)
        drawSimplePrimitive(cylMesh, x, y, z + 1.1f, 0.08f, 2.2f, 0.08f, 0f, 90f, 0xFF3B82F6, 0.95f, 3, zHl)
        drawSimplePrimitive(coneMesh, x, y, z + 2.35f, 0.26f, 0.5f, 0.26f, 0f, 90f, 0xFF3B82F6, 0.95f, 3, zHl)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
    }

    private fun renderEyeScene(
        snap: SimulationSnapshot,
        eyeOffsetMeters: Float,
        aspect: Float,
        skyR: Float, skyG: Float, skyB: Float,
        fogDensity: Float,
        lighting: WorldLightingConfig
    ) {
        val fov = settings.vr.fovDegrees.coerceIn(60f, 120f)
        Matrix.perspectiveM(projMatrix, 0, fov, aspect, 0.06f, 260f)

        val fwd = GlMath.forwardVector(snap.yawDeg, snap.pitchDeg)
        val right = GlMath.rightVectorXZ(snap.yawDeg)
        val eyeX = snap.playerX + right[0] * eyeOffsetMeters
        val eyeY = snap.playerY
        val eyeZ = snap.playerZ + right[2] * eyeOffsetMeters

        val baseUpX = right[1] * fwd[2] - right[2] * fwd[1]
        val baseUpY = right[2] * fwd[0] - right[0] * fwd[2]
        val baseUpZ = right[0] * fwd[1] - right[1] * fwd[0]

        val rollDeg = if (settings.vr.horizonLockEnabled) 0f else snap.rollDeg
        val rollRad = Math.toRadians(rollDeg.toDouble())
        val cosR = cos(rollRad).toFloat()
        val sinR = sin(rollRad).toFloat()
        val upX = baseUpX * cosR + right[0] * sinR
        val upY = baseUpY * cosR + right[1] * sinR
        val upZ = baseUpZ * cosR + right[2] * sinR

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            eyeX + fwd[0], eyeY + fwd[1], eyeZ + fwd[2],
            upX, upY, upZ
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        setupSceneUniforms(eyeX, eyeY, eyeZ, skyR, skyG, skyB, fogDensity, lighting)

        val scene = controller.worldData
        val shadowsOn = lighting.shadowsEnabled && settings.graphics.quality != GraphicsQuality.LOW

        for (b in scene.blocks) {
            if (b.alpha < 0.99f) continue
            if (shadowsOn && b.castsShadow) drawShadowPatch(b.x, b.z, b.sx * 1.06f, b.sz * 1.06f)
            val mesh = when (b.kind) {
                BlockMeshKind.CUBE -> cubeMesh
                BlockMeshKind.CYLINDER -> cylMesh
                BlockMeshKind.SPHERE -> sphereMesh
            }
            val tagInt = when (b.tag) {
                BlockMaterialTag.FLOOR_TILE -> 1
                BlockMaterialTag.FLOOR_ASPHALT -> 2
                BlockMaterialTag.EMISSIVE -> 3
                else -> 0
            }
            drawSimplePrimitive(mesh, b.x, b.y, b.z, b.sx, b.sy, b.sz, 0f, 0f, b.colorArgb, 1f, tagInt, 0f)
        }

        // Render Custom Imported World with true textures, PBR materials, alpha cutout & per-node transforms!
        if (snap.worldType == WorldType.CUSTOM_IMPORTED) {
            renderCustomWorldProject(eyeX, eyeY, eyeZ, highlightSelected = false)
        }

        // Supermarket items & stations & NPCs (when inside supermarket worlds)
        val targetedId = snap.targetedProduct?.id
        val fwdXZ = GlMath.forwardVectorXZ(snap.yawDeg)
        val rightXZ = GlMath.rightVectorXZ(snap.yawDeg)
        var cartIdx = 0

        for (p in scene.products) {
            if (p.container == ItemContainer.BAG) continue
            val isTargeted = p.id == targetedId
            val hl = if (isTargeted) 0.55f + 0.35f * sin(animTimeSec * 6f) else 0f
            when (p.container) {
                ItemContainer.HAND -> {
                    val hx = snap.playerX + fwd[0] * 0.62f + rightXZ[0] * (if (snap.isInspectingDetails) 0.0f else 0.22f)
                    val hy = snap.playerY + fwd[1] * 0.62f - 0.14f
                    val hz = snap.playerZ + fwd[2] * 0.62f + rightXZ[2] * (if (snap.isInspectingDetails) 0.0f else 0.22f)
                    drawProduct(p, hx, hy, hz, snap.inspectYawDeg, snap.inspectPitchDeg, 1.25f, 0.35f)
                }
                ItemContainer.CART, ItemContainer.BASKET -> {
                    val cartDist = if (snap.hasCart) 1.15f else 0.75f
                    val cx = snap.playerX + fwdXZ[0] * cartDist + rightXZ[0] * ((cartIdx % 3 - 1) * 0.14f)
                    val cy = 0.72f + (cartIdx / 3) * 0.14f
                    val cz = snap.playerZ + fwdXZ[2] * cartDist + rightXZ[2] * ((cartIdx % 3 - 1) * 0.14f)
                    cartIdx++
                    drawProduct(p, cx, cy, cz, 0f, 0f, 0.85f, hl)
                }
                else -> drawProduct(p, p.x, p.y, p.z, if (isTargeted) animTimeSec * 40f else 0f, 0f, 1f, hl)
            }
        }

        if (snap.worldType != WorldType.CUSTOM_IMPORTED) {
            val cartBayHl = if (snap.targetedStation == TargetStationType.CART_BAY) 0.6f else 0f
            drawCartModel(-4.2f, 0.55f, 9.6f, 0f, cartBayHl)
            val basketBayHl = if (snap.targetedStation == TargetStationType.BASKET_BAY) 0.6f else 0f
            drawSimplePrimitive(cubeMesh, 4.0f, 0.82f, 9.6f, 0.45f, 0.26f, 0.34f, 0f, 0f, 0xFF0EA5E9, 1f, 0, basketBayHl)
            if (snap.hasCart) {
                drawCartModel(snap.playerX + fwdXZ[0] * 1.15f, 0.50f, snap.playerZ + fwdXZ[2] * 1.15f, snap.yawDeg, 0f)
            } else if (snap.hasBasket) {
                drawSimplePrimitive(cubeMesh, snap.playerX + fwdXZ[0] * 0.75f, 0.68f, snap.playerZ + fwdXZ[2] * 0.75f, 0.42f, 0.24f, 0.32f, snap.yawDeg, 0f, 0xFF0EA5E9, 1f, 0, 0f)
            } else if (snap.hasPaidBag) {
                drawSimplePrimitive(cubeMesh, snap.playerX + fwdXZ[0] * 0.55f + rightXZ[0] * 0.25f, 0.95f, snap.playerZ + fwdXZ[2] * 0.55f + rightXZ[2] * 0.25f, 0.28f, 0.38f, 0.20f, snap.yawDeg, 0f, 0xFF10B981, 1f, 0, 0f)
            }
        }

        for (npc in scene.npcs) {
            val npcHl = if (snap.targetedNpc?.id == npc.id) 0.65f else 0f
            if (shadowsOn) drawShadowPatch(npc.x, npc.z, 0.65f, 0.65f)
            val walkCycle = if (npc.speed > 0.05f) sin(animTimeSec * 5.5f) * 18f else 0f
            drawSimplePrimitive(cylMesh, npc.x - 0.11f, 0.42f, npc.z, 0.14f, 0.82f, 0.14f, npc.yawDeg, walkCycle, 0xFF1E293B, 1f, 0, npcHl)
            drawSimplePrimitive(cylMesh, npc.x + 0.11f, 0.42f, npc.z, 0.14f, 0.82f, 0.14f, npc.yawDeg, -walkCycle, 0xFF1E293B, 1f, 0, npcHl)
            drawSimplePrimitive(cubeMesh, npc.x, 1.14f, npc.z, 0.44f, 0.62f, 0.26f, npc.yawDeg, 0f, npc.shirtColorArgb, 1f, 0, npcHl)
            drawSimplePrimitive(sphereMesh, npc.x, 1.64f, npc.z, 0.30f, 0.32f, 0.30f, npc.yawDeg, 0f, 0xFFF1C27D, 1f, 0, npcHl)
        }

        if (settings.controls.movementMode == MovementMode.TELEPORT && snap.teleportActive) {
            drawSimplePrimitive(cylMesh, snap.teleportTargetX, 0.03f, snap.teleportTargetZ, 0.95f, 0.04f, 0.95f, 0f, 0f, 0xFF00E5FF, 0.72f, 3, 0.8f)
        }

        if (settings.controls.activeScheme == ControlScheme.HAND_TRACKING && handState.landmarks.size >= 21) {
            render3DHand(snap, fwd, right, floatArrayOf(baseUpX, baseUpY, baseUpZ), handState)
        }

        GLES30.glDepthMask(false)
        if (snap.worldType != WorldType.CUSTOM_IMPORTED) {
            val slideOffset = snap.doorOpenAmount * 2.25f
            drawSimplePrimitive(cubeMesh, -1.32f - slideOffset, 1.55f, 12.0f, 2.55f, 3.1f, 0.09f, 0f, 0f, 0xFF7DD3FC, 0.45f, 0, 0f)
            drawSimplePrimitive(cubeMesh, 1.32f + slideOffset, 1.55f, 12.0f, 2.55f, 3.1f, 0.09f, 0f, 0f, 0xFF7DD3FC, 0.45f, 0, 0f)
        }
        for (b in scene.blocks) {
            if (b.alpha >= 0.99f) continue
            drawSimplePrimitive(cubeMesh, b.x, b.y, b.z, b.sx, b.sy, b.sz, 0f, 0f, b.colorArgb, b.alpha, 0, 0f)
        }
        GLES30.glDepthMask(true)
    }

    private fun setupSceneUniforms(
        eyeX: Float, eyeY: Float, eyeZ: Float,
        skyR: Float, skyG: Float, skyB: Float,
        fogDensity: Float,
        lighting: WorldLightingConfig
    ) {
        GLES30.glUseProgram(sceneProgram)
        val angleRad = Math.toRadians(lighting.directionalAngleDeg.toDouble())
        val lx = (cos(angleRad) * 0.55).toFloat()
        val lz = (sin(angleRad) * 0.55).toFloat()
        GLES30.glUniform3f(uLightDirLoc, lx, 0.85f, lz)
        GLES30.glUniform3f(uCamPosLoc, eyeX, eyeY, eyeZ)
        GLES30.glUniform3f(uFogColorLoc, skyR, skyG, skyB)
        GLES30.glUniform1f(uFogDensityLoc, fogDensity)
        GLES30.glUniform1i(uReflectLoc, if (lighting.reflectionsEnabled) 1 else 0)
        GLES30.glUniform1f(uExposureLoc, lighting.exposure.coerceIn(0.4f, 2.2f))
        GLES30.glUniform1f(uDirIntensityLoc, lighting.directionalIntensity.coerceIn(0.1f, 2.2f))
        GLES30.glUniform1f(uAmbientIntensityLoc, lighting.ambientIntensity.coerceIn(0.1f, 1.5f))
    }

    private fun renderCustomWorldProject(
        camX: Float, camY: Float, camZ: Float,
        highlightSelected: Boolean
    ) {
        val proj = activeProject
        val rootBundle = uploadedRootBundle
        val maxDrawDist = when (settings.graphics.quality) {
            GraphicsQuality.LOW -> 95f
            GraphicsQuality.MEDIUM -> 150f
            GraphicsQuality.HIGH -> 240f
        }
        val lodSwitchDist = maxDrawDist * 0.42f

        GLES30.glDisable(GLES30.GL_CULL_FACE)
        if (proj == null || proj.nodes.isEmpty()) {
            // Direct fallback rendering if project state isn't attached yet
            val mats = activeCustomMeshData?.materials ?: emptyList()
            rootBundle?.let { bundle ->
                drawBundleSubMeshes(bundle, mats, emptyMap(), Transform3D(), Transform3D(), 0, bundle.subMeshes.lastIndex, camX, camY, camZ, maxDrawDist, lodSwitchDist, 0f)
            }
            GLES30.glEnable(GLES30.GL_CULL_FACE)
            return
        }

        val worldT = proj.worldTransform
        val rootMats = proj.materials

        // Build map of group transforms so grouped objects inherit parent transform cleanly
        val nodeMap = proj.nodes.associateBy { it.id }

        for (node in proj.nodes) {
            if (!node.visible || node.isGroup) continue
            val effectiveTransform = if (node.parentId != null) {
                val parent = nodeMap[node.parentId]
                if (parent != null) {
                    if (!parent.visible) continue
                    combineParentChildTransform(parent.transform, node.transform)
                } else node.transform
            } else node.transform

            val isSelected = highlightSelected && (editorWholeWorldSelected || node.id == editorSelectedNodeId || node.parentId == editorSelectedNodeId)
            val hl = if (isSelected) 0.45f + 0.25f * sin(animTimeSec * 5f) else 0f

            if (node.assetPath.isNullOrBlank() || node.assetPath == proj.rootAssetPath) {
                val bundle = rootBundle ?: continue
                val startIdx = if (node.subMeshStartIdx >= 0) node.subMeshStartIdx else 0
                val endIdx = if (node.subMeshEndIdx >= startIdx) node.subMeshEndIdx else bundle.subMeshes.lastIndex
                drawBundleSubMeshes(
                    bundle = bundle,
                    materials = rootMats,
                    overrides = node.materialOverrides,
                    worldT = worldT,
                    nodeT = effectiveTransform,
                    startIdx = startIdx,
                    endIdx = endIdx,
                    camX = camX, camY = camY, camZ = camZ,
                    maxDist = maxDrawDist,
                    lodDist = lodSwitchDist,
                    highlight = hl
                )
            } else {
                val extraBundle = uploadedExtraBundles[node.assetPath] ?: continue
                val extraMats = extraMeshData[node.assetPath]?.materials ?: rootMats
                drawBundleSubMeshes(
                    bundle = extraBundle,
                    materials = extraMats,
                    overrides = node.materialOverrides,
                    worldT = worldT,
                    nodeT = effectiveTransform,
                    startIdx = 0,
                    endIdx = extraBundle.subMeshes.lastIndex.coerceAtLeast(0),
                    camX = camX, camY = camY, camZ = camZ,
                    maxDist = maxDrawDist,
                    lodDist = lodSwitchDist,
                    highlight = hl
                )
            }
        }
        GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    private fun combineParentChildTransform(parent: Transform3D, child: Transform3D): Transform3D =
        Transform3D(
            posX = parent.posX + child.posX * parent.scaleX,
            posY = parent.posY + child.posY * parent.scaleY,
            posZ = parent.posZ + child.posZ * parent.scaleZ,
            rotX = parent.rotX + child.rotX,
            rotY = parent.rotY + child.rotY,
            rotZ = parent.rotZ + child.rotZ,
            scaleX = parent.scaleX * child.scaleX,
            scaleY = parent.scaleY * child.scaleY,
            scaleZ = parent.scaleZ * child.scaleZ
        )

    private fun drawBundleSubMeshes(
        bundle: UploadedWorldBundle,
        materials: List<PbrMaterialSpec>,
        overrides: Map<String, PbrMaterialSpec>,
        worldT: Transform3D,
        nodeT: Transform3D,
        startIdx: Int,
        endIdx: Int,
        camX: Float, camY: Float, camZ: Float,
        maxDist: Float,
        lodDist: Float,
        highlight: Float
    ) {
        GlTextureAndShaderHelper.composeWorldAndNodeMatrix(modelMatrix, worldT, nodeT, tmpWorldMatrix, tmpNodeMatrix)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES30.glUniformMatrix4fv(uMvpLoc, 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES30.glUniform1i(uTagLoc, 4)
        GLES30.glUniform1f(uHighlightLoc, highlight)

        if (bundle.subMeshes.isEmpty()) {
            bundle.fallbackMesh?.let { fb ->
                bindMaterialUniforms(materials.firstOrNull() ?: PbrMaterialSpec("fallback", "Default"))
                fb.draw(aPosLoc, aNormLoc, aUvLoc, aColorLoc)
            }
            return
        }

        val safeStart = startIdx.coerceIn(0, bundle.subMeshes.lastIndex)
        val safeEnd = endIdx.coerceIn(safeStart, bundle.subMeshes.lastIndex)

        for (i in safeStart..safeEnd) {
            val sm = bundle.subMeshes[i]
            // Distance culling & LOD check
            val wx = worldT.posX + (nodeT.posX + sm.centerX * nodeT.scaleX) * worldT.scaleX
            val wy = worldT.posY + (nodeT.posY + sm.centerY * nodeT.scaleY) * worldT.scaleY
            val wz = worldT.posZ + (nodeT.posZ + sm.centerZ * nodeT.scaleZ) * worldT.scaleZ
            val dx = wx - camX; val dy = wy - camY; val dz = wz - camZ
            val dist = sqrt(dx * dx + dy * dy + dz * dz)
            val scaledRadius = sm.radius * maxOf(worldT.scaleX, nodeT.scaleX, 1f)
            if (dist - scaledRadius > maxDist) continue

            val baseMat = materials.getOrElse(sm.materialIndex) { PbrMaterialSpec("default", "Default") }
            val mat = overrides[baseMat.id] ?: baseMat
            bindMaterialUniforms(mat)

            val meshToDraw = if (sm.lodMesh != null && dist > lodDist) sm.lodMesh else sm.fullMesh
            meshToDraw.draw(aPosLoc, aNormLoc, aUvLoc, aColorLoc)
        }
        resetDefaultMaterialBindings()
    }

    private fun bindMaterialUniforms(mat: PbrMaterialSpec) {
        val col = mat.baseColorArgb
        val r = ((col shr 16) and 0xFF) / 255f
        val g = ((col shr 8) and 0xFF) / 255f
        val b = (col and 0xFF) / 255f
        GLES30.glUniform3f(uColorLoc, r, g, b)
        GLES30.glUniform1f(uAlphaLoc, mat.alpha.coerceIn(0.05f, 1f))
        GLES30.glUniform1f(uMetallicLoc, mat.metallic.coerceIn(0f, 1f))
        GLES30.glUniform1f(uRoughnessLoc, mat.roughness.coerceIn(0.06f, 1f))
        GLES30.glUniform1f(uEmissiveLoc, mat.emissiveStrength.coerceIn(0f, 2f))
        GLES30.glUniform1f(uAlphaCutoffLoc, mat.alphaCutoff)
        GLES30.glUniform1i(
            uAlphaModeLoc,
            when (mat.alphaMode) {
                AlphaMode.OPAQUE -> 0
                AlphaMode.MASK -> 1
                AlphaMode.BLEND -> 2
            }
        )

        val baseTexId = textureCache.getOrLoadTexture(mat.texturePath)
        if (baseTexId > 0) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, baseTexId)
            GLES30.glUniform1i(uBaseTexLoc, 0)
            GLES30.glUniform1i(uHasBaseTexLoc, 1)
        } else {
            GLES30.glUniform1i(uHasBaseTexLoc, 0)
        }

        val normTexId = textureCache.getOrLoadTexture(mat.normalTexturePath)
        if (normTexId > 0) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, normTexId)
            GLES30.glUniform1i(uNormalTexLoc, 1)
            GLES30.glUniform1i(uHasNormalTexLoc, 1)
        } else {
            GLES30.glUniform1i(uHasNormalTexLoc, 0)
        }
    }

    private fun resetDefaultMaterialBindings() {
        GLES30.glUniform1i(uHasBaseTexLoc, 0)
        GLES30.glUniform1i(uHasNormalTexLoc, 0)
        GLES30.glUniform1i(uAlphaModeLoc, 0)
        GLES30.glUniform1f(uEmissiveLoc, 0f)
        GLES30.glUniform1f(uMetallicLoc, 0.05f)
        GLES30.glUniform1f(uRoughnessLoc, 0.72f)
    }

    private fun render3DHand(snap: SimulationSnapshot, fwd: FloatArray, right: FloatArray, camUp: FloatArray, hand: HandTrackingState) {
        val scale = settings.controls.handCalibrationScale * 0.68f
        val baseX = snap.playerX + fwd[0] * 0.50f - camUp[0] * 0.04f
        val baseY = snap.playerY + fwd[1] * 0.50f - camUp[1] * 0.04f
        val baseZ = snap.playerZ + fwd[2] * 0.50f - camUp[2] * 0.04f
        val pts = hand.landmarks.map { lm ->
            val lx = (lm.x - 0.5f) * scale
            val ly = (0.5f - lm.y) * scale
            val lz = -lm.z * scale * 0.55f
            floatArrayOf(baseX + right[0] * lx + camUp[0] * ly + fwd[0] * lz, baseY + right[1] * lx + camUp[1] * ly + fwd[1] * lz, baseZ + right[2] * lx + camUp[2] * ly + fwd[2] * lz)
        }
        for (pair in HAND_BONE_PAIRS) drawBoneSegment(pts[pair[0]], pts[pair[1]], 0.015f, 0xFFF2C9A0)
        drawBoneSegment(pts[5], pts[17], 0.024f, 0xFFE6B587)
        drawBoneSegment(pts[0], pts[9], 0.028f, 0xFFE6B587)
        for (idx in pts.indices) {
            val p = pts[idx]
            val jointSize = if (idx == 8 || idx == 4) 0.028f else if (idx == 0) 0.036f else 0.020f
            val color = when (idx) { 8 -> 0xFF00E5FF; 4 -> 0xFF10B981; else -> 0xFFF59E0B }
            drawSimplePrimitive(sphereMesh, p[0], p[1], p[2], jointSize, jointSize, jointSize, 0f, 0f, color, 1f, 3, 0.5f)
        }
    }

    private fun drawBoneSegment(a: FloatArray, b: FloatArray, thickness: Float, colorArgb: Long) {
        val mx = (a[0] + b[0]) * 0.5f; val my = (a[1] + b[1]) * 0.5f; val mz = (a[2] + b[2]) * 0.5f
        val dx = b[0] - a[0]; val dy = b[1] - a[1]; val dz = b[2] - a[2]
        val len = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(0.005f)
        val yaw = Math.toDegrees(atan2(dx.toDouble(), dz.toDouble())).toFloat()
        val horiz = sqrt(dx * dx + dz * dz)
        val pitch = Math.toDegrees(atan2(horiz.toDouble(), dy.toDouble())).toFloat()
        drawSimplePrimitive(cylMesh, mx, my, mz, thickness, len, thickness, yaw, pitch, colorArgb, 1f, 0, 0.25f)
    }

    private fun drawProduct(p: ProductItem, x: Float, y: Float, z: Float, yawDeg: Float, pitchDeg: Float, scaleMult: Float, highlight: Float) {
        when (p.meshShape) {
            ProductMeshShape.BOX -> {
                drawSimplePrimitive(cubeMesh, x, y, z, 0.22f * scaleMult, 0.26f * scaleMult, 0.14f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawSimplePrimitive(cubeMesh, x, y + 0.05f * scaleMult, z, 0.23f * scaleMult, 0.07f * scaleMult, 0.145f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.BOTTLE -> {
                drawSimplePrimitive(cylMesh, x, y - 0.02f * scaleMult, z, 0.13f * scaleMult, 0.24f * scaleMult, 0.13f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawSimplePrimitive(cylMesh, x, y + 0.14f * scaleMult, z, 0.06f * scaleMult, 0.08f * scaleMult, 0.06f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.CAN -> drawSimplePrimitive(cylMesh, x, y, z, 0.12f * scaleMult, 0.20f * scaleMult, 0.12f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
            ProductMeshShape.SPHERE_FRUIT -> drawSimplePrimitive(sphereMesh, x, y, z, 0.17f * scaleMult, 0.17f * scaleMult, 0.17f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
            ProductMeshShape.LOAF -> drawSimplePrimitive(sphereMesh, x, y, z, 0.26f * scaleMult, 0.14f * scaleMult, 0.15f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
            ProductMeshShape.BAR -> drawSimplePrimitive(cubeMesh, x, y, z, 0.22f * scaleMult, 0.05f * scaleMult, 0.12f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
            ProductMeshShape.DEVICE -> drawSimplePrimitive(cubeMesh, x, y, z, 0.25f * scaleMult, 0.18f * scaleMult, 0.14f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
        }
    }

    private fun drawCartModel(x: Float, y: Float, z: Float, yawDeg: Float, highlight: Float) {
        drawSimplePrimitive(cubeMesh, x, y + 0.20f, z, 0.56f, 0.36f, 0.78f, yawDeg, 0f, 0xFF94A3B8, 1f, 0, highlight)
        drawSimplePrimitive(cubeMesh, x, y - 0.14f, z, 0.50f, 0.05f, 0.72f, yawDeg, 0f, 0xFF475569, 1f, 0, highlight)
        drawSimplePrimitive(cubeMesh, x, y + 0.44f, z + 0.38f, 0.56f, 0.06f, 0.06f, yawDeg, 0f, 0xFFEF4444, 1f, 0, highlight)
    }

    private fun drawShadowPatch(x: Float, z: Float, sx: Float, sz: Float) {
        drawSimplePrimitive(cubeMesh, x, 0.008f, z, sx, 0.005f, sz, 0f, 0f, 0xFF000000, 0.22f, 0, 0f)
    }

    private fun drawSimplePrimitive(
        mesh: GlMesh,
        x: Float, y: Float, z: Float,
        sx: Float, sy: Float, sz: Float,
        yawDeg: Float, pitchDeg: Float,
        colorArgb: Long,
        alpha: Float,
        tag: Int,
        highlight: Float,
        rotZDeg: Float = 0f
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (yawDeg != 0f) Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        if (pitchDeg != 0f) Matrix.rotateM(modelMatrix, 0, pitchDeg, 1f, 0f, 0f)
        if (rotZDeg != 0f) Matrix.rotateM(modelMatrix, 0, rotZDeg, 0f, 0f, 1f)
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

        val r = ((colorArgb shr 16) and 0xFF) / 255f
        val g = ((colorArgb shr 8) and 0xFF) / 255f
        val b = (colorArgb and 0xFF) / 255f

        resetDefaultMaterialBindings()
        GLES30.glUniformMatrix4fv(uMvpLoc, 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES30.glUniform3f(uColorLoc, r, g, b)
        GLES30.glUniform1f(uAlphaLoc, alpha)
        GLES30.glUniform1i(uTagLoc, tag)
        GLES30.glUniform1f(uHighlightLoc, highlight)

        mesh.draw(aPosLoc, aNormLoc, aUvLoc, aColorLoc)
    }

    private fun drawPostEyeQuad(k1: Float, chromatic: Float, imageScale: Float, eyeOffset: Float) {
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(postProgram)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glUniform1i(uPostTexLoc, 0)
        GLES30.glUniform1f(uDistortionK1Loc, k1)
        GLES30.glUniform1f(uChromaticLoc, chromatic)
        GLES30.glUniform1f(uImageScaleLoc, imageScale)
        GLES30.glUniform1f(uEyeOffsetLoc, eyeOffset)
        GLES30.glUniform1f(uVignetteLoc, 1f)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        val stride = 4 * 4
        GLES30.glEnableVertexAttribArray(aPostPosLoc)
        GLES30.glVertexAttribPointer(aPostPosLoc, 2, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(aPostUvLoc)
        GLES30.glVertexAttribPointer(aPostUvLoc, 2, GLES30.GL_FLOAT, false, stride, 2 * 4)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
    }

    private fun ensureFbo(w: Int, h: Int) {
        if (fboId != 0 && fboWidth == w && fboHeight == h) return
        if (fboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(fboId), 0)
            GLES30.glDeleteTextures(1, intArrayOf(fboColorTex), 0)
            GLES30.glDeleteRenderbuffers(1, intArrayOf(fboDepthRb), 0)
        }
        fboWidth = w; fboHeight = h
        val fbos = IntArray(1); val texs = IntArray(1); val rbs = IntArray(1)
        GLES30.glGenFramebuffers(1, fbos, 0); GLES30.glGenTextures(1, texs, 0); GLES30.glGenRenderbuffers(1, rbs, 0)
        fboId = fbos[0]; fboColorTex = texs[0]; fboDepthRb = rbs[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, w, h, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, fboDepthRb)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, w, h)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, fboColorTex, 0)
        GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, fboDepthRb)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun createFullscreenQuadVbo(): Int {
        val quad = floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, -1f, -1f, 0f, 0f, 1f, 1f, 1f, 1f, -1f, 1f, 0f, 1f)
        val buf: FloatBuffer = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(quad)
        buf.position(0)
        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        return vbo[0]
    }

    companion object {
        private val HAND_BONE_PAIRS = arrayOf(
            intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 4),
            intArrayOf(0, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 8),
            intArrayOf(0, 9), intArrayOf(9, 10), intArrayOf(10, 11), intArrayOf(11, 12),
            intArrayOf(0, 13), intArrayOf(13, 14), intArrayOf(14, 15), intArrayOf(15, 16),
            intArrayOf(0, 17), intArrayOf(17, 18), intArrayOf(18, 19), intArrayOf(19, 20)
        )
    }
}
