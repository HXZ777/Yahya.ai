package com.example.vr.engine

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.DisplayMetrics
import com.example.vr.model.AllSettingsState
import com.example.vr.model.ControlScheme
import com.example.vr.model.GraphicsQuality
import com.example.vr.model.HandTrackingState
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.ItemContainer
import com.example.vr.model.MovementMode
import com.example.vr.model.ProductItem
import com.example.vr.model.ProductMeshShape
import com.example.vr.model.TimeOfDay
import com.example.vr.model.WeatherType
import com.example.vr.world.BlockMaterialTag
import com.example.vr.world.BlockMeshKind
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class VrRenderer(
    private val controller: GameSimulationController
) : GLSurfaceView.Renderer {

    @Volatile
    var settings: AllSettingsState = AllSettingsState()

    @Volatile
    var handState: HandTrackingState = HandTrackingState()

    @Volatile
    var displayMetrics: DisplayMetrics = DisplayMetrics().apply {
        xdpi = 400f
        ydpi = 400f
    }

    @Volatile
    private var pendingCustomMesh: ImportedMeshData? = null
    private var uploadedCustomMesh: GlMesh? = null

    private var sceneProgram = 0
    private var postProgram = 0

    // Scene uniforms & attributes
    private var uMvpLoc = 0
    private var uModelLoc = 0
    private var uColorLoc = 0
    private var uAlphaLoc = 0
    private var uTagLoc = 0
    private var uHighlightLoc = 0
    private var uLightDirLoc = 0
    private var uCamPosLoc = 0
    private var uFogColorLoc = 0
    private var uFogDensityLoc = 0
    private var uReflectLoc = 0
    private var aPosLoc = 0
    private var aNormLoc = 0

    // Post-process uniforms
    private var uPostTexLoc = 0
    private var uDistortionK1Loc = 0
    private var uChromaticLoc = 0
    private var uImageScaleLoc = 0
    private var uEyeOffsetLoc = 0
    private var uVignetteLoc = 0
    private var aPostPosLoc = 0
    private var aPostUvLoc = 0

    // Meshes
    private lateinit var cubeMesh: GlMesh
    private lateinit var cylMesh: GlMesh
    private lateinit var sphereMesh: GlMesh
    private var quadVbo = 0

    // Offscreen FBO for barrel distortion & chromatic aberration
    private var fboId = 0
    private var fboColorTex = 0
    private var fboDepthRb = 0
    private var fboWidth = 0
    private var fboHeight = 0

    private var surfaceWidth = 1280
    private var surfaceHeight = 720

    // Allocation-free matrices
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    // Timing & FPS counter
    private var lastFrameNs = System.nanoTime()
    private var fpsAccumSec = 0f
    private var fpsFrameCount = 0
    private var currentFps = 60
    private var animTimeSec = 0f

    fun setCustomImportedMesh(mesh: ImportedMeshData?) {
        pendingCustomMesh = mesh
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

        sceneProgram = createProgram(SCENE_VS, SCENE_FS)
        uMvpLoc = GLES30.glGetUniformLocation(sceneProgram, "uMvp")
        uModelLoc = GLES30.glGetUniformLocation(sceneProgram, "uModel")
        uColorLoc = GLES30.glGetUniformLocation(sceneProgram, "uColor")
        uAlphaLoc = GLES30.glGetUniformLocation(sceneProgram, "uAlpha")
        uTagLoc = GLES30.glGetUniformLocation(sceneProgram, "uTag")
        uHighlightLoc = GLES30.glGetUniformLocation(sceneProgram, "uHighlight")
        uLightDirLoc = GLES30.glGetUniformLocation(sceneProgram, "uLightDir")
        uCamPosLoc = GLES30.glGetUniformLocation(sceneProgram, "uCamPos")
        uFogColorLoc = GLES30.glGetUniformLocation(sceneProgram, "uFogColor")
        uFogDensityLoc = GLES30.glGetUniformLocation(sceneProgram, "uFogDensity")
        uReflectLoc = GLES30.glGetUniformLocation(sceneProgram, "uReflect")
        aPosLoc = GLES30.glGetAttribLocation(sceneProgram, "aPos")
        aNormLoc = GLES30.glGetAttribLocation(sceneProgram, "aNorm")

        postProgram = createProgram(POST_VS, POST_FS)
        uPostTexLoc = GLES30.glGetUniformLocation(postProgram, "uTex")
        uDistortionK1Loc = GLES30.glGetUniformLocation(postProgram, "uK1")
        uChromaticLoc = GLES30.glGetUniformLocation(postProgram, "uChromatic")
        uImageScaleLoc = GLES30.glGetUniformLocation(postProgram, "uImageScale")
        uEyeOffsetLoc = GLES30.glGetUniformLocation(postProgram, "uEyeOffset")
        uVignetteLoc = GLES30.glGetUniformLocation(postProgram, "uVignette")
        aPostPosLoc = GLES30.glGetAttribLocation(postProgram, "aPos")
        aPostUvLoc = GLES30.glGetAttribLocation(postProgram, "aUv")

        cubeMesh = MeshBuilder.createUnitCube()
        cylMesh = MeshBuilder.createCylinder(14)
        sphereMesh = MeshBuilder.createSphere(8, 12)
        quadVbo = createFullscreenQuadVbo()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(2)
        surfaceHeight = height.coerceAtLeast(2)
        fboWidth = 0
        fboHeight = 0
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()

        // Frame-rate pacing for TargetFps (30 / 45 / 60)
        val minFrameMs = 1000L / settings.graphics.targetFps.fps
        val elapsedMs = (nowNs - lastFrameNs) / 1_000_000L
        if (elapsedMs < minFrameMs) {
            runCatching { Thread.sleep(minFrameMs - elapsedMs) }
        }
        val afterSleepNs = System.nanoTime()
        val dt = ((afterSleepNs - lastFrameNs) / 1_000_000_000.0).toFloat().coerceIn(0.004f, 0.08f)
        lastFrameNs = afterSleepNs

        animTimeSec += dt
        fpsAccumSec += dt
        fpsFrameCount++
        if (fpsAccumSec >= 0.5f) {
            currentFps = (fpsFrameCount / fpsAccumSec).toInt().coerceIn(1, 120)
            fpsAccumSec = 0f
            fpsFrameCount = 0
        }

        // Upload pending custom imported mesh on GL thread if changed
        val pending = pendingCustomMesh
        if (pending != null) {
            uploadedCustomMesh?.delete()
            uploadedCustomMesh = MeshBuilder.createImportedMesh(pending)
            pendingCustomMesh = null
        }

        // Advance simulation tick
        controller.tick(dt, currentFps)
        val snap = controller.snapshot.value

        val vr = settings.vr
        val isStereo = vr.sideBySideEnabled
        val layout = VrBoxOptics.computeLayout(surfaceWidth, surfaceHeight, displayMetrics, vr)
        val qualityScale = when (settings.graphics.quality) {
            GraphicsQuality.LOW -> 0.70f
            GraphicsQuality.MEDIUM -> 0.88f
            GraphicsQuality.HIGH -> 1.0f
        }

        val eyeTargetW = (layout.leftEye.width * qualityScale).toInt().coerceAtLeast(128)
        val eyeTargetH = (layout.leftEye.height * qualityScale).toInt().coerceAtLeast(128)
        val usePostProcess = isStereo && (vr.lensDistortionEnabled || vr.chromaticAberrationEnabled)
        if (usePostProcess) {
            ensureFbo(eyeTargetW, eyeTargetH)
        }

        // Sky & Lighting Setup based on TimeOfDay + Weather
        val (skyR, skyG, skyB) = when (settings.graphics.timeOfDay) {
            TimeOfDay.MORNING -> Triple(0.55f, 0.76f, 0.94f)
            TimeOfDay.NOON -> Triple(0.45f, 0.72f, 0.96f)
            TimeOfDay.SUNSET -> Triple(0.86f, 0.48f, 0.32f)
            TimeOfDay.NIGHT -> Triple(0.05f, 0.08f, 0.16f)
        }
        val fogDensity = when (settings.graphics.weather) {
            WeatherType.CLEAR -> 0.009f
            WeatherType.RAIN -> 0.022f
            WeatherType.FOG -> 0.045f
        }

        if (isStereo) {
            // Clear full screen to pure black outside the fixed VR Box lens boxes
            GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
            GLES30.glClearColor(0f, 0f, 0f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

            // Comfortable virtual stereo camera baseline (~48% of physical IPD = ~30mm)
            // keeps close shelves/hand deeply 3D without causing double vision
            val virtualEyeBaselineM = (vr.ipdMm * 0.48f) / 1000f
            val eyes = arrayOf(layout.leftEye, layout.rightEye)

            for (eye in 0..1) {
                val vp = eyes[eye]
                val eyeSign = if (eye == 0) -0.5f else 0.5f
                val aspect = (vp.width.toFloat() / vp.height.toFloat()).coerceAtLeast(0.45f)

                if (usePostProcess) {
                    GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
                    GLES30.glViewport(0, 0, fboWidth, fboHeight)
                    GLES30.glClearColor(skyR, skyG, skyB, 1f)
                    GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

                    renderEyeScene(snap, eyeSign * virtualEyeBaselineM, aspect, skyR, skyG, skyB, fogDensity)

                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                    GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
                    GLES30.glScissor(vp.x, vp.y, vp.width, vp.height)
                    GLES30.glViewport(vp.x, vp.y, vp.width, vp.height)
                    drawPostEyeQuad(
                        k1 = if (vr.lensDistortionEnabled) vr.distortionK1 else 0f,
                        chromatic = if (vr.chromaticAberrationEnabled) 0.008f else 0f,
                        imageScale = vr.imageScale,
                        eyeOffset = if (eye == 0) -vr.eyeSeparationOffset else vr.eyeSeparationOffset
                    )
                    GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                } else {
                    GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                    GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
                    GLES30.glScissor(vp.x, vp.y, vp.width, vp.height)
                    GLES30.glViewport(vp.x, vp.y, vp.width, vp.height)
                    GLES30.glClearColor(skyR, skyG, skyB, 1f)
                    GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

                    renderEyeScene(snap, eyeSign * virtualEyeBaselineM, aspect, skyR, skyG, skyB, fogDensity)
                    GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
                }
            }
        } else {
            GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
            GLES30.glClearColor(skyR, skyG, skyB, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            val aspect = (surfaceWidth.toFloat() / surfaceHeight.toFloat()).coerceAtLeast(0.5f)
            renderEyeScene(snap, 0f, aspect, skyR, skyG, skyB, fogDensity)
        }
    }

    private fun renderEyeScene(
        snap: SimulationSnapshot,
        eyeOffsetMeters: Float,
        aspect: Float,
        skyR: Float,
        skyG: Float,
        skyB: Float,
        fogDensity: Float
    ) {
        val fov = settings.vr.fovDegrees.coerceIn(60f, 120f)
        Matrix.perspectiveM(projMatrix, 0, fov, aspect, 0.06f, 95f)

        val fwd = GlMath.forwardVector(snap.yawDeg, snap.pitchDeg)
        val right = GlMath.rightVectorXZ(snap.yawDeg)
        val eyeX = snap.playerX + right[0] * eyeOffsetMeters
        val eyeY = snap.playerY
        val eyeZ = snap.playerZ + right[2] * eyeOffsetMeters

        // Compute true orthogonal camera UP vector = right × fwd (never tilted when horizonLockEnabled!)
        val baseUpX = right[1] * fwd[2] - right[2] * fwd[1]
        val baseUpY = right[2] * fwd[0] - right[0] * fwd[2]
        val baseUpZ = right[0] * fwd[1] - right[1] * fwd[0]

        val rollDeg = if (settings.vr.horizonLockEnabled) 0f else snap.rollDeg
        val rollRad = Math.toRadians(rollDeg.toDouble())
        val cosR = cos(rollRad).toFloat()
        val sinR = sin(rollRad).toFloat()
        val upX = baseUpX * cosR + right[0] * sinR
        val upY = baseUpY * cosR + right[1] * sinR
        val upZ = baseUpZ * cosR + right[2] * sinR

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            eyeX + fwd[0], eyeY + fwd[1], eyeZ + fwd[2],
            upX, upY, upZ
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        GLES30.glUseProgram(sceneProgram)
        GLES30.glUniform3f(uLightDirLoc, 0.35f, 0.85f, 0.42f)
        GLES30.glUniform3f(uCamPosLoc, eyeX, eyeY, eyeZ)
        GLES30.glUniform3f(uFogColorLoc, skyR, skyG, skyB)
        GLES30.glUniform1f(uFogDensityLoc, fogDensity)
        GLES30.glUniform1i(uReflectLoc, if (settings.graphics.reflectionsEnabled) 1 else 0)

        val scene = controller.worldData
        val shadowsOn = settings.graphics.shadowsEnabled && settings.graphics.quality != GraphicsQuality.LOW

        // 1. Opaque Static World Blocks
        for (b in scene.blocks) {
            if (b.alpha < 0.99f) continue
            if (shadowsOn && b.castsShadow) {
                drawShadowPatch(b.x, b.z, b.sx * 1.06f, b.sz * 1.06f)
            }
            val mesh = when (b.kind) {
                BlockMeshKind.CUBE -> cubeMesh
                BlockMeshKind.CYLINDER -> cylMesh
                BlockMeshKind.SPHERE -> sphereMesh
            }
            val tagInt = when (b.tag) {
                BlockMaterialTag.FLOOR_TILE -> 1
                BlockMaterialTag.FLOOR_ASPHALT -> 2
                BlockMaterialTag.EMISSIVE -> 3
                else -> 0
            }
            drawMesh(mesh, b.x, b.y, b.z, b.sx, b.sy, b.sz, 0f, 0f, b.colorArgb, 1f, tagInt, 0f)
        }

        // 2. Custom Imported World Mesh (if loaded via World Browser)
        uploadedCustomMesh?.let { custom ->
            drawMesh(custom, 0f, 0.05f, 2.5f, 1f, 1f, 1f, animTimeSec * 8f, 0f, 0xFF38BDF8, 1f, 0, 0f)
        }

        // 3. Interactive Products (Shelf, Belt, Cart/Basket, Held in Hand)
        val targetedId = snap.targetedProduct?.id
        val fwdXZ = GlMath.forwardVectorXZ(snap.yawDeg)
        val rightXZ = GlMath.rightVectorXZ(snap.yawDeg)
        var cartIdx = 0

        for (p in scene.products) {
            if (p.container == ItemContainer.BAG) continue
            val isTargeted = p.id == targetedId
            val hl = if (isTargeted) 0.55f + 0.35f * sin(animTimeSec * 6f) else 0f

            when (p.container) {
                ItemContainer.HAND -> {
                    val hx = snap.playerX + fwd[0] * 0.62f + rightXZ[0] * (if (snap.isInspectingDetails) 0.0f else 0.22f)
                    val hy = snap.playerY + fwd[1] * 0.62f - 0.14f
                    val hz = snap.playerZ + fwd[2] * 0.62f + rightXZ[2] * (if (snap.isInspectingDetails) 0.0f else 0.22f)
                    drawProduct(p, hx, hy, hz, snap.inspectYawDeg, snap.inspectPitchDeg, 1.25f, 0.35f)
                }
                ItemContainer.CART, ItemContainer.BASKET -> {
                    val cartDist = if (snap.hasCart) 1.15f else 0.75f
                    val cx = snap.playerX + fwdXZ[0] * cartDist + rightXZ[0] * ((cartIdx % 3 - 1) * 0.14f)
                    val cy = 0.72f + (cartIdx / 3) * 0.14f
                    val cz = snap.playerZ + fwdXZ[2] * cartDist + rightXZ[2] * ((cartIdx % 3 - 1) * 0.14f)
                    cartIdx++
                    drawProduct(p, cx, cy, cz, 0f, 0f, 0.85f, hl)
                }
                else -> {
                    drawProduct(p, p.x, p.y, p.z, if (isTargeted) animTimeSec * 40f else 0f, 0f, 1f, hl)
                }
            }
        }

        // 4. Cart / Basket Bays & Player's Pushed Cart or Basket
        val cartBayHl = if (snap.targetedStation == TargetStationType.CART_BAY) 0.6f else 0f
        drawCartModel(-4.2f, 0.55f, 9.6f, 0f, cartBayHl)
        val basketBayHl = if (snap.targetedStation == TargetStationType.BASKET_BAY) 0.6f else 0f
        drawMesh(cubeMesh, 4.0f, 0.82f, 9.6f, 0.45f, 0.26f, 0.34f, 0f, 0f, 0xFF0EA5E9, 1f, 0, basketBayHl)

        if (snap.hasCart) {
            val cx = snap.playerX + fwdXZ[0] * 1.15f
            val cz = snap.playerZ + fwdXZ[2] * 1.15f
            drawCartModel(cx, 0.50f, cz, snap.yawDeg, 0f)
        } else if (snap.hasBasket) {
            val bx = snap.playerX + fwdXZ[0] * 0.75f
            val bz = snap.playerZ + fwdXZ[2] * 0.75f
            drawMesh(cubeMesh, bx, 0.68f, bz, 0.42f, 0.24f, 0.32f, snap.yawDeg, 0f, 0xFF0EA5E9, 1f, 0, 0f)
        } else if (snap.hasPaidBag) {
            val gx = snap.playerX + fwdXZ[0] * 0.55f + rightXZ[0] * 0.25f
            val gz = snap.playerZ + fwdXZ[2] * 0.55f + rightXZ[2] * 0.25f
            drawMesh(cubeMesh, gx, 0.95f, gz, 0.28f, 0.38f, 0.20f, snap.yawDeg, 0f, 0xFF10B981, 1f, 0, 0f)
        }

        // Checkout Station Highlights
        if (snap.targetedStation == TargetStationType.CHECKOUT_BELT) {
            drawMesh(cubeMesh, 5.8f, 0.96f, 7.5f, 1.9f, 0.04f, 0.92f, 0f, 0f, 0xFF38BDF8, 0.6f, 3, 0.7f)
        } else if (snap.targetedStation == TargetStationType.LASER_SCANNER) {
            drawMesh(cubeMesh, 6.2f, 1.18f, 7.5f, 0.16f, 0.40f, 0.90f, 0f, 0f, 0xFFFF2244, 0.8f, 3, 0.9f)
        } else if (snap.targetedStation == TargetStationType.POS_TERMINAL) {
            drawMesh(cubeMesh, 7.5f, 1.15f, 6.7f, 0.40f, 0.46f, 0.40f, 0f, 0f, 0xFF10B981, 0.8f, 3, 0.9f)
        }

        // 5. NPCs
        for (npc in scene.npcs) {
            val npcHl = if (snap.targetedNpc?.id == npc.id) 0.65f else 0f
            if (shadowsOn) drawShadowPatch(npc.x, npc.z, 0.65f, 0.65f)
            val walkCycle = if (npc.speed > 0.05f) sin(animTimeSec * 5.5f) * 18f else 0f
            drawMesh(cylMesh, npc.x - 0.11f, 0.42f, npc.z, 0.14f, 0.82f, 0.14f, npc.yawDeg, walkCycle, 0xFF1E293B, 1f, 0, npcHl)
            drawMesh(cylMesh, npc.x + 0.11f, 0.42f, npc.z, 0.14f, 0.82f, 0.14f, npc.yawDeg, -walkCycle, 0xFF1E293B, 1f, 0, npcHl)
            drawMesh(cubeMesh, npc.x, 1.14f, npc.z, 0.44f, 0.62f, 0.26f, npc.yawDeg, 0f, npc.shirtColorArgb, 1f, 0, npcHl)
            drawMesh(sphereMesh, npc.x, 1.64f, npc.z, 0.30f, 0.32f, 0.30f, npc.yawDeg, 0f, 0xFFF1C27D, 1f, 0, npcHl)
            if (npc.hasCart) {
                val nRad = Math.toRadians(npc.yawDeg.toDouble())
                val nfx = -sin(nRad).toFloat()
                val nfz = -cos(nRad).toFloat()
                drawCartModel(npc.x + nfx * 0.95f, 0.48f, npc.z + nfz * 0.95f, npc.yawDeg, 0f)
            }
        }

        // 6. Teleport Target Ring
        if (settings.controls.movementMode == MovementMode.TELEPORT && snap.teleportActive) {
            drawMesh(cylMesh, snap.teleportTargetX, 0.03f, snap.teleportTargetZ, 0.95f, 0.04f, 0.95f, 0f, 0f, 0xFF00E5FF, 0.72f, 3, 0.8f)
        }

        // 7. Full 3D Articulated Hand with Bones & Joints in Camera View
        if (settings.controls.activeScheme == ControlScheme.HAND_TRACKING && handState.landmarks.size >= 21) {
            render3DHand(snap, fwd, right, floatArrayOf(baseUpX, baseUpY, baseUpZ), handState)
        }

        // 8. Translucent Glass Elements & Animated Automatic Sliding Doors
        GLES30.glDepthMask(false)
        val slideOffset = snap.doorOpenAmount * 2.25f
        drawMesh(cubeMesh, -1.32f - slideOffset, 1.55f, 12.0f, 2.55f, 3.1f, 0.09f, 0f, 0f, 0xFF7DD3FC, 0.45f, 0, 0f)
        drawMesh(cubeMesh, 1.32f + slideOffset, 1.55f, 12.0f, 2.55f, 3.1f, 0.09f, 0f, 0f, 0xFF7DD3FC, 0.45f, 0, 0f)

        for (b in scene.blocks) {
            if (b.alpha >= 0.99f) continue
            drawMesh(cubeMesh, b.x, b.y, b.z, b.sx, b.sy, b.sz, 0f, 0f, b.colorArgb, b.alpha, 0, 0f)
        }

        if (settings.graphics.weather == WeatherType.RAIN) {
            for (r in 0 until 45) {
                val rx = ((r * 73) % 30) - 15f
                val rz = 13f + ((r * 37) % 16)
                val ry = 6.0f - ((animTimeSec * 9f + r * 0.4f) % 6.0f)
                drawMesh(cubeMesh, rx, ry, rz, 0.03f, 0.42f, 0.03f, 0f, 0f, 0xFFBAE6FD, 0.55f, 3, 0f)
            }
        }
        GLES30.glDepthMask(true)
    }

    private fun render3DHand(
        snap: SimulationSnapshot,
        fwd: FloatArray,
        right: FloatArray,
        camUp: FloatArray,
        hand: HandTrackingState
    ) {
        val scale = settings.controls.handCalibrationScale * 0.68f
        val baseX = snap.playerX + fwd[0] * 0.50f - camUp[0] * 0.04f
        val baseY = snap.playerY + fwd[1] * 0.50f - camUp[1] * 0.04f
        val baseZ = snap.playerZ + fwd[2] * 0.50f - camUp[2] * 0.04f

        val pts = hand.landmarks.map { lm ->
            val lx = (lm.x - 0.5f) * scale
            val ly = (0.5f - lm.y) * scale
            val lz = -lm.z * scale * 0.55f
            floatArrayOf(
                baseX + right[0] * lx + camUp[0] * ly + fwd[0] * lz,
                baseY + right[1] * lx + camUp[1] * ly + fwd[1] * lz,
                baseZ + right[2] * lx + camUp[2] * ly + fwd[2] * lz
            )
        }

        // Draw 20 bone connections so full palm + 5 fingers are clearly visible!
        for (pair in HAND_BONE_PAIRS) {
            val a = pts[pair[0]]
            val b = pts[pair[1]]
            drawBoneSegment(a, b, 0.015f, 0xFFF2C9A0)
        }

        // Palm center connector
        drawBoneSegment(pts[5], pts[17], 0.024f, 0xFFE6B587)
        drawBoneSegment(pts[0], pts[9], 0.028f, 0xFFE6B587)

        // Draw 21 joint spheres
        for (idx in pts.indices) {
            val p = pts[idx]
            val jointSize = if (idx == 8 || idx == 4) 0.028f else if (idx == 0) 0.036f else 0.020f
            val color = when (idx) {
                8 -> 0xFF00E5FF
                4 -> 0xFF10B981
                else -> 0xFFF59E0B
            }
            drawMesh(sphereMesh, p[0], p[1], p[2], jointSize, jointSize, jointSize, 0f, 0f, color, 1f, 3, 0.5f)
        }
    }

    private fun drawBoneSegment(a: FloatArray, b: FloatArray, thickness: Float, colorArgb: Long) {
        val mx = (a[0] + b[0]) * 0.5f
        val my = (a[1] + b[1]) * 0.5f
        val mz = (a[2] + b[2]) * 0.5f
        val dx = b[0] - a[0]
        val dy = b[1] - a[1]
        val dz = b[2] - a[2]
        val len = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(0.005f)
        val yaw = Math.toDegrees(atan2(dx.toDouble(), dz.toDouble())).toFloat()
        val horiz = sqrt(dx * dx + dz * dz)
        val pitch = Math.toDegrees(atan2(horiz.toDouble(), dy.toDouble())).toFloat()
        drawMesh(cylMesh, mx, my, mz, thickness, len, thickness, yaw, pitch, colorArgb, 1f, 0, 0.25f)
    }

    private fun drawProduct(
        p: ProductItem,
        x: Float, y: Float, z: Float,
        yawDeg: Float, pitchDeg: Float,
        scaleMult: Float,
        highlight: Float
    ) {
        when (p.meshShape) {
            ProductMeshShape.BOX -> {
                drawMesh(cubeMesh, x, y, z, 0.22f * scaleMult, 0.26f * scaleMult, 0.14f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawMesh(cubeMesh, x, y + 0.05f * scaleMult, z, 0.23f * scaleMult, 0.07f * scaleMult, 0.145f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.BOTTLE -> {
                drawMesh(cylMesh, x, y - 0.02f * scaleMult, z, 0.13f * scaleMult, 0.24f * scaleMult, 0.13f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawMesh(cylMesh, x, y + 0.14f * scaleMult, z, 0.06f * scaleMult, 0.08f * scaleMult, 0.06f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.CAN -> {
                drawMesh(cylMesh, x, y, z, 0.12f * scaleMult, 0.20f * scaleMult, 0.12f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawMesh(cylMesh, x, y + 0.08f * scaleMult, z, 0.122f * scaleMult, 0.03f * scaleMult, 0.122f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.SPHERE_FRUIT -> {
                drawMesh(sphereMesh, x, y, z, 0.17f * scaleMult, 0.17f * scaleMult, 0.17f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawMesh(cubeMesh, x, y + 0.09f * scaleMult, z, 0.03f * scaleMult, 0.05f * scaleMult, 0.03f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.LOAF -> {
                drawMesh(sphereMesh, x, y, z, 0.26f * scaleMult, 0.14f * scaleMult, 0.15f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.BAR -> {
                drawMesh(cubeMesh, x, y, z, 0.22f * scaleMult, 0.05f * scaleMult, 0.12f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawMesh(cubeMesh, x, y + 0.01f * scaleMult, z, 0.14f * scaleMult, 0.055f * scaleMult, 0.122f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 0, highlight)
            }
            ProductMeshShape.DEVICE -> {
                drawMesh(cubeMesh, x, y, z, 0.25f * scaleMult, 0.18f * scaleMult, 0.14f * scaleMult, yawDeg, pitchDeg, p.primaryColorArgb, 1f, 0, highlight)
                drawMesh(cubeMesh, x, y, z, 0.26f * scaleMult, 0.05f * scaleMult, 0.06f * scaleMult, yawDeg, pitchDeg, p.accentColorArgb, 1f, 3, highlight)
            }
        }
    }

    private fun drawCartModel(x: Float, y: Float, z: Float, yawDeg: Float, highlight: Float) {
        drawMesh(cubeMesh, x, y + 0.20f, z, 0.56f, 0.36f, 0.78f, yawDeg, 0f, 0xFF94A3B8, 1f, 0, highlight)
        drawMesh(cubeMesh, x, y - 0.14f, z, 0.50f, 0.05f, 0.72f, yawDeg, 0f, 0xFF475569, 1f, 0, highlight)
        drawMesh(cubeMesh, x, y + 0.44f, z + 0.38f, 0.56f, 0.06f, 0.06f, yawDeg, 0f, 0xFFEF4444, 1f, 0, highlight)
    }

    private fun drawShadowPatch(x: Float, z: Float, sx: Float, sz: Float) {
        drawMesh(cubeMesh, x, 0.008f, z, sx, 0.005f, sz, 0f, 0f, 0xFF000000, 0.22f, 0, 0f)
    }

    private fun drawMesh(
        mesh: GlMesh,
        x: Float, y: Float, z: Float,
        sx: Float, sy: Float, sz: Float,
        yawDeg: Float, pitchDeg: Float,
        colorArgb: Long,
        alpha: Float,
        tag: Int,
        highlight: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (yawDeg != 0f) Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        if (pitchDeg != 0f) Matrix.rotateM(modelMatrix, 0, pitchDeg, 1f, 0f, 0f)
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

        val r = ((colorArgb shr 16) and 0xFF) / 255f
        val g = ((colorArgb shr 8) and 0xFF) / 255f
        val b = (colorArgb and 0xFF) / 255f

        GLES30.glUniformMatrix4fv(uMvpLoc, 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES30.glUniform3f(uColorLoc, r, g, b)
        GLES30.glUniform1f(uAlphaLoc, alpha)
        GLES30.glUniform1i(uTagLoc, tag)
        GLES30.glUniform1f(uHighlightLoc, highlight)

        mesh.draw(aPosLoc, aNormLoc)
    }

    private fun drawPostEyeQuad(k1: Float, chromatic: Float, imageScale: Float, eyeOffset: Float) {
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(postProgram)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glUniform1i(uPostTexLoc, 0)
        GLES30.glUniform1f(uDistortionK1Loc, k1)
        GLES30.glUniform1f(uChromaticLoc, chromatic)
        GLES30.glUniform1f(uImageScaleLoc, imageScale)
        GLES30.glUniform1f(uEyeOffsetLoc, eyeOffset)
        GLES30.glUniform1f(uVignetteLoc, 1f)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        val stride = 4 * 4
        GLES30.glEnableVertexAttribArray(aPostPosLoc)
        GLES30.glVertexAttribPointer(aPostPosLoc, 2, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(aPostUvLoc)
        GLES30.glVertexAttribPointer(aPostUvLoc, 2, GLES30.GL_FLOAT, false, stride, 2 * 4)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
    }

    private fun ensureFbo(w: Int, h: Int) {
        if (fboId != 0 && fboWidth == w && fboHeight == h) return
        if (fboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(fboId), 0)
            GLES30.glDeleteTextures(1, intArrayOf(fboColorTex), 0)
            GLES30.glDeleteRenderbuffers(1, intArrayOf(fboDepthRb), 0)
        }
        fboWidth = w
        fboHeight = h

        val fbos = IntArray(1)
        val texs = IntArray(1)
        val rbs = IntArray(1)
        GLES30.glGenFramebuffers(1, fbos, 0)
        GLES30.glGenTextures(1, texs, 0)
        GLES30.glGenRenderbuffers(1, rbs, 0)
        fboId = fbos[0]; fboColorTex = texs[0]; fboDepthRb = rbs[0]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, w, h, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, fboDepthRb)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, w, h)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, fboColorTex, 0)
        GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, fboDepthRb)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun createFullscreenQuadVbo(): Int {
        val quad = floatArrayOf(
            -1f, -1f, 0f, 0f,
             1f, -1f, 1f, 0f,
             1f,  1f, 1f, 1f,
            -1f, -1f, 0f, 0f,
             1f,  1f, 1f, 1f,
            -1f,  1f, 0f, 1f
        )
        val buf: FloatBuffer = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(quad)
        buf.position(0)
        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        return vbo[0]
    }

    private fun createProgram(vsSource: String, fsSource: String): Int {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vsSource)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, src)
        GLES30.glCompileShader(shader)
        return shader
    }

    companion object {
        private val HAND_BONE_PAIRS = arrayOf(
            intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 4),
            intArrayOf(0, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 8),
            intArrayOf(0, 9), intArrayOf(9, 10), intArrayOf(10, 11), intArrayOf(11, 12),
            intArrayOf(0, 13), intArrayOf(13, 14), intArrayOf(14, 15), intArrayOf(15, 16),
            intArrayOf(0, 17), intArrayOf(17, 18), intArrayOf(18, 19), intArrayOf(19, 20)
        )

        private const val SCENE_VS = """#version 300 es
            layout(location = 0) in vec3 aPos;
            layout(location = 1) in vec3 aNorm;
            uniform mat4 uMvp;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec3 vNormal;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                vNormal = normalize(transpose(inverse(mat3(uModel))) * aNorm);
                gl_Position = uMvp * vec4(aPos, 1.0);
            }
        """

        private const val SCENE_FS = """#version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec3 vNormal;
            uniform vec3 uColor;
            uniform float uAlpha;
            uniform int uTag;
            uniform float uHighlight;
            uniform vec3 uLightDir;
            uniform vec3 uCamPos;
            uniform vec3 uFogColor;
            uniform float uFogDensity;
            uniform int uReflect;
            out vec4 fragColor;

            void main() {
                vec3 N = normalize(vNormal);
                vec3 L = normalize(uLightDir);
                vec3 V = normalize(uCamPos - vWorldPos);
                vec3 H = normalize(L + V);

                vec3 baseCol = uColor;

                if (uTag == 1) {
                    vec2 grid = abs(fract(vWorldPos.xz * 0.85) - 0.5);
                    float line = step(0.47, max(grid.x, grid.y));
                    baseCol = mix(baseCol, baseCol * 0.82, line);
                } else if (uTag == 2) {
                    float grain = fract(sin(dot(floor(vWorldPos.xz * 12.0), vec2(12.9898, 78.233))) * 43758.5453);
                    baseCol *= (0.90 + 0.16 * grain);
                }

                float diff = max(dot(N, L), 0.0);
                float hemi = 0.44 + 0.24 * N.y;
                float specPower = (uTag == 1 && uReflect == 1) ? 48.0 : 24.0;
                float specStr = (uTag == 1 && uReflect == 1) ? 0.35 : 0.14;
                float spec = pow(max(dot(N, H), 0.0), specPower) * specStr;

                vec3 lit = baseCol * (hemi + diff * 0.65) + vec3(spec);

                if (uTag == 3) {
                    lit = baseCol * 1.18;
                }

                if (uHighlight > 0.01) {
                    float rim = pow(1.0 - max(dot(N, V), 0.0), 2.0);
                    lit = mix(lit, vec3(0.0, 0.90, 1.0), uHighlight * (0.35 + 0.55 * rim));
                }

                float dist = length(uCamPos - vWorldPos);
                float fogFactor = 1.0 - exp(-dist * uFogDensity);
                vec3 finalRgb = mix(lit, uFogColor, clamp(fogFactor, 0.0, 0.85));

                fragColor = vec4(finalRgb, uAlpha);
            }
        """

        private const val POST_VS = """#version 300 es
            layout(location = 0) in vec2 aPos;
            layout(location = 1) in vec2 aUv;
            out vec2 vUv;
            void main() {
                vUv = aUv;
                gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """

        private const val POST_FS = """#version 300 es
            precision mediump float;
            in vec2 vUv;
            uniform sampler2D uTex;
            uniform float uK1;
            uniform float uChromatic;
            uniform float uImageScale;
            uniform float uEyeOffset;
            uniform float uVignette;
            out vec4 fragColor;

            vec2 distort(vec2 centered, float k) {
                float r2 = dot(centered, centered);
                return centered * (1.0 + k * r2);
            }

            void main() {
                vec2 c = (vUv - vec2(0.5 + uEyeOffset, 0.5)) / max(uImageScale, 0.5);
                vec2 uvR = distort(c, uK1 + uChromatic) + 0.5;
                vec2 uvG = distort(c, uK1) + 0.5;
                vec2 uvB = distort(c, uK1 - uChromatic) + 0.5;

                if (uvG.x < 0.0 || uvG.x > 1.0 || uvG.y < 0.0 || uvG.y > 1.0) {
                    fragColor = vec4(0.0, 0.0, 0.0, 1.0);
                    return;
                }

                float r = texture(uTex, clamp(uvR, 0.0, 1.0)).r;
                float g = texture(uTex, clamp(uvG, 0.0, 1.0)).g;
                float b = texture(uTex, clamp(uvB, 0.0, 1.0)).b;

                float rDist = length(c);
                float vig = 1.0 - smoothstep(0.47, 0.55, rDist) * uVignette;
                fragColor = vec4(vec3(r, g, b) * vig, 1.0);
            }
        """
    }
}
