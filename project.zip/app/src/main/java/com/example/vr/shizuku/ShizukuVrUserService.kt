package com.example.vr.shizuku

import android.annotation.SuppressLint
import android.hardware.display.VirtualDisplay
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.Parcel
import android.os.SystemClock
import android.system.Os
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.InvocationTargetException
import kotlin.system.exitProcess

/**
 * Shizuku UserService running in the privileged Shell (UID 2000) process—never Root.
 * Creates an isolated VirtualDisplay bound directly to MineVR's OpenGL Surface,
 * launches Minecraft Bedrock onto that off-screen displayId, and forwards controller &
 * head-look input events directly to that displayId.
 */
class ShizukuVrUserService : IShizukuVrService.Stub() {

    private var activeCallbackProxy: Any? = null
    private var activeVirtualDisplayId: Int = -1
    private var lastErrorMessage: String = ""

    private val virtualDisplayCallbackBinder = object : Binder() {
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            return when (code) {
                INTERFACE_TRANSACTION -> {
                    reply?.writeString(IVIRTUAL_DISPLAY_CALLBACK_DESCRIPTOR)
                    true
                }
                FIRST_CALL_TRANSACTION,
                FIRST_CALL_TRANSACTION + 1,
                FIRST_CALL_TRANSACTION + 2 -> {
                    data.enforceInterface(IVIRTUAL_DISPLAY_CALLBACK_DESCRIPTOR)
                    reply?.writeNoException()
                    true
                }
                else -> super.onTransact(code, data, reply, flags)
            }
        }
    }

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { HiddenApiBypass.addHiddenApiExemptions("L") }
        }
    }

    override fun destroy() {
        releaseVirtualDisplay()
        exitProcess(0)
    }

    override fun getUid(): Int = runCatching { Os.getuid() }.getOrDefault(-1)

    override fun getLastError(): String = lastErrorMessage

    @SuppressLint("PrivateApi", "DiscouragedPrivateApi")
    override fun createVirtualDisplay(surface: Surface?, width: Int, height: Int, dpi: Int): Int {
        releaseVirtualDisplay()
        lastErrorMessage = ""

        if (surface == null || !surface.isValid) {
            lastErrorMessage = "Invalid OpenGL Surface provided for VirtualDisplay"
            return -1
        }

        val w = width.coerceIn(320, 2560)
        val h = height.coerceIn(240, 1600)
        val density = dpi.coerceIn(120, 640)

        return try {
            val idm = getDisplayManagerService()
            val callbackStubClass = Class.forName(IVIRTUAL_DISPLAY_CALLBACK_STUB)
            val callbackProxy = callbackStubClass
                .getMethod("asInterface", IBinder::class.java)
                .invoke(null, virtualDisplayCallbackBinder)
                ?: throw IllegalStateException("Failed to create IVirtualDisplayCallback proxy")

            val callingPkg = resolveShellOrAppPackage()

            val baseFlags = FLAG_PUBLIC or
                FLAG_OWN_CONTENT_ONLY or
                FLAG_SUPPORTS_TOUCH or
                FLAG_ROTATES_WITH_CONTENT or
                FLAG_DESTROY_CONTENT_ON_REMOVAL

            val flagCandidates = listOf(
                baseFlags or FLAG_TRUSTED,
                baseFlags,
                FLAG_OWN_CONTENT_ONLY or FLAG_SUPPORTS_TOUCH or FLAG_ROTATES_WITH_CONTENT or FLAG_DESTROY_CONTENT_ON_REMOVAL
            )

            var createdDisplayId = -1
            var lastAttemptError: Throwable? = null

            for (flags in flagCandidates) {
                try {
                    val id = invokeCreateVirtualDisplay(
                        idm = idm,
                        callbackProxy = callbackProxy,
                        callingPackage = callingPkg,
                        surface = surface,
                        width = w,
                        height = h,
                        dpi = density,
                        flags = flags
                    )
                    if (id > 0) {
                        createdDisplayId = id
                        break
                    }
                } catch (t: Throwable) {
                    lastAttemptError = unwrapInvocation(t)
                }
            }

            if (createdDisplayId <= 0) {
                val msg = lastAttemptError?.let { "${it.javaClass.simpleName}: ${it.message}" }
                    ?: "IDisplayManager.createVirtualDisplay returned invalid displayId=$createdDisplayId"
                lastErrorMessage = msg
                -1
            } else {
                activeCallbackProxy = callbackProxy
                activeVirtualDisplayId = createdDisplayId
                createdDisplayId
            }
        } catch (t: Throwable) {
            val root = unwrapInvocation(t)
            lastErrorMessage = "${root.javaClass.simpleName}: ${root.message ?: "VirtualDisplay error"}"
            -1
        }
    }

    @SuppressLint("PrivateApi")
    override fun resizeVirtualDisplay(width: Int, height: Int, dpi: Int) {
        val token = activeCallbackProxy ?: return
        runCatching {
            val idm = getDisplayManagerService()
            val cbInterface = Class.forName(IVIRTUAL_DISPLAY_CALLBACK_DESCRIPTOR)
            idm.javaClass.getMethod(
                "resizeVirtualDisplay",
                cbInterface,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            ).invoke(idm, token, width.coerceIn(320, 2560), height.coerceIn(240, 1600), dpi.coerceIn(120, 640))
        }.onFailure { err ->
            val root = unwrapInvocation(err)
            lastErrorMessage = "${root.javaClass.simpleName}: ${root.message}"
        }
    }

    @SuppressLint("PrivateApi")
    override fun releaseVirtualDisplay() {
        val token = activeCallbackProxy
        activeCallbackProxy = null
        activeVirtualDisplayId = -1
        if (token == null) return
        runCatching {
            val idm = getDisplayManagerService()
            val cbInterface = Class.forName(IVIRTUAL_DISPLAY_CALLBACK_DESCRIPTOR)
            idm.javaClass.getMethod("releaseVirtualDisplay", cbInterface).invoke(idm, token)
        }
    }

    override fun launchPackageOnDisplay(packageName: String?, activityComponent: String?, displayId: Int): String {
        if (packageName.isNullOrBlank()) {
            lastErrorMessage = "Target package name is empty"
            return lastErrorMessage
        }
        if (displayId <= 0) {
            lastErrorMessage = "Cannot launch package on invalid displayId=$displayId"
            return lastErrorMessage
        }

        val cmd = if (!activityComponent.isNullOrBlank()) {
            arrayOf(
                "am", "start",
                "--display", displayId.toString(),
                "-a", "android.intent.action.MAIN",
                "-c", "android.intent.category.LAUNCHER",
                "-f", "0x10200000",
                "-n", activityComponent
            )
        } else {
            arrayOf(
                "am", "start",
                "--display", displayId.toString(),
                "-a", "android.intent.action.MAIN",
                "-c", "android.intent.category.LAUNCHER",
                "-f", "0x10200000",
                packageName
            )
        }

        return try {
            val process = ProcessBuilder(*cmd)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use(BufferedReader::readText).trim()
            val exitCode = process.waitFor()
            val hasFailureText = output.contains("Error:", ignoreCase = true) ||
                output.contains("SecurityException", ignoreCase = true) ||
                output.contains("Unable to resolve", ignoreCase = true) ||
                output.contains("does not exist", ignoreCase = true)
            if (exitCode != 0 || hasFailureText) {
                lastErrorMessage = output.ifBlank { "am start failed with exitCode=$exitCode" }
                lastErrorMessage
            } else {
                ""
            }
        } catch (t: Throwable) {
            lastErrorMessage = "${t.javaClass.simpleName}: ${t.message}"
            lastErrorMessage
        }
    }

    override fun isPackageRunningOnDisplay(packageName: String?, displayId: Int): Boolean {
        if (packageName.isNullOrBlank() || displayId <= 0) return false
        return runCatching {
            val process = ProcessBuilder("dumpsys", "activity", "activities")
                .redirectErrorStream(true)
                .start()
            var inTargetDisplay = false
            var foundOnDisplay = false
            InputStreamReader(process.inputStream).buffered().use { reader ->
                reader.forEachLine { line ->
                    val trimmed = line.trimStart()
                    if (trimmed.startsWith("Display #")) {
                        inTargetDisplay = trimmed.startsWith("Display #$displayId ") ||
                            trimmed.startsWith("Display #$displayId(")
                    } else if (inTargetDisplay && trimmed.contains(packageName)) {
                        if (trimmed.contains("ActivityRecord{") ||
                            trimmed.contains("ResumedActivity:") ||
                            trimmed.contains("topResumedActivity=") ||
                            trimmed.contains("Task{")
                        ) {
                            foundOnDisplay = true
                        }
                    }
                }
            }
            process.waitFor()
            foundOnDisplay
        }.getOrDefault(false)
    }

    override fun injectKeyEvent(event: KeyEvent?, displayId: Int): Boolean {
        if (event == null || displayId <= 0) return false
        return runCatching {
            val copy = KeyEvent(event)
            setInputEventDisplayId(copy, displayId)
            injectToInputManager(copy)
        }.onFailure { err ->
            val root = unwrapInvocation(err)
            lastErrorMessage = "Key inject error: ${root.message}"
        }.getOrDefault(false)
    }

    override fun injectMotionEvent(event: MotionEvent?, displayId: Int): Boolean {
        if (event == null || displayId <= 0) return false
        return runCatching {
            val copy = MotionEvent.obtain(event)
            try {
                setInputEventDisplayId(copy, displayId)
                injectToInputManager(copy)
            } finally {
                copy.recycle()
            }
        }.onFailure { err ->
            val root = unwrapInvocation(err)
            lastErrorMessage = "Motion inject error: ${root.message}"
        }.getOrDefault(false)
    }

    override fun injectTouchEvent(
        displayId: Int,
        action: Int,
        x: Float,
        y: Float,
        downTimeMs: Long,
        eventTimeMs: Long
    ): Boolean {
        if (displayId <= 0) return false
        val safeDown = if (downTimeMs > 0L) downTimeMs else SystemClock.uptimeMillis()
        val safeEvent = if (eventTimeMs >= safeDown) eventTimeMs else SystemClock.uptimeMillis()
        return runCatching {
            val motion = MotionEvent.obtain(safeDown, safeEvent, action, x, y, 0)
            try {
                motion.source = InputDevice.SOURCE_TOUCHSCREEN
                setInputEventDisplayId(motion, displayId)
                injectToInputManager(motion)
            } finally {
                motion.recycle()
            }
        }.onFailure { err ->
            val root = unwrapInvocation(err)
            lastErrorMessage = "Touch inject error: ${root.message}"
        }.getOrDefault(false)
    }

    @SuppressLint("PrivateApi")
    private fun getDisplayManagerService(): Any {
        val smClass = Class.forName("android.os.ServiceManager")
        val binder = smClass.getMethod("getService", String::class.java).invoke(null, "display") as? IBinder
            ?: throw IllegalStateException("ServiceManager.getService(\"display\") returned null")
        val stubClass = Class.forName("android.hardware.display.IDisplayManager\$Stub")
        return stubClass.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            ?: throw IllegalStateException("IDisplayManager.Stub.asInterface returned null")
    }

    @SuppressLint("PrivateApi")
    private fun getInputManagerService(): Any {
        val smClass = Class.forName("android.os.ServiceManager")
        val binder = smClass.getMethod("getService", String::class.java).invoke(null, "input") as? IBinder
            ?: throw IllegalStateException("ServiceManager.getService(\"input\") returned null")
        val stubClass = Class.forName("android.hardware.input.IInputManager\$Stub")
        return stubClass.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            ?: throw IllegalStateException("IInputManager.Stub.asInterface returned null")
    }

    private fun invokeCreateVirtualDisplay(
        idm: Any,
        callbackProxy: Any,
        callingPackage: String,
        surface: Surface,
        width: Int,
        height: Int,
        dpi: Int,
        flags: Int
    ): Int {
        // Android 11+ (API 30+ including Android 13 API 33) uses VirtualDisplayConfig
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val vdcBuilderClass = Class.forName("android.hardware.display.VirtualDisplayConfig\$Builder")
            val builder = vdcBuilderClass.getConstructor(
                String::class.java,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            ).newInstance(VIRTUAL_DISPLAY_NAME, width, height, dpi)

            vdcBuilderClass.getMethod("setFlags", Int::class.javaPrimitiveType).invoke(builder, flags)
            vdcBuilderClass.getMethod("setSurface", Surface::class.java).invoke(builder, surface)
            val vdc = vdcBuilderClass.getMethod("build").invoke(builder)

            val createMethod = idm.javaClass.methods.firstOrNull { method ->
                method.name == "createVirtualDisplay" &&
                    method.parameterTypes.size == 4 &&
                    method.parameterTypes[0].name == "android.hardware.display.VirtualDisplayConfig"
            }
            if (createMethod != null) {
                val res = createMethod.invoke(idm, vdc, callbackProxy, null, callingPackage)
                return (res as? Int) ?: -1
            }
        }

        // Legacy 10-arg fallback if VirtualDisplayConfig overload wasn't found
        val legacyMethod = idm.javaClass.methods.firstOrNull { method ->
            method.name == "createVirtualDisplay" && method.parameterTypes.size == 10
        } ?: throw NoSuchMethodException("No compatible IDisplayManager.createVirtualDisplay method found")

        val res = legacyMethod.invoke(
            idm,
            callbackProxy,
            null,
            callingPackage,
            VIRTUAL_DISPLAY_NAME,
            width,
            height,
            dpi,
            surface,
            flags,
            null
        )
        return (res as? Int) ?: -1
    }

    private fun setInputEventDisplayId(event: InputEvent, displayId: Int) {
        val method = InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
        method.invoke(event, displayId)
    }

    private fun injectToInputManager(event: InputEvent): Boolean {
        val iim = getInputManagerService()
        val injectMethod = iim.javaClass.methods.firstOrNull { method ->
            method.name == "injectInputEvent" && method.parameterTypes.size == 2
        } ?: iim.javaClass.methods.firstOrNull { method ->
            method.name == "injectInputEventToTarget" && method.parameterTypes.size >= 2
        } ?: return false

        val result = when (injectMethod.parameterTypes.size) {
            2 -> injectMethod.invoke(iim, event, 0) // INJECT_INPUT_EVENT_MODE_ASYNC = 0
            else -> injectMethod.invoke(iim, event, 0, -1)
        }
        return (result as? Boolean) ?: true
    }

    private fun resolveShellOrAppPackage(): String {
        val uid = getUid()
        if (uid == 2000) return "com.android.shell"
        if (uid == 0) return "android"
        return runCatching {
            val atClass = Class.forName("android.app.ActivityThread")
            atClass.getMethod("currentPackageName").invoke(null) as? String
        }.getOrNull() ?: "com.android.shell"
    }

    private fun unwrapInvocation(t: Throwable): Throwable =
        if (t is InvocationTargetException && t.cause != null) t.cause!! else t

    companion object {
        private const val VIRTUAL_DISPLAY_NAME = "MineVR_VirtualDisplay"
        private const val IVIRTUAL_DISPLAY_CALLBACK_DESCRIPTOR = "android.hardware.display.IVirtualDisplayCallback"
        private const val IVIRTUAL_DISPLAY_CALLBACK_STUB = "android.hardware.display.IVirtualDisplayCallback\$Stub"

        // android.hardware.display.DisplayManager constants
        private const val FLAG_PUBLIC = 1
        private const val FLAG_OWN_CONTENT_ONLY = 1 shl 3
        private const val FLAG_SUPPORTS_TOUCH = 1 shl 6
        private const val FLAG_ROTATES_WITH_CONTENT = 1 shl 7
        private const val FLAG_DESTROY_CONTENT_ON_REMOVAL = 1 shl 8
        private const val FLAG_TRUSTED = 1 shl 10

        @Suppress("unused")
        private fun keepImportReference(): VirtualDisplay? = null
    }
}
