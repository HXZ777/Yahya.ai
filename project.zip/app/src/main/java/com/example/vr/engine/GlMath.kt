package com.example.vr.engine

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class Aabb(
    val minX: Float,
    val minY: Float,
    val minZ: Float,
    val maxX: Float,
    val maxY: Float,
    val maxZ: Float
) {
    fun centerX(): Float = (minX + maxX) * 0.5f
    fun centerY(): Float = (minY + maxY) * 0.5f
    fun centerZ(): Float = (minZ + maxZ) * 0.5f
}

object GlMath {

    fun rayIntersectsAabb(
        ox: Float, oy: Float, oz: Float,
        dx: Float, dy: Float, dz: Float,
        box: Aabb,
        maxDist: Float
    ): Float? {
        var tMin = 0f
        var tMax = maxDist

        // X slab
        if (kotlin.math.abs(dx) < 1e-6f) {
            if (ox < box.minX || ox > box.maxX) return null
        } else {
            val inv = 1f / dx
            var t1 = (box.minX - ox) * inv
            var t2 = (box.maxX - ox) * inv
            if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
            tMin = max(tMin, t1)
            tMax = min(tMax, t2)
            if (tMin > tMax) return null
        }

        // Y slab
        if (kotlin.math.abs(dy) < 1e-6f) {
            if (oy < box.minY || oy > box.maxY) return null
        } else {
            val inv = 1f / dy
            var t1 = (box.minY - oy) * inv
            var t2 = (box.maxY - oy) * inv
            if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
            tMin = max(tMin, t1)
            tMax = min(tMax, t2)
            if (tMin > tMax) return null
        }

        // Z slab
        if (kotlin.math.abs(dz) < 1e-6f) {
            if (oz < box.minZ || oz > box.maxZ) return null
        } else {
            val inv = 1f / dz
            var t1 = (box.minZ - oz) * inv
            var t2 = (box.maxZ - oz) * inv
            if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
            tMin = max(tMin, t1)
            tMax = min(tMax, t2)
            if (tMin > tMax) return null
        }

        return if (tMin in 0f..maxDist) tMin else null
    }

    fun resolveCircleAabbXZ(
        px: Float,
        pz: Float,
        radius: Float,
        colliders: List<Aabb>
    ): Pair<Float, Float> {
        var x = px
        var z = pz
        for (box in colliders) {
            val closestX = x.coerceIn(box.minX, box.maxX)
            val closestZ = z.coerceIn(box.minZ, box.maxZ)
            val dx = x - closestX
            val dz = z - closestZ
            val distSq = dx * dx + dz * dz
            if (distSq < radius * radius) {
                val dist = sqrt(distSq)
                if (dist > 1e-5f) {
                    val push = radius - dist
                    x += (dx / dist) * push
                    z += (dz / dist) * push
                } else {
                    // Inside box: push out along nearest edge
                    val leftPen = kotlin.math.abs(x - box.minX)
                    val rightPen = kotlin.math.abs(box.maxX - x)
                    val backPen = kotlin.math.abs(z - box.minZ)
                    val frontPen = kotlin.math.abs(box.maxZ - z)
                    val minPen = min(min(leftPen, rightPen), min(backPen, frontPen))
                    when (minPen) {
                        leftPen -> x = box.minX - radius
                        rightPen -> x = box.maxX + radius
                        backPen -> z = box.minZ - radius
                        else -> z = box.maxZ + radius
                    }
                }
            }
        }
        return x to z
    }

    fun forwardVector(yawDeg: Float, pitchDeg: Float): FloatArray {
        val yawRad = Math.toRadians(yawDeg.toDouble())
        val pitchRad = Math.toRadians(pitchDeg.toDouble())
        val cosPitch = cos(pitchRad)
        val fx = (-sin(yawRad) * cosPitch).toFloat()
        val fy = sin(pitchRad).toFloat()
        val fz = (-cos(yawRad) * cosPitch).toFloat()
        val len = sqrt(fx * fx + fy * fy + fz * fz).coerceAtLeast(1e-5f)
        return floatArrayOf(fx / len, fy / len, fz / len)
    }

    fun rightVectorXZ(yawDeg: Float): FloatArray {
        val yawRad = Math.toRadians(yawDeg.toDouble())
        return floatArrayOf(cos(yawRad).toFloat(), 0f, (-sin(yawRad)).toFloat())
    }

    fun forwardVectorXZ(yawDeg: Float): FloatArray {
        val yawRad = Math.toRadians(yawDeg.toDouble())
        return floatArrayOf((-sin(yawRad)).toFloat(), 0f, (-cos(yawRad)).toFloat())
    }
}
