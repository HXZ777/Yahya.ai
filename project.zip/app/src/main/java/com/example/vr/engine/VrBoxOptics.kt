package com.example.vr.engine

import android.util.DisplayMetrics
import com.example.vr.model.VrSettingsState
import kotlin.math.min
import kotlin.math.roundToInt

data class EyeViewportPx(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

data class VrBoxLayoutPx(
    val leftEye: EyeViewportPx,
    val rightEye: EyeViewportPx,
    val totalWidth: Int,
    val totalHeight: Int
)

object VrBoxOptics {

    /**
     * Computes fixed physical VR Box optical viewports calibrated to ~63mm lens center spacing
     * and ~58x64mm lens windows so images never over-stretch on large/wide phones.
     */
    fun computeLayout(
        surfaceWidthPx: Int,
        surfaceHeightPx: Int,
        metrics: DisplayMetrics,
        vr: VrSettingsState
    ): VrBoxLayoutPx = computeLayout(
        surfaceWidthPx = surfaceWidthPx,
        surfaceHeightPx = surfaceHeightPx,
        xdpi = metrics.xdpi,
        ydpi = metrics.ydpi,
        densityDpi = metrics.densityDpi,
        vr = vr
    )

    fun computeLayout(
        surfaceWidthPx: Int,
        surfaceHeightPx: Int,
        xdpi: Float,
        ydpi: Float,
        densityDpi: Int,
        vr: VrSettingsState
    ): VrBoxLayoutPx {
        val w = surfaceWidthPx.coerceAtLeast(2)
        val h = surfaceHeightPx.coerceAtLeast(2)

        if (!vr.sideBySideEnabled) {
            val single = EyeViewportPx(0, 0, w, h)
            return VrBoxLayoutPx(single, single, w, h)
        }

        if (!vr.fixedVrBoxMode) {
            val halfW = w / 2
            return VrBoxLayoutPx(
                leftEye = EyeViewportPx(0, 0, halfW, h),
                rightEye = EyeViewportPx(halfW, 0, halfW, h),
                totalWidth = w,
                totalHeight = h
            )
        }

        val fallbackDpi = if (densityDpi in 120..700) densityDpi.toFloat() else 395f
        val validX = if (xdpi in 120f..800f) xdpi else fallbackDpi
        val validY = if (ydpi in 120f..800f) ydpi else fallbackDpi
        val rawDpiX = if (w >= h) maxOf(validX, validY) else minOf(validX, validY)
        val pxPerMm = (rawDpiX / 25.4f).coerceIn(8.0f, 28.0f)

        // Standard VR Box optical center spacing (default 63mm), clamped safely inside screen
        val desiredSepPx = vr.ipdMm.coerceIn(55f, 70f) * pxPerMm
        val sepPx = desiredSepPx.coerceIn(w * 0.36f, w * 0.50f)

        // Fixed physical lens window (~58mm wide x ~64mm tall), bounded so left & right never touch
        val maxEyeW = min(sepPx - 4f, w - sepPx - 4f).coerceAtLeast(w * 0.25f)
        val eyeW = min(58f * pxPerMm, maxEyeW).roundToInt().coerceAtLeast(64)
        val eyeH = min(64f * pxPerMm, h.toFloat()).roundToInt().coerceAtLeast(64)

        val centerX = w * 0.5f
        val leftX = (centerX - sepPx * 0.5f - eyeW * 0.5f).roundToInt().coerceIn(0, (w / 2 - eyeW).coerceAtLeast(0))
        val rightX = (centerX + sepPx * 0.5f - eyeW * 0.5f).roundToInt().coerceIn(w / 2, (w - eyeW).coerceAtLeast(w / 2))
        val eyeY = ((h - eyeH) * 0.5f).roundToInt().coerceAtLeast(0)

        return VrBoxLayoutPx(
            leftEye = EyeViewportPx(leftX, eyeY, eyeW, eyeH),
            rightEye = EyeViewportPx(rightX, eyeY, eyeW, eyeH),
            totalWidth = w,
            totalHeight = h
        )
    }
}
