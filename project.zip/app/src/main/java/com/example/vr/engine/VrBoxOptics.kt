package com.example.vr.engine

import android.util.DisplayMetrics
import com.example.vr.model.VrSettingsState
import kotlin.math.min
import kotlin.math.roundToInt

data class EyeViewportPx(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

data class VrBoxLayoutPx(
    val leftEye: EyeViewportPx,
    val rightEye: EyeViewportPx,
    val totalWidth: Int,
    val totalHeight: Int
)

object VrBoxOptics {

    fun computeLayout(
        surfaceWidthPx: Int,
        surfaceHeightPx: Int,
        metrics: DisplayMetrics,
        vr: VrSettingsState
    ): VrBoxLayoutPx = computeLayout(
        surfaceWidthPx = surfaceWidthPx,
        surfaceHeightPx = surfaceHeightPx,
        xdpi = metrics.xdpi,
        ydpi = metrics.ydpi,
        densityDpi = metrics.densityDpi,
        vr = vr
    )

    fun computeLayout(
        surfaceWidthPx: Int,
        surfaceHeightPx: Int,
        xdpi: Float,
        ydpi: Float,
        densityDpi: Int,
        vr: VrSettingsState
    ): VrBoxLayoutPx {
        val w = surfaceWidthPx.coerceAtLeast(2)
        val h = surfaceHeightPx.coerceAtLeast(2)

        if (!vr.sideBySideEnabled) {
            val single = EyeViewportPx(0, 0, w, h)
            return VrBoxLayoutPx(single, single, w, h)
        }

        val scale = vr.vrScale.coerceIn(0.65f, 1.15f)
        val shiftYPx = (vr.alignYOffset.coerceIn(-0.15f, 0.15f) * h).roundToInt()

        if (!vr.fixedVrBoxMode) {
            val halfW = w / 2
            val eyeW = (halfW * scale).roundToInt().coerceIn(64, halfW)
            val eyeH = (h * scale).roundToInt().coerceIn(64, h)
            val centerShiftX = (vr.alignXOffset.coerceIn(-0.15f, 0.15f) * halfW).roundToInt()
            val leftX = ((halfW - eyeW) / 2 + centerShiftX).coerceIn(0, (halfW - eyeW).coerceAtLeast(0))
            val rightX = (halfW + (halfW - eyeW) / 2 - centerShiftX).coerceIn(halfW, (w - eyeW).coerceAtLeast(halfW))
            val eyeY = ((h - eyeH) / 2 + shiftYPx).coerceIn(0, (h - eyeH).coerceAtLeast(0))
            return VrBoxLayoutPx(
                leftEye = EyeViewportPx(leftX, eyeY, eyeW, eyeH),
                rightEye = EyeViewportPx(rightX, eyeY, eyeW, eyeH),
                totalWidth = w,
                totalHeight = h
            )
        }

        val fallbackDpi = if (densityDpi in 120..700) densityDpi.toFloat() else 395f
        val validX = if (xdpi in 120f..800f) xdpi else fallbackDpi
        val validY = if (ydpi in 120f..800f) ydpi else fallbackDpi
        val rawDpiX = if (w >= h) maxOf(validX, validY) else minOf(validX, validY)
        val pxPerMm = (rawDpiX / 25.4f).coerceIn(8.0f, 28.0f)

        val desiredSepPx = vr.ipdMm.coerceIn(55f, 72f) * pxPerMm
        val sepPx = desiredSepPx.coerceIn(w * 0.36f, w * 0.50f)

        val maxEyeW = min(sepPx - 4f, w - sepPx - 4f).coerceAtLeast(w * 0.25f)
        val eyeW = (min(58f * pxPerMm, maxEyeW) * scale).roundToInt().coerceIn(64, (w / 2).coerceAtLeast(64))
        val eyeH = (min(64f * pxPerMm, h.toFloat()) * scale).roundToInt().coerceIn(64, h)

        val alignShiftX = (vr.alignXOffset.coerceIn(-0.15f, 0.15f) * eyeW).roundToInt()
        val centerX = w * 0.5f
        val leftX = (centerX - sepPx * 0.5f - eyeW * 0.5f + alignShiftX)
            .roundToInt()
            .coerceIn(0, (w / 2 - eyeW).coerceAtLeast(0))
        val rightX = (centerX + sepPx * 0.5f - eyeW * 0.5f - alignShiftX)
            .roundToInt()
            .coerceIn(w / 2, (w - eyeW).coerceAtLeast(w / 2))
        val eyeY = ((h - eyeH) * 0.5f + shiftYPx)
            .roundToInt()
            .coerceIn(0, (h - eyeH).coerceAtLeast(0))

        return VrBoxLayoutPx(
            leftEye = EyeViewportPx(leftX, eyeY, eyeW, eyeH),
            rightEye = EyeViewportPx(rightX, eyeY, eyeW, eyeH),
            totalWidth = w,
            totalHeight = h
        )
    }
}
