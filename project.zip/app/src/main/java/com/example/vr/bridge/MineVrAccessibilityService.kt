package com.example.vr.bridge

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.example.vr.model.AccessibilityBridgeSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.hypot

data class LookSwipeSegment(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val durationMs: Long,
    val needsReanchor: Boolean = false
)

object HeadLookBridgeMath {
    /**
     * Computes a continuous touch-drag step inside the right-half camera look zone
     * from the current virtual finger position (curX, curY) without lifting the finger
     * unless approaching the look-zone boundary.
     */
    fun computeContinuousStep(
        screenWidthPx: Int,
        screenHeightPx: Int,
        curX: Float?,
        curY: Float?,
        deltaYawDeg: Float,
        deltaPitchDeg: Float,
        sensitivity: Float,
        invertY: Boolean
    ): LookSwipeSegment? {
        val w = screenWidthPx.coerceAtLeast(320).toFloat()
        val h = screenHeightPx.coerceAtLeast(240).toFloat()
        val mag = hypot(deltaYawDeg.toDouble(), deltaPitchDeg.toDouble()).toFloat()
        if (mag < 0.05f) return null

        val pxPerDeg = (w * 0.0095f) * sensitivity.coerceIn(0.25f, 3.0f)
        val rawDx = (-deltaYawDeg * pxPerDeg).coerceIn(-w * 0.14f, w * 0.14f)
        val ySign = if (invertY) -1f else 1f
        val rawDy = (-deltaPitchDeg * pxPerDeg * ySign).coerceIn(-h * 0.14f, h * 0.14f)
        if (abs(rawDx) < 0.5f && abs(rawDy) < 0.5f) return null

        val minX = w * 0.52f
        val maxX = w * 0.95f
        val minY = h * 0.15f
        val maxY = h * 0.85f
        val anchorX = w * 0.73f
        val anchorY = h * 0.50f

        val sx = curX ?: anchorX
        val sy = curY ?: anchorY
        val targetX = sx + rawDx
        val targetY = sy + rawDy

        val hitsEdge = targetX < minX || targetX > maxX || targetY < minY || targetY > maxY
        if (hitsEdge) {
            val endX = (anchorX + rawDx).coerceIn(minX, maxX)
            val endY = (anchorY + rawDy).coerceIn(minY, maxY)
            return LookSwipeSegment(
                startX = anchorX,
                startY = anchorY,
                endX = endX,
                endY = endY,
                durationMs = 16L,
                needsReanchor = true
            )
        }

        return LookSwipeSegment(
            startX = sx,
            startY = sy,
            endX = targetX,
            endY = targetY,
            durationMs = 16L,
            needsReanchor = false
        )
    }

    /** Backwards-compatible single-step helper used by diagnostics & unit tests. */
    fun computeLookSwipe(
        screenWidthPx: Int,
        screenHeightPx: Int,
        deltaYawDeg: Float,
        deltaPitchDeg: Float,
        sensitivity: Float,
        invertY: Boolean
    ): LookSwipeSegment? = computeContinuousStep(
        screenWidthPx = screenWidthPx,
        screenHeightPx = screenHeightPx,
        curX = null,
        curY = null,
        deltaYawDeg = deltaYawDeg,
        deltaPitchDeg = deltaPitchDeg,
        sensitivity = sensitivity,
        invertY = invertY
    )
}

class MineVrAccessibilityService : AccessibilityService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastDispatchTimeMs = 0L
    private var accumulatedYawDeg = 0f
    private var accumulatedPitchDeg = 0f
    private var gestureInFlight = false

    private var activeStroke: GestureDescription.StrokeDescription? = null
    private var fingerX: Float? = null
    private var fingerY: Float? = null

    private val idleReleaseRunnable = Runnable {
        releaseActiveStroke()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _snapshot.value = _snapshot.value.copy(
            isServiceEnabled = true,
            lastError = null
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        resetStrokeState()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(idleReleaseRunnable)
        resetStrokeState()
        if (instance === this) instance = null
        _snapshot.value = _snapshot.value.copy(
            isServiceEnabled = false,
            isDispatchingGestures = false
        )
        super.onDestroy()
    }

    fun submitHeadDelta(
        deltaYawDeg: Float,
        deltaPitchDeg: Float,
        sensitivity: Float,
        invertY: Boolean,
        enabled: Boolean
    ) {
        if (!enabled) {
            accumulatedYawDeg = 0f
            accumulatedPitchDeg = 0f
            releaseActiveStroke()
            return
        }
        accumulatedYawDeg += deltaYawDeg
        accumulatedPitchDeg += deltaPitchDeg

        val now = System.currentTimeMillis()
        // Dispatch at ~60Hz (16ms cadence) without waiting for finger-lift!
        if (gestureInFlight || now - lastDispatchTimeMs < 16L) return

        val (widthPx, heightPx) = resolveActiveDisplaySizePx()
        val segment = HeadLookBridgeMath.computeContinuousStep(
            screenWidthPx = widthPx,
            screenHeightPx = heightPx,
            curX = fingerX,
            curY = fingerY,
            deltaYawDeg = accumulatedYawDeg,
            deltaPitchDeg = accumulatedPitchDeg,
            sensitivity = sensitivity,
            invertY = invertY
        ) ?: return

        accumulatedYawDeg = 0f
        accumulatedPitchDeg = 0f
        dispatchContinuousSegment(segment, now)
    }

    fun sendDiagnosticTestSwipe(): Boolean {
        resetStrokeState()
        val (widthPx, heightPx) = resolveActiveDisplaySizePx()
        val segment = HeadLookBridgeMath.computeLookSwipe(
            screenWidthPx = widthPx,
            screenHeightPx = heightPx,
            deltaYawDeg = -8f,
            deltaPitchDeg = 0f,
            sensitivity = 1.0f,
            invertY = false
        ) ?: return false
        return dispatchSingleEndedSwipe(segment, System.currentTimeMillis())
    }

    private fun resolveActiveDisplaySizePx(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val bounds = wm.currentWindowMetrics.bounds
            if (bounds.width() > 0 && bounds.height() > 0) {
                return bounds.width() to bounds.height()
            }
        }
        val dm = getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        if (display != null) {
            val size = Point()
            @Suppress("DEPRECATION")
            display.getRealSize(size)
            if (size.x > 0 && size.y > 0) {
                return size.x to size.y
            }
        }
        val fallback = resources.displayMetrics
        return fallback.widthPixels to fallback.heightPixels
    }

    private fun dispatchContinuousSegment(segment: LookSwipeSegment, nowMs: Long): Boolean {
        mainHandler.removeCallbacks(idleReleaseRunnable)

        val supportsContinue = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
        if (!supportsContinue) {
            return dispatchSingleEndedSwipe(segment, nowMs)
        }

        // If approaching edge, terminate old stroke cleanly first and re-anchor at center
        if (segment.needsReanchor && activeStroke != null) {
            releaseActiveStroke()
        }

        val path = Path().apply {
            moveTo(segment.startX, segment.startY)
            lineTo(segment.endX, segment.endY)
        }

        val prev = activeStroke
        val nextStroke = if (prev != null && !segment.needsReanchor) {
            prev.continueStroke(path, 0L, segment.durationMs, true)
        } else {
            GestureDescription.StrokeDescription(path, 0L, segment.durationMs, true)
        }

        val gesture = GestureDescription.Builder().addStroke(nextStroke).build()
        gestureInFlight = true
        lastDispatchTimeMs = nowMs

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureInFlight = false
                activeStroke = nextStroke
                fingerX = segment.endX
                fingerY = segment.endY
                _snapshot.value = _snapshot.value.copy(
                    isServiceEnabled = true,
                    isDispatchingGestures = true,
                    gesturesDispatchedCount = _snapshot.value.gesturesDispatchedCount + 1,
                    lastGestureMs = System.currentTimeMillis(),
                    lastError = null
                )
                mainHandler.postDelayed(idleReleaseRunnable, 240L)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                resetStrokeState()
            }
        }, mainHandler)

        if (!dispatched) {
            resetStrokeState()
            _snapshot.value = _snapshot.value.copy(lastError = "Gesture rejected by OS")
        }
        return dispatched
    }

    private fun releaseActiveStroke() {
        val prev = activeStroke ?: return
        val x = fingerX ?: return
        val y = fingerY ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !gestureInFlight) {
            val endPath = Path().apply {
                moveTo(x, y)
                lineTo(x, y)
            }
            val finalStroke = prev.continueStroke(endPath, 0L, 10L, false)
            val gesture = GestureDescription.Builder().addStroke(finalStroke).build()
            dispatchGesture(gesture, null, mainHandler)
        }
        resetStrokeState()
    }

    private fun resetStrokeState() {
        gestureInFlight = false
        activeStroke = null
        fingerX = null
        fingerY = null
    }

    private fun dispatchSingleEndedSwipe(segment: LookSwipeSegment, nowMs: Long): Boolean {
        val path = Path().apply {
            moveTo(segment.startX, segment.startY)
            lineTo(segment.endX, segment.endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, segment.durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        gestureInFlight = true
        lastDispatchTimeMs = nowMs

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureInFlight = false
                _snapshot.value = _snapshot.value.copy(
                    isServiceEnabled = true,
                    isDispatchingGestures = true,
                    gesturesDispatchedCount = _snapshot.value.gesturesDispatchedCount + 1,
                    lastGestureMs = System.currentTimeMillis(),
                    lastError = null
                )
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }
        }, mainHandler)

        if (!dispatched) {
            gestureInFlight = false
            _snapshot.value = _snapshot.value.copy(lastError = "Gesture rejected by OS")
        }
        return dispatched
    }

    companion object {
        @Volatile
        var instance: MineVrAccessibilityService? = null
            private set

        private val _snapshot = MutableStateFlow(AccessibilityBridgeSnapshot())
        val snapshot: StateFlow<AccessibilityBridgeSnapshot> = _snapshot.asStateFlow()

        fun refreshSystemEnabledState(context: Context) {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            val expected = "${context.packageName}/${MineVrAccessibilityService::class.java.name}"
            val expectedShort = "${context.packageName}/.vr.bridge.MineVrAccessibilityService"
            val splitter = TextUtils.SimpleStringSplitter(':').apply { setString(enabledServices) }
            var found = false
            while (splitter.hasNext()) {
                val entry = splitter.next()
                if (entry.equals(expected, ignoreCase = true) || entry.equals(expectedShort, ignoreCase = true)) {
                    found = true
                    break
                }
            }
            _snapshot.value = _snapshot.value.copy(
                isServiceEnabled = found || instance != null
            )
        }
    }
}
