package com.example.vr.bridge

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import com.example.vr.model.AccessibilityBridgeSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.hypot

data class LookSwipeSegment(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val durationMs: Long
)

object HeadLookBridgeMath {
    /**
     * Converts head rotation deltas (in degrees) into a calibrated touch-drag vector
     * inside the right-half camera look zone of Minecraft Bedrock.
     */
    fun computeLookSwipe(
        screenWidthPx: Int,
        screenHeightPx: Int,
        deltaYawDeg: Float,
        deltaPitchDeg: Float,
        sensitivity: Float,
        invertY: Boolean
    ): LookSwipeSegment? {
        val w = screenWidthPx.coerceAtLeast(320).toFloat()
        val h = screenHeightPx.coerceAtLeast(240).toFloat()
        val mag = hypot(deltaYawDeg.toDouble(), deltaPitchDeg.toDouble()).toFloat()
        if (mag < 0.35f) return null

        val pxPerDeg = (w * 0.0085f) * sensitivity.coerceIn(0.25f, 3.0f)
        // Turning head right decreases OpenGL yaw -> drag finger right (+dx) to rotate Minecraft camera right
        val rawDx = (-deltaYawDeg * pxPerDeg).coerceIn(-w * 0.22f, w * 0.22f)
        val ySign = if (invertY) -1f else 1f
        // Looking up (+deltaPitch) drags finger up (-dy) in standard touch-look
        val rawDy = (-deltaPitchDeg * pxPerDeg * ySign).coerceIn(-h * 0.22f, h * 0.22f)
        if (abs(rawDx) < 2f && abs(rawDy) < 2f) return null

        val anchorX = w * 0.72f
        val anchorY = h * 0.48f
        val endX = (anchorX + rawDx).coerceIn(w * 0.52f, w * 0.96f)
        val endY = (anchorY + rawDy).coerceIn(h * 0.15f, h * 0.85f)

        return LookSwipeSegment(
            startX = anchorX,
            startY = anchorY,
            endX = endX,
            endY = endY,
            durationMs = 28L
        )
    }
}

class MineVrAccessibilityService : AccessibilityService() {

    private var lastDispatchTimeMs = 0L
    private var accumulatedYawDeg = 0f
    private var accumulatedPitchDeg = 0f
    private var gestureInFlight = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _snapshot.value = _snapshot.value.copy(
            isServiceEnabled = true,
            lastError = null
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        gestureInFlight = false
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        _snapshot.value = _snapshot.value.copy(
            isServiceEnabled = false,
            isDispatchingGestures = false
        )
        super.onDestroy()
    }

    fun submitHeadDelta(
        deltaYawDeg: Float,
        deltaPitchDeg: Float,
        sensitivity: Float,
        invertY: Boolean,
        enabled: Boolean
    ) {
        if (!enabled) {
            accumulatedYawDeg = 0f
            accumulatedPitchDeg = 0f
            return
        }
        accumulatedYawDeg += deltaYawDeg
        accumulatedPitchDeg += deltaPitchDeg

        val now = System.currentTimeMillis()
        if (gestureInFlight || now - lastDispatchTimeMs < 42L) return

        val metrics = resources.displayMetrics
        val segment = HeadLookBridgeMath.computeLookSwipe(
            screenWidthPx = metrics.widthPixels,
            screenHeightPx = metrics.heightPixels,
            deltaYawDeg = accumulatedYawDeg,
            deltaPitchDeg = accumulatedPitchDeg,
            sensitivity = sensitivity,
            invertY = invertY
        ) ?: return

        accumulatedYawDeg = 0f
        accumulatedPitchDeg = 0f
        dispatchSwipe(segment, now)
    }

    fun sendDiagnosticTestSwipe(): Boolean {
        val metrics = resources.displayMetrics
        val segment = HeadLookBridgeMath.computeLookSwipe(
            screenWidthPx = metrics.widthPixels,
            screenHeightPx = metrics.heightPixels,
            deltaYawDeg = -8f,
            deltaPitchDeg = 0f,
            sensitivity = 1.0f,
            invertY = false
        ) ?: return false
        return dispatchSwipe(segment, System.currentTimeMillis())
    }

    private fun dispatchSwipe(segment: LookSwipeSegment, nowMs: Long): Boolean {
        val path = Path().apply {
            moveTo(segment.startX, segment.startY)
            lineTo(segment.endX, segment.endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, segment.durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        gestureInFlight = true
        lastDispatchTimeMs = nowMs

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureInFlight = false
                _snapshot.value = _snapshot.value.copy(
                    isServiceEnabled = true,
                    isDispatchingGestures = true,
                    gesturesDispatchedCount = _snapshot.value.gesturesDispatchedCount + 1,
                    lastGestureMs = System.currentTimeMillis(),
                    lastError = null
                )
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }
        }, null)

        if (!dispatched) {
            gestureInFlight = false
            _snapshot.value = _snapshot.value.copy(
                lastError = "Gesture rejected by OS"
            )
        }
        return dispatched
    }

    companion object {
        @Volatile
        var instance: MineVrAccessibilityService? = null
            private set

        private val _snapshot = MutableStateFlow(AccessibilityBridgeSnapshot())
        val snapshot: StateFlow<AccessibilityBridgeSnapshot> = _snapshot.asStateFlow()

        fun refreshSystemEnabledState(context: Context) {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            val expected = "${context.packageName}/${MineVrAccessibilityService::class.java.name}"
            val expectedShort = "${context.packageName}/.vr.bridge.MineVrAccessibilityService"
            val splitter = TextUtils.SimpleStringSplitter(':').apply { setString(enabledServices) }
            var found = false
            while (splitter.hasNext()) {
                val entry = splitter.next()
                if (entry.equals(expected, ignoreCase = true) || entry.equals(expectedShort, ignoreCase = true)) {
                    found = true
                    break
                }
            }
            _snapshot.value = _snapshot.value.copy(
                isServiceEnabled = found || instance != null
            )
        }
    }
}
