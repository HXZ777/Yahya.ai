package com.example.vr.engine

import android.opengl.GLES30

object MineVrShaders {

    fun createProgram(vsSource: String, fsSource: String): Int {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vsSource)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, src)
        GLES30.glCompileShader(shader)
        return shader
    }

    const val VOXEL_VS = """#version 300 es
        layout(location = 0) in vec3 aPos;
        layout(location = 1) in vec3 aNorm;
        layout(location = 2) in vec3 aColor;
        uniform mat4 uMvp;
        uniform mat4 uModel;
        out vec3 vNormal;
        out vec3 vColor;
        out vec3 vWorldPos;
        void main() {
            vec4 wp = uModel * vec4(aPos, 1.0);
            vWorldPos = wp.xyz;
            vNormal = normalize(mat3(uModel) * aNorm);
            vColor = aColor;
            gl_Position = uMvp * vec4(aPos, 1.0);
        }
    """

    const val VOXEL_FS = """#version 300 es
        precision mediump float;
        in vec3 vNormal;
        in vec3 vColor;
        in vec3 vWorldPos;
        uniform vec3 uSunDir;
        uniform vec3 uCamPos;
        uniform float uBrightness;
        out vec4 fragColor;
        void main() {
            vec3 n = normalize(vNormal);
            vec3 l = normalize(uSunDir);
            float diff = max(dot(n, l), 0.0);
            float ambient = 0.42 + 0.16 * max(n.y, 0.0);
            // Subtle voxel edge grid shading for crisp Minecraft block feel
            vec3 f = abs(fract(vWorldPos + 0.0005) - 0.5);
            float edge = step(0.475, max(max(f.x, f.y), f.z));
            vec3 base = mix(vColor, vColor * 0.86, edge * 0.45);
            vec3 lit = base * (ambient + diff * 0.68) * uBrightness;
            float dist = length(uCamPos - vWorldPos);
            float fog = 1.0 - exp(-dist * 0.022);
            vec3 sky = vec3(0.44, 0.72, 0.96) * uBrightness;
            fragColor = vec4(mix(lit, sky, clamp(fog, 0.0, 0.88)), 1.0);
        }
    """

    const val DISTORT_VS = """#version 300 es
        layout(location = 0) in vec2 aPos;
        layout(location = 1) in vec2 aUv;
        out vec2 vUv;
        void main() {
            vUv = aUv;
            gl_Position = vec4(aPos, 0.0, 1.0);
        }
    """

    // Post-processing Barrel Distortion for 2D FBO (used by True 3D Voxel VR)
    const val DISTORT_2D_FS = """#version 300 es
        precision mediump float;
        in vec2 vUv;
        uniform sampler2D uTex;
        uniform float uK1;
        uniform float uK2;
        uniform float uChromatic;
        uniform float uBrightness;
        uniform float uFlip;
        out vec4 fragColor;

        vec2 distort(vec2 centered, float k1, float k2) {
            float r2 = dot(centered, centered);
            return centered * (1.0 + k1 * r2 + k2 * r2 * r2);
        }

        void main() {
            vec2 baseUv = uFlip > 0.5 ? vec2(1.0 - vUv.x, 1.0 - vUv.y) : vUv;
            vec2 c = baseUv - vec2(0.5);
            vec2 uvR = distort(c, uK1 + uChromatic, uK2) + 0.5;
            vec2 uvG = distort(c, uK1, uK2) + 0.5;
            vec2 uvB = distort(c, uK1 - uChromatic, uK2) + 0.5;

            if (uvG.x < 0.0 || uvG.x > 1.0 || uvG.y < 0.0 || uvG.y > 1.0) {
                fragColor = vec4(0.0, 0.0, 0.0, 1.0);
                return;
            }

            float r = texture(uTex, clamp(uvR, 0.0, 1.0)).r;
            float g = texture(uTex, clamp(uvG, 0.0, 1.0)).g;
            float b = texture(uTex, clamp(uvB, 0.0, 1.0)).b;

            float vig = 1.0 - smoothstep(0.45, 0.56, length(c)) * 0.25;
            fragColor = vec4(vec3(r, g, b) * uBrightness * vig, 1.0);
        }
    """

    // Zero-copy GPU SurfaceTexture (GL_TEXTURE_EXTERNAL_OES) Barrel Distortion for MediaProjection
    const val DISTORT_OES_FS = """#version 300 es
        #extension GL_OES_EGL_image_external_essl3 : require
        precision mediump float;
        in vec2 vUv;
        uniform samplerExternalOES uExtTex;
        uniform mat4 uTexMatrix;
        uniform float uK1;
        uniform float uK2;
        uniform float uChromatic;
        uniform float uBrightness;
        uniform float uFlip;
        out vec4 fragColor;

        vec2 distort(vec2 centered, float k1, float k2) {
            float r2 = dot(centered, centered);
            return centered * (1.0 + k1 * r2 + k2 * r2 * r2);
        }

        void main() {
            vec2 baseUv = uFlip > 0.5 ? vec2(1.0 - vUv.x, 1.0 - vUv.y) : vUv;
            vec2 c = baseUv - vec2(0.5);
            vec2 uvR = distort(c, uK1 + uChromatic, uK2) + 0.5;
            vec2 uvG = distort(c, uK1, uK2) + 0.5;
            vec2 uvB = distort(c, uK1 - uChromatic, uK2) + 0.5;

            if (uvG.x < 0.0 || uvG.x > 1.0 || uvG.y < 0.0 || uvG.y > 1.0) {
                fragColor = vec4(0.0, 0.0, 0.0, 1.0);
                return;
            }

            vec2 tR = (uTexMatrix * vec4(clamp(uvR, 0.0, 1.0), 0.0, 1.0)).xy;
            vec2 tG = (uTexMatrix * vec4(clamp(uvG, 0.0, 1.0), 0.0, 1.0)).xy;
            vec2 tB = (uTexMatrix * vec4(clamp(uvB, 0.0, 1.0), 0.0, 1.0)).xy;

            float r = texture(uExtTex, tR).r;
            float g = texture(uExtTex, tG).g;
            float b = texture(uExtTex, tB).b;

            float vig = 1.0 - smoothstep(0.45, 0.56, length(c)) * 0.25;
            fragColor = vec4(vec3(r, g, b) * uBrightness * vig, 1.0);
        }
    """
}
