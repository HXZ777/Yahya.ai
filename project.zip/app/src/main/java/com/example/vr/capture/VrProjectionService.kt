package com.example.vr.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Surface
import android.view.WindowManager
import com.example.MainActivity
import com.example.R
import com.example.vr.model.ProjectionCaptureState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

class VrProjectionService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var targetSurface: Surface? = null
    private var captureWidth: Int = 1280
    private var captureHeight: Int = 720
    private var captureDensity: Int = 320

    private val mainHandler = Handler(Looper.getMainLooper())

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCaptureInternal()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }

        override fun onCapturedContentResize(width: Int, height: Int) {
            if (width < 2 || height < 2) return
            val (scaledW, scaledH) = scaleProportionalEven(width, height, maxDimension = 1920)
            if (scaledW != captureWidth || scaledH != captureHeight) {
                captureWidth = scaledW
                captureHeight = scaledH
                virtualDisplay?.resize(captureWidth, captureHeight, captureDensity)
                resizeListener?.invoke(captureWidth, captureHeight)
                _state.value = _state.value.copy(
                    captureWidth = captureWidth,
                    captureHeight = captureHeight
                )
            }
        }

        override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
            _state.value = _state.value.copy(isCapturedContentVisible = isVisible)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCaptureInternal()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val dataIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
                } else {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT)
                }
                if (resultCode != Activity.RESULT_OK || dataIntent == null) {
                    _state.value = _state.value.copy(
                        hasPermissionConsent = false,
                        isServiceRunning = false,
                        errorMessage = "Screen capture permission denied"
                    )
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForegroundCompat()
                startProjection(resultCode, dataIntent)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "MineVR Screen Projection",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle(getString(R.string.app_name))
            .setContentText("VR screen projection active locally")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startProjection(resultCode: Int, dataIntent: Intent) {
        stopCaptureInternal()
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = runCatching { mgr.getMediaProjection(resultCode, dataIntent) }.getOrNull()
        if (projection == null) {
            _state.value = _state.value.copy(
                hasPermissionConsent = false,
                isServiceRunning = false,
                errorMessage = "Unable to acquire MediaProjection"
            )
            stopSelf()
            return
        }

        val (rawW, rawH, dpi) = resolveDisplayMetrics()
        val (scaledW, scaledH) = scaleProportionalEven(
            width = maxOf(rawW, rawH),
            height = minOf(rawW, rawH),
            maxDimension = 1920
        )
        captureWidth = scaledW
        captureHeight = scaledH
        captureDensity = dpi

        projection.registerCallback(projectionCallback, mainHandler)
        mediaProjection = projection
        activeService = this

        resizeListener?.invoke(captureWidth, captureHeight)

        val surface = pendingSurface
        if (surface != null && surface.isValid) {
            attachSurfaceInternal(surface)
        }

        _state.value = _state.value.copy(
            hasPermissionConsent = true,
            isServiceRunning = true,
            isCapturedContentVisible = true,
            captureWidth = captureWidth,
            captureHeight = captureHeight,
            errorMessage = null
        )
    }

    private fun resolveDisplayMetrics(): Triple<Int, Int, Int> {
        val dm = resources.displayMetrics
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val bounds = wm.maximumWindowMetrics.bounds
            if (bounds.width() > 0 && bounds.height() > 0) {
                return Triple(bounds.width(), bounds.height(), dm.densityDpi)
            }
        }
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun attachSurfaceInternal(surface: Surface?) {
        targetSurface = surface
        virtualDisplay?.release()
        virtualDisplay = null
        if (surface == null || !surface.isValid) return
        val proj = mediaProjection ?: return
        virtualDisplay = runCatching {
            proj.createVirtualDisplay(
                "MineVR_VirtualDisplay",
                captureWidth,
                captureHeight,
                captureDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface,
                null,
                mainHandler
            )
        }.onFailure { err ->
            _state.value = _state.value.copy(errorMessage = err.message ?: "VirtualDisplay failed")
        }.getOrNull()
    }

    private fun stopCaptureInternal() {
        if (activeService === this) activeService = null
        virtualDisplay?.release()
        virtualDisplay = null
        runCatching { mediaProjection?.unregisterCallback(projectionCallback) }
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        targetSurface = null
        _state.value = ProjectionCaptureState()
    }

    override fun onDestroy() {
        stopCaptureInternal()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "minevr_projection_channel"
        private const val NOTIFICATION_ID = 4102
        const val ACTION_START = "com.example.vr.capture.START"
        const val ACTION_STOP = "com.example.vr.capture.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"

        @Volatile
        private var activeService: VrProjectionService? = null

        @Volatile
        private var pendingSurface: Surface? = null

        @Volatile
        private var resizeListener: ((Int, Int) -> Unit)? = null

        private val _state = MutableStateFlow(ProjectionCaptureState())
        val state: StateFlow<ProjectionCaptureState> = _state.asStateFlow()

        private var fpsWindowStartMs = 0L
        private var fpsCounter = 0

        fun setResizeListener(listener: ((Int, Int) -> Unit)?) {
            resizeListener = listener
            val st = _state.value
            if (st.captureWidth >= 2 && st.captureHeight >= 2) {
                listener?.invoke(st.captureWidth, st.captureHeight)
            }
        }

        fun attachRenderSurface(surface: Surface?) {
            pendingSurface = surface
            activeService?.attachSurfaceInternal(surface)
        }

        fun detachRenderSurface(surface: Surface?) {
            if (surface == null || pendingSurface === surface) {
                pendingSurface = null
                activeService?.attachSurfaceInternal(null)
            }
        }

        fun scaleProportionalEven(width: Int, height: Int, maxDimension: Int = 1920): Pair<Int, Int> {
            val w = width.coerceAtLeast(2)
            val h = height.coerceAtLeast(2)
            val longest = maxOf(w, h)
            val scale = if (longest > maxDimension) maxDimension.toFloat() / longest.toFloat() else 1f
            val outW = ((w * scale).roundToInt().coerceAtLeast(2)) and 1.inv()
            val outH = ((h * scale).roundToInt().coerceAtLeast(2)) and 1.inv()
            return outW.coerceAtLeast(2) to outH.coerceAtLeast(2)
        }

        fun reportCapturedFrame(isAppInForegroundFullscreen: Boolean) {
            val now = System.currentTimeMillis()
            if (fpsWindowStartMs == 0L) fpsWindowStartMs = now
            fpsCounter++
            var currentFps = _state.value.estimatedFps
            if (now - fpsWindowStartMs >= 1000L) {
                currentFps = fpsCounter
                fpsCounter = 0
                fpsWindowStartMs = now
            }
            _state.value = _state.value.copy(
                isReceivingFrames = true,
                frameCount = _state.value.frameCount + 1,
                estimatedFps = currentFps,
                isSelfMirrorWarning = isAppInForegroundFullscreen
            )
        }

        fun startService(context: Context, resultCode: Int, dataIntent: Intent) {
            val intent = Intent(context, VrProjectionService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA_INTENT, dataIntent)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, VrProjectionService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.startService(intent) }
        }
    }
}
