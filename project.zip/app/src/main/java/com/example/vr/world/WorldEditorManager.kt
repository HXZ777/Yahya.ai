package com.example.vr.world

import com.example.vr.model.ImportedMeshData
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.Transform3D
import com.example.vr.model.WorldLightingConfig
import com.example.vr.model.WorldNodeEntry
import com.example.vr.model.WorldObjectCategory
import com.example.vr.model.WorldProjectState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

enum class EditorTransformTool {
    MOVE,
    ROTATE,
    SCALE
}

data class WorldEditorUiState(
    val project: WorldProjectState? = null,
    val selectedNodeId: String? = null,
    val selectedSpawnId: String? = null,
    val wholeWorldSelected: Boolean = false,
    val activeTool: EditorTransformTool = EditorTransformTool.MOVE,
    val activeAxis: Int = -1, // -1=Free/XZ, 0=X, 1=Y, 2=Z
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusBannerEn: String? = null,
    val statusBannerAr: String? = null
)

class WorldEditorManager {

    private val _state = MutableStateFlow(WorldEditorUiState())
    val state: StateFlow<WorldEditorUiState> = _state.asStateFlow()

    private val undoStack = ArrayDeque<WorldProjectState>()
    private val redoStack = ArrayDeque<WorldProjectState>()

    fun openProject(project: WorldProjectState) {
        undoStack.clear()
        redoStack.clear()
        val firstNodeId = project.nodes.firstOrNull { !it.isGroup }?.id ?: project.nodes.firstOrNull()?.id
        _state.value = WorldEditorUiState(
            project = project,
            selectedNodeId = firstNodeId,
            selectedSpawnId = null,
            wholeWorldSelected = false,
            canUndo = false,
            canRedo = false
        )
    }

    fun setTool(tool: EditorTransformTool) {
        _state.value = _state.value.copy(activeTool = tool)
    }

    fun setAxis(axis: Int) {
        _state.value = _state.value.copy(activeAxis = axis)
    }

    fun selectWholeWorld() {
        _state.value = _state.value.copy(
            wholeWorldSelected = true,
            selectedNodeId = null,
            selectedSpawnId = null
        )
    }

    fun selectNode(nodeId: String) {
        _state.value = _state.value.copy(
            selectedNodeId = nodeId,
            selectedSpawnId = null,
            wholeWorldSelected = false
        )
    }

    fun selectSpawnPoint(spawnId: String) {
        _state.value = _state.value.copy(
            selectedSpawnId = spawnId,
            selectedNodeId = null,
            wholeWorldSelected = false
        )
    }

    fun applyTransformDelta(
        dx: Float = 0f,
        dy: Float = 0f,
        dz: Float = 0f,
        dRotX: Float = 0f,
        dRotY: Float = 0f,
        dRotZ: Float = 0f,
        dScaleAll: Float = 0f,
        recordUndo: Boolean = true
    ) {
        val cur = _state.value
        val proj = cur.project ?: return

        val spawnId = cur.selectedSpawnId
        if (spawnId != null) {
            val updatedSpawns = proj.spawnPoints.map { sp ->
                if (sp.id == spawnId) {
                    sp.copy(
                        x = sp.x + dx,
                        y = (sp.y + dy).coerceAtLeast(0f),
                        z = sp.z + dz,
                        yawDeg = (sp.yawDeg + dRotY) % 360f
                    )
                } else sp
            }
            commitProjectChange(proj.copy(spawnPoints = updatedSpawns), recordUndo)
            return
        }

        if (cur.wholeWorldSelected) {
            val wt = proj.worldTransform
            val sDelta = 1f + dScaleAll
            val updatedWt = wt.copy(
                posX = wt.posX + dx,
                posY = wt.posY + dy,
                posZ = wt.posZ + dz,
                rotX = (wt.rotX + dRotX) % 360f,
                rotY = (wt.rotY + dRotY) % 360f,
                rotZ = (wt.rotZ + dRotZ) % 360f,
                scaleX = (wt.scaleX * sDelta).coerceIn(0.05f, 15f),
                scaleY = (wt.scaleY * sDelta).coerceIn(0.05f, 15f),
                scaleZ = (wt.scaleZ * sDelta).coerceIn(0.05f, 15f)
            )
            commitProjectChange(proj.copy(worldTransform = updatedWt), recordUndo)
            return
        }

        val nodeId = cur.selectedNodeId ?: return
        val sDelta = 1f + dScaleAll
        val updatedNodes = proj.nodes.map { node ->
            if (node.id == nodeId) {
                val t = node.transform
                node.copy(
                    transform = t.copy(
                        posX = t.posX + dx,
                        posY = t.posY + dy,
                        posZ = t.posZ + dz,
                        rotX = (t.rotX + dRotX) % 360f,
                        rotY = (t.rotY + dRotY) % 360f,
                        rotZ = (t.rotZ + dRotZ) % 360f,
                        scaleX = (t.scaleX * sDelta).coerceIn(0.05f, 20f),
                        scaleY = (t.scaleY * sDelta).coerceIn(0.05f, 20f),
                        scaleZ = (t.scaleZ * sDelta).coerceIn(0.05f, 20f)
                    )
                )
            } else node
        }
        commitProjectChange(proj.copy(nodes = updatedNodes), recordUndo)
    }

    fun setWorldUniformScale(newScale: Float) {
        val proj = _state.value.project ?: return
        val clamped = newScale.coerceIn(0.1f, 10f)
        commitProjectChange(
            proj.copy(
                worldTransform = proj.worldTransform.copy(
                    scaleX = clamped,
                    scaleY = clamped,
                    scaleZ = clamped
                )
            )
        )
    }

    fun rotateQuick(degrees: Float) {
        applyTransformDelta(dRotY = degrees, recordUndo = true)
    }

    fun resetSelectedTransform() {
        val cur = _state.value
        val proj = cur.project ?: return
        when {
            cur.selectedSpawnId != null -> {
                val updated = proj.spawnPoints.map { sp ->
                    if (sp.id == cur.selectedSpawnId) sp.copy(x = 0f, y = 0f, z = 10f, yawDeg = 0f, elevationOffset = 0f) else sp
                }
                commitProjectChange(proj.copy(spawnPoints = updated))
            }
            cur.wholeWorldSelected -> {
                commitProjectChange(proj.copy(worldTransform = Transform3D()))
            }
            cur.selectedNodeId != null -> {
                val updated = proj.nodes.map { n ->
                    if (n.id == cur.selectedNodeId) n.copy(transform = Transform3D()) else n
                }
                commitProjectChange(proj.copy(nodes = updated))
            }
        }
    }

    fun duplicateSelectedNode() {
        val cur = _state.value
        val proj = cur.project ?: return
        val node = proj.nodes.find { it.id == cur.selectedNodeId } ?: return
        if (node.isGroup) return
        val newId = "node_copy_${UUID.randomUUID().toString().take(6)}"
        val copy = node.copy(
            id = newId,
            name = "${node.name} (Copy)",
            transform = node.transform.copy(posX = node.transform.posX + 2.2f)
        )
        commitProjectChange(proj.copy(nodes = proj.nodes + copy))
        _state.value = _state.value.copy(selectedNodeId = newId)
    }

    fun deleteSelected() {
        val cur = _state.value
        val proj = cur.project ?: return
        if (cur.selectedSpawnId != null && proj.spawnPoints.size > 1) {
            val remaining = proj.spawnPoints.filterNot { it.id == cur.selectedSpawnId }
            val fixedPrimary = if (remaining.none { it.isPrimary }) {
                remaining.mapIndexed { i, sp -> sp.copy(isPrimary = i == 0) }
            } else remaining
            commitProjectChange(proj.copy(spawnPoints = fixedPrimary))
            _state.value = _state.value.copy(selectedSpawnId = fixedPrimary.firstOrNull()?.id)
            return
        }
        val targetId = cur.selectedNodeId ?: return
        val remainingNodes = proj.nodes.filterNot { it.id == targetId || it.parentId == targetId }
        commitProjectChange(proj.copy(nodes = remainingNodes))
        _state.value = _state.value.copy(selectedNodeId = remainingNodes.firstOrNull()?.id)
    }

    fun moveNodeOrder(nodeId: String, direction: Int) {
        val proj = _state.value.project ?: return
        val list = proj.nodes.toMutableList()
        val idx = list.indexOfFirst { it.id == nodeId }
        if (idx < 0) return
        val targetIdx = (idx + direction).coerceIn(0, list.lastIndex)
        if (targetIdx == idx) return
        val item = list.removeAt(idx)
        list.add(targetIdx, item)
        commitProjectChange(proj.copy(nodes = list))
    }

    fun renameNode(nodeId: String, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return
        val proj = _state.value.project ?: return
        val updated = proj.nodes.map { if (it.id == nodeId) it.copy(name = trimmed) else it }
        commitProjectChange(proj.copy(nodes = updated))
    }

    fun toggleNodeVisibility(nodeId: String) {
        val proj = _state.value.project ?: return
        val updated = proj.nodes.map { if (it.id == nodeId) it.copy(visible = !it.visible) else it }
        commitProjectChange(proj.copy(nodes = updated))
    }

    fun toggleNodeCollision(nodeId: String) {
        val proj = _state.value.project ?: return
        val updated = proj.nodes.map { if (it.id == nodeId) it.copy(collisionEnabled = !it.collisionEnabled) else it }
        commitProjectChange(proj.copy(nodes = updated))
    }

    fun createGroupAndAssign(groupName: String, memberNodeIds: List<String>) {
        val proj = _state.value.project ?: return
        val gid = "group_${UUID.randomUUID().toString().take(6)}"
        val groupNode = WorldNodeEntry(
            id = gid,
            name = groupName.trim().ifEmpty { "Group" },
            category = WorldObjectCategory.GROUP,
            isGroup = true
        )
        val updatedNodes = proj.nodes.map { n ->
            if (n.id in memberNodeIds && !n.isGroup) n.copy(parentId = gid) else n
        } + groupNode
        commitProjectChange(proj.copy(nodes = updatedNodes))
        _state.value = _state.value.copy(selectedNodeId = gid, selectedSpawnId = null, wholeWorldSelected = false)
    }

    fun assignNodeToGroup(nodeId: String, groupId: String?) {
        val proj = _state.value.project ?: return
        val updated = proj.nodes.map { n ->
            if (n.id == nodeId && !n.isGroup) n.copy(parentId = groupId) else n
        }
        commitProjectChange(proj.copy(nodes = updated))
    }

    fun addImportedModelNode(nodeName: String, assetPath: String, mesh: ImportedMeshData) {
        val proj = _state.value.project ?: return
        val newId = "prop_${UUID.randomUUID().toString().take(6)}"
        val newNode = WorldNodeEntry(
            id = newId,
            name = nodeName,
            category = WorldObjectCategory.IMPORTED_MODELS,
            assetPath = assetPath,
            subMeshStartIdx = 0,
            subMeshEndIdx = mesh.subMeshes.lastIndex.coerceAtLeast(0),
            transform = Transform3D(posX = 0f, posY = 0f, posZ = 2f, scaleX = 0.35f, scaleY = 0.35f, scaleZ = 0.35f),
            localMinX = mesh.boundsMin.getOrElse(0) { -1f },
            localMinY = mesh.boundsMin.getOrElse(1) { 0f },
            localMinZ = mesh.boundsMin.getOrElse(2) { -1f },
            localMaxX = mesh.boundsMax.getOrElse(0) { 1f },
            localMaxY = mesh.boundsMax.getOrElse(1) { 2f },
            localMaxZ = mesh.boundsMax.getOrElse(2) { 1f }
        )
        commitProjectChange(proj.copy(nodes = proj.nodes + newNode))
        _state.value = _state.value.copy(
            selectedNodeId = newId,
            selectedSpawnId = null,
            wholeWorldSelected = false,
            statusBannerEn = "Added '$nodeName' to world!",
            statusBannerAr = "تمت إضافة '$nodeName' إلى العالم!"
        )
    }

    fun addSpawnPoint(name: String = "Spawn ${(_state.value.project?.spawnPoints?.size ?: 0) + 1}") {
        val proj = _state.value.project ?: return
        val id = "spawn_${UUID.randomUUID().toString().take(6)}"
        val sp = SpawnPointEntry(
            id = id,
            name = name,
            x = (proj.spawnPoints.size * 1.5f),
            y = 0f,
            z = 8f,
            yawDeg = 0f,
            elevationOffset = 0f,
            isPrimary = proj.spawnPoints.isEmpty()
        )
        commitProjectChange(proj.copy(spawnPoints = proj.spawnPoints + sp))
        _state.value = _state.value.copy(selectedSpawnId = id, selectedNodeId = null, wholeWorldSelected = false)
    }

    fun setPrimarySpawn(spawnId: String) {
        val proj = _state.value.project ?: return
        val updated = proj.spawnPoints.map { it.copy(isPrimary = it.id == spawnId) }
        commitProjectChange(proj.copy(spawnPoints = updated))
    }

    fun updateSpawnElevation(spawnId: String, elevationOffset: Float) {
        val proj = _state.value.project ?: return
        val updated = proj.spawnPoints.map {
            if (it.id == spawnId) it.copy(elevationOffset = elevationOffset.coerceIn(0f, 30f)) else it
        }
        commitProjectChange(proj.copy(spawnPoints = updated))
    }

    fun updateMaterial(updatedMat: PbrMaterialSpec) {
        val proj = _state.value.project ?: return
        val marked = updatedMat.copy(userModified = true)
        val newMaterials = proj.materials.map { if (it.id == marked.id) marked else it }
        val newNodes = proj.nodes.map { n ->
            if (n.materialOverrides.containsKey(marked.id)) {
                n.copy(materialOverrides = n.materialOverrides + (marked.id to marked))
            } else n
        }
        commitProjectChange(proj.copy(materials = newMaterials, nodes = newNodes))
    }

    fun updateLighting(lighting: WorldLightingConfig) {
        val proj = _state.value.project ?: return
        commitProjectChange(proj.copy(lighting = lighting))
    }

    fun setWorldCollisionEnabled(enabled: Boolean) {
        val proj = _state.value.project ?: return
        commitProjectChange(proj.copy(collisionEnabled = enabled))
    }

    fun undo() {
        val curProj = _state.value.project ?: return
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(curProj)
        _state.value = _state.value.copy(
            project = prev,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    fun redo() {
        val curProj = _state.value.project ?: return
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(curProj)
        _state.value = _state.value.copy(
            project = next,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    fun replaceProjectStateFromRestore(restored: WorldProjectState) {
        undoStack.clear()
        redoStack.clear()
        _state.value = _state.value.copy(
            project = restored,
            selectedNodeId = restored.nodes.firstOrNull()?.id,
            selectedSpawnId = null,
            wholeWorldSelected = false,
            canUndo = false,
            canRedo = false,
            statusBannerEn = "Original world restored!",
            statusBannerAr = "تمت استعادة العالم الأصلي!"
        )
    }

    fun clearBanner() {
        _state.value = _state.value.copy(statusBannerEn = null, statusBannerAr = null)
    }

    private fun commitProjectChange(next: WorldProjectState, recordUndo: Boolean = true) {
        val prev = _state.value.project
        if (recordUndo && prev != null && prev != next) {
            if (undoStack.size >= 35) undoStack.removeFirst()
            undoStack.addLast(prev)
            redoStack.clear()
        }
        _state.value = _state.value.copy(
            project = next,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }
}
