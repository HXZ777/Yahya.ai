package com.example.vr.input

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.vr.model.HandGesture
import com.example.vr.model.HandLandmarkPoint
import com.example.vr.model.HandTrackingHealth
import com.example.vr.model.HandTrackingState
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot

class HandTrackingManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val httpClient = OkHttpClient()

    private val _state = MutableStateFlow(HandTrackingState(modelDownloaded = modelFile().exists()))
    val state: StateFlow<HandTrackingState> = _state.asStateFlow()

    private var handLandmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var darkFrameStreak = 0
    private var prevIndexZ = 0f
    private var prevPalmScale = 0f
    private var sensitivity = 0.72f
    private var isRunning = false
    private var autoDownloadAttempted = false

    // Optical-motion + skin-centroid fallback buffer when MediaPipe .task isn't downloaded yet
    private var prevGrid: FloatArray? = null
    private var smoothedLandmarks: List<HandLandmarkPoint> = emptyList()
    private var smoothPtrX = 0.55f
    private var smoothPtrY = 0.62f

    companion object {
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
        private const val MODEL_FILE_NAME = "hand_landmarker.task"
    }

    fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun modelFile(): File {
        val dir = File(context.filesDir, "models").apply { mkdirs() }
        return File(dir, MODEL_FILE_NAME)
    }

    fun updateSensitivity(value: Float) {
        sensitivity = value.coerceIn(0.3f, 1.0f)
    }

    fun downloadHandModel() {
        if (_state.value.modelDownloadProgress != null) return
        scope.launch {
            _state.value = _state.value.copy(
                modelDownloadProgress = 0.05f,
                statusNoteEn = "Downloading MediaPipe Hand Landmarker...",
                statusNoteAr = "جاري تنزيل نموذج تتبع اليد MediaPipe..."
            )
            try {
                val req = Request.Builder().url(MODEL_URL).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                    val body = resp.body ?: throw IllegalStateException("Empty body")
                    val total = body.contentLength().coerceAtLeast(1L)
                    val tmpFile = File(modelFile().parentFile, "$MODEL_FILE_NAME.tmp")
                    body.byteStream().use { input ->
                        FileOutputStream(tmpFile).use { output ->
                            val buf = ByteArray(16384)
                            var copied = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                output.write(buf, 0, n)
                                copied += n
                                _state.value = _state.value.copy(
                                    modelDownloadProgress = (copied.toFloat() / total).coerceIn(0.05f, 0.99f)
                                )
                            }
                        }
                    }
                    if (tmpFile.exists() && tmpFile.length() > 100_000L) {
                        tmpFile.renameTo(modelFile())
                    }
                }
                initLandmarkerIfNeeded()
                _state.value = _state.value.copy(
                    modelDownloaded = modelFile().exists(),
                    modelDownloadProgress = null,
                    statusNoteEn = "MediaPipe Hand Landmarker ready",
                    statusNoteAr = "نموذج تتبع اليد MediaPipe جاهز"
                )
            } catch (t: Throwable) {
                _state.value = _state.value.copy(
                    modelDownloadProgress = null,
                    statusNoteEn = "Optical hand tracker active (MediaPipe offline: ${t.message ?: "No net"})",
                    statusNoteAr = "التتبع البصري لليد نشط (تعذر تنزيل MediaPipe لعدم توفر اتصال)"
                )
            }
        }
    }

    private fun initLandmarkerIfNeeded() {
        if (handLandmarker != null) return
        val file = modelFile()
        if (!file.exists()) return
        runCatching {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(file.absolutePath)
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.40f)
                .setMinHandPresenceConfidence(0.40f)
                .setMinTrackingConfidence(0.40f)
                .build()
            handLandmarker = HandLandmarker.createFromOptions(context, options)
        }
    }

    fun startCameraTracking(
        lifecycleOwner: LifecycleOwner,
        useFrontCamera: Boolean,
        previewView: PreviewView? = null
    ) {
        if (!hasCameraPermission()) {
            _state.value = _state.value.copy(
                health = HandTrackingHealth.PERMISSION_REQUIRED,
                statusNoteEn = "Camera permission is required for hand tracking.",
                statusNoteAr = "يجب منح إذن الكاميرا لتشغيل تتبع اليد."
            )
            return
        }
        initLandmarkerIfNeeded()
        if (handLandmarker == null && !autoDownloadAttempted) {
            autoDownloadAttempted = true
            downloadHandModel()
        }
        isRunning = true
        darkFrameStreak = 0
        val initialHand = synthesize21HandLandmarks(smoothPtrX, smoothPtrY, HandGesture.OPEN_HAND)
        smoothedLandmarks = initialHand
        _state.value = _state.value.copy(
            health = HandTrackingHealth.TRACKING_ACTIVE,
            gesture = HandGesture.OPEN_HAND,
            landmarks = initialHand
        )

        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (!isRunning) return@addListener
            val provider = runCatching { future.get() }.getOrNull() ?: return@addListener
            cameraProvider = provider
            provider.unbindAll()

            val selector = if (useFrontCamera) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(analysisExecutor) { proxy ->
                analyzeFrame(proxy, useFrontCamera)
            }

            runCatching {
                if (previewView != null) {
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    provider.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
                } else {
                    provider.bindToLifecycle(lifecycleOwner, selector, analysis)
                }
            }.onFailure { err ->
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.VR_BOX_OCCLUDED,
                    statusNoteEn = "Camera unavailable on this device (${err.message}). Switch to Gaze or Xbox.",
                    statusNoteAr = "الكاميرا غير متاحة حالياً. يمكنك التبديل للتحكم بالنظر أو يد Xbox."
                )
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stopCameraTracking() {
        isRunning = false
        runCatching { cameraProvider?.unbindAll() }
        smoothedLandmarks = emptyList()
        _state.value = _state.value.copy(
            health = HandTrackingHealth.INACTIVE,
            gesture = HandGesture.NONE,
            landmarks = emptyList()
        )
    }

    private fun analyzeFrame(proxy: ImageProxy, isFrontCamera: Boolean) {
        try {
            val bitmap = proxy.toBitmap()
            val avgLuma = sampleAverageLuminance(bitmap)

            if (avgLuma < 12f) {
                darkFrameStreak++
            } else {
                darkFrameStreak = 0
            }

            if (darkFrameStreak >= 14) {
                smoothedLandmarks = emptyList()
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.VR_BOX_OCCLUDED,
                    averageLuma = avgLuma,
                    gesture = HandGesture.NONE,
                    landmarks = emptyList(),
                    statusNoteEn = "Camera blocked inside VR Box cover. Switch to Gaze or Xbox.",
                    statusNoteAr = "عدسة الكاميرا محجوبة داخل غطاء VR Box. بدّل للتحكم بالنظر أو يد Xbox."
                )
                bitmap.recycle()
                return
            }

            val rotation = proxy.imageInfo.rotationDegrees
            val matrix = Matrix().apply {
                if (rotation != 0) postRotate(rotation.toFloat())
                if (isFrontCamera) postScale(-1f, 1f)
            }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, false)
            if (rotated !== bitmap) bitmap.recycle()

            val landmarker = handLandmarker
            if (landmarker == null) {
                // Optical motion + skin centroid fallback so the 3D hand ALWAYS responds visibly even before model download!
                val (cx, cy, activeMotion) = trackOpticalHandFallback(rotated)
                rotated.recycle()

                smoothPtrX += (cx - smoothPtrX) * 0.42f
                smoothPtrY += (cy - smoothPtrY) * 0.42f
                val gesture = if (activeMotion > 0.08f) HandGesture.OPEN_HAND else HandGesture.POINT_INDEX
                val synth = synthesize21HandLandmarks(smoothPtrX, smoothPtrY, gesture)
                smoothedLandmarks = synth

                _state.value = _state.value.copy(
                    health = HandTrackingHealth.TRACKING_ACTIVE,
                    averageLuma = avgLuma,
                    gesture = gesture,
                    pointerX = smoothPtrX,
                    pointerY = smoothPtrY,
                    landmarks = synth,
                    statusNoteEn = "Optical hand tracking active (move hand in front of camera)",
                    statusNoteAr = "التتبع البصري لليد نشط (حرّك يدك أمام الكاميرا)"
                )
                return
            }

            val mpImage = BitmapImageBuilder(rotated).build()
            val result: HandLandmarkerResult = landmarker.detectForVideo(mpImage, SystemClock.uptimeMillis())
            rotated.recycle()

            val handList = result.landmarks()
            if (handList.isEmpty()) {
                // Keep a soft idle resting hand visible when tracking is on so player sees virtual hand ready
                val idleHand = synthesize21HandLandmarks(0.66f, 0.72f, HandGesture.OPEN_HAND)
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.NO_HAND_VISIBLE,
                    averageLuma = avgLuma,
                    gesture = HandGesture.NONE,
                    landmarks = idleHand,
                    statusNoteEn = "Camera ready — hold your hand in front of the lens",
                    statusNoteAr = "الكاميرا جاهزة — ضع يدك أمام العدسة للتحكم"
                )
                return
            }

            val rawLm = handList[0].map { HandLandmarkPoint(it.x(), it.y(), it.z()) }
            val lm = smoothLandmarkList(rawLm)
            val gesture = classifyGesture(lm)
            val indexTip = lm[8]

            _state.value = _state.value.copy(
                health = HandTrackingHealth.TRACKING_ACTIVE,
                averageLuma = avgLuma,
                gesture = gesture,
                pointerX = indexTip.x.coerceIn(0f, 1f),
                pointerY = indexTip.y.coerceIn(0f, 1f),
                landmarks = lm,
                statusNoteEn = "MediaPipe hand tracked: $gesture",
                statusNoteAr = "تم رصد اليد بـ MediaPipe: $gesture"
            )
        } catch (_: Throwable) {
            // Keep analyzer resilient
        } finally {
            proxy.close()
        }
    }

    private fun smoothLandmarkList(raw: List<HandLandmarkPoint>): List<HandLandmarkPoint> {
        if (smoothedLandmarks.size != raw.size) {
            smoothedLandmarks = raw
            return raw
        }
        val blended = raw.mapIndexed { i, p ->
            val prev = smoothedLandmarks[i]
            HandLandmarkPoint(
                x = prev.x + (p.x - prev.x) * 0.55f,
                y = prev.y + (p.y - prev.y) * 0.55f,
                z = prev.z + (p.z - prev.z) * 0.55f
            )
        }
        smoothedLandmarks = blended
        return blended
    }

    private fun trackOpticalHandFallback(bmp: Bitmap): Triple<Float, Float, Float> {
        val cols = 16
        val rows = 12
        val grid = FloatArray(cols * rows)
        val w = bmp.width
        val h = bmp.height

        var skinSumX = 0f
        var skinSumY = 0f
        var skinWeight = 0f
        var motionSumX = 0f
        var motionSumY = 0f
        var motionWeight = 0f

        val prev = prevGrid
        for (ry in 0 until rows) {
            val py = ((ry + 0.5f) * h / rows).toInt().coerceIn(0, h - 1)
            for (rx in 0 until cols) {
                val px = ((rx + 0.5f) * w / cols).toInt().coerceIn(0, w - 1)
                val c = bmp.getPixel(px, py)
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val luma = (299 * r + 587 * g + 114 * b) / 1000f
                val idx = ry * cols + rx
                grid[idx] = luma

                val nx = (rx + 0.5f) / cols
                val ny = (ry + 0.5f) / rows

                // Simple skin-tone heuristic
                if (r > 70 && g > 40 && b > 20 && r > g && r > b && (r - g) > 12) {
                    skinSumX += nx
                    skinSumY += ny
                    skinWeight += 1f
                }
                if (prev != null) {
                    val diff = abs(luma - prev[idx]) / 255f
                    if (diff > 0.06f) {
                        motionSumX += nx * diff
                        motionSumY += ny * diff
                        motionWeight += diff
                    }
                }
            }
        }
        prevGrid = grid

        return when {
            motionWeight > 0.06f -> Triple(
                (motionSumX / motionWeight).coerceIn(0.15f, 0.85f),
                (motionSumY / motionWeight).coerceIn(0.15f, 0.85f),
                motionWeight
            )
            skinWeight >= 4f -> Triple(
                (skinSumX / skinWeight).coerceIn(0.15f, 0.85f),
                (skinSumY / skinWeight).coerceIn(0.15f, 0.85f),
                0.04f
            )
            else -> Triple(smoothPtrX, smoothPtrY, 0f)
        }
    }

    private fun synthesize21HandLandmarks(cx: Float, cy: Float, gesture: HandGesture): List<HandLandmarkPoint> {
        val curl = if (gesture == HandGesture.FIST) 0.45f else 1.0f
        val wrist = HandLandmarkPoint(cx, cy + 0.14f, 0f)
        val thumb = listOf(
            HandLandmarkPoint(cx - 0.04f, cy + 0.10f, -0.01f),
            HandLandmarkPoint(cx - 0.07f, cy + 0.06f, -0.02f),
            HandLandmarkPoint(cx - 0.10f, cy + 0.02f, -0.03f),
            HandLandmarkPoint(cx - 0.12f, cy - 0.02f * curl, -0.04f)
        )
        fun finger(xOff: Float, len: Float, fCurl: Float): List<HandLandmarkPoint> {
            val mcpY = cy + 0.02f
            return listOf(
                HandLandmarkPoint(cx + xOff, mcpY, -0.01f),
                HandLandmarkPoint(cx + xOff * 1.05f, mcpY - len * 0.35f * fCurl, -0.02f),
                HandLandmarkPoint(cx + xOff * 1.08f, mcpY - len * 0.70f * fCurl, -0.03f),
                HandLandmarkPoint(cx + xOff * 1.10f, mcpY - len * fCurl, -0.04f)
            )
        }
        val index = finger(-0.045f, 0.16f, 1.0f)
        val middle = finger(-0.012f, 0.18f, curl)
        val ring = finger(0.022f, 0.165f, curl)
        val pinky = finger(0.055f, 0.135f, curl)
        return listOf(wrist) + thumb + index + middle + ring + pinky
    }

    private fun classifyGesture(lm: List<HandLandmarkPoint>): HandGesture {
        if (lm.size < 21) return HandGesture.NONE
        val wrist = lm[0]
        val thumbTip = lm[4]
        val indexMcp = lm[5]
        val indexPip = lm[6]
        val indexTip = lm[8]
        val middlePip = lm[10]
        val middleTip = lm[12]
        val ringPip = lm[14]
        val ringTip = lm[16]
        val pinkyPip = lm[18]
        val pinkyTip = lm[20]

        val palmScale = hypot((indexMcp.x - wrist.x).toDouble(), (indexMcp.y - wrist.y).toDouble())
            .toFloat().coerceAtLeast(0.05f)

        fun isExtended(tip: HandLandmarkPoint, pip: HandLandmarkPoint): Boolean {
            val tipDist = hypot((tip.x - wrist.x).toDouble(), (tip.y - wrist.y).toDouble())
            val pipDist = hypot((pip.x - wrist.x).toDouble(), (pip.y - wrist.y).toDouble())
            return tipDist > pipDist * (1.06 - (1f - sensitivity) * 0.12)
        }

        val indexExt = isExtended(indexTip, indexPip)
        val middleExt = isExtended(middleTip, middlePip)
        val ringExt = isExtended(ringTip, ringPip)
        val pinkyExt = isExtended(pinkyTip, pinkyPip)

        val pinchDist = hypot((thumbTip.x - indexTip.x).toDouble(), (thumbTip.y - indexTip.y).toDouble()).toFloat()
        val pinchRatio = pinchDist / palmScale

        val deltaZ = prevIndexZ - indexTip.z
        val scaleGrowth = palmScale - prevPalmScale
        prevIndexZ = indexTip.z
        prevPalmScale = palmScale

        return when {
            pinchRatio < 0.42f * (1.15f - sensitivity * 0.25f) && middleExt -> HandGesture.PINCH_SELECT
            !indexExt && !middleExt && !ringExt && !pinkyExt -> HandGesture.FIST
            indexExt && !middleExt && !ringExt && !pinkyExt -> {
                if (deltaZ > 0.035f) HandGesture.INDEX_PRESS else HandGesture.POINT_INDEX
            }
            indexExt && middleExt && ringExt && pinkyExt -> {
                if (scaleGrowth > 0.025f) HandGesture.PUSH_FORWARD else HandGesture.OPEN_HAND
            }
            else -> HandGesture.OPEN_HAND
        }
    }

    private fun sampleAverageLuminance(bitmap: Bitmap): Float {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return 0f
        var sum = 0L
        var count = 0
        val stepX = (w / 12).coerceAtLeast(1)
        val stepY = (h / 12).coerceAtLeast(1)
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val px = bitmap.getPixel(x, y)
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                sum += ((299 * r + 587 * g + 114 * b) / 1000)
                count++
                x += stepX
            }
            y += stepY
        }
        return if (count == 0) 0f else sum.toFloat() / count
    }

    fun release() {
        stopCameraTracking()
        runCatching { handLandmarker?.close() }
        handLandmarker = null
        analysisExecutor.shutdownNow()
    }
}
