package com.example.vr.input

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.vr.model.HandGesture
import com.example.vr.model.HandLandmarkPoint
import com.example.vr.model.HandTrackingHealth
import com.example.vr.model.HandTrackingState
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.hypot

class HandTrackingManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val httpClient = OkHttpClient()

    private val _state = MutableStateFlow(HandTrackingState(modelDownloaded = modelFile().exists()))
    val state: StateFlow<HandTrackingState> = _state.asStateFlow()

    private var handLandmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var darkFrameStreak = 0
    private var prevIndexZ = 0f
    private var prevPalmScale = 0f
    private var sensitivity = 0.72f
    private var isRunning = false

    companion object {
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
        private const val MODEL_FILE_NAME = "hand_landmarker.task"
    }

    fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun modelFile(): File {
        val dir = File(context.filesDir, "models").apply { mkdirs() }
        return File(dir, MODEL_FILE_NAME)
    }

    fun updateSensitivity(value: Float) {
        sensitivity = value.coerceIn(0.3f, 1.0f)
    }

    fun downloadHandModel() {
        if (_state.value.modelDownloadProgress != null) return
        scope.launch {
            _state.value = _state.value.copy(
                modelDownloadProgress = 0.05f,
                statusNoteEn = "Downloading MediaPipe Hand Landmarker...",
                statusNoteAr = "جاري تنزيل نموذج تتبع اليد MediaPipe..."
            )
            try {
                val req = Request.Builder().url(MODEL_URL).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                    val body = resp.body ?: throw IllegalStateException("Empty body")
                    val total = body.contentLength().coerceAtLeast(1L)
                    val tmpFile = File(modelFile().parentFile, "$MODEL_FILE_NAME.tmp")
                    body.byteStream().use { input ->
                        FileOutputStream(tmpFile).use { output ->
                            val buf = ByteArray(16384)
                            var copied = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                output.write(buf, 0, n)
                                copied += n
                                _state.value = _state.value.copy(
                                    modelDownloadProgress = (copied.toFloat() / total).coerceIn(0.05f, 0.99f)
                                )
                            }
                        }
                    }
                    if (tmpFile.exists() && tmpFile.length() > 100_000L) {
                        tmpFile.renameTo(modelFile())
                    }
                }
                initLandmarkerIfNeeded()
                _state.value = _state.value.copy(
                    modelDownloaded = modelFile().exists(),
                    modelDownloadProgress = null,
                    statusNoteEn = "Hand Landmarker model ready",
                    statusNoteAr = "نموذج تتبع اليد جاهز للعمل"
                )
            } catch (t: Throwable) {
                _state.value = _state.value.copy(
                    modelDownloadProgress = null,
                    statusNoteEn = "Model download failed (${t.message ?: "Offline"}). Check internet.",
                    statusNoteAr = "فشل تنزيل النموذج (${t.message ?: "لا يوجد اتصال"}). تحقق من الإنترنت."
                )
            }
        }
    }

    private fun initLandmarkerIfNeeded() {
        if (handLandmarker != null) return
        val file = modelFile()
        if (!file.exists()) return
        runCatching {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(file.absolutePath)
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.45f)
                .setMinHandPresenceConfidence(0.45f)
                .setMinTrackingConfidence(0.45f)
                .build()
            handLandmarker = HandLandmarker.createFromOptions(context, options)
        }
    }

    fun startCameraTracking(
        lifecycleOwner: LifecycleOwner,
        useFrontCamera: Boolean,
        previewView: PreviewView? = null
    ) {
        if (!hasCameraPermission()) {
            _state.value = _state.value.copy(
                health = HandTrackingHealth.PERMISSION_REQUIRED,
                statusNoteEn = "Camera permission is required for hand tracking.",
                statusNoteAr = "يجب منح إذن الكاميرا لتشغيل تتبع اليد."
            )
            return
        }
        initLandmarkerIfNeeded()
        isRunning = true
        darkFrameStreak = 0

        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (!isRunning) return@addListener
            val provider = runCatching { future.get() }.getOrNull() ?: return@addListener
            cameraProvider = provider
            provider.unbindAll()

            val selector = if (useFrontCamera) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(analysisExecutor) { proxy ->
                analyzeFrame(proxy, useFrontCamera)
            }

            runCatching {
                if (previewView != null) {
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    provider.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
                } else {
                    provider.bindToLifecycle(lifecycleOwner, selector, analysis)
                }
            }.onFailure { err ->
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.VR_BOX_OCCLUDED,
                    statusNoteEn = "Camera unavailable on this device (${err.message}). Switch to Gaze or Xbox.",
                    statusNoteAr = "الكاميرا غير متاحة حالياً. يمكنك التبديل للتحكم بالنظر أو يد Xbox."
                )
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stopCameraTracking() {
        isRunning = false
        runCatching { cameraProvider?.unbindAll() }
        _state.value = _state.value.copy(
            health = HandTrackingHealth.INACTIVE,
            gesture = HandGesture.NONE,
            landmarks = emptyList()
        )
    }

    private fun analyzeFrame(proxy: ImageProxy, isFrontCamera: Boolean) {
        try {
            val bitmap = proxy.toBitmap()
            val avgLuma = sampleAverageLuminance(bitmap)

            if (avgLuma < 14f) {
                darkFrameStreak++
            } else {
                darkFrameStreak = 0
            }

            if (darkFrameStreak >= 12) {
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.VR_BOX_OCCLUDED,
                    averageLuma = avgLuma,
                    gesture = HandGesture.NONE,
                    landmarks = emptyList(),
                    statusNoteEn = "Camera view is dark/blocked (phone inside VR Box cover). Switch to Gaze or Xbox.",
                    statusNoteAr = "عدسة الكاميرا محجوبة داخل نظارة VR Box. بدّل للتحكم بالنظر أو يد Xbox."
                )
                bitmap.recycle()
                return
            }

            val landmarker = handLandmarker
            if (landmarker == null) {
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.MODEL_MISSING,
                    averageLuma = avgLuma,
                    modelDownloaded = false,
                    statusNoteEn = "Camera clear (luma ${avgLuma.toInt()}). Download MediaPipe Hand Model in Controls.",
                    statusNoteAr = "الكاميرا واضحة (إضاءة ${avgLuma.toInt()}). قم بتنزيل نموذج MediaPipe من الإعدادات."
                )
                bitmap.recycle()
                return
            }

            val rotation = proxy.imageInfo.rotationDegrees
            val matrix = Matrix().apply {
                if (rotation != 0) postRotate(rotation.toFloat())
                if (isFrontCamera) postScale(-1f, 1f)
            }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, false)
            if (rotated !== bitmap) bitmap.recycle()

            val mpImage = BitmapImageBuilder(rotated).build()
            val result: HandLandmarkerResult = landmarker.detectForVideo(mpImage, SystemClock.uptimeMillis())
            rotated.recycle()

            val handList = result.landmarks()
            if (handList.isEmpty()) {
                _state.value = _state.value.copy(
                    health = HandTrackingHealth.NO_HAND_VISIBLE,
                    averageLuma = avgLuma,
                    gesture = HandGesture.NONE,
                    landmarks = emptyList(),
                    statusNoteEn = "Camera clear — hold hand in view of the lens.",
                    statusNoteAr = "الكاميرا تعمل — ضع يدك أمام العدسة."
                )
                return
            }

            val lm = handList[0].map { HandLandmarkPoint(it.x(), it.y(), it.z()) }
            val gesture = classifyGesture(lm)
            val indexTip = lm[8]

            _state.value = _state.value.copy(
                health = HandTrackingHealth.TRACKING_ACTIVE,
                averageLuma = avgLuma,
                gesture = gesture,
                pointerX = indexTip.x.coerceIn(0f, 1f),
                pointerY = indexTip.y.coerceIn(0f, 1f),
                landmarks = lm,
                statusNoteEn = "Hand tracked: $gesture",
                statusNoteAr = "تم رصد اليد: $gesture"
            )
        } catch (_: Throwable) {
            // Keep analyzer resilient
        } finally {
            proxy.close()
        }
    }

    private fun classifyGesture(lm: List<HandLandmarkPoint>): HandGesture {
        if (lm.size < 21) return HandGesture.NONE
        val wrist = lm[0]
        val thumbTip = lm[4]
        val indexMcp = lm[5]
        val indexPip = lm[6]
        val indexTip = lm[8]
        val middlePip = lm[10]
        val middleTip = lm[12]
        val ringPip = lm[14]
        val ringTip = lm[16]
        val pinkyPip = lm[18]
        val pinkyTip = lm[20]

        val palmScale = hypot((indexMcp.x - wrist.x).toDouble(), (indexMcp.y - wrist.y).toDouble())
            .toFloat().coerceAtLeast(0.05f)

        fun isExtended(tip: HandLandmarkPoint, pip: HandLandmarkPoint): Boolean {
            val tipDist = hypot((tip.x - wrist.x).toDouble(), (tip.y - wrist.y).toDouble())
            val pipDist = hypot((pip.x - wrist.x).toDouble(), (pip.y - wrist.y).toDouble())
            return tipDist > pipDist * (1.06 - (1f - sensitivity) * 0.12)
        }

        val indexExt = isExtended(indexTip, indexPip)
        val middleExt = isExtended(middleTip, middlePip)
        val ringExt = isExtended(ringTip, ringPip)
        val pinkyExt = isExtended(pinkyTip, pinkyPip)

        val pinchDist = hypot((thumbTip.x - indexTip.x).toDouble(), (thumbTip.y - indexTip.y).toDouble()).toFloat()
        val pinchRatio = pinchDist / palmScale

        val deltaZ = prevIndexZ - indexTip.z
        val scaleGrowth = palmScale - prevPalmScale
        prevIndexZ = indexTip.z
        prevPalmScale = palmScale

        return when {
            pinchRatio < 0.42f * (1.15f - sensitivity * 0.25f) && middleExt -> HandGesture.PINCH_SELECT
            !indexExt && !middleExt && !ringExt && !pinkyExt -> HandGesture.FIST
            indexExt && !middleExt && !ringExt && !pinkyExt -> {
                if (deltaZ > 0.035f) HandGesture.INDEX_PRESS else HandGesture.POINT_INDEX
            }
            indexExt && middleExt && ringExt && pinkyExt -> {
                if (scaleGrowth > 0.025f) HandGesture.PUSH_FORWARD else HandGesture.OPEN_HAND
            }
            else -> HandGesture.OPEN_HAND
        }
    }

    private fun sampleAverageLuminance(bitmap: Bitmap): Float {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return 0f
        var sum = 0L
        var count = 0
        val stepX = (w / 12).coerceAtLeast(1)
        val stepY = (h / 12).coerceAtLeast(1)
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val px = bitmap.getPixel(x, y)
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                sum += ((299 * r + 587 * g + 114 * b) / 1000)
                count++
                x += stepX
            }
            y += stepY
        }
        return if (count == 0) 0f else sum.toFloat() / count
    }

    fun release() {
        stopCameraTracking()
        runCatching { handLandmarker?.close() }
        handLandmarker = null
        analysisExecutor.shutdownNow()
    }
}
