package com.example.vr.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface
import com.example.vr.model.HeadTrackingSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.hypot

class HeadTracker(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager

    private val gameRotSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
    private val rotSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rawGyroSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private val rotMatrix = FloatArray(16)
    private val accelValues = FloatArray(3)
    private val magValues = FloatArray(3)
    private var hasAccel = false
    private var hasMag = false

    @Volatile
    var rawYawDeg: Float = 0f
        private set

    @Volatile
    var pitchDeg: Float = 0f
        private set

    @Volatile
    var rollDeg: Float = 0f
        private set

    @Volatile
    var hasSensorData: Boolean = false
        private set

    @Volatile
    var horizonLockEnabled: Boolean = true

    @Volatile
    var sensitivity: Float = 1.15f

    @Volatile
    var smoothingFactor: Float = 0.35f

    private var zeroYawOffsetDeg: Float = 0f
    private var hasAutoZeroedInitialYaw: Boolean = false
    private var isRegistered = false
    private var lastGyroTimestampNs: Long = 0L

    private var rateWindowStartNs: Long = 0L
    private var rateSampleCount: Int = 0
    private var measuredHz: Int = 0
    private var measuredJitterDeg: Float = 0f
    private var prevSampleYaw: Float = 0f
    private var prevEmitYaw: Float = 0f
    private var prevEmitPitch: Float = 0f

    private var deltaListener: ((Float, Float) -> Unit)? = null

    private val _snapshot = MutableStateFlow(
        HeadTrackingSnapshot(
            isGyroSupported = isGyroSupported,
            activeSensorName = resolvePrimarySensorName()
        )
    )
    val snapshot: StateFlow<HeadTrackingSnapshot> = _snapshot.asStateFlow()

    val isGyroSupported: Boolean
        get() = gameRotSensor != null || rotSensor != null || rawGyroSensor != null || (accelSensor != null && magSensor != null)

    fun setDeltaListener(listener: ((deltaYawDeg: Float, deltaPitchDeg: Float) -> Unit)?) {
        deltaListener = listener
    }

    fun applyConfig(
        horizonLock: Boolean,
        headSensitivity: Float,
        headSmoothing: Float,
        savedZeroOffsetDeg: Float? = null
    ) {
        horizonLockEnabled = horizonLock
        sensitivity = headSensitivity.coerceIn(0.4f, 2.5f)
        smoothingFactor = headSmoothing.coerceIn(0.08f, 0.90f)
        if (savedZeroOffsetDeg != null) {
            zeroYawOffsetDeg = savedZeroOffsetDeg
            hasAutoZeroedInitialYaw = true
        }
    }

    fun calibrateZeroYaw(): Float {
        zeroYawOffsetDeg = rawYawDeg
        hasAutoZeroedInitialYaw = true
        publishSnapshot()
        return zeroYawOffsetDeg
    }

    fun resetToCenter() {
        zeroYawOffsetDeg = rawYawDeg
        hasAutoZeroedInitialYaw = true
        prevEmitYaw = getCalibratedYawDeg()
        prevEmitPitch = pitchDeg
        publishSnapshot()
    }

    fun getCalibratedYawDeg(): Float {
        val diff = wrapAngleDeg(rawYawDeg - zeroYawOffsetDeg) * sensitivity
        return wrapAngleDeg(diff)
    }

    fun getScaledPitchDeg(): Float = (pitchDeg * sensitivity).coerceIn(-85f, 85f)

    fun start() {
        if (isRegistered) return
        lastGyroTimestampNs = 0L
        rateWindowStartNs = 0L
        rateSampleCount = 0

        val primaryRot = gameRotSensor ?: rotSensor
        if (primaryRot != null) {
            sensorManager.registerListener(this, primaryRot, SensorManager.SENSOR_DELAY_FASTEST)
        } else if (rawGyroSensor != null) {
            sensorManager.registerListener(this, rawGyroSensor, SensorManager.SENSOR_DELAY_FASTEST)
            accelSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        } else if (accelSensor != null && magSensor != null) {
            sensorManager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_GAME)
            sensorManager.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        isRegistered = true
        publishSnapshot()
    }

    fun stop() {
        if (!isRegistered) return
        sensorManager.unregisterListener(this)
        isRegistered = false
    }

    override fun onSensorChanged(event: SensorEvent) {
        updateRateStats(event.timestamp)
        when (event.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR,
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotMatrix, event.values)
                updateOrientationFromWorldMatrix(rotMatrix)
            }
            Sensor.TYPE_GYROSCOPE -> handleRawGyro(event)
            Sensor.TYPE_ACCELEROMETER -> {
                for (i in 0..2) {
                    accelValues[i] = if (!hasAccel) event.values[i] else accelValues[i] + (event.values[i] - accelValues[i]) * 0.25f
                }
                hasAccel = true
                if (gameRotSensor == null && rotSensor == null && rawGyroSensor == null && hasMag) {
                    if (SensorManager.getRotationMatrix(rotMatrix, null, accelValues, magValues)) {
                        updateOrientationFromWorldMatrix(rotMatrix)
                    }
                }
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                for (i in 0..2) {
                    magValues[i] = if (!hasMag) event.values[i] else magValues[i] + (event.values[i] - magValues[i]) * 0.25f
                }
                hasMag = true
                if (gameRotSensor == null && rotSensor == null && rawGyroSensor == null && hasAccel) {
                    if (SensorManager.getRotationMatrix(rotMatrix, null, accelValues, magValues)) {
                        updateOrientationFromWorldMatrix(rotMatrix)
                    }
                }
            }
        }
    }

    /**
     * Pure testable orientation update given target yaw/pitch/roll in degrees.
     */
    fun applyFilteredOrientationSample(targetYaw: Float, targetPitch: Float, targetRoll: Float) {
        val alpha = (1f - smoothingFactor).coerceIn(0.18f, 0.96f)
        if (!hasSensorData) {
            rawYawDeg = wrapAngleDeg(targetYaw)
            pitchDeg = targetPitch.coerceIn(-82f, 82f)
            rollDeg = if (horizonLockEnabled) 0f else targetRoll.coerceIn(-35f, 35f)
            if (!hasAutoZeroedInitialYaw) {
                zeroYawOffsetDeg = rawYawDeg
                hasAutoZeroedInitialYaw = true
            }
            prevSampleYaw = rawYawDeg
            prevEmitYaw = getCalibratedYawDeg()
            prevEmitPitch = pitchDeg
            hasSensorData = true
        } else {
            val instantDelta = abs(wrapAngleDeg(targetYaw - prevSampleYaw))
            measuredJitterDeg = measuredJitterDeg * 0.85f + instantDelta * 0.15f
            prevSampleYaw = targetYaw

            rawYawDeg = lerpAngleDeg(rawYawDeg, targetYaw, alpha)
            pitchDeg += (targetPitch.coerceIn(-82f, 82f) - pitchDeg) * alpha
            val desiredRoll = if (horizonLockEnabled) 0f else targetRoll.coerceIn(-35f, 35f)
            rollDeg += (desiredRoll - rollDeg) * alpha

            val curYaw = getCalibratedYawDeg()
            val curPitch = getScaledPitchDeg()
            val dYaw = wrapAngleDeg(curYaw - prevEmitYaw)
            val dPitch = curPitch - prevEmitPitch
            prevEmitYaw = curYaw
            prevEmitPitch = curPitch
            if (abs(dYaw) > 0.002f || abs(dPitch) > 0.002f) {
                deltaListener?.invoke(dYaw, dPitch)
            }
        }
        publishSnapshot()
    }

    private fun updateOrientationFromWorldMatrix(r: FloatArray) {
        val fx = -r[2]
        val fy = -r[6]
        val fz = -r[10]

        val rotation = currentDisplayRotation()
        val ux: Float
        val uy: Float
        val rz: Float
        when (rotation) {
            Surface.ROTATION_90 -> {
                ux = r[0]; uy = r[4]; rz = -r[9]
            }
            Surface.ROTATION_270 -> {
                ux = -r[0]; uy = -r[4]; rz = r[9]
            }
            Surface.ROTATION_180 -> {
                ux = -r[1]; uy = -r[5]; rz = -r[8]
            }
            else -> {
                ux = r[1]; uy = r[5]; rz = r[8]
            }
        }

        val targetPitch = Math.toDegrees(asin(fz.coerceIn(-0.999f, 0.999f).toDouble())).toFloat()
            .coerceIn(-82f, 82f)

        val horizLen = hypot(fx.toDouble(), fy.toDouble()).toFloat()
        val yawVecX: Float
        val yawVecY: Float
        if (horizLen > 0.18f) {
            yawVecX = fx
            yawVecY = fy
        } else {
            val sign = if (fz > 0f) -1f else 1f
            yawVecX = fx + sign * ux * 0.5f
            yawVecY = fy + sign * uy * 0.5f
        }
        val targetYaw = -Math.toDegrees(atan2(yawVecX.toDouble(), yawVecY.toDouble())).toFloat()
        val targetRoll = if (horizonLockEnabled) {
            0f
        } else {
            Math.toDegrees(asin((-rz).coerceIn(-0.99f, 0.99f).toDouble())).toFloat().coerceIn(-35f, 35f)
        }
        applyFilteredOrientationSample(targetYaw, targetPitch, targetRoll)
    }

    private fun handleRawGyro(event: SensorEvent) {
        if (lastGyroTimestampNs != 0L) {
            val dt = (event.timestamp - lastGyroTimestampNs) * 1e-9f
            if (dt in 0.0001f..0.2f) {
                val gx = Math.toDegrees(event.values[0].toDouble()).toFloat()
                val gy = Math.toDegrees(event.values[1].toDouble()).toFloat()
                val gz = Math.toDegrees(event.values[2].toDouble()).toFloat()
                val nextYaw: Float
                val nextPitch: Float
                when (currentDisplayRotation()) {
                    Surface.ROTATION_90 -> {
                        nextYaw = rawYawDeg + gx * dt
                        nextPitch = (pitchDeg + gy * dt).coerceIn(-82f, 82f)
                    }
                    Surface.ROTATION_270 -> {
                        nextYaw = rawYawDeg - gx * dt
                        nextPitch = (pitchDeg - gy * dt).coerceIn(-82f, 82f)
                    }
                    Surface.ROTATION_180 -> {
                        nextYaw = rawYawDeg - gy * dt
                        nextPitch = (pitchDeg - gx * dt).coerceIn(-82f, 82f)
                    }
                    else -> {
                        nextYaw = rawYawDeg + gy * dt
                        nextPitch = (pitchDeg + gx * dt).coerceIn(-82f, 82f)
                    }
                }
                val nextRoll = if (horizonLockEnabled) 0f else (rollDeg - gz * dt).coerceIn(-35f, 35f)
                applyFilteredOrientationSample(nextYaw, nextPitch, nextRoll)
            }
        }
        lastGyroTimestampNs = event.timestamp
    }

    private fun updateRateStats(timestampNs: Long) {
        if (rateWindowStartNs == 0L) {
            rateWindowStartNs = timestampNs
            rateSampleCount = 0
        }
        rateSampleCount++
        val elapsed = timestampNs - rateWindowStartNs
        if (elapsed >= 1_000_000_000L) {
            measuredHz = ((rateSampleCount * 1_000_000_000L) / elapsed).toInt()
            rateWindowStartNs = timestampNs
            rateSampleCount = 0
        }
    }

    private fun publishSnapshot() {
        _snapshot.value = HeadTrackingSnapshot(
            isGyroSupported = isGyroSupported,
            activeSensorName = resolvePrimarySensorName(),
            hasSensorData = hasSensorData,
            rawYawDeg = rawYawDeg,
            calibratedYawDeg = getCalibratedYawDeg(),
            pitchDeg = getScaledPitchDeg(),
            rollDeg = rollDeg,
            sampleRateHz = measuredHz,
            jitterDeg = measuredJitterDeg
        )
    }

    private fun resolvePrimarySensorName(): String = when {
        gameRotSensor != null -> "Game Rotation Vector"
        rotSensor != null -> "Rotation Vector"
        rawGyroSensor != null -> "Raw Gyroscope"
        accelSensor != null && magSensor != null -> "Accel + Magnetometer"
        else -> "Unavailable"
    }

    private fun currentDisplayRotation(): Int {
        return runCatching {
            displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.rotation
        }.getOrNull() ?: Surface.ROTATION_90
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        fun wrapAngleDeg(deg: Float): Float {
            var res = deg
            while (res > 180f) res -= 360f
            while (res < -180f) res += 360f
            return res
        }

        fun lerpAngleDeg(from: Float, to: Float, alpha: Float): Float {
            val delta = wrapAngleDeg(to - from)
            return wrapAngleDeg(from + delta * alpha)
        }
    }
}
