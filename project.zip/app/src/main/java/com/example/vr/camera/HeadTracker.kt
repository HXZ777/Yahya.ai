package com.example.vr.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.hypot

class HeadTracker(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager

    private val gameRotSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
    private val rotSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rawGyroSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private val rotMatrix = FloatArray(16)
    private val accelValues = FloatArray(3)
    private val magValues = FloatArray(3)
    private var hasAccel = false
    private var hasMag = false

    @Volatile
    var rawYawDeg: Float = 0f
        private set

    @Volatile
    var pitchDeg: Float = 0f
        private set

    @Volatile
    var rollDeg: Float = 0f
        private set

    @Volatile
    var hasSensorData: Boolean = false
        private set

    @Volatile
    var horizonLockEnabled: Boolean = true

    private var zeroYawOffsetDeg: Float = 0f
    private var hasAutoZeroedInitialYaw: Boolean = false
    private var isRegistered = false
    private var lastGyroTimestampNs: Long = 0L

    val isGyroSupported: Boolean
        get() = gameRotSensor != null || rotSensor != null || rawGyroSensor != null || (accelSensor != null && magSensor != null)

    fun setZeroOffset(offsetDeg: Float) {
        zeroYawOffsetDeg = offsetDeg
        hasAutoZeroedInitialYaw = true
    }

    fun calibrateZeroYaw(): Float {
        zeroYawOffsetDeg = rawYawDeg
        hasAutoZeroedInitialYaw = true
        return zeroYawOffsetDeg
    }

    fun resetAutoZero() {
        hasAutoZeroedInitialYaw = false
    }

    fun getCalibratedYawDeg(): Float {
        var diff = rawYawDeg - zeroYawOffsetDeg
        while (diff > 180f) diff -= 360f
        while (diff < -180f) diff += 360f
        return diff
    }

    fun start() {
        if (isRegistered) return
        lastGyroTimestampNs = 0L
        hasAutoZeroedInitialYaw = false

        val primaryRot = gameRotSensor ?: rotSensor
        if (primaryRot != null) {
            sensorManager.registerListener(this, primaryRot, SensorManager.SENSOR_DELAY_GAME)
        } else if (rawGyroSensor != null) {
            sensorManager.registerListener(this, rawGyroSensor, SensorManager.SENSOR_DELAY_GAME)
            accelSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        } else if (accelSensor != null && magSensor != null) {
            sensorManager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_GAME)
            sensorManager.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        isRegistered = true
    }

    fun stop() {
        if (!isRegistered) return
        sensorManager.unregisterListener(this)
        isRegistered = false
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR,
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotMatrix, event.values)
                updateOrientationFromWorldMatrix(rotMatrix)
            }
            Sensor.TYPE_GYROSCOPE -> {
                handleRawGyro(event)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                for (i in 0..2) {
                    accelValues[i] = if (!hasAccel) event.values[i] else accelValues[i] + (event.values[i] - accelValues[i]) * 0.25f
                }
                hasAccel = true
                if (gameRotSensor == null && rotSensor == null && rawGyroSensor == null && hasMag) {
                    if (SensorManager.getRotationMatrix(rotMatrix, null, accelValues, magValues)) {
                        updateOrientationFromWorldMatrix(rotMatrix)
                    }
                }
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                for (i in 0..2) {
                    magValues[i] = if (!hasMag) event.values[i] else magValues[i] + (event.values[i] - magValues[i]) * 0.25f
                }
                hasMag = true
                if (gameRotSensor == null && rotSensor == null && rawGyroSensor == null && hasAccel) {
                    if (SensorManager.getRotationMatrix(rotMatrix, null, accelValues, magValues)) {
                        updateOrientationFromWorldMatrix(rotMatrix)
                    }
                }
            }
        }
    }

    /**
     * Direct 3D vector extraction from Android's device->world matrix (no Euler gimbal lock!).
     * World frame in SensorManager: +X = East, +Y = North, +Z = Sky (Up).
     * Rear camera / VR gaze always points along device -Z = (0, 0, -1).
     */
    private fun updateOrientationFromWorldMatrix(r: FloatArray) {
        // Forward vector in world space = R * (0, 0, -1)
        val fx = -r[2]
        val fy = -r[6]
        val fz = -r[10]

        // Device screen UP and RIGHT vectors depending on current Display rotation
        val rotation = currentDisplayRotation()
        val ux: Float; val uy: Float; val uz: Float
        val rx: Float; val ry: Float; val rz: Float
        when (rotation) {
            Surface.ROTATION_90 -> {
                // Standard landscape: device +X points UP, device -Y points RIGHT
                ux = r[0]; uy = r[4]; uz = r[8]
                rx = -r[1]; ry = -r[5]; rz = -r[9]
            }
            Surface.ROTATION_270 -> {
                // Reverse landscape: device -X points UP, device +Y points RIGHT
                ux = -r[0]; uy = -r[4]; uz = -r[8]
                rx = r[1]; ry = r[5]; rz = r[9]
            }
            Surface.ROTATION_180 -> {
                ux = -r[1]; uy = -r[5]; uz = -r[9]
                rx = -r[0]; ry = -r[4]; rz = -r[8]
            }
            else -> {
                // Portrait: device +Y points UP, device +X points RIGHT
                ux = r[1]; uy = r[5]; uz = r[9]
                rx = r[0]; ry = r[4]; rz = r[8]
            }
        }

        // Pitch: angle above/below horizontal plane
        val targetPitch = Math.toDegrees(asin(fz.coerceIn(-0.999f, 0.999f).toDouble())).toFloat()
            .coerceIn(-82f, 82f)

        // Yaw: horizontal direction of gaze; when looking straight up/down, blend in Up vector to avoid 180° flips
        val horizLen = hypot(fx.toDouble(), fy.toDouble()).toFloat()
        val yawVecX: Float
        val yawVecY: Float
        if (horizLen > 0.18f) {
            yawVecX = fx
            yawVecY = fy
        } else {
            val sign = if (fz > 0f) -1f else 1f
            yawVecX = fx + sign * ux * 0.5f
            yawVecY = fy + sign * uy * 0.5f
        }
        // Negate atan2(East, North) so turning right decreases OpenGL yaw (matching -sin(yaw), -cos(yaw))
        val targetYaw = -Math.toDegrees(atan2(yawVecX.toDouble(), yawVecY.toDouble())).toFloat()

        // Roll: tilt relative to gravity (disabled by default via horizonLockEnabled to keep horizon flat!)
        val targetRoll = if (horizonLockEnabled) {
            0f
        } else {
            Math.toDegrees(asin((-rz).coerceIn(-0.99f, 0.99f).toDouble())).toFloat().coerceIn(-35f, 35f)
        }

        if (!hasSensorData) {
            rawYawDeg = targetYaw
            pitchDeg = targetPitch
            rollDeg = targetRoll
            if (!hasAutoZeroedInitialYaw) {
                zeroYawOffsetDeg = targetYaw
                hasAutoZeroedInitialYaw = true
            }
            hasSensorData = true
        } else {
            // Smooth low-pass filter to eliminate micro-jitter inside VR Box
            rawYawDeg = lerpAngleDeg(rawYawDeg, targetYaw, 0.38f)
            pitchDeg += (targetPitch - pitchDeg) * 0.38f
            rollDeg += (targetRoll - rollDeg) * 0.35f
        }
    }

    private fun handleRawGyro(event: SensorEvent) {
        if (lastGyroTimestampNs != 0L) {
            val dt = (event.timestamp - lastGyroTimestampNs) * 1e-9f
            if (dt in 0.0001f..0.2f) {
                val gx = Math.toDegrees(event.values[0].toDouble()).toFloat()
                val gy = Math.toDegrees(event.values[1].toDouble()).toFloat()
                val gz = Math.toDegrees(event.values[2].toDouble()).toFloat()
                when (currentDisplayRotation()) {
                    Surface.ROTATION_90 -> {
                        // Landscape: +X points UP, turning head right gives gx < 0 -> decreases OpenGL yaw
                        rawYawDeg += gx * dt
                        pitchDeg = (pitchDeg + gy * dt).coerceIn(-82f, 82f)
                        rollDeg = if (horizonLockEnabled) 0f else (rollDeg - gz * dt).coerceIn(-35f, 35f)
                    }
                    Surface.ROTATION_270 -> {
                        rawYawDeg -= gx * dt
                        pitchDeg = (pitchDeg - gy * dt).coerceIn(-82f, 82f)
                        rollDeg = if (horizonLockEnabled) 0f else (rollDeg - gz * dt).coerceIn(-35f, 35f)
                    }
                    Surface.ROTATION_180 -> {
                        rawYawDeg -= gy * dt
                        pitchDeg = (pitchDeg - gx * dt).coerceIn(-82f, 82f)
                        rollDeg = if (horizonLockEnabled) 0f else (rollDeg - gz * dt).coerceIn(-35f, 35f)
                    }
                    else -> {
                        rawYawDeg += gy * dt
                        pitchDeg = (pitchDeg + gx * dt).coerceIn(-82f, 82f)
                        rollDeg = if (horizonLockEnabled) 0f else (rollDeg - gz * dt).coerceIn(-35f, 35f)
                    }
                }
                hasSensorData = true
            }
        }
        lastGyroTimestampNs = event.timestamp
    }

    private fun lerpAngleDeg(from: Float, to: Float, alpha: Float): Float {
        var delta = to - from
        while (delta > 180f) delta -= 360f
        while (delta < -180f) delta += 360f
        var res = from + delta * alpha
        while (res > 180f) res -= 360f
        while (res < -180f) res += 360f
        return res
    }

    private fun currentDisplayRotation(): Int {
        return runCatching {
            displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.rotation
        }.getOrNull() ?: Surface.ROTATION_90
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
