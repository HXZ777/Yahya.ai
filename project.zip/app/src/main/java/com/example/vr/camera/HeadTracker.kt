package com.example.vr.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface

class HeadTracker(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val rotationSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rawGyroSensor: Sensor? =
        if (rotationSensor == null) sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) else null

    private val rotationMatrix = FloatArray(9)
    private val remappedMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    @Volatile
    var rawYawDeg: Float = 0f
        private set

    @Volatile
    var pitchDeg: Float = 0f
        private set

    @Volatile
    var rollDeg: Float = 0f
        private set

    @Volatile
    var hasSensorData: Boolean = false
        private set

    private var zeroYawOffsetDeg: Float = 0f
    private var isRegistered = false
    private var lastGyroTimestampNs: Long = 0L

    val isGyroSupported: Boolean
        get() = rotationSensor != null || rawGyroSensor != null

    fun setZeroOffset(offsetDeg: Float) {
        zeroYawOffsetDeg = offsetDeg
    }

    fun calibrateZeroYaw(): Float {
        zeroYawOffsetDeg = rawYawDeg
        return zeroYawOffsetDeg
    }

    fun getCalibratedYawDeg(): Float {
        var diff = rawYawDeg - zeroYawOffsetDeg
        while (diff > 180f) diff -= 360f
        while (diff < -180f) diff += 360f
        return diff
    }

    fun start() {
        if (isRegistered) return
        val active = rotationSensor ?: rawGyroSensor ?: return
        lastGyroTimestampNs = 0L
        sensorManager.registerListener(this, active, SensorManager.SENSOR_DELAY_GAME)
        isRegistered = true
    }

    fun stop() {
        if (!isRegistered) return
        sensorManager.unregisterListener(this)
        isRegistered = false
    }

    override fun onSensorChanged(event: SensorEvent) {
        val rotation = currentDisplayRotation()

        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            if (lastGyroTimestampNs != 0L) {
                val dt = (event.timestamp - lastGyroTimestampNs) * 1e-9f
                if (dt in 0.0001f..0.2f) {
                    val gx = Math.toDegrees(event.values[0].toDouble()).toFloat()
                    val gy = Math.toDegrees(event.values[1].toDouble()).toFloat()
                    val gz = Math.toDegrees(event.values[2].toDouble()).toFloat()
                    when (rotation) {
                        Surface.ROTATION_90 -> {
                            rawYawDeg += gx * dt
                            pitchDeg = (pitchDeg + gy * dt).coerceIn(-80f, 80f)
                            rollDeg = (rollDeg + gz * dt).coerceIn(-45f, 45f)
                        }
                        Surface.ROTATION_270 -> {
                            rawYawDeg -= gx * dt
                            pitchDeg = (pitchDeg - gy * dt).coerceIn(-80f, 80f)
                            rollDeg = (rollDeg + gz * dt).coerceIn(-45f, 45f)
                        }
                        else -> {
                            rawYawDeg += gy * dt
                            pitchDeg = (pitchDeg + gx * dt).coerceIn(-80f, 80f)
                            rollDeg = (rollDeg + gz * dt).coerceIn(-45f, 45f)
                        }
                    }
                    hasSensorData = true
                }
            }
            lastGyroTimestampNs = event.timestamp
            return
        }

        if (event.sensor.type != Sensor.TYPE_GAME_ROTATION_VECTOR &&
            event.sensor.type != Sensor.TYPE_ROTATION_VECTOR
        ) return

        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)

        // Remap upright phone inside VR Box (rear camera facing forward = AXIS_MINUS_Z)
        val (axisX, axisY) = when (rotation) {
            Surface.ROTATION_90 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_MINUS_Z
            Surface.ROTATION_270 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_Z
            Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Z
            else -> SensorManager.AXIS_X to SensorManager.AXIS_MINUS_Z
        }

        SensorManager.remapCoordinateSystem(rotationMatrix, axisX, axisY, remappedMatrix)
        SensorManager.getOrientation(remappedMatrix, orientationAngles)

        val yawRad = orientationAngles[0]
        val pitchRad = orientationAngles[1]
        val rollRad = orientationAngles[2]

        // Negate yaw & pitch so turning right / looking up matches OpenGL (-Z forward, +Y up)
        rawYawDeg = -Math.toDegrees(yawRad.toDouble()).toFloat()
        pitchDeg = (-Math.toDegrees(pitchRad.toDouble()).toFloat()).coerceIn(-80f, 80f)
        rollDeg = Math.toDegrees(rollRad.toDouble()).toFloat().coerceIn(-45f, 45f)
        hasSensorData = true
    }

    private fun currentDisplayRotation(): Int {
        return runCatching {
            displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.rotation
        }.getOrNull() ?: Surface.ROTATION_90
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
