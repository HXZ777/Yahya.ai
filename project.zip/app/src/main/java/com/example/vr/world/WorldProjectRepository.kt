package com.example.vr.world

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.TextureQuality
import com.example.vr.model.Transform3D
import com.example.vr.model.WorldEntry
import com.example.vr.model.WorldLightingConfig
import com.example.vr.model.WorldNodeEntry
import com.example.vr.model.WorldObjectCategory
import com.example.vr.model.WorldProjectState
import com.example.vr.model.WorldType
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object WorldProjectRepository {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    fun projectDir(context: Context, worldId: String): File =
        File(context.filesDir, "world_projects/$worldId").apply { mkdirs() }

    fun texturesDir(context: Context, worldId: String): File =
        File(projectDir(context, worldId), "textures").apply { mkdirs() }

    fun modelsDir(context: Context, worldId: String): File =
        File(projectDir(context, worldId), "models").apply { mkdirs() }

    fun unpackedDir(context: Context, worldId: String): File =
        File(projectDir(context, worldId), "unpacked").apply { mkdirs() }

    fun saveProject(
        context: Context,
        project: WorldProjectState,
        saveAsOriginalIfMissing: Boolean = true
    ): WorldProjectState {
        val dir = projectDir(context, project.worldId)
        val stamped = project.copy(lastModifiedMs = System.currentTimeMillis())
        val encoded = json.encodeToString(stamped)
        File(dir, "project.json").writeText(encoded)
        val origFile = File(dir, "original_project.json")
        if (saveAsOriginalIfMissing && !origFile.exists()) {
            origFile.writeText(encoded)
        }
        return stamped
    }

    fun loadProject(context: Context, worldId: String): WorldProjectState? {
        val file = File(projectDir(context, worldId), "project.json")
        if (!file.exists() || !file.canRead()) return null
        return runCatching {
            json.decodeFromString<WorldProjectState>(file.readText())
        }.getOrNull()
    }

    fun restoreOriginalProject(context: Context, worldId: String): WorldProjectState? {
        val dir = projectDir(context, worldId)
        val orig = File(dir, "original_project.json")
        if (!orig.exists() || !orig.canRead()) return loadProject(context, worldId)
        return runCatching {
            val state = json.decodeFromString<WorldProjectState>(orig.readText())
                .copy(lastModifiedMs = System.currentTimeMillis())
            File(dir, "project.json").writeText(json.encodeToString(state))
            state
        }.getOrNull()
    }

    fun duplicateProject(
        context: Context,
        sourceEntry: WorldEntry
    ): Pair<WorldEntry, WorldProjectState>? {
        val newId = "custom_${UUID.randomUUID().toString().take(8)}"
        val srcDir = projectDir(context, sourceEntry.id)
        val dstDir = projectDir(context, newId)

        runCatching {
            if (srcDir.exists()) {
                srcDir.copyRecursively(dstDir, overwrite = true)
            }
        }

        // Copy main asset file if it lives under custom_worlds
        var newAssetPath = sourceEntry.customAssetPath
        if (!sourceEntry.customAssetPath.isNullOrBlank()) {
            val srcFile = File(sourceEntry.customAssetPath)
            if (srcFile.exists()) {
                val dstFile = File(srcFile.parentFile, "$newId.${srcFile.extension}")
                srcFile.copyTo(dstFile, overwrite = true)
                newAssetPath = dstFile.absolutePath
            }
        }

        val srcProject = loadProject(context, sourceEntry.id)
        val newTitleEn = "${sourceEntry.titleEn} (Copy)"
        val newTitleAr = "${sourceEntry.titleAr} (نسخة)"

        val updatedProject = (srcProject ?: WorldProjectState(
            worldId = newId,
            titleEn = newTitleEn,
            titleAr = newTitleAr,
            rootAssetPath = newAssetPath.orEmpty()
        )).copy(
            worldId = newId,
            titleEn = newTitleEn,
            titleAr = newTitleAr,
            rootAssetPath = newAssetPath.orEmpty(),
            materials = srcProject?.materials?.map { mat ->
                mat.copy(
                    texturePath = mat.texturePath?.replace(sourceEntry.id, newId),
                    normalTexturePath = mat.normalTexturePath?.replace(sourceEntry.id, newId),
                    aoTexturePath = mat.aoTexturePath?.replace(sourceEntry.id, newId),
                    emissiveTexturePath = mat.emissiveTexturePath?.replace(sourceEntry.id, newId)
                )
            } ?: emptyList(),
            lastModifiedMs = System.currentTimeMillis()
        )

        val savedProj = saveProject(context, updatedProject, saveAsOriginalIfMissing = false)
        File(dstDir, "original_project.json").writeText(json.encodeToString(savedProj))

        val newEntry = sourceEntry.copy(
            id = newId,
            titleEn = newTitleEn,
            titleAr = newTitleAr,
            customAssetPath = newAssetPath
        )
        return newEntry to savedProj
    }

    fun buildInitialProject(
        worldEntry: WorldEntry,
        mesh: com.example.vr.model.ImportedMeshData
    ): WorldProjectState {
        val nodes = ArrayList<WorldNodeEntry>()
        if (mesh.subMeshes.isNotEmpty()) {
            // Group consecutive or matching nodeNames into meaningful editable WorldNodeEntries (capped cleanly so hierarchy stays responsive)
            val grouped = mesh.subMeshes.withIndex().groupBy { (_, sm) -> sm.nodeName.ifBlank { sm.name } }
            var orderIdx = 0
            for ((nodeName, items) in grouped) {
                if (orderIdx >= 64) {
                    // Put remaining submeshes into a consolidated node so no geometry is lost
                    val firstIdx = items.first().index
                    val lastIdx = mesh.subMeshes.lastIndex
                    nodes.add(
                        WorldNodeEntry(
                            id = "node_rest_$orderIdx",
                            name = "Environment Props",
                            category = WorldObjectCategory.ENVIRONMENT,
                            assetPath = worldEntry.customAssetPath,
                            subMeshStartIdx = firstIdx,
                            subMeshEndIdx = lastIdx,
                            transform = Transform3D(),
                            localMinX = mesh.boundsMin[0],
                            localMinY = mesh.boundsMin[1],
                            localMinZ = mesh.boundsMin[2],
                            localMaxX = mesh.boundsMax[0],
                            localMaxY = mesh.boundsMax[1],
                            localMaxZ = mesh.boundsMax[2]
                        )
                    )
                    break
                }
                val startIdx = items.minOf { it.index }
                val endIdx = items.maxOf { it.index }
                val minX = items.minOf { it.value.boundsMin[0] }
                val minY = items.minOf { it.value.boundsMin[1] }
                val minZ = items.minOf { it.value.boundsMin[2] }
                val maxX = items.maxOf { it.value.boundsMax[0] }
                val maxY = items.maxOf { it.value.boundsMax[1] }
                val maxZ = items.maxOf { it.value.boundsMax[2] }
                val cat = items.first().value.categoryHint
                nodes.add(
                    WorldNodeEntry(
                        id = "node_${orderIdx}_${UUID.randomUUID().toString().take(4)}",
                        name = nodeName.take(40),
                        category = cat,
                        assetPath = worldEntry.customAssetPath,
                        subMeshStartIdx = startIdx,
                        subMeshEndIdx = endIdx,
                        transform = Transform3D(),
                        localMinX = minX,
                        localMinY = minY,
                        localMinZ = minZ,
                        localMaxX = maxX,
                        localMaxY = maxY,
                        localMaxZ = maxZ
                    )
                )
                orderIdx++
            }
        } else {
            nodes.add(
                WorldNodeEntry(
                    id = "node_main",
                    name = worldEntry.titleEn.ifBlank { "Imported World" },
                    category = WorldObjectCategory.BUILDINGS,
                    assetPath = worldEntry.customAssetPath,
                    subMeshStartIdx = 0,
                    subMeshEndIdx = 0,
                    transform = Transform3D(),
                    localMinX = mesh.boundsMin.getOrElse(0) { -10f },
                    localMinY = mesh.boundsMin.getOrElse(1) { 0f },
                    localMinZ = mesh.boundsMin.getOrElse(2) { -10f },
                    localMaxX = mesh.boundsMax.getOrElse(0) { 10f },
                    localMaxY = mesh.boundsMax.getOrElse(1) { 6f },
                    localMaxZ = mesh.boundsMax.getOrElse(2) { 10f }
                )
            )
        }

        val spawnZ = (mesh.boundsMax.getOrElse(2) { 8f } + 2.5f).coerceIn(3.5f, 36f)
        val spawnY = mesh.boundsMin.getOrElse(1) { 0f }.coerceAtLeast(0f)

        return WorldProjectState(
            worldId = worldEntry.id,
            titleEn = worldEntry.titleEn,
            titleAr = worldEntry.titleAr,
            rootAssetPath = worldEntry.customAssetPath.orEmpty(),
            worldTransform = Transform3D(),
            nodes = nodes,
            materials = mesh.materials,
            spawnPoints = listOf(
                SpawnPointEntry(
                    id = "spawn_main",
                    name = "Main Entrance",
                    x = 0f,
                    y = spawnY,
                    z = spawnZ,
                    yawDeg = 0f,
                    elevationOffset = 0f,
                    isPrimary = true
                )
            ),
            lighting = WorldLightingConfig(),
            collisionEnabled = true,
            diagnostics = mesh.diagnostics,
            lastModifiedMs = System.currentTimeMillis()
        )
    }

    fun copyPickedImageToTexture(
        context: Context,
        worldId: String,
        uri: Uri,
        textureQuality: TextureQuality
    ): String? {
        val dir = texturesDir(context, worldId)
        val outFile = File(dir, "custom_tex_${UUID.randomUUID().toString().take(8)}.png")
        return runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            saveDownsampledTextureBytes(bytes, outFile, textureQuality.maxDimensionPx)
        }.getOrNull()
    }

    fun saveDownsampledTextureBytes(
        bytes: ByteArray,
        outFile: File,
        maxDimPx: Int
    ): String? {
        if (bytes.isEmpty()) return null
        val optsBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, optsBounds)
        if (optsBounds.outWidth <= 0 || optsBounds.outHeight <= 0) return null

        var sample = 1
        while (optsBounds.outWidth / sample > maxDimPx || optsBounds.outHeight / sample > maxDimPx) {
            sample *= 2
        }
        val optsDecode = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, optsDecode) ?: return null
        return try {
            outFile.parentFile?.mkdirs()
            FileOutputStream(outFile).use { fos ->
                bmp.compress(Bitmap.CompressFormat.PNG, 92, fos)
            }
            outFile.absolutePath
        } finally {
            bmp.recycle()
        }
    }

    fun exportProjectAsZip(
        context: Context,
        project: WorldProjectState,
        worldEntry: WorldEntry,
        outputUri: Uri
    ): Boolean {
        return runCatching {
            context.contentResolver.openOutputStream(outputUri)?.use { os ->
                ZipOutputStream(BufferedOutputStream(os, 64 * 1024)).use { zos ->
                    // 1. project.json
                    zos.putNextEntry(ZipEntry("project.json"))
                    zos.write(json.encodeToString(project).toByteArray())
                    zos.closeEntry()

                    // 2. Primary asset file
                    worldEntry.customAssetPath?.let { path ->
                        val f = File(path)
                        if (f.exists() && f.isFile) {
                            addFileToZip(zos, f, "assets/${f.name}")
                        }
                    }

                    // 3. Added models & textures inside projectDir
                    val pDir = projectDir(context, project.worldId)
                    listOf("textures", "models").forEach { sub ->
                        val subDir = File(pDir, sub)
                        if (subDir.exists() && subDir.isDirectory) {
                            subDir.listFiles()?.forEach { child ->
                                if (child.isFile) {
                                    addFileToZip(zos, child, "$sub/${child.name}")
                                }
                            }
                        }
                    }
                }
            } != null
        }.getOrDefault(false)
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        zos.putNextEntry(ZipEntry(entryName))
        BufferedInputStream(FileInputStream(file), 64 * 1024).use { bis ->
            bis.copyTo(zos, 64 * 1024)
        }
        zos.closeEntry()
    }

    fun deleteProjectDir(context: Context, worldId: String) {
        runCatching {
            File(context.filesDir, "world_projects/$worldId").deleteRecursively()
        }
    }

    /** Pure helper to serialize/deserialize for unit testing without Android Context. */
    fun encodeProjectJson(project: WorldProjectState): String = json.encodeToString(project)
    fun decodeProjectJson(raw: String): WorldProjectState? =
        runCatching { json.decodeFromString<WorldProjectState>(raw) }.getOrNull()
}
