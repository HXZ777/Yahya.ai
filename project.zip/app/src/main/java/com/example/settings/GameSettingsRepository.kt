package com.example.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.vr.model.AllSettingsState
import com.example.vr.model.SaveGameState
import com.example.vr.model.WorldEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.vrDataStore: DataStore<Preferences> by preferencesDataStore(name = "vr_supermarket_prefs")

class GameSettingsRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private object Keys {
        val SETTINGS = stringPreferencesKey("all_settings_json")
        val SAVE_GAME = stringPreferencesKey("save_game_json")
        val DOWNLOADED_WORLDS = stringPreferencesKey("downloaded_world_ids_json")
        val CUSTOM_WORLDS = stringPreferencesKey("custom_worlds_json")
    }

    val settingsFlow: Flow<AllSettingsState> = context.vrDataStore.data.map { prefs ->
        val raw = prefs[Keys.SETTINGS]
        if (raw.isNullOrBlank()) AllSettingsState()
        else runCatching { json.decodeFromString<AllSettingsState>(raw) }.getOrDefault(AllSettingsState())
    }

    val saveGameFlow: Flow<SaveGameState?> = context.vrDataStore.data.map { prefs ->
        val raw = prefs[Keys.SAVE_GAME]
        if (raw.isNullOrBlank()) null
        else runCatching { json.decodeFromString<SaveGameState>(raw) }.getOrNull()
    }

    val downloadedWorldIdsFlow: Flow<Set<String>> = context.vrDataStore.data.map { prefs ->
        val raw = prefs[Keys.DOWNLOADED_WORLDS]
        if (raw.isNullOrBlank()) setOf("world_grand_supermarket")
        else runCatching { json.decodeFromString<Set<String>>(raw) }.getOrDefault(setOf("world_grand_supermarket"))
    }

    val customWorldsFlow: Flow<List<WorldEntry>> = context.vrDataStore.data.map { prefs ->
        val raw = prefs[Keys.CUSTOM_WORLDS]
        if (raw.isNullOrBlank()) emptyList()
        else runCatching { json.decodeFromString<List<WorldEntry>>(raw) }.getOrDefault(emptyList())
    }

    suspend fun saveSettings(settings: AllSettingsState) {
        context.vrDataStore.edit { prefs ->
            prefs[Keys.SETTINGS] = json.encodeToString(settings)
        }
    }

    suspend fun saveGame(save: SaveGameState) {
        context.vrDataStore.edit { prefs ->
            prefs[Keys.SAVE_GAME] = json.encodeToString(save.copy(timestampMs = System.currentTimeMillis()))
        }
    }

    suspend fun clearSaveGame() {
        context.vrDataStore.edit { prefs ->
            prefs.remove(Keys.SAVE_GAME)
        }
    }

    suspend fun markWorldDownloaded(worldId: String, downloaded: Boolean) {
        val current = downloadedWorldIdsFlow.first().toMutableSet()
        if (downloaded) current.add(worldId) else if (worldId != "world_grand_supermarket") current.remove(worldId)
        context.vrDataStore.edit { prefs ->
            prefs[Keys.DOWNLOADED_WORLDS] = json.encodeToString(current)
        }
    }

    suspend fun addCustomWorld(entry: WorldEntry) {
        val current = customWorldsFlow.first().filterNot { it.id == entry.id } + entry
        context.vrDataStore.edit { prefs ->
            prefs[Keys.CUSTOM_WORLDS] = json.encodeToString(current)
        }
    }

    suspend fun removeCustomWorld(worldId: String) {
        val current = customWorldsFlow.first().filterNot { it.id == worldId }
        context.vrDataStore.edit { prefs ->
            prefs[Keys.CUSTOM_WORLDS] = json.encodeToString(current)
        }
    }
}
