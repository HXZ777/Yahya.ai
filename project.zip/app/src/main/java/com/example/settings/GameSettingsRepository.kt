package com.example.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.vr.model.MineVrSettingsState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.mineVrDataStore: DataStore<Preferences> by preferencesDataStore(name = "minevr_prefs")

class GameSettingsRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private object Keys {
        val SETTINGS = stringPreferencesKey("minevr_settings_json")
    }

    val settingsFlow: Flow<MineVrSettingsState> = context.mineVrDataStore.data.map { prefs ->
        val raw = prefs[Keys.SETTINGS]
        if (raw.isNullOrBlank()) MineVrSettingsState()
        else runCatching { json.decodeFromString<MineVrSettingsState>(raw) }.getOrDefault(MineVrSettingsState())
    }

    suspend fun saveSettings(settings: MineVrSettingsState) {
        context.mineVrDataStore.edit { prefs ->
            prefs[Keys.SETTINGS] = json.encodeToString(settings)
        }
    }

    suspend fun resetSettings() {
        context.mineVrDataStore.edit { prefs ->
            prefs[Keys.SETTINGS] = json.encodeToString(MineVrSettingsState())
        }
    }
}
