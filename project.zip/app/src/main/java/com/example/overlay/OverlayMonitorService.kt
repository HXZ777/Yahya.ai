package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.data.preferences.StatsPreferencesRepository
import com.example.data.telemetry.SystemTelemetryReader
import com.example.domain.model.OverlayPositionPreset
import com.example.domain.model.OverlaySettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class OverlayMonitorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var windowManager: WindowManager
    private lateinit var prefsRepository: StatsPreferencesRepository
    private lateinit var telemetryReader: SystemTelemetryReader

    private var overlayView: FloatingOverlayView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var currentSettings = OverlaySettings()

    private var pollingJob: Job? = null
    private var settingsJob: Job? = null

    // Lightweight Choreographer loop used ONLY when user explicitly opts into Compositor Hz fallback
    private var choreographerActive = false
    private var frameCount = 0
    private var frameWindowStartNs = 0L
    @Volatile
    private var latestCompositorFps: Int? = null

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!choreographerActive) return
            if (frameWindowStartNs == 0L) {
                frameWindowStartNs = frameTimeNanos
                frameCount = 0
            } else {
                frameCount++
                val elapsedNs = frameTimeNanos - frameWindowStartNs
                if (elapsedNs >= 1_000_000_000L) {
                    latestCompositorFps = ((frameCount * 1_000_000_000.0) / elapsedNs)
                        .roundToInt()
                        .coerceIn(1, 240)
                    frameWindowStartNs = frameTimeNanos
                    frameCount = 0
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefsRepository = StatsPreferencesRepository(applicationContext)
        telemetryReader = SystemTelemetryReader(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlayAndSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            OverlayStateHolder.setOverlayRunning(false)
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()
        attachOverlayIfNeeded()
        observeSettingsAndTelemetry()
        OverlayStateHolder.setOverlayRunning(true)

        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val view = overlayView ?: return
        val params = layoutParams ?: return
        clampPositionToScreen(params, view)
        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: Exception) {
            // Ignored if view detached
        }
    }

    override fun onDestroy() {
        stopChoreographer()
        pollingJob?.cancel()
        settingsJob?.cancel()
        detachOverlay()
        OverlayStateHolder.setOverlayRunning(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val stopIntent = Intent(this, OverlayMonitorService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_body))
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPending)
            .addAction(0, getString(R.string.notif_action_stop), stopPending)
            .build()
    }

    private fun attachOverlayIfNeeded() {
        if (overlayView != null) return

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 48
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val view = FloatingOverlayView(this) { dx, dy, isFinished ->
            val activeView = overlayView ?: return@FloatingOverlayView
            val activeParams = layoutParams ?: return@FloatingOverlayView
            if (dx != 0 || dy != 0) {
                activeParams.x += dx
                activeParams.y += dy
                clampPositionToScreen(activeParams, activeView)
                try {
                    windowManager.updateViewLayout(activeView, activeParams)
                } catch (_: Exception) {
                    // Ignored
                }
            }
            if (isFinished) {
                val finalX = activeParams.x
                val finalY = activeParams.y
                serviceScope.launch {
                    prefsRepository.saveCustomOffset(finalX, finalY)
                }
            }
        }

        overlayView = view
        layoutParams = params

        try {
            windowManager.addView(view, params)
            view.post {
                applyPositionFromSettings(currentSettings)
            }
        } catch (_: Exception) {
            overlayView = null
            layoutParams = null
            stopOverlayAndSelf()
        }
    }

    private fun detachOverlay() {
        val view = overlayView ?: return
        try {
            windowManager.removeViewImmediate(view)
        } catch (_: Exception) {
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
                // Ignored
            }
        }
        overlayView = null
        layoutParams = null
    }

    private fun observeSettingsAndTelemetry() {
        if (settingsJob == null) {
            settingsJob = serviceScope.launch {
                prefsRepository.settingsFlow.collectLatest { settings ->
                    val intervalChanged = currentSettings.refreshIntervalMs != settings.refreshIntervalMs
                    val fallbackChanged =
                        currentSettings.useCompositorHzFallback != settings.useCompositorHzFallback
                    val positionChanged =
                        currentSettings.positionPreset != settings.positionPreset ||
                            currentSettings.customOffsetX != settings.customOffsetX ||
                            currentSettings.customOffsetY != settings.customOffsetY

                    currentSettings = settings
                    overlayView?.applySettings(settings)

                    if (positionChanged) {
                        overlayView?.post { applyPositionFromSettings(settings) }
                    }

                    if (settings.useCompositorHzFallback) {
                        startChoreographer()
                    } else {
                        stopChoreographer()
                    }

                    if (pollingJob == null || intervalChanged || fallbackChanged) {
                        restartTelemetryLoop(settings.refreshIntervalMs)
                    }
                }
            }
        }
    }

    private fun restartTelemetryLoop(intervalMs: Long) {
        pollingJob?.cancel()
        pollingJob = serviceScope.launch {
            while (isActive) {
                val snapshot = withContext(Dispatchers.Default) {
                    telemetryReader.readSnapshot(
                        compositorFps = latestCompositorFps,
                        allowCompositorFallback = currentSettings.useCompositorHzFallback,
                    )
                }
                OverlayStateHolder.updateSnapshot(snapshot)
                overlayView?.renderSnapshot(snapshot)
                delay(intervalMs)
            }
        }
    }

    private fun startChoreographer() {
        if (choreographerActive) return
        choreographerActive = true
        frameWindowStartNs = 0L
        frameCount = 0
        latestCompositorFps = null
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    private fun stopChoreographer() {
        if (!choreographerActive) return
        choreographerActive = false
        latestCompositorFps = null
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    private fun applyPositionFromSettings(settings: OverlaySettings) {
        val view = overlayView ?: return
        val params = layoutParams ?: return

        val dm = resources.displayMetrics
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels
        val viewW = view.width.takeIf { it > 0 } ?: view.measuredWidth.takeIf { it > 0 } ?: 320
        val viewH = view.height.takeIf { it > 0 } ?: view.measuredHeight.takeIf { it > 0 } ?: 64

        val marginH = (12 * dm.density).roundToInt()
        val topSafe = (36 * dm.density).roundToInt()
        val bottomSafe = (48 * dm.density).roundToInt()

        val customX = settings.customOffsetX
        val customY = settings.customOffsetY
        if (customX != null && customY != null) {
            params.x = customX
            params.y = customY
        } else {
            when (settings.positionPreset) {
                OverlayPositionPreset.TOP_START -> {
                    params.x = marginH
                    params.y = topSafe
                }
                OverlayPositionPreset.TOP_CENTER -> {
                    params.x = ((screenW - viewW) / 2).coerceAtLeast(marginH)
                    params.y = topSafe
                }
                OverlayPositionPreset.TOP_END -> {
                    params.x = (screenW - viewW - marginH).coerceAtLeast(marginH)
                    params.y = topSafe
                }
                OverlayPositionPreset.CENTER -> {
                    params.x = ((screenW - viewW) / 2).coerceAtLeast(marginH)
                    params.y = ((screenH - viewH) / 2).coerceAtLeast(topSafe)
                }
                OverlayPositionPreset.BOTTOM_CENTER -> {
                    params.x = ((screenW - viewW) / 2).coerceAtLeast(marginH)
                    params.y = (screenH - viewH - bottomSafe).coerceAtLeast(topSafe)
                }
            }
        }

        clampPositionToScreen(params, view)
        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: Exception) {
            // Ignored
        }
    }

    private fun clampPositionToScreen(params: WindowManager.LayoutParams, view: FloatingOverlayView) {
        val dm = resources.displayMetrics
        val viewW = view.width.takeIf { it > 0 } ?: view.measuredWidth
        val viewH = view.height.takeIf { it > 0 } ?: view.measuredHeight
        val maxX = (dm.widthPixels - viewW).coerceAtLeast(0)
        val maxY = (dm.heightPixels - viewH).coerceAtLeast(0)
        params.x = params.x.coerceIn(0, maxX)
        params.y = params.y.coerceIn(0, maxY)
    }

    private fun stopOverlayAndSelf() {
        stopChoreographer()
        pollingJob?.cancel()
        settingsJob?.cancel()
        detachOverlay()
        OverlayStateHolder.setOverlayRunning(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    companion object {
        private const val CHANNEL_ID = "statistics_overlay_channel"
        private const val NOTIFICATION_ID = 4102
        const val ACTION_START = "com.example.overlay.ACTION_START"
        const val ACTION_STOP = "com.example.overlay.ACTION_STOP"

        fun start(context: Context) {
            val intent = Intent(context, OverlayMonitorService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, OverlayMonitorService::class.java).apply {
                action = ACTION_STOP
            }
            context.stopService(intent)
        }
    }
}
