package com.example.overlay

import com.example.domain.model.SystemStatsSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Shared in-process state bridge between OverlayMonitorService and the Compose UI
 * so toggle button state and live telemetry stay synchronized instantly.
 */
object OverlayStateHolder {
    private val _isOverlayRunning = MutableStateFlow(false)
    val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

    private val _latestSnapshot = MutableStateFlow(SystemStatsSnapshot())
    val latestSnapshot: StateFlow<SystemStatsSnapshot> = _latestSnapshot.asStateFlow()

    fun setOverlayRunning(running: Boolean) {
        _isOverlayRunning.value = running
    }

    fun updateSnapshot(snapshot: SystemStatsSnapshot) {
        _latestSnapshot.value = snapshot
    }
}
