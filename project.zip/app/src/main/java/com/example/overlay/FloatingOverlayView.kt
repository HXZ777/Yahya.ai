package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.domain.model.DxvkStatus
import com.example.domain.model.OverlaySettings
import com.example.domain.model.StatType
import com.example.domain.model.SystemStatsSnapshot
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Lightweight native View rendered inside WindowManager for minimal CPU/memory footprint over games.
 * Visually mirrors the dark rounded horizontal pill with thin gray border, colored labels,
 * crisp off-white values, and thin vertical dividers.
 */
@SuppressLint("ViewConstructor")
class FloatingOverlayView(
    context: Context,
    private val onDragPositionChanged: (deltaX: Int, deltaY: Int, isFinished: Boolean) -> Unit,
) : FrameLayout(context) {

    private val pillContainer = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }

    private val backgroundDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
    }

    private val monoTypeface: Typeface =
        ResourcesCompat.getFont(context, R.font.jetbrains_mono) ?: Typeface.MONOSPACE

    private val statViews = mutableMapOf<StatType, TextView>()
    private val dividerViews = mutableListOf<View>()

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var isDragging = false

    private var currentSettings = OverlaySettings()
    private var currentSnapshot = SystemStatsSnapshot()

    init {
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        pillContainer.background = backgroundDrawable
        addView(
            pillContainer,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT),
        )

        StatType.ORDERED.forEachIndexed { index, statType ->
            val tv = TextView(context).apply {
                typeface = monoTypeface
                includeFontPadding = false
                maxLines = 1
                setSingleLine(true)
            }
            statViews[statType] = tv
            pillContainer.addView(
                tv,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ),
            )

            if (index < StatType.ORDERED.lastIndex) {
                val divider = View(context).apply {
                    setBackgroundColor(Color.parseColor("#2B303A"))
                }
                dividerViews.add(divider)
                pillContainer.addView(
                    divider,
                    LinearLayout.LayoutParams(dp(1f), dp(12f)),
                )
            }
        }

        applySettings(currentSettings)
        renderSnapshot(currentSnapshot)
    }

    fun applySettings(settings: OverlaySettings) {
        currentSettings = settings
        val scale = settings.scalePercent / 100f

        val bgAlpha = (settings.backgroundAlpha * 255f).roundToInt().coerceIn(40, 255)
        val borderAlpha = ((settings.backgroundAlpha * 0.85f + 0.15f) * 255f).roundToInt().coerceIn(70, 255)

        backgroundDrawable.setColor(Color.argb(bgAlpha, 10, 11, 14))
        backgroundDrawable.setStroke(dp(1f).coerceAtLeast(1), Color.argb(borderAlpha, 44, 48, 58))
        backgroundDrawable.cornerRadius = dpF(8f * scale)

        val hPad = dp(8f * scale)
        val vPad = dp(4.5f * scale)
        pillContainer.setPadding(hPad, vPad, hPad, vPad)

        val itemGap = dp(6f * scale)
        val dividerHeight = dp(12f * scale)

        statViews.values.forEach { tv ->
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, settings.fontSizeSp * scale)
            tv.setPadding(itemGap, 0, itemGap, 0)
        }

        dividerViews.forEach { divider ->
            val lp = divider.layoutParams as LinearLayout.LayoutParams
            lp.width = dp(1f).coerceAtLeast(1)
            lp.height = dividerHeight
            divider.layoutParams = lp
        }

        renderSnapshot(currentSnapshot)
    }

    fun renderSnapshot(snapshot: SystemStatsSnapshot) {
        currentSnapshot = snapshot
        val settings = currentSettings

        val visibleStats = StatType.ORDERED.filter { stat ->
            if (!settings.enabledStats.contains(stat)) return@filter false
            if (stat == StatType.DXVK && settings.hideDxvkWhenNotDetected &&
                snapshot.dxvkStatus == DxvkStatus.NOT_DETECTED
            ) {
                return@filter false
            }
            true
        }

        // If user toggled everything off, keep a minimal pill hint rather than an invisible 0px window
        if (visibleStats.isEmpty()) {
            statViews.forEach { (stat, tv) ->
                if (stat == StatType.CPU) {
                    tv.visibility = View.VISIBLE
                    tv.text = "STATS OFF"
                    tv.setTextColor(Color.parseColor("#94A3B8"))
                } else {
                    tv.visibility = View.GONE
                }
            }
            dividerViews.forEach { it.visibility = View.GONE }
            return
        }

        val visibleSet = visibleStats.toSet()
        StatType.ORDERED.forEach { stat ->
            val tv = statViews[stat] ?: return@forEach
            if (stat in visibleSet) {
                tv.visibility = View.VISIBLE
                tv.text = buildStatSpan(stat, snapshot, settings)
            } else {
                tv.visibility = View.GONE
            }
        }

        // Show dividers strictly between adjacent visible stats (never leading/trailing)
        dividerViews.forEach { it.visibility = View.GONE }
        var seenVisible = false
        StatType.ORDERED.forEachIndexed { index, stat ->
            if (stat in visibleSet) {
                if (seenVisible && index - 1 >= 0) {
                    // Find previous visible stat's divider (the divider right before this stat)
                    dividerViews[index - 1].visibility = View.VISIBLE
                }
                seenVisible = true
            }
        }
    }

    private fun buildStatSpan(
        stat: StatType,
        snapshot: SystemStatsSnapshot,
        settings: OverlaySettings,
    ): CharSequence {
        val labelColorLong = settings.statColors[stat] ?: 0xFFFFFFFFL
        val labelColor = labelColorLong.toInt()
        val valueColor = Color.parseColor("#F1F5F9")
        val mutedColor = Color.parseColor("#94A3B8")

        val (label, value, isUnavailable) = when (stat) {
            StatType.DXVK -> {
                if (snapshot.dxvkStatus == DxvkStatus.DETECTED) {
                    Triple("DXVK", "", false)
                } else {
                    Triple("DXVK", "N/A", true)
                }
            }
            StatType.CPU -> {
                val v = snapshot.cpuPercent?.let { "$it%" } ?: "N/A"
                Triple("CPU", v, snapshot.cpuPercent == null)
            }
            StatType.RAM -> {
                val v = snapshot.ramPercent?.let { "$it%" } ?: "N/A"
                Triple("RAM", v, snapshot.ramPercent == null)
            }
            StatType.PWR -> {
                val v = snapshot.powerWatts?.let {
                    String.format(Locale.US, "%.1fW", it)
                } ?: "N/A"
                Triple("PWR", v, snapshot.powerWatts == null)
            }
            StatType.TMP -> {
                val v = snapshot.tempCelsius?.let {
                    String.format(Locale.US, "%.1f°C", it)
                } ?: "N/A"
                Triple("TMP", v, snapshot.tempCelsius == null)
            }
            StatType.FPS -> {
                val v = snapshot.fpsValue?.toString() ?: "N/A"
                Triple("FPS", v, snapshot.fpsValue == null)
            }
        }

        val builder = SpannableStringBuilder()
        builder.append(label)
        builder.setSpan(
            ForegroundColorSpan(labelColor),
            0,
            label.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
        )

        if (value.isNotEmpty()) {
            val start = builder.length
            builder.append(" ").append(value)
            builder.setSpan(
                ForegroundColorSpan(if (isUnavailable) mutedColor else valueColor),
                start,
                builder.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
            )
        }
        return builder
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                lastRawX = event.rawX
                lastRawY = event.rawY
                isDragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val totalDx = event.rawX - downRawX
                val totalDy = event.rawY - downRawY
                if (!isDragging && (abs(totalDx) > touchSlop || abs(totalDy) > touchSlop)) {
                    isDragging = true
                }
                if (isDragging) {
                    val stepDx = (event.rawX - lastRawX).roundToInt()
                    val stepDy = (event.rawY - lastRawY).roundToInt()
                    lastRawX = event.rawX
                    lastRawY = event.rawY
                    if (stepDx != 0 || stepDy != 0) {
                        onDragPositionChanged(stepDx, stepDy, false)
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDragging) {
                    onDragPositionChanged(0, 0, true)
                }
                isDragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun dp(value: Float): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value,
        resources.displayMetrics,
    ).roundToInt()

    private fun dpF(value: Float): Float = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value,
        resources.displayMetrics,
    )
}
