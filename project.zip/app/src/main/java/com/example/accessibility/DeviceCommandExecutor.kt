package com.example.accessibility

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.domain.model.CompanionCommand
import com.example.voice.ArabicTtsEngine
import java.util.Locale

data class ExecutionOutcome(
    val success: Boolean,
    val detail: String,
)

class DeviceCommandExecutor(
    private val context: Context,
    private val ttsEngine: ArabicTtsEngine,
) {

    fun execute(command: CompanionCommand, autoSpeakReplies: Boolean): ExecutionOutcome {
        return when (command) {
            is CompanionCommand.Speak -> {
                if (autoSpeakReplies) {
                    ttsEngine.speak(command.text)
                    ExecutionOutcome(true, "تم نطق الرد: ${command.text}")
                } else {
                    ExecutionOutcome(true, "وصل الرد النصي (النطق التلقائي معطّل): ${command.text}")
                }
            }

            is CompanionCommand.OpenUrl -> openUrl(command.url)
            is CompanionCommand.OpenApp -> openApp(command.packageName, command.appName)

            is CompanionCommand.Tap -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(false, "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.")
                val (ok, msg) = service.tapByTextOrCoordinates(command.targetText, command.x, command.y)
                ExecutionOutcome(ok, msg)
            }

            is CompanionCommand.Scroll -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(false, "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.")
                val (ok, msg) = service.scrollScreen(command.direction)
                ExecutionOutcome(ok, msg)
            }

            is CompanionCommand.TypeText -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(false, "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.")
                val (ok, msg) = service.typeText(command.text, command.targetHint)
                ExecutionOutcome(ok, msg)
            }

            is CompanionCommand.GlobalAction -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(false, "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.")
                val (ok, msg) = service.performSystemAction(command.action)
                ExecutionOutcome(ok, msg)
            }
        }
    }

    private fun openUrl(rawUrl: String): ExecutionOutcome {
        val normalized = if (rawUrl.startsWith("http://", true) || rawUrl.startsWith("https://", true)) {
            rawUrl
        } else {
            "https://$rawUrl"
        }
        return runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ExecutionOutcome(true, "تم فتح الرابط: $normalized")
        }.getOrElse { e ->
            ExecutionOutcome(false, "تعذر فتح الرابط: ${e.localizedMessage ?: "خطأ غير معروف"}")
        }
    }

    private fun openApp(packageName: String?, appName: String?): ExecutionOutcome {
        val pm = context.packageManager
        if (!packageName.isNullOrBlank()) {
            val launch = pm.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return ExecutionOutcome(true, "تم فتح التطبيق ($packageName)")
            }
        }

        if (!appName.isNullOrBlank()) {
            val queryIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val activities = pm.queryIntentActivities(queryIntent, 0)
            val targetLower = appName.trim().lowercase(Locale.ROOT)
            val matched = activities.firstOrNull { info ->
                val label = info.loadLabel(pm).toString().lowercase(Locale.ROOT)
                val pkg = info.activityInfo.packageName.lowercase(Locale.ROOT)
                label == targetLower || label.contains(targetLower) || pkg.contains(targetLower)
            }
            if (matched != null) {
                val launch = pm.getLaunchIntentForPackage(matched.activityInfo.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    return ExecutionOutcome(true, "تم فتح تطبيق ${matched.loadLabel(pm)}")
                }
            }
            return ExecutionOutcome(false, "لم يتم العثور على تطبيق باسم \"$appName\" على الجهاز.")
        }

        return ExecutionOutcome(false, "لم يتم تحديد اسم التطبيق أو الحزمة.")
    }
}
