package com.example.accessibility

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.domain.model.AssistantCommand
import com.example.voice.ArabicTtsEngine
import java.util.Locale

data class ExecutionOutcome(
    val success: Boolean,
    val detail: String,
)

class DeviceCommandExecutor(
    private val context: Context,
    private val ttsEngine: ArabicTtsEngine,
) {

    fun executeLocalDeviceCommand(
        command: AssistantCommand,
        autoSpeakReplies: Boolean,
    ): ExecutionOutcome {
        return when (command) {
            is AssistantCommand.Speak -> {
                if (autoSpeakReplies) {
                    ttsEngine.speak(command.text)
                    ExecutionOutcome(true, "تم نطق الرد: ${command.text}")
                } else {
                    ExecutionOutcome(true, "الرد النصي جاهز (النطق التلقائي معطّل): ${command.text}")
                }
            }

            is AssistantCommand.AskClarification -> {
                ExecutionOutcome(true, command.question)
            }

            is AssistantCommand.OpenUrl -> openUrl(command.url)
            is AssistantCommand.OpenApp -> openApp(command.packageName, command.appName)

            is AssistantCommand.ReadScreen -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(
                        false,
                        "خدمة تسهيل الوصول غير مفعّلة لقراءة الشاشة. يمكن تفعيلها يدوياً من تبويب التحكم.",
                    )
                val (ok, summary) = service.readScreenSummary()
                ExecutionOutcome(ok, summary)
            }

            is AssistantCommand.Tap -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(
                        false,
                        "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.",
                    )
                val (ok, msg) = service.tapByTextOrCoordinates(command.targetText, command.x, command.y)
                ExecutionOutcome(ok, msg)
            }

            is AssistantCommand.Scroll -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(
                        false,
                        "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.",
                    )
                val (ok, msg) = service.scrollScreen(command.direction)
                ExecutionOutcome(ok, msg)
            }

            is AssistantCommand.TypeText -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(
                        false,
                        "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.",
                    )
                val (ok, msg) = service.typeText(command.text, command.targetHint)
                ExecutionOutcome(ok, msg)
            }

            is AssistantCommand.GlobalAction -> {
                val service = YahyaAccessibilityService.instance
                    ?: return ExecutionOutcome(
                        false,
                        "خدمة تسهيل الوصول غير مفعّلة. فعّلها يدوياً من إعدادات التحكم.",
                    )
                val (ok, msg) = service.performSystemAction(command.action)
                ExecutionOutcome(ok, msg)
            }

            is AssistantCommand.WebSearch,
            is AssistantCommand.FetchWebpage,
            -> ExecutionOutcome(false, "أمر ويب يُنفّذ عبر محرك الإنترنت في HXZ AI.")
        }
    }

    private fun openUrl(rawUrl: String): ExecutionOutcome {
        val trimmed = rawUrl.trim()
        val normalized = when {
            trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true) -> trimmed
            trimmed.contains("://") -> return ExecutionOutcome(false, "نوع الرابط غير مدعوم لأسباب أمنية.")
            else -> "https://$trimmed"
        }
        return runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ExecutionOutcome(true, "تم فتح الرابط في المتصفح: $normalized")
        }.getOrElse { e ->
            ExecutionOutcome(false, "تعذر فتح الرابط: ${e.localizedMessage ?: "خطأ غير معروف"}")
        }
    }

    private fun openApp(packageName: String?, appName: String?): ExecutionOutcome {
        val pm = context.packageManager
        if (!packageName.isNullOrBlank()) {
            val launch = pm.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return ExecutionOutcome(true, "تم فتح التطبيق ($packageName)")
            }
        }

        if (!appName.isNullOrBlank()) {
            val queryIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val activities = pm.queryIntentActivities(queryIntent, 0)
            val targetLower = appName.trim().lowercase(Locale.ROOT)
            val matched = activities.firstOrNull { info ->
                val label = info.loadLabel(pm).toString().lowercase(Locale.ROOT)
                val pkg = info.activityInfo.packageName.lowercase(Locale.ROOT)
                label == targetLower || label.contains(targetLower) || pkg.contains(targetLower)
            }
            if (matched != null) {
                val launch = pm.getLaunchIntentForPackage(matched.activityInfo.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    return ExecutionOutcome(true, "تم فتح تطبيق ${matched.loadLabel(pm)}")
                }
            }
            return ExecutionOutcome(false, "لم يتم العثور على تطبيق باسم \"$appName\" على الجهاز.")
        }

        return ExecutionOutcome(false, "لم يتم تحديد اسم التطبيق أو الحزمة.")
    }
}
