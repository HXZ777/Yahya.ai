package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.domain.model.AccessibilityHealth
import com.example.domain.model.GlobalDeviceAction
import com.example.domain.model.ScrollDirection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class YahyaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isBound.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Events keep window hierarchy fresh for on-demand control commands
    }

    override fun onInterrupt() {
        // No continuous stream held
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        _isBound.value = false
    }

    fun tapByTextOrCoordinates(
        targetText: String?,
        x: Float?,
        y: Float?,
    ): Pair<Boolean, String> {
        val root = rootInActiveWindow
        if (!targetText.isNullOrBlank() && root != null) {
            val matches = root.findAccessibilityNodeInfosByText(targetText)
            val node = matches?.firstOrNull { it.isVisibleToUser }
                ?: findNodeByDescription(root, targetText)
            if (node != null) {
                var clickable: AccessibilityNodeInfo? = node
                while (clickable != null && !clickable.isClickable) {
                    clickable = clickable.parent
                }
                if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true to "تم النقر على \"$targetText\""
                }
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty) {
                    val tapped = dispatchTapGesture(rect.exactCenterX(), rect.exactCenterY())
                    return tapped to if (tapped) {
                        "تم النقر بالإيماءة على \"$targetText\""
                    } else {
                        "تعذر تنفيذ النقر على \"$targetText\""
                    }
                }
            }
            return false to "لم يتم العثور على عنصر باسم \"$targetText\" في الشاشة الحالية."
        }

        if (x != null && y != null) {
            val tapped = dispatchTapGesture(x, y)
            return tapped to if (tapped) {
                "تم النقر عند الإحداثيات (${x.toInt()}, ${y.toInt()})"
            } else {
                "تعذر تنفيذ النقر عند الإحداثيات المطلوبة."
            }
        }

        return false to "لم يتم تحديد هدف أو إحداثيات للنقر."
    }

    fun scrollScreen(direction: ScrollDirection): Pair<Boolean, String> {
        val root = rootInActiveWindow
        if (root != null) {
            val scrollable = findScrollableNode(root)
            if (scrollable != null) {
                val action = when (direction) {
                    ScrollDirection.DOWN, ScrollDirection.RIGHT -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    ScrollDirection.UP, ScrollDirection.LEFT -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                }
                if (scrollable.performAction(action)) {
                    return true to "تم التمرير (${direction.name})"
                }
            }
        }

        val metrics = resources.displayMetrics
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        val path = Path()
        when (direction) {
            ScrollDirection.DOWN -> {
                path.moveTo(w * 0.5f, h * 0.72f)
                path.lineTo(w * 0.5f, h * 0.28f)
            }
            ScrollDirection.UP -> {
                path.moveTo(w * 0.5f, h * 0.28f)
                path.lineTo(w * 0.5f, h * 0.72f)
            }
            ScrollDirection.LEFT -> {
                path.moveTo(w * 0.8f, h * 0.5f)
                path.lineTo(w * 0.2f, h * 0.5f)
            }
            ScrollDirection.RIGHT -> {
                path.moveTo(w * 0.2f, h * 0.5f)
                path.lineTo(w * 0.8f, h * 0.5f)
            }
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 280L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val dispatched = dispatchGesture(gesture, null, null)
        return dispatched to if (dispatched) "تم التمرير بالإيماءة" else "تعذر تنفيذ التمرير"
    }

    fun typeText(text: String, targetHint: String?): Pair<Boolean, String> {
        val root = rootInActiveWindow
            ?: return false to "لا توجد نافذة نشطة للكتابة فيها."

        var editNode: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (editNode == null || !editNode.isEditable) {
            editNode = findEditableNode(root, targetHint)
        }
        if (editNode == null) {
            return false to "لم يتم العثور على حقل نصي نشط في الشاشة الحالية."
        }

        editNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return ok to if (ok) "تم إدخال النص بنجاح" else "رفض الحقل إدخال النص برمجياً."
    }

    fun performSystemAction(action: GlobalDeviceAction): Pair<Boolean, String> {
        val globalId = when (action) {
            GlobalDeviceAction.BACK -> GLOBAL_ACTION_BACK
            GlobalDeviceAction.HOME -> GLOBAL_ACTION_HOME
            GlobalDeviceAction.RECENTS -> GLOBAL_ACTION_RECENTS
            GlobalDeviceAction.NOTIFICATIONS -> GLOBAL_ACTION_NOTIFICATIONS
        }
        val ok = performGlobalAction(globalId)
        return ok to if (ok) "تم تنفيذ إجراء النظام: ${action.name}" else "تعذر تنفيذ إجراء النظام."
    }

    private fun dispatchTapGesture(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun findNodeByDescription(
        node: AccessibilityNodeInfo,
        query: String,
    ): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString().orEmpty()
        val txt = node.text?.toString().orEmpty()
        if ((desc.contains(query, ignoreCase = true) || txt.contains(query, ignoreCase = true)) && node.isVisibleToUser) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByDescription(child, query)
            if (found != null) return found
        }
        return null
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollableNode(child)
            if (found != null) return found
        }
        return null
    }

    private fun findEditableNode(
        node: AccessibilityNodeInfo,
        hint: String?,
    ): AccessibilityNodeInfo? {
        if (node.isEditable && node.isVisibleToUser) {
            if (hint.isNullOrBlank()) return node
            val nodeHint = node.hintText?.toString().orEmpty()
            val nodeText = node.text?.toString().orEmpty()
            if (nodeHint.contains(hint, ignoreCase = true) || nodeText.contains(hint, ignoreCase = true)) {
                return node
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditableNode(child, hint)
            if (found != null) return found
        }
        return if (!hint.isNullOrBlank()) findEditableNode(node, null) else null
    }

    companion object {
        @Volatile
        var instance: YahyaAccessibilityService? = null
            private set

        private val _isBound = MutableStateFlow(false)
        val isBound: StateFlow<Boolean> = _isBound.asStateFlow()

        fun isEnabledInSettings(context: Context): Boolean {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            ) ?: return false
            val expected = ComponentName(context, YahyaAccessibilityService::class.java).flattenToString()
            return enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
        }

        fun currentHealth(context: Context): AccessibilityHealth {
            return AccessibilityHealth(
                isEnabledInSettings = isEnabledInSettings(context),
                isServiceBound = instance != null || _isBound.value,
            )
        }
    }
}
