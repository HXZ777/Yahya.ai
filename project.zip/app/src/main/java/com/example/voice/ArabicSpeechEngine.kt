package com.example.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.example.domain.model.ListeningMode
import com.example.domain.model.MicStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ArabicSpeechEngine(
    private val context: Context,
    private val onTranscriptReady: (transcript: String, mode: ListeningMode) -> Unit,
    private val onStatusLog: (title: String, detail: String, isError: Boolean) -> Unit,
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _micStatus = MutableStateFlow(MicStatus.READY)
    val micStatus: StateFlow<MicStatus> = _micStatus.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var currentMode: ListeningMode = ListeningMode.PUSH_TO_TALK
    private var currentLanguage: String = "ar-SA"
    private var isActiveSession: Boolean = false
    private var awaitingCommandAfterWake: Boolean = false

    fun refreshAvailability(): MicStatus {
        val hasMicPerm = hasRecordPermission()
        val available = SpeechRecognizer.isRecognitionAvailable(context)
        val status = when {
            !hasMicPerm -> MicStatus.PERMISSION_MISSING
            !available -> MicStatus.UNAVAILABLE
            isActiveSession && currentMode == ListeningMode.CONTINUOUS_WAKE && !awaitingCommandAfterWake ->
                MicStatus.WAKE_ARMED
            isActiveSession -> MicStatus.LISTENING
            else -> MicStatus.READY
        }
        _micStatus.value = status
        return status
    }

    fun hasRecordPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun startListening(
        language: String,
        mode: ListeningMode,
        awaitingFollowUpAfterWake: Boolean = false,
    ) {
        currentLanguage = language
        currentMode = mode
        awaitingCommandAfterWake = awaitingFollowUpAfterWake

        mainHandler.post {
            if (!hasRecordPermission()) {
                _micStatus.value = MicStatus.PERMISSION_MISSING
                onStatusLog("صلاحية الميكروفون مطلوبة", "يرجى منح صلاحية الميكروفون أولاً.", true)
                return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _micStatus.value = MicStatus.UNAVAILABLE
                onStatusLog(
                    "محرك التعرف الصوتي غير متاح",
                    "تأكد من تفعيل خدمات Google أو محرك التعرف الصوتي في إعدادات النظام.",
                    true,
                )
                return@post
            }

            isActiveSession = true
            _partialTranscript.value = ""
            startRecognizerInternal()
        }
    }

    fun stopListening() {
        mainHandler.post {
            isActiveSession = false
            awaitingCommandAfterWake = false
            mainHandler.removeCallbacksAndMessages(null)
            runCatching { recognizer?.stopListening() }
            runCatching { recognizer?.destroy() }
            recognizer = null
            _rmsLevel.value = 0f
            _partialTranscript.value = ""
            refreshAvailability()
        }
    }

    private fun startRecognizerInternal() {
        runCatching { recognizer?.destroy() }
        val sr = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = sr

        sr.setRecognitionListener(
            object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _micStatus.value = if (
                        currentMode == ListeningMode.CONTINUOUS_WAKE && !awaitingCommandAfterWake
                    ) {
                        MicStatus.WAKE_ARMED
                    } else {
                        MicStatus.LISTENING
                    }
                }

                override fun onBeginningOfSpeech() {
                    _micStatus.value = MicStatus.LISTENING
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Normalize typical SpeechRecognizer rmsdB (-2..10+) into 0f..1f
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _rmsLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    _rmsLevel.value = 0f
                    if (isActiveSession) {
                        _micStatus.value = MicStatus.PROCESSING
                    }
                }

                override fun onError(error: Int) {
                    _rmsLevel.value = 0f
                    val shouldRestart = isActiveSession &&
                        currentMode == ListeningMode.CONTINUOUS_WAKE &&
                        (error == SpeechRecognizer.ERROR_NO_MATCH ||
                            error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_CLIENT)

                    if (shouldRestart) {
                        awaitingCommandAfterWake = false
                        _micStatus.value = MicStatus.WAKE_ARMED
                        mainHandler.postDelayed({
                            if (isActiveSession) startRecognizerInternal()
                        }, 400L)
                        return
                    }

                    isActiveSession = false
                    awaitingCommandAfterWake = false
                    val errorMsg = mapSpeechError(error)
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        _micStatus.value = MicStatus.ERROR
                        onStatusLog("خطأ التعرف الصوتي", errorMsg, true)
                    } else {
                        refreshAvailability()
                    }
                }

                override fun onResults(results: Bundle?) {
                    _rmsLevel.value = 0f
                    val candidates = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = candidates?.firstOrNull()?.trim().orEmpty()
                    _partialTranscript.value = best

                    if (currentMode == ListeningMode.PUSH_TO_TALK) {
                        isActiveSession = false
                        refreshAvailability()
                    }

                    if (best.isNotBlank()) {
                        onTranscriptReady(best, currentMode)
                    } else if (isActiveSession && currentMode == ListeningMode.CONTINUOUS_WAKE) {
                        mainHandler.postDelayed({
                            if (isActiveSession) startRecognizerInternal()
                        }, 350L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (partial.isNotBlank()) {
                        _partialTranscript.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            },
        )

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentLanguage)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, currentLanguage)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        sr.startListening(intent)
    }

    fun continueWakeCycle(awaitFollowUpCommand: Boolean) {
        awaitingCommandAfterWake = awaitFollowUpCommand
        if (isActiveSession && currentMode == ListeningMode.CONTINUOUS_WAKE) {
            mainHandler.postDelayed({
                if (isActiveSession) startRecognizerInternal()
            }, 350L)
        }
    }

    private fun mapSpeechError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "مشكلة في التقاط الصوت من الميكروفون."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "صلاحية الميكروفون غير ممنوحة."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "تعذر الاتصال بخدمة التعرف الصوتي عبر الشبكة."
        SpeechRecognizer.ERROR_NO_MATCH -> "لم يتم التعرف على كلام واضح."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "محرك التعرف الصوتي مشغول حالياً."
        SpeechRecognizer.ERROR_SERVER -> "خطأ في خادم التعرف الصوتي."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "انتهت مهلة الانتظار دون صوت."
        else -> "رمز خطأ التعرف الصوتي: $code"
    }
}
