package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class ArabicTtsEngine(context: Context) : TextToSpeech.OnInitListener {

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext, this)
    private var isReady: Boolean = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val saResult = tts.setLanguage(Locale("ar", "SA"))
            if (saResult == TextToSpeech.LANG_MISSING_DATA || saResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale("ar"))
            }
            isReady = true
        }
    }

    fun speak(text: String) {
        if (!isReady || text.isBlank()) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yahya_reply_${System.currentTimeMillis()}")
    }

    fun stop() {
        if (isReady) {
            tts.stop()
        }
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
