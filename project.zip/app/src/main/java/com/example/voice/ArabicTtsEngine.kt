package com.example.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.domain.model.TtsVoiceOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class ArabicTtsEngine(context: Context) : TextToSpeech.OnInitListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext, this)
    private var isReady: Boolean = false
    private var speechRate: Float = 1.0f
    private var preferredVoiceName: String? = null
    private var pendingCallback: (() -> Unit)? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val saResult = tts.setLanguage(Locale("ar", "SA"))
            if (saResult == TextToSpeech.LANG_MISSING_DATA || saResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale("ar"))
            }
            tts.setSpeechRate(speechRate)
            tts.setOnUtteranceProgressListener(
                object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        completeCurrentUtterance()
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        completeCurrentUtterance()
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        completeCurrentUtterance()
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        completeCurrentUtterance()
                    }
                },
            )
            refreshAvailableArabicVoices()
            preferredVoiceName?.let { applyVoiceByName(it) }
            isReady = true
        }
    }

    private fun completeCurrentUtterance() {
        _isSpeaking.value = false
        mainHandler.post {
            val callback = pendingCallback
            pendingCallback = null
            callback?.invoke()
        }
    }

    fun refreshAvailableArabicVoices() {
        val voices = runCatching { tts.voices }.getOrNull().orEmpty()
        val arabicVoices = voices
            .filter { voice ->
                voice.locale.language.equals("ar", ignoreCase = true) &&
                    !voice.isNetworkConnectionRequired
            }
            .ifEmpty {
                voices.filter { it.locale.language.equals("ar", ignoreCase = true) }
            }
            .sortedWith(compareBy<Voice> { it.locale.country }.thenBy { it.name })
            .distinctBy { it.name }
            .take(12)
            .mapIndexed { index, voice ->
                val country = voice.locale.displayCountry.ifBlank { voice.locale.toLanguageTag() }
                val qualityTag = if (voice.quality >= Voice.QUALITY_HIGH) "جودة عالية" else "قياسي"
                TtsVoiceOption(
                    name = voice.name,
                    displayLabel = "صوت عربي ${index + 1} ($country • $qualityTag)",
                    localeTag = voice.locale.toLanguageTag(),
                )
            }
        _availableVoices.value = arabicVoices
    }

    fun setSpeechRate(rate: Float) {
        speechRate = rate.coerceIn(0.6f, 1.8f)
        if (isReady) {
            runCatching { tts.setSpeechRate(speechRate) }
        }
    }

    fun setVoice(voiceName: String?) {
        preferredVoiceName = voiceName
        if (isReady) {
            if (voiceName.isNullOrBlank()) {
                val saResult = tts.setLanguage(Locale("ar", "SA"))
                if (saResult == TextToSpeech.LANG_MISSING_DATA || saResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale("ar"))
                }
            } else {
                applyVoiceByName(voiceName)
            }
        }
    }

    private fun applyVoiceByName(voiceName: String) {
        val target = runCatching { tts.voices }.getOrNull()
            ?.firstOrNull { it.name == voiceName }
        if (target != null) {
            runCatching { tts.voice = target }
        }
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        val clean = text.trim()
        if (!isReady || clean.isBlank()) {
            _isSpeaking.value = false
            onFinished?.invoke()
            return
        }
        pendingCallback = onFinished
        _isSpeaking.value = true
        val utteranceId = "hxz_reply_${System.currentTimeMillis()}"
        val res = tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (res == TextToSpeech.ERROR) {
            completeCurrentUtterance()
        }
    }

    fun stop() {
        pendingCallback = null
        _isSpeaking.value = false
        if (isReady) {
            runCatching { tts.stop() }
        }
    }

    fun shutdown() {
        pendingCallback = null
        _isSpeaking.value = false
        runCatching {
            tts.stop()
            tts.shutdown()
        }
    }
}
