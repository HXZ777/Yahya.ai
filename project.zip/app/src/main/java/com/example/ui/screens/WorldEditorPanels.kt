package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.vr.model.AppLanguage
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.TimeOfDay
import com.example.vr.model.WorldLightingConfig
import com.example.vr.model.WorldNodeEntry
import com.example.vr.model.WorldObjectCategory
import com.example.vr.model.WorldProjectState
import com.example.vr.world.WorldEditorManager
import com.example.vr.world.WorldEditorUiState

@Composable
fun SceneHierarchyPanel(
    editorState: WorldEditorUiState,
    editorManager: WorldEditorManager,
    language: AppLanguage,
    strings: AppStrings,
    onMutated: () -> Unit
) {
    val project = editorState.project ?: return
    var renameTarget by remember { mutableStateOf<WorldNodeEntry?>(null) }
    var renameText by remember { mutableStateOf("") }
    var showGroupDialog by remember { mutableStateOf(false) }
    var groupNameInput by remember { mutableStateOf("Group 1") }
    var selectedForGroup by remember { mutableStateOf<Set<String>>(emptySet()) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(strings.sceneHierarchyTitle, style = MaterialTheme.typography.titleSmall, color = VrCyan)
            OutlinedButton(
                onClick = {
                    selectedForGroup = editorState.selectedNodeId?.let { setOf(it) } ?: emptySet()
                    groupNameInput = "Group ${project.nodes.count { it.isGroup } + 1}"
                    showGroupDialog = true
                },
                modifier = Modifier.testTag("hierarchy_create_group_btn")
            ) {
                Icon(Icons.Filled.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(strings.createGroup, style = MaterialTheme.typography.labelSmall)
            }
        }

        // World Root Row
        Surface(
            onClick = { editorManager.selectWholeWorld() },
            shape = RoundedCornerShape(10.dp),
            color = if (editorState.wholeWorldSelected) VrCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, if (editorState.wholeWorldSelected) VrCyan else MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.Public, contentDescription = null, tint = VrCyan, modifier = Modifier.size(18.dp))
                Text(
                    text = "World (${if (language == AppLanguage.ARABIC) project.titleAr else project.titleEn})",
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Custom Groups first
        val groups = project.nodes.filter { it.isGroup }
        groups.forEach { grp ->
            val children = project.nodes.filter { it.parentId == grp.id && !it.isGroup }
            HierarchyNodeRow(
                node = grp,
                isSelected = editorState.selectedNodeId == grp.id,
                indentDp = 8,
                onSelect = { editorManager.selectNode(grp.id) },
                onRename = { renameTarget = grp; renameText = grp.name },
                onToggleVisible = { editorManager.toggleNodeVisibility(grp.id); onMutated() },
                onToggleCollision = { editorManager.toggleNodeCollision(grp.id); onMutated() },
                onMoveUp = { editorManager.moveNodeOrder(grp.id, -1); onMutated() },
                onMoveDown = { editorManager.moveNodeOrder(grp.id, 1); onMutated() }
            )
            children.forEach { child ->
                HierarchyNodeRow(
                    node = child,
                    isSelected = editorState.selectedNodeId == child.id,
                    indentDp = 24,
                    onSelect = { editorManager.selectNode(child.id) },
                    onRename = { renameTarget = child; renameText = child.name },
                    onToggleVisible = { editorManager.toggleNodeVisibility(child.id); onMutated() },
                    onToggleCollision = { editorManager.toggleNodeCollision(child.id); onMutated() },
                    onMoveUp = { editorManager.moveNodeOrder(child.id, -1); onMutated() },
                    onMoveDown = { editorManager.moveNodeOrder(child.id, 1); onMutated() }
                )
            }
        }

        // Categorized ungrouped nodes
        val categories = listOf(
            WorldObjectCategory.BUILDINGS to (if (language == AppLanguage.ARABIC) "المباني (Buildings)" else "Buildings"),
            WorldObjectCategory.ENVIRONMENT to (if (language == AppLanguage.ARABIC) "البيئة والأشجار (Environment)" else "Environment"),
            WorldObjectCategory.FURNITURE to (if (language == AppLanguage.ARABIC) "الأثاث (Furniture)" else "Furniture"),
            WorldObjectCategory.LIGHTS to (if (language == AppLanguage.ARABIC) "الإضاءة (Lights)" else "Lights"),
            WorldObjectCategory.IMPORTED_MODELS to (if (language == AppLanguage.ARABIC) "المجسمات المستوردة" else "Imported Models")
        )
        categories.forEach { (cat, catTitle) ->
            val items = project.nodes.filter { !it.isGroup && it.parentId == null && it.category == cat }
            if (items.isNotEmpty()) {
                Text(catTitle, style = MaterialTheme.typography.labelSmall, color = VrAmber, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
                items.forEach { node ->
                    HierarchyNodeRow(
                        node = node,
                        isSelected = editorState.selectedNodeId == node.id,
                        indentDp = 14,
                        onSelect = { editorManager.selectNode(node.id) },
                        onRename = { renameTarget = node; renameText = node.name },
                        onToggleVisible = { editorManager.toggleNodeVisibility(node.id); onMutated() },
                        onToggleCollision = { editorManager.toggleNodeCollision(node.id); onMutated() },
                        onMoveUp = { editorManager.moveNodeOrder(node.id, -1); onMutated() },
                        onMoveDown = { editorManager.moveNodeOrder(node.id, 1); onMutated() }
                    )
                }
            }
        }

        // Spawn Points branch
        Text(
            text = if (language == AppLanguage.ARABIC) "نقاط البداية (Spawn Points)" else "Spawn Points",
            style = MaterialTheme.typography.labelSmall,
            color = VrEmerald,
            modifier = Modifier.padding(start = 6.dp, top = 4.dp)
        )
        project.spawnPoints.forEach { sp ->
            Surface(
                onClick = { editorManager.selectSpawnPoint(sp.id) },
                shape = RoundedCornerShape(8.dp),
                color = if (editorState.selectedSpawnId == sp.id) VrEmerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, if (editorState.selectedSpawnId == sp.id) VrEmerald else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier.padding(start = 14.dp).fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = if (sp.isPrimary) VrEmerald else VrAmber, modifier = Modifier.size(16.dp))
                    Text(
                        text = if (sp.isPrimary) "${sp.name} ★" else sp.name,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(strings.renameItem) },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    editorManager.renameNode(target.id, renameText)
                    onMutated()
                    renameTarget = null
                }) { Text(strings.apply) }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text(strings.cancel) } }
        )
    }

    if (showGroupDialog) {
        AlertDialog(
            onDismissRequest = { showGroupDialog = false },
            title = { Text(strings.createGroup) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = groupNameInput,
                        onValueChange = { groupNameInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    project.nodes.filter { !it.isGroup }.take(8).forEach { node ->
                        val checked = node.id in selectedForGroup
                        FilterChip(
                            selected = checked,
                            onClick = {
                                selectedForGroup = if (checked) selectedForGroup - node.id else selectedForGroup + node.id
                            },
                            label = { Text(node.name, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    editorManager.createGroupAndAssign(groupNameInput, selectedForGroup.toList())
                    onMutated()
                    showGroupDialog = false
                }) { Text(strings.apply) }
            },
            dismissButton = { TextButton(onClick = { showGroupDialog = false }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun HierarchyNodeRow(
    node: WorldNodeEntry,
    isSelected: Boolean,
    indentDp: Int,
    onSelect: () -> Unit,
    onRename: () -> Unit,
    onToggleVisible: () -> Unit,
    onToggleCollision: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) VrCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (isSelected) VrCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = indentDp.dp)
            .testTag("hierarchy_node_${node.id}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (node.isGroup) {
                Icon(Icons.Filled.Folder, contentDescription = null, tint = VrAmber, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                text = node.name,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onMoveUp, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Filled.ArrowUpward, contentDescription = "Up", modifier = Modifier.size(14.dp))
            }
            IconButton(onClick = onMoveDown, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Filled.ArrowDownward, contentDescription = "Down", modifier = Modifier.size(14.dp))
            }
            IconButton(onClick = onRename, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Filled.Edit, contentDescription = "Rename", modifier = Modifier.size(14.dp))
            }
            IconButton(onClick = onToggleCollision, modifier = Modifier.size(34.dp)) {
                Icon(
                    Icons.Filled.Shield,
                    contentDescription = "Collision",
                    tint = if (node.collisionEnabled) VrEmerald else Color.Gray,
                    modifier = Modifier.size(14.dp)
                )
            }
            IconButton(onClick = onToggleVisible, modifier = Modifier.size(34.dp)) {
                Icon(
                    if (node.visible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = "Visibility",
                    tint = if (node.visible) VrCyan else Color.Gray,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MaterialInspectorPanel(
    project: WorldProjectState,
    editorManager: WorldEditorManager,
    language: AppLanguage,
    strings: AppStrings,
    onPickTextureForMaterial: (PbrMaterialSpec, Uri) -> Unit,
    onMutated: () -> Unit
) {
    var selectedMatId by remember(project.worldId) { mutableStateOf(project.materials.firstOrNull()?.id) }
    val activeMat = project.materials.find { it.id == selectedMatId } ?: project.materials.firstOrNull()

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null && activeMat != null) {
            onPickTextureForMaterial(activeMat, uri)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(strings.materialsTitle, style = MaterialTheme.typography.titleSmall, color = VrCyan)

        // Import & Material Diagnostics Summary Card
        val diag = project.diagnostics
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, if (diag.missingTextures.isNotEmpty() || diag.missingMtlFiles.isNotEmpty()) VrAmber else VrEmerald.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        if (diag.missingTextures.isNotEmpty()) Icons.Filled.Warning else Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = if (diag.missingTextures.isNotEmpty()) VrAmber else VrEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(strings.diagnosticsReportTitle, style = MaterialTheme.typography.labelLarge)
                }
                Text(
                    text = if (language == AppLanguage.ARABIC) diag.summaryAr.ifEmpty { "الخامات: ${project.materials.size}" } else diag.summaryEn.ifEmpty { "Materials: ${project.materials.size}" },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (diag.missingTextures.isNotEmpty()) {
                    Text(
                        text = (if (language == AppLanguage.ARABIC) "خامات مفقودة: " else "Missing textures: ") + diag.missingTextures.joinToString(", "),
                        style = MaterialTheme.typography.labelSmall,
                        color = VrAmber
                    )
                }
                if (diag.missingMtlFiles.isNotEmpty()) {
                    Text(
                        text = (if (language == AppLanguage.ARABIC) "ملفات MTL مفقودة: " else "Missing MTL: ") + diag.missingMtlFiles.joinToString(", "),
                        style = MaterialTheme.typography.labelSmall,
                        color = VrCoral
                    )
                }
                if (diag.fixesApplied.isNotEmpty()) {
                    Text(
                        text = (if (language == AppLanguage.ARABIC) "إصلاحات تلقائية: " else "Auto-fixes: ") + diag.fixesApplied.joinToString(" • "),
                        style = MaterialTheme.typography.labelSmall,
                        color = VrEmerald
                    )
                }
            }
        }

        if (project.materials.isEmpty()) {
            Text(
                text = if (language == AppLanguage.ARABIC) "لا توجد خامات مضمنة في هذا المشهد." else "No materials found in this scene.",
                style = MaterialTheme.typography.bodySmall
            )
            return
        }

        // Material selector chips
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            project.materials.forEach { mat ->
                val warn = mat.missingTextureName != null && mat.texturePath == null
                FilterChip(
                    selected = activeMat?.id == mat.id,
                    onClick = { selectedMatId = mat.id },
                    label = {
                        Text(
                            text = (if (warn) "⚠ " else "") + mat.name.take(18),
                            maxLines = 1
                        )
                    }
                )
            }
        }

        activeMat?.let { mat ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(mat.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = when {
                                mat.userModified -> if (language == AppLanguage.ARABIC) "معدّل يدوياً" else "Edited"
                                mat.texturePath != null -> if (language == AppLanguage.ARABIC) "خامة أصلية سليمة ✓" else "Original Texture ✓"
                                else -> if (language == AppLanguage.ARABIC) "لون مادي" else "Color Material"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (mat.texturePath != null && !mat.userModified) VrEmerald else VrCyan
                        )
                    }

                    if (mat.missingTextureName != null && mat.texturePath == null) {
                        Text(
                            text = (if (language == AppLanguage.ARABIC) "تحذير: الخامة المفقودة '${mat.missingTextureName}' — اختر صورة بديلة أو لون:" else "Missing texture '${mat.missingTextureName}' — pick a replacement:"),
                            style = MaterialTheme.typography.labelSmall,
                            color = VrAmber
                        )
                    }

                    Text(strings.materialColorLabel, style = MaterialTheme.typography.labelMedium)
                    val colorPresets = listOf(
                        0xFFFFFFFFL, 0xFF3E8E41L, 0xFF8D6E63L, 0xFFCBD5E1L,
                        0xFF38BDF8L, 0xFFF59E0BL, 0xFFEF4444L, 0xFF1E293BL
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        colorPresets.forEach { argb ->
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Color(argb.toInt()))
                                    .clickable {
                                        editorManager.updateMaterial(mat.copy(baseColorArgb = argb, userModified = true))
                                        onMutated()
                                    }
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth().testTag("material_pick_texture_btn")
                    ) {
                        Icon(Icons.Filled.Image, contentDescription = null, tint = VrCyan)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.changeTextureBtn)
                    }

                    SettingSliderRow(
                        title = strings.metallicLabel,
                        valueText = "${(mat.metallic * 100).toInt()}%",
                        value = mat.metallic,
                        range = 0f..1f,
                        onValueChange = { v -> editorManager.updateMaterial(mat.copy(metallic = v)); onMutated() }
                    )
                    SettingSliderRow(
                        title = strings.roughnessLabel,
                        valueText = "${(mat.roughness * 100).toInt()}%",
                        value = mat.roughness,
                        range = 0.05f..1f,
                        onValueChange = { v -> editorManager.updateMaterial(mat.copy(roughness = v)); onMutated() }
                    )
                    SettingSliderRow(
                        title = strings.transparencyLabel,
                        valueText = "${(mat.alpha * 100).toInt()}%",
                        value = mat.alpha,
                        range = 0.1f..1f,
                        onValueChange = { v -> editorManager.updateMaterial(mat.copy(alpha = v)); onMutated() }
                    )
                    SettingSliderRow(
                        title = strings.reflectivityLabel,
                        valueText = "${(mat.reflectivity * 100).toInt()}%",
                        value = mat.reflectivity,
                        range = 0f..1f,
                        onValueChange = { v -> editorManager.updateMaterial(mat.copy(reflectivity = v)); onMutated() }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SpawnPointsPanel(
    project: WorldProjectState,
    editorState: WorldEditorUiState,
    editorManager: WorldEditorManager,
    strings: AppStrings,
    onTestSpawn: (SpawnPointEntry) -> Unit,
    onMutated: () -> Unit
) {
    val activeSpawn = project.spawnPoints.find { it.id == editorState.selectedSpawnId }
        ?: project.spawnPoints.firstOrNull { it.isPrimary }
        ?: project.spawnPoints.firstOrNull()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(strings.spawnPointEditorTitle, style = MaterialTheme.typography.titleSmall, color = VrEmerald)
            OutlinedButton(
                onClick = { editorManager.addSpawnPoint(); onMutated() },
                modifier = Modifier.testTag("add_spawn_point_btn")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(strings.addSpawnPoint, style = MaterialTheme.typography.labelSmall)
            }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            project.spawnPoints.forEach { sp ->
                FilterChip(
                    selected = activeSpawn?.id == sp.id,
                    onClick = { editorManager.selectSpawnPoint(sp.id) },
                    label = { Text(if (sp.isPrimary) "${sp.name} ★" else sp.name) }
                )
            }
        }

        activeSpawn?.let { sp ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${sp.name}  (X=${String.format("%.1f", sp.x)}, Y=${String.format("%.1f", sp.y + sp.elevationOffset)}, Z=${String.format("%.1f", sp.z)})",
                        style = MaterialTheme.typography.labelMedium,
                        color = VrCyan
                    )
                    SettingSliderRow(
                        title = strings.spawnHeightLabel,
                        valueText = "${String.format("%.2f", sp.elevationOffset)} m",
                        value = sp.elevationOffset,
                        range = 0f..15f,
                        onValueChange = { v -> editorManager.updateSpawnElevation(sp.id, v); onMutated() }
                    )
                    SettingSliderRow(
                        title = strings.spawnRotationLabel,
                        valueText = "${sp.yawDeg.toInt()}°",
                        value = ((sp.yawDeg % 360f) + 360f) % 360f,
                        range = 0f..360f,
                        onValueChange = { v ->
                            val delta = v - (((sp.yawDeg % 360f) + 360f) % 360f)
                            editorManager.selectSpawnPoint(sp.id)
                            editorManager.applyTransformDelta(dRotY = delta, recordUndo = false)
                            onMutated()
                        }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { editorManager.setPrimarySpawn(sp.id); onMutated() },
                            enabled = !sp.isPrimary,
                            modifier = Modifier.weight(1f).testTag("set_primary_spawn_btn")
                        ) {
                            Text(strings.setPrimarySpawn, style = MaterialTheme.typography.labelSmall)
                        }
                        Button(
                            onClick = { onTestSpawn(sp) },
                            modifier = Modifier.weight(1f).testTag("test_spawn_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = VrEmerald, contentColor = VrObsidian)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.testSpawnPoint, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (project.spawnPoints.size > 1) {
                        OutlinedButton(
                            onClick = {
                                editorManager.selectSpawnPoint(sp.id)
                                editorManager.deleteSelected()
                                onMutated()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, VrCoral.copy(alpha = 0.6f))
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = null, tint = VrCoral, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.delete, color = VrCoral)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LightingSettingsPanel(
    project: WorldProjectState,
    editorManager: WorldEditorManager,
    strings: AppStrings,
    onMutated: () -> Unit
) {
    val l: WorldLightingConfig = project.lighting
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(strings.lightingEnvTitle, style = MaterialTheme.typography.titleSmall, color = VrCyan)

        Text(strings.timeOfDayTitle, style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TimeOfDay.entries.forEach { tod ->
                FilterChip(
                    selected = l.timeOfDay == tod,
                    onClick = { editorManager.updateLighting(l.copy(timeOfDay = tod)); onMutated() },
                    label = { Text(tod.name) }
                )
            }
        }

        SettingSliderRow(
            title = strings.dirLightIntensity,
            valueText = "${(l.directionalIntensity * 100).toInt()}%",
            value = l.directionalIntensity,
            range = 0.2f..2.0f,
            onValueChange = { v -> editorManager.updateLighting(l.copy(directionalIntensity = v)); onMutated() }
        )
        SettingSliderRow(
            title = strings.dirLightAngle,
            valueText = "${l.directionalAngleDeg.toInt()}°",
            value = l.directionalAngleDeg,
            range = 0f..360f,
            onValueChange = { v -> editorManager.updateLighting(l.copy(directionalAngleDeg = v)); onMutated() }
        )
        SettingSliderRow(
            title = strings.ambientLightIntensity,
            valueText = "${(l.ambientIntensity * 100).toInt()}%",
            value = l.ambientIntensity,
            range = 0.1f..1.2f,
            onValueChange = { v -> editorManager.updateLighting(l.copy(ambientIntensity = v)); onMutated() }
        )
        SettingSliderRow(
            title = strings.exposureLabel,
            valueText = String.format("%.2fx", l.exposure),
            value = l.exposure,
            range = 0.5f..1.8f,
            onValueChange = { v -> editorManager.updateLighting(l.copy(exposure = v)); onMutated() }
        )
        SettingSwitchRow(
            title = strings.fogDensityLabel,
            checked = l.fogEnabled,
            testTag = "editor_fog_switch",
            onCheckedChange = { v -> editorManager.updateLighting(l.copy(fogEnabled = v)); onMutated() }
        )
        if (l.fogEnabled) {
            SettingSliderRow(
                title = strings.fogDensityLabel,
                valueText = String.format("%.3f", l.fogDensity),
                value = l.fogDensity,
                range = 0.0f..0.04f,
                onValueChange = { v -> editorManager.updateLighting(l.copy(fogDensity = v)); onMutated() }
            )
        }
        SettingSwitchRow(
            title = strings.shadowsTitle,
            checked = l.shadowsEnabled,
            testTag = "editor_shadows_switch",
            onCheckedChange = { v -> editorManager.updateLighting(l.copy(shadowsEnabled = v)); onMutated() }
        )
        SettingSwitchRow(
            title = strings.reflectionsTitle,
            checked = l.reflectionsEnabled,
            testTag = "editor_reflections_switch",
            onCheckedChange = { v -> editorManager.updateLighting(l.copy(reflectionsEnabled = v)); onMutated() }
        )
        SettingSwitchRow(
            title = strings.collisionSettingLabel,
            checked = project.collisionEnabled,
            testTag = "editor_collision_switch",
            onCheckedChange = { v -> editorManager.setWorldCollisionEnabled(v); onMutated() }
        )
    }
}
