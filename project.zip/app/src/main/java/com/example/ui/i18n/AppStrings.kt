package com.example.ui.i18n

import com.example.domain.model.AppLanguage
import com.example.domain.model.CpuSource
import com.example.domain.model.FpsSource
import com.example.domain.model.OverlayPositionPreset
import com.example.domain.model.StatType
import com.example.domain.model.TempSource

data class AppStrings(
    val appTitle: String,
    val appSubtitle: String,
    val navHome: String,
    val navCustomize: String,
    val navAppearance: String,
    val navSettings: String,

    val statusActive: String,
    val statusStopped: String,
    val startOverlayButton: String,
    val stopOverlayButton: String,
    val overlayControlHint: String,

    val livePreviewTitle: String,
    val dragHint: String,
    val sensorTransparencyTitle: String,

    val permissionsTitle: String,
    val overlayPermTitle: String,
    val overlayPermDesc: String,
    val notifPermTitle: String,
    val notifPermDesc: String,
    val batteryOptTitle: String,
    val batteryOptDesc: String,
    val permGranted: String,
    val permRequired: String,
    val permOptional: String,
    val permGrantBtn: String,
    val permConfigureBtn: String,

    val overlayPermDialogTitle: String,
    val overlayPermDialogBody: String,
    val openSettingsBtn: String,
    val cancelBtn: String,

    val customizeTitle: String,
    val customizeSubtitle: String,
    val quickPresetsLabel: String,
    val presetFpsOnly: String,
    val presetCpuRam: String,
    val presetFpsTmp: String,
    val presetCore4: String,
    val presetAll: String,
    val enabledCountFormat: String,

    val appearanceTitle: String,
    val appearanceSubtitle: String,
    val scaleLabel: String,
    val opacityLabel: String,
    val fontSizeLabel: String,
    val positionLabel: String,
    val resetPositionBtn: String,
    val customDraggedActive: String,
    val colorsLabel: String,
    val resetColorsBtn: String,

    val settingsTitle: String,
    val settingsSubtitle: String,
    val languageSection: String,
    val arabicLabel: String,
    val englishLabel: String,
    val refreshRateSection: String,
    val refreshFast: String,
    val refreshBalanced: String,
    val refreshSaver: String,
    val telemetryOptionsSection: String,
    val compositorHzTitle: String,
    val compositorHzDesc: String,
    val hideDxvkTitle: String,
    val hideDxvkDesc: String,
    val magicosTitle: String,
    val magicosDesc: String,
    val openAppSettingsBtn: String,
    val aboutSection: String,
    val aboutVersion: String,
    val aboutArchNote: String,

    val notAvailable: String,
    val activeShort: String,
) {
    fun statTitle(stat: StatType): String = when (stat) {
        StatType.FPS -> if (this === ArabicStrings) "معدل الإطارات (FPS)" else "Frame Rate (FPS)"
        StatType.CPU -> if (this === ArabicStrings) "استخدام المعالج (CPU)" else "CPU Usage (CPU)"
        StatType.RAM -> if (this === ArabicStrings) "الذاكرة العشوائية (RAM)" else "Memory Usage (RAM)"
        StatType.PWR -> if (this === ArabicStrings) "استهلاك الطاقة (PWR)" else "Power Draw (PWR)"
        StatType.TMP -> if (this === ArabicStrings) "درجة الحرارة (TMP)" else "Temperature (TMP)"
        StatType.DXVK -> if (this === ArabicStrings) "حالة DXVK" else "DXVK Status"
    }

    fun statDescription(stat: StatType): String = when (stat) {
        StatType.FPS -> if (this === ArabicStrings) {
            "يعرض معدل الإطارات الفعلي عند توفر واجهة نظامية، أو N/A عند تقييده."
        } else {
            "Displays live frame rate when a readable system source is exposed, otherwise N/A."
        }
        StatType.CPU -> if (this === ArabicStrings) {
            "نسبة استخدام المعالج أو تردد الأنوية الفعلي."
        } else {
            "Real CPU utilization from kernel stats or core frequency scaling."
        }
        StatType.RAM -> if (this === ArabicStrings) {
            "نسبة الذاكرة العشوائية المستخدمة من إجمالي الرام."
        } else {
            "Active RAM utilization percentage via Android ActivityManager."
        }
        StatType.PWR -> if (this === ArabicStrings) {
            "القدرة بالواط من قراءة الجهد والتيار اللحظي للبطارية."
        } else {
            "Live wattage calculated from battery voltage and current."
        }
        StatType.TMP -> if (this === ArabicStrings) {
            "درجة الحرارة من مستشعرات النظام المتاحة مع توضيح مصدرها."
        } else {
            "Temperature from readable thermal zones or battery sensor (clearly labeled)."
        }
        StatType.DXVK -> if (this === ArabicStrings) {
            "يكتشف بيئة DXVK فعلياً عند تشغيلها فقط."
        } else {
            "Shows DXVK state only when a genuine DXVK environment/layer is detected."
        }
    }

    fun cpuSourceLabel(source: CpuSource): String = when (source) {
        CpuSource.PROC_STAT -> if (this === ArabicStrings) "المصدر: /proc/stat" else "Source: /proc/stat"
        CpuSource.CPU_FREQ_SCALING -> if (this === ArabicStrings) "المصدر: تردد الأنوية (CPUFreq)" else "Source: CPUFreq Scaling"
        CpuSource.UNAVAILABLE -> if (this === ArabicStrings) "المصدر: مقيد من النظام" else "Source: Restricted"
    }

    fun tempSourceLabel(source: TempSource, zone: String?): String = when (source) {
        TempSource.SOC_THERMAL -> if (this === ArabicStrings) {
            "مستشعر المعالج/النظام (${zone ?: "SoC"})"
        } else {
            "SoC / CPU Thermal (${zone ?: "SoC"})"
        }
        TempSource.SKIN_THERMAL -> if (this === ArabicStrings) {
            "مستشعر هيكل الجهاز (${zone ?: "Skin"})"
        } else {
            "Device Skin Thermal (${zone ?: "Skin"})"
        }
        TempSource.BATTERY -> if (this === ArabicStrings) {
            "مستشعر البطارية (ليست حرارة المعالج)"
        } else {
            "Battery Sensor (not CPU die temp)"
        }
        TempSource.UNAVAILABLE -> if (this === ArabicStrings) "غير متاح" else "Unavailable"
    }

    fun fpsSourceLabel(source: FpsSource): String = when (source) {
        FpsSource.KERNEL_SYSFS -> if (this === ArabicStrings) "قراءة نواة العرض (Sysfs)" else "Kernel Display Sysfs"
        FpsSource.COMPOSITOR_HZ -> if (this === ArabicStrings) "معدل تحديث الواجهة (Compositor Hz)" else "Display Compositor Hz"
        FpsSource.UNAVAILABLE -> if (this === ArabicStrings) {
            "غير متاح دون Root/ADB (يعرض N/A)"
        } else {
            "Restricted on Android 14 without Root/ADB (N/A)"
        }
    }

    fun positionLabel(preset: OverlayPositionPreset): String = when (preset) {
        OverlayPositionPreset.TOP_START -> if (this === ArabicStrings) "أعلى البداية" else "Top Start"
        OverlayPositionPreset.TOP_CENTER -> if (this === ArabicStrings) "أعلى المنتصف" else "Top Center"
        OverlayPositionPreset.TOP_END -> if (this === ArabicStrings) "أعلى النهاية" else "Top End"
        OverlayPositionPreset.CENTER -> if (this === ArabicStrings) "المنتصف" else "Center"
        OverlayPositionPreset.BOTTOM_CENTER -> if (this === ArabicStrings) "الأسفل" else "Bottom"
    }
}

val ArabicStrings = AppStrings(
    appTitle = "الإحصائيات",
    appSubtitle = "مراقب أداء الهاتف المباشر فوق التطبيقات والألعاب",
    navHome = "الرئيسية",
    navCustomize = "الإحصائيات",
    navAppearance = "المظهر",
    navSettings = "الإعدادات",

    statusActive = "المستطيل العائم يعمل",
    statusStopped = "المستطيل العائم متوقف",
    startOverlayButton = "تشغيل المستطيل العائم",
    stopOverlayButton = "إيقاف المستطيل العائم",
    overlayControlHint = "التحكم بالكامل عبر هذا الزر فقط — يتوقف التحديث وتُحفظ الموارد عند الإيقاف.",

    livePreviewTitle = "معاينة مباشرة للمستطيل العائم",
    dragHint = "يمكنك سحب المستطيل بحرية إلى أي مكان فوق الألعاب والتطبيقات.",
    sensorTransparencyTitle = "مصادر القراءة الفعلية على هذا الجهاز",

    permissionsTitle = "الأذونات والتوافق",
    overlayPermTitle = "الظهور فوق التطبيقات الأخرى",
    overlayPermDesc = "ضروري لعرض مستطيل الإحصائيات فوق الألعاب والتطبيقات.",
    notifPermTitle = "صلاحية الإشعارات",
    notifPermDesc = "لإظهار إشعار الخدمة الأمامية على أندرويد 13+ ومنع إيقافها.",
    batteryOptTitle = "تحسين البطارية (MagicOS 8 / Honor)",
    batteryOptDesc = "استثناء التطبيق من توفير الطاقة يضمن ثبات المستطيل أثناء اللعب.",
    permGranted = "ممنوحة",
    permRequired = "مطلوبة",
    permOptional = "موصى بها",
    permGrantBtn = "منح الصلاحية",
    permConfigureBtn = "فتح الإعدادات",

    overlayPermDialogTitle = "مطلوب صلاحية الظهور فوق التطبيقات",
    overlayPermDialogBody = "لعرض مستطيل الإحصائيات فوق الألعاب والتطبيقات الأخرى، يرجى تفعيل خيار «الظهور فوق التطبيقات الأخرى» لتطبيق الإحصائيات من إعدادات النظام.",
    openSettingsBtn = "فتح الإعدادات",
    cancelBtn = "إلغاء",

    customizeTitle = "تخصيص الإحصائيات",
    customizeSubtitle = "اختر العناصر التي تظهر في المستطيل. يتغير عرض المستطيل تلقائياً دون فراغات.",
    quickPresetsLabel = "قوالب سريعة",
    presetFpsOnly = "FPS فقط",
    presetCpuRam = "CPU و RAM",
    presetFpsTmp = "FPS و TMP",
    presetCore4 = "الأربعة الأساسية",
    presetAll = "الكل",
    enabledCountFormat = "العناصر المفعّلة: %d من 6",

    appearanceTitle = "المظهر",
    appearanceSubtitle = "عدّل الحجم والشفافية وحجم الخط والألوان والموضع مع تطبيق فوري.",
    scaleLabel = "حجم المستطيل",
    opacityLabel = "شفافية الخلفية",
    fontSizeLabel = "حجم الخط",
    positionLabel = "موضع المستطيل",
    resetPositionBtn = "إعادة للوضع المحدد",
    customDraggedActive = "موضع مخصص بالسحب اليدوي نشط",
    colorsLabel = "ألوان الإحصائيات",
    resetColorsBtn = "استعادة الألوان الافتراضية",

    settingsTitle = "الإعدادات",
    settingsSubtitle = "اللغة ومعدل التحديث وخيارات الشفافية والتوافق.",
    languageSection = "لغة الواجهة",
    arabicLabel = "العربية",
    englishLabel = "English",
    refreshRateSection = "معدل تحديث البيانات",
    refreshFast = "سريع (500 مللي ثانية)",
    refreshBalanced = "متوازن (1 ثانية)",
    refreshSaver = "توفير البطارية (2 ثانية)",
    telemetryOptionsSection = "خيارات قراءة المستشعرات",
    compositorHzTitle = "استخدام معدل تحديث الشاشة (Hz) لـ FPS",
    compositorHzDesc = "أندرويد 14 يمنع قراءة FPS ألعاب الطرف الثالث دون Root/ADB. عند التفعيل يعرض معدل إطارات الواجهة (Compositor Hz) بدلاً من N/A.",
    hideDxvkTitle = "إخفاء DXVK تلقائياً عند عدم الاكتشاف",
    hideDxvkDesc = "يُخفي خانة DXVK من المستطيل إذا لم تُكتشف بيئة DXVK نشطة على الجهاز.",
    magicosTitle = "توافق Android 14 و Honor MagicOS 8",
    magicosDesc = "في هواتف Honor (MagicOS 8)، يُنصح بضبط «تشغيل التطبيقات» على «إدارة يدوياً» والسماح بالعمل في الخلفية والنافذة العائمة حتى لا يغلق النظام المستطيل أثناء الألعاب.",
    openAppSettingsBtn = "إعدادات التطبيق",
    aboutSection = "معلومات التطبيق",
    aboutVersion = "الإصدار 1.0 • Android 14 / API 34+",
    aboutArchNote = "تطبيق أندرويد أصلي بـ Kotlin و Jetpack Compose و WindowManager بدون WebView وبدون أرقام وهمية.",

    notAvailable = "N/A",
    activeShort = "نشط",
)

val EnglishStrings = AppStrings(
    appTitle = "Statistics",
    appSubtitle = "Real-time floating performance overlay over apps & games",
    navHome = "Home",
    navCustomize = "Stats",
    navAppearance = "Appearance",
    navSettings = "Settings",

    statusActive = "Floating Overlay Active",
    statusStopped = "Floating Overlay Stopped",
    startOverlayButton = "Start Floating Overlay",
    stopOverlayButton = "Stop Floating Overlay",
    overlayControlHint = "Controlled exclusively via this button — polling stops completely when turned off.",

    livePreviewTitle = "Live Overlay Preview",
    dragHint = "Drag the floating bar freely anywhere over games and apps.",
    sensorTransparencyTitle = "Real Device Sensor Sources",

    permissionsTitle = "Permissions & Compatibility",
    overlayPermTitle = "Display Over Other Apps",
    overlayPermDesc = "Required to keep the statistics bar visible above games and apps.",
    notifPermTitle = "Notifications",
    notifPermDesc = "Keeps the foreground service indicator compliant on Android 13+.",
    batteryOptTitle = "Battery Optimization (MagicOS 8 / Honor)",
    batteryOptDesc = "Allowing unrestricted background usage prevents OS killing during games.",
    permGranted = "Granted",
    permRequired = "Required",
    permOptional = "Recommended",
    permGrantBtn = "Grant",
    permConfigureBtn = "Settings",

    overlayPermDialogTitle = "Overlay Permission Required",
    overlayPermDialogBody = "To show the floating statistics bar over games and other apps, please enable 'Display over other apps' for Statistics in Android settings.",
    openSettingsBtn = "Open Settings",
    cancelBtn = "Cancel",

    customizeTitle = "Customize Statistics",
    customizeSubtitle = "Toggle metrics on or off. The bar automatically shrinks to fit with zero gaps.",
    quickPresetsLabel = "Quick Presets",
    presetFpsOnly = "FPS Only",
    presetCpuRam = "CPU & RAM",
    presetFpsTmp = "FPS & TMP",
    presetCore4 = "Core 4",
    presetAll = "All",
    enabledCountFormat = "Enabled metrics: %d of 6",

    appearanceTitle = "Appearance",
    appearanceSubtitle = "Adjust overlay scale, opacity, font size, colors, and position live.",
    scaleLabel = "Overlay Size",
    opacityLabel = "Background Opacity",
    fontSizeLabel = "Font Size",
    positionLabel = "Overlay Position",
    resetPositionBtn = "Snap to Preset",
    customDraggedActive = "Custom dragged position active",
    colorsLabel = "Stat Label Colors",
    resetColorsBtn = "Reset Default Colors",

    settingsTitle = "Settings",
    settingsSubtitle = "Language, refresh rate, sensor honesty options, and permissions.",
    languageSection = "App Language",
    arabicLabel = "العربية",
    englishLabel = "English",
    refreshRateSection = "Refresh Interval",
    refreshFast = "Fast (500 ms)",
    refreshBalanced = "Balanced (1000 ms)",
    refreshSaver = "Battery Saver (2000 ms)",
    telemetryOptionsSection = "Sensor Reading Options",
    compositorHzTitle = "Use Display Compositor Hz for FPS",
    compositorHzDesc = "Android 14 blocks third-party game FPS reads without Root/ADB. Enable this to show live display compositor Hz instead of N/A.",
    hideDxvkTitle = "Auto-hide DXVK when not detected",
    hideDxvkDesc = "Automatically hides the DXVK item when no active DXVK runtime is detected.",
    magicosTitle = "Android 14 & Honor MagicOS 8",
    magicosDesc = "On Honor MagicOS 8 devices, set App Launch to 'Manage manually' and allow background & floating window activity so the system doesn't kill the overlay during gaming.",
    openAppSettingsBtn = "App Info",
    aboutSection = "About",
    aboutVersion = "Version 1.0 • Android 14 / API 34+",
    aboutArchNote = "Native Kotlin + Jetpack Compose + WindowManager app with zero WebView and zero fabricated telemetry.",

    notAvailable = "N/A",
    activeShort = "ON",
)

fun stringsFor(language: AppLanguage): AppStrings = when (language) {
    AppLanguage.ARABIC -> ArabicStrings
    AppLanguage.ENGLISH -> EnglishStrings
}
