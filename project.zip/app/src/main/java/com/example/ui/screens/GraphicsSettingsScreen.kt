package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrEmerald
import com.example.vr.model.GameMode
import com.example.vr.model.GraphicsQuality
import com.example.vr.model.GraphicsSettingsState
import com.example.vr.model.TargetFps
import com.example.vr.model.TimeOfDay
import com.example.vr.model.WeatherType

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun GraphicsSettingsScreen(
    graphics: GraphicsSettingsState,
    gameMode: GameMode,
    strings: AppStrings,
    onUpdateGraphics: ((GraphicsSettingsState) -> GraphicsSettingsState) -> Unit,
    onUpdateGameMode: (GameMode) -> Unit,
    onResetSave: () -> Unit,
    onBack: () -> Unit
) {
    var saveCleared by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(strings.graphicsTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("graphics_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(strings.qualityTitle, style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = graphics.quality == GraphicsQuality.LOW,
                                onClick = { onUpdateGraphics { it.copy(quality = GraphicsQuality.LOW) } },
                                label = { Text(strings.qualityLow) }
                            )
                            FilterChip(
                                selected = graphics.quality == GraphicsQuality.MEDIUM,
                                onClick = { onUpdateGraphics { it.copy(quality = GraphicsQuality.MEDIUM) } },
                                label = { Text(strings.qualityMedium) }
                            )
                            FilterChip(
                                selected = graphics.quality == GraphicsQuality.HIGH,
                                onClick = { onUpdateGraphics { it.copy(quality = GraphicsQuality.HIGH) } },
                                label = { Text(strings.qualityHigh) }
                            )
                        }

                        Text(strings.targetFpsTitle, style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TargetFps.entries.forEach { fps ->
                                FilterChip(
                                    selected = graphics.targetFps == fps,
                                    onClick = { onUpdateGraphics { it.copy(targetFps = fps) } },
                                    label = { Text("${fps.fps} FPS") },
                                    modifier = Modifier.testTag("fps_chip_${fps.fps}")
                                )
                            }
                        }

                        SettingSwitchRow(
                            title = strings.shadowsTitle,
                            checked = graphics.shadowsEnabled,
                            testTag = "shadows_switch",
                            onCheckedChange = { v -> onUpdateGraphics { it.copy(shadowsEnabled = v) } }
                        )
                        SettingSwitchRow(
                            title = strings.reflectionsTitle,
                            checked = graphics.reflectionsEnabled,
                            testTag = "reflections_switch",
                            onCheckedChange = { v -> onUpdateGraphics { it.copy(reflectionsEnabled = v) } }
                        )
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(strings.timeOfDayTitle, style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TimeOfDay.entries.forEach { tod ->
                                FilterChip(
                                    selected = graphics.timeOfDay == tod,
                                    onClick = { onUpdateGraphics { it.copy(timeOfDay = tod) } },
                                    label = { Text(tod.name) }
                                )
                            }
                        }

                        Text(strings.weatherTitle, style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            WeatherType.entries.forEach { w ->
                                FilterChip(
                                    selected = graphics.weather == w,
                                    onClick = { onUpdateGraphics { it.copy(weather = w) } },
                                    label = { Text(w.name) }
                                )
                            }
                        }

                        SettingSliderRow(
                            title = strings.hudSizeTitle,
                            valueText = "${(graphics.hudScale * 100).toInt()}%",
                            value = graphics.hudScale,
                            range = 0.75f..1.30f,
                            onValueChange = { v -> onUpdateGraphics { it.copy(hudScale = v) } }
                        )
                        SettingSliderRow(
                            title = strings.hudOffsetTitle,
                            valueText = "${graphics.hudVerticalOffset.toInt()} dp",
                            value = graphics.hudVerticalOffset,
                            range = -24f..24f,
                            onValueChange = { v -> onUpdateGraphics { it.copy(hudVerticalOffset = v) } }
                        )
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(strings.audioTitle, style = MaterialTheme.typography.titleMedium)
                        SettingSwitchRow(
                            title = strings.sfxToggle,
                            checked = graphics.sfxEnabled,
                            testTag = "sfx_switch",
                            onCheckedChange = { v -> onUpdateGraphics { it.copy(sfxEnabled = v) } }
                        )
                        SettingSwitchRow(
                            title = strings.musicToggle,
                            checked = graphics.musicEnabled,
                            testTag = "music_switch",
                            onCheckedChange = { v -> onUpdateGraphics { it.copy(musicEnabled = v) } }
                        )

                        Text(strings.gameModeTitle, style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = gameMode == GameMode.SANDBOX,
                                onClick = { onUpdateGameMode(GameMode.SANDBOX) },
                                label = { Text(strings.modeSandbox) }
                            )
                            FilterChip(
                                selected = gameMode == GameMode.BUDGET_CHALLENGE,
                                onClick = { onUpdateGameMode(GameMode.BUDGET_CHALLENGE) },
                                label = { Text(strings.modeBudgetChallenge) }
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                onResetSave()
                                saveCleared = true
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("reset_save_btn"),
                            border = BorderStroke(1.dp, VrCoral.copy(alpha = 0.6f))
                        ) {
                            Text(strings.resetSaveButton, color = VrCoral)
                        }
                        if (saveCleared) {
                            Text("✓ OK", color = VrEmerald, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
