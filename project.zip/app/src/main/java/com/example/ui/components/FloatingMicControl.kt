package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.MicStatus
import com.example.ui.theme.LocalYahyaColors

@Composable
fun FloatingMicControl(
    assistantName: String,
    isListening: Boolean,
    micStatus: MicStatus,
    rmsLevel: Float,
    onToggleMute: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val isActive = isListening ||
        micStatus == MicStatus.LISTENING ||
        micStatus == MicStatus.WAKE_ARMED ||
        micStatus == MicStatus.PROCESSING

    val infiniteTransition = rememberInfiniteTransition(label = "floating_mic_pulse")
    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "pulse_progress",
    )

    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "dot_alpha",
    )

    val rmsScale by animateFloatAsState(
        targetValue = if (isActive) 1f + (rmsLevel * 0.22f) else 1f,
        animationSpec = spring(stiffness = 420f, dampingRatio = 0.7f),
        label = "floating_rms_scale",
    )

    val buttonColor by animateColorAsState(
        targetValue = when {
            micStatus == MicStatus.WAKE_ARMED -> yColors.warning
            isActive -> yColors.accentTeal
            else -> yColors.surfaceElevated
        },
        animationSpec = tween(260),
        label = "floating_bg_color",
    )

    val iconTint by animateColorAsState(
        targetValue = if (isActive) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            yColors.danger
        },
        animationSpec = tween(260),
        label = "floating_icon_tint",
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            micStatus == MicStatus.WAKE_ARMED -> yColors.warning
            isActive -> yColors.accentTeal
            else -> yColors.danger.copy(alpha = 0.55f)
        },
        animationSpec = tween(260),
        label = "floating_border_color",
    )

    val statusText = when {
        micStatus == MicStatus.WAKE_ARMED -> "$assistantName بانتظار التنبيه..."
        micStatus == MicStatus.PROCESSING -> "جاري معالجة الصوت..."
        isActive -> "$assistantName يستمع الآن"
        else -> "الميكروفون مكتوم"
    }

    val buttonA11yLabel = if (isActive) {
        "كتم الميكروفون وإيقاف الاستماع"
    } else {
        "إلغاء كتم الميكروفون وبدء الاستماع"
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        AnimatedVisibility(
            visible = isActive,
            enter = fadeIn(tween(220)) + expandHorizontally(spring(stiffness = 380f)),
            exit = fadeOut(tween(180)) + shrinkHorizontally(tween(180)),
        ) {
            Surface(
                color = yColors.surfaceCard.copy(alpha = 0.96f),
                shape = CircleShape,
                border = BorderStroke(1.dp, borderColor.copy(alpha = 0.65f)),
                shadowElevation = 6.dp,
                modifier = Modifier.testTag("floating_listening_indicator"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(borderColor.copy(alpha = dotAlpha)),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(72.dp),
        ) {
            if (isActive) {
                Canvas(modifier = Modifier.size(72.dp)) {
                    val baseR = size.minDimension * 0.40f
                    val expandingR = baseR * (1f + pulseProgress * 0.34f) * rmsScale
                    val ringAlpha = (1f - pulseProgress) * 0.65f
                    drawCircle(
                        color = borderColor.copy(alpha = ringAlpha),
                        radius = expandingR,
                        style = Stroke(width = 2.5.dp.toPx()),
                    )
                }
            }

            val interactionSource = remember { MutableInteractionSource() }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(58.dp)
                    .minimumInteractiveComponentSize()
                    .shadow(
                        elevation = if (isActive) 12.dp else 6.dp,
                        shape = CircleShape,
                        ambientColor = borderColor,
                        spotColor = borderColor,
                    )
                    .clip(CircleShape)
                    .background(
                        brush = if (isActive) {
                            Brush.radialGradient(
                                colors = listOf(buttonColor, buttonColor.copy(alpha = 0.86f)),
                            )
                        } else {
                            Brush.radialGradient(
                                colors = listOf(yColors.surfaceElevated, yColors.surfaceCard),
                            )
                        },
                    )
                    .border(
                        width = if (isActive) 2.dp else 1.5.dp,
                        color = borderColor,
                        shape = CircleShape,
                    )
                    .clickable(
                        interactionSource = interactionSource,
                        indication = ripple(bounded = true, color = borderColor),
                        role = Role.Button,
                        onClick = onToggleMute,
                    )
                    .semantics { contentDescription = buttonA11yLabel }
                    .testTag("floating_mic_button"),
            ) {
                AnimatedContent(
                    targetState = isActive,
                    transitionSpec = {
                        (scaleIn(spring(stiffness = 450f, dampingRatio = 0.72f)) + fadeIn(tween(160)))
                            .togetherWith(scaleOut(tween(120)) + fadeOut(tween(120)))
                    },
                    label = "floating_mic_icon_transition",
                ) { active ->
                    Icon(
                        imageVector = if (active) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(26.dp),
                    )
                }
            }
        }
    }
}
