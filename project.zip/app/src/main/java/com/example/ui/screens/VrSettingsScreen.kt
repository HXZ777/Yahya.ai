package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.vr.model.VrSettingsState
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VrSettingsScreen(
    vr: VrSettingsState,
    strings: AppStrings,
    onUpdateVr: ((VrSettingsState) -> VrSettingsState) -> Unit,
    onCalibrateHeadset: () -> Unit,
    onTestVrNow: () -> Unit,
    onBack: () -> Unit
) {
    var calibratedNotice by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(strings.vrSettingsTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("vr_settings_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // FOV Control Card (60 - 120 degrees)
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.fovTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "${vr.fovDegrees.roundToInt()}°",
                                style = MaterialTheme.typography.headlineSmall,
                                color = VrCyan
                            )
                        }
                        Slider(
                            value = vr.fovDegrees,
                            onValueChange = { valDeg -> onUpdateVr { it.copy(fovDegrees = valDeg.roundToInt().toFloat()) } },
                            valueRange = 60f..120f,
                            steps = 59,
                            modifier = Modifier.testTag("fov_slider")
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(60, 70, 80, 90, 100, 110, 120).forEach { preset ->
                                FilterChip(
                                    selected = vr.fovDegrees.roundToInt() == preset,
                                    onClick = { onUpdateVr { it.copy(fovDegrees = preset.toFloat()) } },
                                    label = { Text("${preset}°") },
                                    modifier = Modifier.testTag("fov_preset_$preset")
                                )
                            }
                        }
                        Text(
                            text = strings.fovPhysicalDisclaimer,
                            style = MaterialTheme.typography.bodySmall,
                            color = VrAmber
                        )
                    }
                }
            }

            // Optics & Stereo Sliders
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingSwitchRow(
                            title = strings.sideBySideTitle,
                            checked = vr.sideBySideEnabled,
                            testTag = "sbs_switch",
                            onCheckedChange = { v -> onUpdateVr { it.copy(sideBySideEnabled = v) } }
                        )

                        SettingSliderRow(
                            title = strings.ipdTitle,
                            valueText = "${vr.ipdMm.roundToInt()} mm",
                            value = vr.ipdMm,
                            range = 55f..75f,
                            onValueChange = { v -> onUpdateVr { it.copy(ipdMm = v) } }
                        )

                        SettingSwitchRow(
                            title = strings.lensDistortionTitle,
                            checked = vr.lensDistortionEnabled,
                            testTag = "distortion_switch",
                            onCheckedChange = { v -> onUpdateVr { it.copy(lensDistortionEnabled = v) } }
                        )

                        if (vr.lensDistortionEnabled) {
                            SettingSliderRow(
                                title = strings.distortionStrengthTitle,
                                valueText = String.format("%.2f", vr.distortionK1),
                                value = vr.distortionK1,
                                range = 0.0f..0.45f,
                                onValueChange = { v -> onUpdateVr { it.copy(distortionK1 = v) } }
                            )
                        }

                        SettingSwitchRow(
                            title = strings.chromaticAberrationTitle,
                            checked = vr.chromaticAberrationEnabled,
                            testTag = "chromatic_switch",
                            onCheckedChange = { v -> onUpdateVr { it.copy(chromaticAberrationEnabled = v) } }
                        )

                        SettingSliderRow(
                            title = strings.imageScaleTitle,
                            valueText = "${(vr.imageScale * 100).roundToInt()}%",
                            value = vr.imageScale,
                            range = 0.75f..1.15f,
                            onValueChange = { v -> onUpdateVr { it.copy(imageScale = v) } }
                        )

                        SettingSliderRow(
                            title = strings.eyeDistanceTitle,
                            valueText = String.format("%+.3f", vr.eyeSeparationOffset),
                            value = vr.eyeSeparationOffset,
                            range = -0.08f..0.08f,
                            onValueChange = { v -> onUpdateVr { it.copy(eyeSeparationOffset = v) } }
                        )
                    }
                }
            }

            // Calibration & Live VR Test Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            onCalibrateHeadset()
                            calibratedNotice = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("calibrate_headset_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.CenterFocusStrong, contentDescription = null, tint = VrEmerald)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.calibrateHeadset)
                    }
                    if (calibratedNotice) {
                        Text(
                            text = strings.calibratedToast,
                            style = MaterialTheme.typography.bodySmall,
                            color = VrEmerald
                        )
                    }

                    Button(
                        onClick = onTestVrNow,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("test_vr_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VrCyan,
                            contentColor = VrObsidian
                        )
                    ) {
                        Icon(Icons.Filled.Visibility, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.testVrButton, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
internal fun SettingSwitchRow(
    title: String,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
internal fun SettingSliderRow(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, style = MaterialTheme.typography.labelMedium, color = VrCyan)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range
        )
    }
}
