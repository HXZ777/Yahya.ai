package com.example.ui.screens

import android.content.Intent
import android.opengl.GLSurfaceView
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.MineVrRenderer
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.AccessibilityBridgeSnapshot
import com.example.vr.model.HeadTrackingSnapshot
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VrSettingsScreen(
    vr: VrSettingsState,
    headState: HeadTrackingSnapshot,
    accessibilityState: AccessibilityBridgeSnapshot,
    headTracker: HeadTracker,
    controllerManager: PlayStationControllerManager,
    strings: MineVrStrings,
    onSaveVr: (VrSettingsState) -> Unit,
    onCalibrateForward: () -> Unit,
    onRecenter: () -> Unit,
    onResetDefaults: () -> Unit,
    onTestSplitScreen: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var draft by remember(vr) { mutableStateOf(vr) }

    val previewRenderer = remember {
        MineVrRenderer(context, headTracker, controllerManager).apply {
            isPreviewMode = true
            renderMode = VrRenderMode.STEREO_VOXEL_SANDBOX
            vrSettings = draft
        }
    }
    previewRenderer.vrSettings = draft

    DisposableEffect(Unit) {
        headTracker.start()
        onDispose {
            headTracker.stop()
        }
    }

    Scaffold(
        containerColor = MineObsidian,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(strings.vrSettingsTitle, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("vr_settings_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MineBedrockSurface),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .widthIn(max = 680.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Optical Preview (OpenGL ES SBS + Barrel Distortion)
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.livePreviewLabel, style = MaterialTheme.typography.titleSmall, color = DiamondCyan)
                        Text(
                            text = "${draft.fovDegrees.roundToInt()}° · ${draft.ipdMm.roundToInt()}mm",
                            style = MaterialTheme.typography.labelMedium,
                            color = CreeperEmerald
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(175.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                GLSurfaceView(ctx).apply {
                                    setEGLContextClientVersion(3)
                                    setRenderer(previewRenderer)
                                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Gyroscope & Calibration Section
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.gyroTestSection, style = MaterialTheme.typography.titleSmall, color = CreeperEmerald)
                    Text(
                        text = "Yaw: ${"%.1f".format(headState.calibratedYawDeg)}°  |  Pitch: ${"%.1f".format(headState.pitchDeg)}°  |  Roll: ${"%.1f".format(headState.rollDeg)}°",
                        style = MaterialTheme.typography.labelMedium,
                        color = MineTextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        FilledTonalButton(
                            onClick = onCalibrateForward,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("calibrate_head_button")
                        ) {
                            Icon(Icons.Filled.CenterFocusStrong, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.calibrateHead)
                        }
                        OutlinedButton(
                            onClick = onRecenter,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("recenter_head_button")
                        ) {
                            Text(strings.recenterHead)
                        }
                    }

                    Button(
                        onClick = {
                            onSaveVr(draft)
                            onTestSplitScreen()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_vr_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DiamondCyan, contentColor = Color(0xFF042030))
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.testSplitScreen)
                    }
                }
            }

            // VR Box Optics Sliders
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SliderParam(
                        label = strings.ipdLabel,
                        valueText = "${"%.1f".format(draft.ipdMm)} mm",
                        value = draft.ipdMm,
                        range = 55f..72f,
                        onValueChange = { draft = draft.copy(ipdMm = it) }
                    )

                    SliderParam(
                        label = strings.distortionK1Label,
                        valueText = "%.2f".format(draft.barrelDistortionK1),
                        value = draft.barrelDistortionK1,
                        range = 0f..0.55f,
                        onValueChange = { draft = draft.copy(barrelDistortionK1 = it) }
                    )

                    SliderParam(
                        label = strings.distortionK2Label,
                        valueText = "%.2f".format(draft.barrelDistortionK2),
                        value = draft.barrelDistortionK2,
                        range = 0f..0.25f,
                        onValueChange = { draft = draft.copy(barrelDistortionK2 = it) }
                    )

                    SliderParam(
                        label = strings.alignXLabel,
                        valueText = "%.3f".format(draft.alignXOffset),
                        value = draft.alignXOffset,
                        range = -0.12f..0.12f,
                        onValueChange = { draft = draft.copy(alignXOffset = it) }
                    )

                    SliderParam(
                        label = strings.alignYLabel,
                        valueText = "%.3f".format(draft.alignYOffset),
                        value = draft.alignYOffset,
                        range = -0.12f..0.12f,
                        onValueChange = { draft = draft.copy(alignYOffset = it) }
                    )

                    SliderParam(
                        label = strings.vrScaleLabel,
                        valueText = "${(draft.vrScale * 100).roundToInt()}%",
                        value = draft.vrScale,
                        range = 0.70f..1.10f,
                        onValueChange = { draft = draft.copy(vrScale = it) }
                    )

                    // FOV Presets + Slider
                    SliderParam(
                        label = strings.fovLabel,
                        valueText = "${draft.fovDegrees.roundToInt()}°",
                        value = draft.fovDegrees,
                        range = 60f..120f,
                        onValueChange = { draft = draft.copy(fovDegrees = it) }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(60f, 85f, 100f, 120f).forEach { preset ->
                            OutlinedButton(
                                onClick = { draft = draft.copy(fovDegrees = preset) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("fov_preset_${preset.toInt()}")
                            ) {
                                Text("${preset.toInt()}°", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }

                    SliderParam(
                        label = strings.brightnessLabel,
                        valueText = "${(draft.brightness * 100).roundToInt()}%",
                        value = draft.brightness,
                        range = 0.50f..1.40f,
                        onValueChange = { draft = draft.copy(brightness = it) }
                    )

                    SliderParam(
                        label = strings.headSensitivityLabel,
                        valueText = "%.2fx".format(draft.headSensitivity),
                        value = draft.headSensitivity,
                        range = 0.50f..2.0f,
                        onValueChange = { draft = draft.copy(headSensitivity = it) }
                    )

                    SliderParam(
                        label = strings.headSmoothingLabel,
                        valueText = "${(draft.headSmoothing * 100).roundToInt()}%",
                        value = draft.headSmoothing,
                        range = 0.10f..0.80f,
                        onValueChange = { draft = draft.copy(headSmoothing = it) }
                    )

                    SwitchRow(
                        label = strings.fixedVrBoxModeLabel,
                        checked = draft.fixedVrBoxMode,
                        onCheckedChange = { draft = draft.copy(fixedVrBoxMode = it) }
                    )
                    SwitchRow(
                        label = strings.flipOrientationLabel,
                        checked = draft.flipOrientation,
                        onCheckedChange = { draft = draft.copy(flipOrientation = it) }
                    )
                    SwitchRow(
                        label = strings.horizonLockLabel,
                        checked = draft.horizonLockEnabled,
                        onCheckedChange = { draft = draft.copy(horizonLockEnabled = it) }
                    )
                }
            }

            // Optional Accessibility Head-to-Camera Bridge
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.accessibilityLookBridgeLabel,
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldAmber,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = if (accessibilityState.isServiceEnabled) strings.accessibilityEnabledBadge else strings.accessibilityDisabledBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (accessibilityState.isServiceEnabled) CreeperEmerald else RedstoneCoral
                        )
                    }
                    Text(
                        text = strings.shizukuHeadLookDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                    SwitchRow(
                        label = strings.shizukuHeadLookLabel,
                        checked = draft.shizukuHeadLookEnabled,
                        onCheckedChange = { draft = draft.copy(shizukuHeadLookEnabled = it) }
                    )
                    Text(
                        text = strings.accessibilityLookBridgeDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                    SwitchRow(
                        label = strings.accessibilityLookBridgeLabel,
                        checked = draft.accessibilityHeadLookEnabled,
                        onCheckedChange = { draft = draft.copy(accessibilityHeadLookEnabled = it) }
                    )
                    SliderParam(
                        label = strings.accessibilitySensLabel,
                        valueText = "%.2fx".format(draft.accessibilityLookSensitivity),
                        value = draft.accessibilityLookSensitivity,
                        range = 0.4f..2.5f,
                        onValueChange = { draft = draft.copy(accessibilityLookSensitivity = it) }
                    )
                    SwitchRow(
                        label = strings.accessibilityInvertYLabel,
                        checked = draft.accessibilityInvertY,
                        onCheckedChange = { draft = draft.copy(accessibilityInvertY = it) }
                    )
                    OutlinedButton(
                        onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(strings.openAccessibilitySettings)
                    }
                }
            }

            // Save & Reset Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onResetDefaults()
                        draft = VrSettingsState()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.resetDefaults)
                }
                Button(
                    onClick = {
                        onSaveVr(draft)
                        scope.launch { snackbarHostState.showSnackbar(strings.savedToast) }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_vr_settings_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E))
                ) {
                    Icon(Icons.Filled.Save, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.save)
                }
            }
        }
    }
}

@Composable
private fun SliderParam(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, style = MaterialTheme.typography.labelMedium, color = DiamondCyan)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = CreeperEmerald,
                activeTrackColor = CreeperEmerald
            )
        )
    }
}

@Composable
private fun SwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
