package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.domain.model.MicStatus
import com.example.ui.theme.LocalYahyaColors

@Composable
fun VoiceOrbButton(
    micStatus: MicStatus,
    rmsLevel: Float,
    wakePhrase: String,
    continuousWakeMode: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val isActive = micStatus == MicStatus.LISTENING ||
        micStatus == MicStatus.WAKE_ARMED ||
        micStatus == MicStatus.PROCESSING

    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )

    val rmsScale by animateFloatAsState(
        targetValue = if (micStatus == MicStatus.LISTENING) 1f + (rmsLevel * 0.34f) else 1f,
        animationSpec = spring(stiffness = 380f, dampingRatio = 0.65f),
        label = "rms_scale",
    )

    val orbColor by animateColorAsState(
        targetValue = when (micStatus) {
            MicStatus.LISTENING -> yColors.accentTeal
            MicStatus.WAKE_ARMED -> yColors.warning
            MicStatus.PROCESSING -> MaterialTheme.colorScheme.tertiary
            MicStatus.PERMISSION_MISSING, MicStatus.ERROR, MicStatus.UNAVAILABLE -> yColors.danger
            MicStatus.READY -> yColors.accentTeal.copy(alpha = 0.85f)
        },
        label = "orb_color",
    )

    val statusHeadline = when (micStatus) {
        MicStatus.LISTENING -> "جاري الاستماع الآن..."
        MicStatus.WAKE_ARMED -> "في انتظار كلمة التنبيه"
        MicStatus.PROCESSING -> "جاري معالجة الصوت..."
        MicStatus.PERMISSION_MISSING -> "صلاحية الميكروفون مطلوبة"
        MicStatus.UNAVAILABLE -> "محرك التعرف الصوتي غير متاح"
        MicStatus.ERROR -> "حدث خطأ — اضغط لإعادة المحاولة"
        MicStatus.READY -> if (continuousWakeMode) "تشغيل وضع الاستماع المستمر" else "اضغط للتحدث"
    }

    val statusSubtext = when (micStatus) {
        MicStatus.LISTENING -> "تحدث باللغة العربية بوضوح، اضغط للإيقاف"
        MicStatus.WAKE_ARMED -> "قل \"$wakePhrase\" ثم أمرك الصوتي"
        MicStatus.PROCESSING -> "تحويل الصوت إلى نص وإرساله"
        MicStatus.PERMISSION_MISSING -> "اضغط لمنح صلاحية تسجيل الصوت"
        MicStatus.UNAVAILABLE -> "تأكد من تفعيل التعرف الصوتي في النظام"
        MicStatus.ERROR -> "تحقق من الميكروفون ثم أعد المحاولة"
        MicStatus.READY -> if (continuousWakeMode) "كلمة التنبيه المفعّلة: \"$wakePhrase\"" else "التقاط فوري للأمر وإرساله للهاتف الرئيسي"
    }

    val iconVector = when (micStatus) {
        MicStatus.LISTENING -> Icons.Rounded.GraphicEq
        MicStatus.WAKE_ARMED -> Icons.Rounded.Hearing
        MicStatus.PERMISSION_MISSING, MicStatus.UNAVAILABLE, MicStatus.ERROR -> Icons.Rounded.MicOff
        else -> Icons.Rounded.Mic
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(236.dp),
        ) {
            Canvas(modifier = Modifier.size(236.dp)) {
                val center = this.center
                val baseRadius = size.minDimension * 0.34f
                val activeRadius = baseRadius * (if (isActive) rmsScale * idlePulse else idlePulse)

                // Ambient radial glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            orbColor.copy(alpha = if (isActive) 0.32f else 0.14f),
                            orbColor.copy(alpha = 0.05f),
                            Color.Transparent,
                        ),
                        center = center,
                        radius = size.minDimension * 0.50f,
                    ),
                    radius = size.minDimension * 0.50f,
                    center = center,
                )

                // Outer harmonic ring
                drawCircle(
                    color = orbColor.copy(alpha = if (isActive) 0.45f else 0.18f),
                    radius = activeRadius * 1.32f,
                    center = center,
                    style = Stroke(width = if (isActive) 3.dp.toPx() else 1.5.dp.toPx()),
                )

                // Inner harmonic ring driven by live RMS
                if (isActive) {
                    drawCircle(
                        color = orbColor.copy(alpha = 0.65f),
                        radius = activeRadius * 1.15f,
                        center = center,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                }
            }

            val interactionSource = remember { MutableInteractionSource() }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(144.dp)
                    .scale(if (micStatus == MicStatus.LISTENING) 1f + (rmsLevel * 0.08f) else 1f)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                orbColor.copy(alpha = if (isActive) 0.36f else 0.20f),
                                yColors.surfaceElevated,
                            ),
                        ),
                    )
                    .border(
                        width = if (isActive) 2.5.dp else 1.5.dp,
                        color = orbColor,
                        shape = CircleShape,
                    )
                    .clickable(
                        interactionSource = interactionSource,
                        indication = ripple(bounded = true, color = orbColor),
                        role = Role.Button,
                        onClick = onClick,
                    )
                    .semantics { contentDescription = statusHeadline }
                    .testTag("mic_main_button"),
            ) {
                Icon(
                    imageVector = iconVector,
                    contentDescription = statusHeadline,
                    tint = orbColor,
                    modifier = Modifier.size(56.dp),
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            color = orbColor.copy(alpha = 0.12f),
            shape = MaterialTheme.shapes.small,
            border = androidx.compose.foundation.BorderStroke(1.dp, orbColor.copy(alpha = 0.35f)),
        ) {
            Text(
                text = statusHeadline,
                style = MaterialTheme.typography.titleMedium,
                color = orbColor,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = statusSubtext,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
    }
}
