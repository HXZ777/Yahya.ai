package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FabPosition
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.domain.model.AssistantSettings
import com.example.ui.components.FloatingMicControl
import com.example.ui.screens.ControlScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LocalYahyaColors
import com.example.ui.theme.YahyaCompanionTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class AssistantRoute(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
) {
    data object Home : AssistantRoute(
        route = "home",
        label = "الرئيسية",
        selectedIcon = Icons.Rounded.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_home",
    )

    data object Control : AssistantRoute(
        route = "control",
        label = "التحكم",
        selectedIcon = Icons.Rounded.Security,
        unselectedIcon = Icons.Outlined.Security,
        testTag = "nav_control",
    )

    data object Settings : AssistantRoute(
        route = "settings",
        label = "الإعدادات",
        selectedIcon = Icons.Rounded.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        testTag = "nav_settings",
    )
}

private val navDestinations = listOf(
    AssistantRoute.Home,
    AssistantRoute.Control,
    AssistantRoute.Settings,
)

@Composable
fun YahyaCompanionAppRoot(
    viewModel: MainViewModel,
    requestMicPermissionOnSignal: Boolean = false,
    onMicPermissionSignalHandled: () -> Unit = {},
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val hasApiKey by viewModel.hasApiKey.collectAsStateWithLifecycle()
    val maskedApiKey by viewModel.maskedApiKey.collectAsStateWithLifecycle()
    val hasInternet by viewModel.hasInternet.collectAsStateWithLifecycle()
    val assistantPowerEnabled by viewModel.assistantPowerEnabled.collectAsStateWithLifecycle()
    val aiStatus by viewModel.aiStatus.collectAsStateWithLifecycle()
    val isTestingConnection by viewModel.isTestingConnection.collectAsStateWithLifecycle()
    val connectionTestResult by viewModel.connectionTestResult.collectAsStateWithLifecycle()
    val availableCloudModels by viewModel.availableCloudModels.collectAsStateWithLifecycle()
    val isFetchingModels by viewModel.isFetchingModels.collectAsStateWithLifecycle()
    val modelsFetchError by viewModel.modelsFetchError.collectAsStateWithLifecycle()
    val availableTtsVoices by viewModel.availableTtsVoices.collectAsStateWithLifecycle()

    val micStatus by viewModel.micStatus.collectAsStateWithLifecycle()
    val isMicListening by viewModel.isMicListening.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.partialTranscript.collectAsStateWithLifecycle()
    val rmsLevel by viewModel.rmsLevel.collectAsStateWithLifecycle()
    val isForegroundServiceRunning by viewModel.isForegroundServiceRunning.collectAsStateWithLifecycle()
    val isSystemOverlayRunning by viewModel.isSystemOverlayRunning.collectAsStateWithLifecycle()
    val canDrawOverlays by viewModel.canDrawOverlays.collectAsStateWithLifecycle()
    val conversation by viewModel.conversation.collectAsStateWithLifecycle()
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsStateWithLifecycle()
    val accessibilityHealth by viewModel.accessibilityHealth.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val uiScope = rememberCoroutineScope()
    var pendingFloatingStart by remember { mutableStateOf(false) }
    var pendingOverlayEnable by remember { mutableStateOf(false) }
    var showLaunchSplash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(550L)
        showLaunchSplash = false
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshDeviceHealth()
        if (pendingOverlayEnable) {
            pendingOverlayEnable = false
            if (Settings.canDrawOverlays(context)) {
                viewModel.setSystemOverlayEnabled(true)
            } else {
                viewModel.setSystemOverlayEnabled(false)
                uiScope.launch {
                    snackbarHostState.showSnackbar(
                        message = "يرجى تفعيل إذن الظهور فوق التطبيقات الأخرى لإظهار زر HXZ AI العائم.",
                        duration = SnackbarDuration.Long,
                    )
                }
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { results ->
        viewModel.refreshDeviceHealth()
        val micGranted = results[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO,
            ) == PackageManager.PERMISSION_GRANTED
        if (micGranted) {
            if (pendingFloatingStart) {
                viewModel.startDirectListening()
            } else {
                viewModel.startMicrophone()
            }
        } else {
            viewModel.logMicPermissionDenied()
            uiScope.launch {
                val res = snackbarHostState.showSnackbar(
                    message = "تم رفض صلاحية الميكروفون من HXZ AI. يرجى منح الإذن للاستماع للأوامر الصوتية.",
                    actionLabel = "الإعدادات",
                    duration = SnackbarDuration.Long,
                )
                if (res == SnackbarResult.ActionPerformed) {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    runCatching { context.startActivity(intent) }
                }
            }
        }
        pendingFloatingStart = false
    }

    fun requestAudioAndNotificationPermissions(fromFloatingButton: Boolean = false) {
        pendingFloatingStart = fromFloatingButton
        val perms = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
        permissionLauncher.launch(perms)
    }

    fun handleMicTap() {
        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            requestAudioAndNotificationPermissions(fromFloatingButton = false)
        } else {
            viewModel.toggleMicrophone()
        }
    }

    fun handleFloatingMicTap() {
        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            requestAudioAndNotificationPermissions(fromFloatingButton = true)
        } else {
            viewModel.toggleDirectMicrophone()
        }
    }

    fun handleToggleAssistantPower() {
        if (!assistantPowerEnabled) {
            val hasMic = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO,
            ) == PackageManager.PERMISSION_GRANTED
            if (settings.isWakeMode && !hasMic) {
                requestAudioAndNotificationPermissions(fromFloatingButton = false)
                return
            }
        }
        viewModel.toggleAssistantPower()
    }

    fun handleToggleSystemOverlay(enable: Boolean) {
        if (!enable) {
            pendingOverlayEnable = false
            viewModel.setSystemOverlayEnabled(false)
            return
        }
        if (Settings.canDrawOverlays(context)) {
            viewModel.setSystemOverlayEnabled(true)
        } else {
            pendingOverlayEnable = true
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}"),
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(intent) }
        }
    }

    LaunchedEffect(requestMicPermissionOnSignal) {
        if (requestMicPermissionOnSignal) {
            onMicPermissionSignalHandled()
            requestAudioAndNotificationPermissions(fromFloatingButton = true)
        }
    }

    YahyaCompanionTheme {
        val layoutDirection = if (settings.rtlEnabled) LayoutDirection.Rtl else LayoutDirection.Ltr
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            val yColors = LocalYahyaColors.current
            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            fun navigateTo(route: String) {
                navController.navigate(route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                yColors.surfaceDeep,
                                yColors.surfaceCard.copy(alpha = 0.65f),
                                yColors.surfaceDeep,
                            ),
                        ),
                    ),
            ) {
                val useNavigationRail = maxWidth >= 600.dp

                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    floatingActionButtonPosition = FabPosition.End,
                    floatingActionButton = {
                        if (!isSystemOverlayRunning) {
                            FloatingMicControl(
                                assistantName = settings.assistantName,
                                isListening = isMicListening,
                                micStatus = micStatus,
                                rmsLevel = rmsLevel,
                                onToggleMute = ::handleFloatingMicTap,
                            )
                        }
                    },
                    bottomBar = {
                        if (!useNavigationRail) {
                            NavigationBar(
                                containerColor = yColors.surfaceCard.copy(alpha = 0.96f),
                                windowInsets = WindowInsets.navigationBars,
                            ) {
                                navDestinations.forEach { dest ->
                                    val selected = currentDestination?.hierarchy?.any {
                                        it.route == dest.route
                                    } == true
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { navigateTo(dest.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.label,
                                            )
                                        },
                                        label = { Text(dest.label) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = yColors.accentTeal,
                                            selectedTextColor = yColors.accentTeal,
                                            indicatorColor = yColors.accentTealSoft,
                                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        ),
                                        modifier = Modifier.testTag(dest.testTag),
                                    )
                                }
                            }
                        }
                    },
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                    ) {
                        if (useNavigationRail) {
                            NavigationRail(
                                containerColor = yColors.surfaceCard.copy(alpha = 0.95f),
                                modifier = Modifier.fillMaxHeight(),
                            ) {
                                navDestinations.forEach { dest ->
                                    val selected = currentDestination?.hierarchy?.any {
                                        it.route == dest.route
                                    } == true
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { navigateTo(dest.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.label,
                                            )
                                        },
                                        label = { Text(dest.label) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = yColors.accentTeal,
                                            selectedTextColor = yColors.accentTeal,
                                            indicatorColor = yColors.accentTealSoft,
                                        ),
                                        modifier = Modifier.testTag(dest.testTag),
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            NavHost(
                                navController = navController,
                                startDestination = AssistantRoute.Home.route,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .widthIn(max = 680.dp),
                            ) {
                                composable(AssistantRoute.Home.route) {
                                    HomeScreen(
                                        settings = settings,
                                        hasApiKey = hasApiKey,
                                        hasInternet = hasInternet,
                                        assistantPowerEnabled = assistantPowerEnabled,
                                        aiStatus = aiStatus,
                                        micStatus = micStatus,
                                        partialTranscript = partialTranscript,
                                        rmsLevel = rmsLevel,
                                        isForegroundServiceRunning = isForegroundServiceRunning,
                                        pendingConfirmation = pendingConfirmation,
                                        conversation = conversation,
                                        logs = logs,
                                        onToggleAssistantPower = ::handleToggleAssistantPower,
                                        onMicClick = ::handleMicTap,
                                        onSendManualText = viewModel::sendManualTranscript,
                                        onApproveConfirmation = viewModel::approvePendingConfirmation,
                                        onRejectConfirmation = viewModel::rejectPendingConfirmation,
                                        onNavigateToSettings = { navigateTo(AssistantRoute.Settings.route) },
                                        onClearConversation = viewModel::clearConversationAndLogs,
                                    )
                                }

                                composable(AssistantRoute.Control.route) {
                                    ControlScreen(
                                        settings = settings,
                                        accessibilityHealth = accessibilityHealth,
                                        hasInternet = hasInternet,
                                        canDrawOverlays = canDrawOverlays,
                                        isSystemOverlayRunning = isSystemOverlayRunning,
                                        onToggleSystemOverlay = ::handleToggleSystemOverlay,
                                        onToggleConfirmSensitive = { confirm ->
                                            viewModel.updateSafetyAndUi(confirm, settings.rtlEnabled)
                                        },
                                        onRequestMicPermission = {
                                            requestAudioAndNotificationPermissions(fromFloatingButton = false)
                                        },
                                        onTestSafeUrl = viewModel::testSafeUrlPreview,
                                        onTestGuardrail = viewModel::testSensitiveGuardrailPreview,
                                    )
                                }

                                composable(AssistantRoute.Settings.route) {
                                    SettingsScreen(
                                        settings = settings,
                                        hasApiKey = hasApiKey,
                                        maskedApiKey = maskedApiKey,
                                        isTestingConnection = isTestingConnection,
                                        connectionTestResult = connectionTestResult,
                                        availableCloudModels = availableCloudModels,
                                        isFetchingModels = isFetchingModels,
                                        modelsFetchError = modelsFetchError,
                                        availableTtsVoices = availableTtsVoices,
                                        canDrawOverlays = canDrawOverlays,
                                        isSystemOverlayRunning = isSystemOverlayRunning,
                                        onSaveIdentity = viewModel::updateAssistantIdentity,
                                        onSaveApiKey = viewModel::saveApiKey,
                                        onClearApiKey = viewModel::clearApiKey,
                                        onFetchCloudModels = viewModel::fetchAvailableCloudModels,
                                        onSaveGeminiModel = viewModel::updateGeminiModelId,
                                        onTestGeminiConnection = viewModel::testAiConnection,
                                        onUpdateSpeechSettings = viewModel::updateSpeechSettings,
                                        onUpdateWebSearchEnabled = viewModel::updateWebSearchEnabled,
                                        onUpdateSafetyAndUi = viewModel::updateSafetyAndUi,
                                        onToggleSystemOverlay = ::handleToggleSystemOverlay,
                                        onOpenControlScreen = { navigateTo(AssistantRoute.Control.route) },
                                        onClearConversation = viewModel::clearConversationAndLogs,
                                    )
                                }
                            }
                        }
                    }
                }

                // Branded HXZ AI Splash Screen Transition
                AnimatedVisibility(
                    visible = showLaunchSplash,
                    exit = fadeOut(),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(yColors.surfaceDeep),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_art_1795128413339),
                                contentDescription = AssistantSettings.APP_OFFICIAL_NAME,
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(RoundedCornerShape(24.dp)),
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = AssistantSettings.APP_OFFICIAL_NAME,
                                style = MaterialTheme.typography.headlineLarge,
                                color = yColors.accentTeal,
                                fontWeight = FontWeight.Bold,
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "مساعدك الذكي المستقل",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}
