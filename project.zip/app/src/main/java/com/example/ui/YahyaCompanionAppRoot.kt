package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.ControlScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PairingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LocalYahyaColors
import com.example.ui.theme.YahyaCompanionTheme

sealed class CompanionRoute(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
) {
    data object Home : CompanionRoute(
        route = "home",
        label = "الرئيسية",
        selectedIcon = Icons.Rounded.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_home",
    )

    data object Pairing : CompanionRoute(
        route = "pairing",
        label = "الإقران",
        selectedIcon = Icons.Rounded.QrCode2,
        unselectedIcon = Icons.Outlined.QrCode2,
        testTag = "nav_pairing",
    )

    data object Control : CompanionRoute(
        route = "control",
        label = "التحكم",
        selectedIcon = Icons.Rounded.Security,
        unselectedIcon = Icons.Outlined.Security,
        testTag = "nav_control",
    )

    data object Settings : CompanionRoute(
        route = "settings",
        label = "الإعدادات",
        selectedIcon = Icons.Rounded.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        testTag = "nav_settings",
    )
}

private val navDestinations = listOf(
    CompanionRoute.Home,
    CompanionRoute.Pairing,
    CompanionRoute.Control,
    CompanionRoute.Settings,
)

@Composable
fun YahyaCompanionAppRoot(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val micStatus by viewModel.micStatus.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.partialTranscript.collectAsStateWithLifecycle()
    val rmsLevel by viewModel.rmsLevel.collectAsStateWithLifecycle()
    val isForegroundServiceRunning by viewModel.isForegroundServiceRunning.collectAsStateWithLifecycle()
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsStateWithLifecycle()
    val accessibilityHealth by viewModel.accessibilityHealth.collectAsStateWithLifecycle()
    val localIp by viewModel.localIp.collectAsStateWithLifecycle()
    val discoveredDevices by viewModel.discoveredDevices.collectAsStateWithLifecycle()
    val isNsdScanning by viewModel.isNsdScanning.collectAsStateWithLifecycle()

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshDeviceHealth()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { results ->
        viewModel.refreshDeviceHealth()
        if (results[Manifest.permission.RECORD_AUDIO] == true) {
            viewModel.startMicrophone()
        }
    }

    fun requestAudioAndNotificationPermissions() {
        val perms = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
        permissionLauncher.launch(perms)
    }

    fun handleMicTap() {
        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            requestAudioAndNotificationPermissions()
        } else {
            viewModel.toggleMicrophone()
        }
    }

    YahyaCompanionTheme {
        val layoutDirection = if (settings.rtlEnabled) LayoutDirection.Rtl else LayoutDirection.Ltr
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            val yColors = LocalYahyaColors.current
            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            fun navigateTo(route: String) {
                navController.navigate(route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                yColors.surfaceDeep,
                                yColors.surfaceCard.copy(alpha = 0.65f),
                                yColors.surfaceDeep,
                            ),
                        ),
                    ),
            ) {
                val useNavigationRail = maxWidth >= 600.dp

                Scaffold(
                    containerColor = androidx.compose.ui.graphics.Color.Transparent,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    bottomBar = {
                        if (!useNavigationRail) {
                            NavigationBar(
                                containerColor = yColors.surfaceCard.copy(alpha = 0.96f),
                                windowInsets = WindowInsets.navigationBars,
                            ) {
                                navDestinations.forEach { dest ->
                                    val selected = currentDestination?.hierarchy?.any {
                                        it.route == dest.route
                                    } == true
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { navigateTo(dest.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.label,
                                            )
                                        },
                                        label = { Text(dest.label) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = yColors.accentTeal,
                                            selectedTextColor = yColors.accentTeal,
                                            indicatorColor = yColors.accentTealSoft,
                                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        ),
                                        modifier = Modifier.testTag(dest.testTag),
                                    )
                                }
                            }
                        }
                    },
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                    ) {
                        if (useNavigationRail) {
                            NavigationRail(
                                containerColor = yColors.surfaceCard.copy(alpha = 0.95f),
                                modifier = Modifier.fillMaxHeight(),
                            ) {
                                navDestinations.forEach { dest ->
                                    val selected = currentDestination?.hierarchy?.any {
                                        it.route == dest.route
                                    } == true
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { navigateTo(dest.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.label,
                                            )
                                        },
                                        label = { Text(dest.label) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = yColors.accentTeal,
                                            selectedTextColor = yColors.accentTeal,
                                            indicatorColor = yColors.accentTealSoft,
                                        ),
                                        modifier = Modifier.testTag(dest.testTag),
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            NavHost(
                                navController = navController,
                                startDestination = CompanionRoute.Home.route,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .widthIn(max = 680.dp),
                            ) {
                                composable(CompanionRoute.Home.route) {
                                    HomeScreen(
                                        settings = settings,
                                        connectionState = connectionState,
                                        micStatus = micStatus,
                                        partialTranscript = partialTranscript,
                                        rmsLevel = rmsLevel,
                                        isForegroundServiceRunning = isForegroundServiceRunning,
                                        pendingConfirmation = pendingConfirmation,
                                        logs = logs,
                                        onMicClick = ::handleMicTap,
                                        onSendManualText = viewModel::sendManualTranscript,
                                        onApproveConfirmation = viewModel::approvePendingConfirmation,
                                        onRejectConfirmation = viewModel::rejectPendingConfirmation,
                                        onNavigateToPairing = { navigateTo(CompanionRoute.Pairing.route) },
                                        onNavigateToSettings = { navigateTo(CompanionRoute.Settings.route) },
                                        onClearLogs = viewModel::clearLogs,
                                    )
                                }

                                composable(CompanionRoute.Pairing.route) {
                                    PairingScreen(
                                        settings = settings,
                                        connectionState = connectionState,
                                        localIp = localIp,
                                        deviceModelLabel = viewModel.deviceModelLabel,
                                        discoveredDevices = discoveredDevices,
                                        isNsdScanning = isNsdScanning,
                                        onPairAndConnect = viewModel::pairAndConnect,
                                        onScanPayload = viewModel::parseAndPairQrPayload,
                                        onReconnect = viewModel::reconnectPairedDevice,
                                        onUnpair = viewModel::disconnectAndUnpair,
                                        onPingTest = viewModel::sendPingTest,
                                        onRotateCredentials = viewModel::rotateLocalPairingCredentials,
                                        onStartNsd = viewModel::startNsdDiscovery,
                                        onStopNsd = viewModel::stopNsdDiscovery,
                                    )
                                }

                                composable(CompanionRoute.Control.route) {
                                    ControlScreen(
                                        settings = settings,
                                        accessibilityHealth = accessibilityHealth,
                                        onToggleConfirmSensitive = { confirm ->
                                            viewModel.updateSafetyAndUi(confirm, settings.rtlEnabled)
                                        },
                                        onRequestMicPermission = ::requestAudioAndNotificationPermissions,
                                        onTestSafeUrl = viewModel::testSafeUrlPreview,
                                        onTestGuardrail = viewModel::testSensitiveGuardrailPreview,
                                    )
                                }

                                composable(CompanionRoute.Settings.route) {
                                    SettingsScreen(
                                        settings = settings,
                                        connectionState = connectionState,
                                        onSaveIdentity = viewModel::updateAssistantIdentity,
                                        onUpdateSpeechSettings = viewModel::updateSpeechSettings,
                                        onUpdateSafetyAndUi = viewModel::updateSafetyAndUi,
                                        onOpenPairing = { navigateTo(CompanionRoute.Pairing.route) },
                                        onUnpair = viewModel::disconnectAndUnpair,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
