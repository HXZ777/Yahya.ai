package com.example.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.domain.model.ApkResultInfo
import com.example.domain.model.BuildExecutionState
import com.example.ui.components.BuildEngineSheet
import com.example.ui.components.UploadConsentDialog
import com.example.ui.screens.BuildProgressScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ResultScreen
import com.example.ui.theme.ObsidianCanvas
import com.example.ui.theme.ZipToApkTheme
import java.io.File

object AppRoutes {
    const val HOME = "home"
    const val BUILD_PROGRESS = "build_progress"
    const val RESULT = "result"
}

@Composable
fun ZipToApkAppRoot(viewModel: MainViewModel) {
    ZipToApkTheme {
        val context = LocalContext.current
        val navController = rememberNavController()
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val settings by viewModel.settings.collectAsStateWithLifecycle()
        val buildState by viewModel.buildState.collectAsStateWithLifecycle()

        val snackbarHostState = remember { SnackbarHostState() }
        var showEngineSheet by remember { mutableStateOf(false) }
        var pendingApkToSave by remember { mutableStateOf<ApkResultInfo?>(null) }

        val zipPickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument(),
        ) { uri ->
            if (uri != null) {
                viewModel.onZipUriSelected(uri)
            }
        }

        val apkSaveLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive"),
        ) { targetUri ->
            val apk = pendingApkToSave
            if (targetUri != null && apk != null) {
                viewModel.saveApkToSafUri(apk.apkFilePath, targetUri)
            }
            pendingApkToSave = null
        }

        LaunchedEffect(uiState.statusBannerMessage) {
            val message = uiState.statusBannerMessage
            if (!message.isNullOrBlank()) {
                snackbarHostState.showSnackbar(message)
                viewModel.dismissBanner()
            }
        }

        fun launchApkInstaller(apk: ApkResultInfo) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()
            ) {
                val permIntent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}"),
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(permIntent)
                return
            }

            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                File(apk.apkFilePath),
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
        }

        Scaffold(
            containerColor = ObsidianCanvas,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = AppRoutes.HOME,
            ) {
                composable(AppRoutes.HOME) {
                    HomeScreen(
                        uiState = uiState,
                        settings = settings,
                        contentPadding = innerPadding,
                        onSelectZipClick = {
                            zipPickerLauncher.launch(
                                arrayOf(
                                    "application/zip",
                                    "application/x-zip-compressed",
                                    "application/octet-stream",
                                ),
                            )
                        },
                        onBuildApkClick = {
                            viewModel.startBuildApk(
                                onNavigateToProgress = {
                                    navController.navigate(AppRoutes.BUILD_PROGRESS) {
                                        launchSingleTop = true
                                    }
                                },
                            )
                        },
                        onClearProject = viewModel::clearSelectedProject,
                        onCleanCache = { viewModel.cleanTempCache() },
                        onOpenEngineSettings = { showEngineSheet = true },
                    )
                }

                composable(AppRoutes.BUILD_PROGRESS) {
                    BuildProgressScreen(
                        buildState = buildState,
                        contentPadding = innerPadding,
                        onBack = { navController.popBackStack() },
                        onOpenEngineSettings = { showEngineSheet = true },
                        onExtractPrebuiltApk = {
                            viewModel.extractEmbeddedPrebuiltApk(
                                onNavigateToResult = {
                                    navController.navigate(AppRoutes.RESULT) {
                                        launchSingleTop = true
                                    }
                                },
                            )
                        },
                        onViewResult = {
                            navController.navigate(AppRoutes.RESULT) {
                                launchSingleTop = true
                            }
                        },
                    )
                }

                composable(AppRoutes.RESULT) {
                    val succeeded = buildState as? BuildExecutionState.Succeeded
                    if (succeeded != null) {
                        ResultScreen(
                            result = succeeded.result,
                            contentPadding = innerPadding,
                            onBackToHome = {
                                navController.popBackStack(AppRoutes.HOME, inclusive = false)
                            },
                            onSaveApkClick = { apk ->
                                pendingApkToSave = apk
                                apkSaveLauncher.launch(apk.fileName)
                            },
                            onInstallApkApproved = ::launchApkInstaller,
                        )
                    } else {
                        LaunchedEffect(Unit) {
                            navController.popBackStack(AppRoutes.HOME, inclusive = false)
                        }
                    }
                }
            }
        }

        if (showEngineSheet) {
            BuildEngineSheet(
                settings = settings,
                deviceProbe = uiState.deviceProbe,
                runnerHealth = uiState.runnerHealth,
                isTestingRunner = uiState.isTestingRunner,
                tempStorageBytes = uiState.tempStorageBytes,
                onUpdateSettings = viewModel::updateEngineSettings,
                onTestRunner = viewModel::testRemoteRunnerHealth,
                onCleanCache = { viewModel.cleanTempCache() },
                onDismiss = { showEngineSheet = false },
            )
        }

        if (uiState.showUploadConsentDialog) {
            UploadConsentDialog(
                runnerUrl = settings.remoteRunnerUrl,
                zipName = uiState.zipSelection?.displayName ?: "project.zip",
                onConfirm = {
                    viewModel.confirmUploadConsentAndStartBuild {
                        navController.navigate(AppRoutes.BUILD_PROGRESS) {
                            launchSingleTop = true
                        }
                    }
                },
                onDismiss = viewModel::dismissUploadConsentDialog,
            )
        }
    }
}
