package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.DefaultStatColors
import com.example.domain.model.OverlayPositionPreset
import com.example.domain.model.StatType
import com.example.ui.MainUiState
import com.example.ui.components.LiveOverlayPreviewCard
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoisePrimary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppearanceScreen(
    uiState: MainUiState,
    strings: AppStrings,
    contentPadding: PaddingValues,
    onScaleChange: (Int) -> Unit,
    onOpacityChange: (Float) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onPositionPresetSelect: (OverlayPositionPreset) -> Unit,
    onStatColorSelect: (StatType, Long) -> Unit,
    onResetColors: () -> Unit,
) {
    val settings = uiState.settings

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 16.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = strings.appearanceTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                )
                Text(
                    text = strings.appearanceSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )

                LiveOverlayPreviewCard(
                    settings = settings,
                    snapshot = uiState.snapshot,
                    strings = strings,
                    showDragHint = false,
                )

                // Size, Opacity, Font Size Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        LabeledSlider(
                            label = strings.scaleLabel,
                            valueLabel = "${settings.scalePercent}%",
                            value = settings.scalePercent.toFloat(),
                            valueRange = 75f..150f,
                            onValueChange = { onScaleChange(it.roundToInt()) },
                            testTag = "slider_scale",
                        )

                        HorizontalDivider(color = NavyBorder)

                        LabeledSlider(
                            label = strings.opacityLabel,
                            valueLabel = "${(settings.backgroundAlpha * 100f).roundToInt()}%",
                            value = settings.backgroundAlpha,
                            valueRange = 0.35f..1.0f,
                            onValueChange = onOpacityChange,
                            testTag = "slider_opacity",
                        )

                        HorizontalDivider(color = NavyBorder)

                        LabeledSlider(
                            label = strings.fontSizeLabel,
                            valueLabel = "${settings.fontSizeSp.roundToInt()} sp",
                            value = settings.fontSizeSp,
                            valueRange = 10f..18f,
                            onValueChange = { onFontSizeChange((it * 2f).roundToInt() / 2f) },
                            testTag = "slider_font_size",
                        )
                    }
                }

                // Position Preset Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = strings.positionLabel,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                            )
                            if (settings.customOffsetX != null) {
                                TextButton(
                                    onClick = { onPositionPresetSelect(settings.positionPreset) },
                                ) {
                                    Text(
                                        text = strings.resetPositionBtn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TurquoisePrimary,
                                    )
                                }
                            }
                        }

                        if (settings.customOffsetX != null) {
                            Text(
                                text = strings.customDraggedActive,
                                style = MaterialTheme.typography.bodySmall,
                                color = TurquoisePrimary,
                            )
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            OverlayPositionPreset.entries.forEach { preset ->
                                val selected = settings.customOffsetX == null && settings.positionPreset == preset
                                FilterChip(
                                    selected = selected,
                                    onClick = { onPositionPresetSelect(preset) },
                                    label = { Text(strings.positionLabel(preset)) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = TurquoisePrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = TurquoisePrimary,
                                        containerColor = NavyElevated,
                                        labelColor = TextSecondary,
                                    ),
                                )
                            }
                        }
                    }
                }

                // Colors Customization Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = strings.colorsLabel,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                            )
                            TextButton(onClick = onResetColors) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = strings.resetColorsBtn,
                                    tint = TurquoisePrimary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.size(4.dp))
                                Text(
                                    text = strings.resetColorsBtn,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TurquoisePrimary,
                                )
                            }
                        }

                        StatType.ORDERED.forEachIndexed { index, stat ->
                            if (index > 0) {
                                HorizontalDivider(color = NavyBorder)
                            }
                            val selectedColor = settings.statColors[stat] ?: DefaultStatColors.CPU
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = stat.name,
                                    fontFamily = JetBrainsMonoFamily,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(selectedColor),
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    DefaultStatColors.paletteOptions.forEach { colorOption ->
                                        val isChosen = selectedColor == colorOption
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(Color(colorOption))
                                                .border(
                                                    width = if (isChosen) 2.5.dp else 1.dp,
                                                    color = if (isChosen) Color.White else NavyBorder,
                                                    shape = CircleShape,
                                                )
                                                .clickable { onStatColorSelect(stat, colorOption) },
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            if (isChosen) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Check,
                                                    contentDescription = stat.name,
                                                    tint = Color(0xFF0A0B0E),
                                                    modifier = Modifier.size(18.dp),
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
            )
            Text(
                text = valueLabel,
                fontFamily = JetBrainsMonoFamily,
                style = MaterialTheme.typography.labelMedium,
                color = TurquoisePrimary,
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            modifier = Modifier.testTag(testTag),
            colors = SliderDefaults.colors(
                thumbColor = TurquoisePrimary,
                activeTrackColor = TurquoisePrimary,
                inactiveTrackColor = NavyElevated,
            ),
        )
    }
}
