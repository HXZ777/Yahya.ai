package com.example.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.AppLanguage
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.AppearanceScreen
import com.example.ui.screens.CustomizeStatsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavySurface
import com.example.ui.theme.StatisticsTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoisePrimary

enum class MainTab {
    HOME,
    CUSTOMIZE,
    APPEARANCE,
    SETTINGS,
}

@Composable
fun StatisticsAppRoot(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = stringsFor(uiState.settings.language)
    val layoutDirection = if (uiState.settings.language == AppLanguage.ARABIC) {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewModel.startForegroundPreview()
                Lifecycle.Event.ON_PAUSE -> viewModel.stopForegroundPreview()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            viewModel.stopForegroundPreview()
        }
    }

    val notificationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) {
        viewModel.refreshPermissions()
    }

    var currentTab by rememberSaveable { mutableStateOf(MainTab.HOME) }

    BackHandler(enabled = currentTab != MainTab.HOME) {
        currentTab = MainTab.HOME
    }

    val requestNotifications: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            openAppNotificationSettings(context)
        }
    }

    StatisticsTheme {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useRail = maxWidth >= 600.dp

                val tabs = listOf(
                    TabSpec(MainTab.HOME, strings.navHome, Icons.Rounded.Home, Icons.Outlined.Home),
                    TabSpec(MainTab.CUSTOMIZE, strings.navCustomize, Icons.Rounded.Tune, Icons.Outlined.Tune),
                    TabSpec(MainTab.APPEARANCE, strings.navAppearance, Icons.Rounded.Palette, Icons.Outlined.Palette),
                    TabSpec(MainTab.SETTINGS, strings.navSettings, Icons.Rounded.Settings, Icons.Outlined.Settings),
                )

                Scaffold(
                    containerColor = NavyDeep,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    bottomBar = {
                        if (!useRail) {
                            NavigationBar(
                                containerColor = NavySurface,
                                contentColor = TextPrimary,
                                modifier = Modifier.navigationBarsPadding(),
                            ) {
                                tabs.forEach { tab ->
                                    val selected = currentTab == tab.tab
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { currentTab = tab.tab },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label,
                                            )
                                        },
                                        label = { Text(tab.label, maxLines = 1) },
                                        modifier = Modifier.testTag("nav_${tab.tab.name.lowercase()}"),
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = TurquoisePrimary,
                                            selectedTextColor = TurquoisePrimary,
                                            indicatorColor = TurquoisePrimary.copy(alpha = 0.16f),
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary,
                                        ),
                                    )
                                }
                            }
                        }
                    },
                ) { innerPadding ->
                    Row(modifier = Modifier.fillMaxSize()) {
                        if (useRail) {
                            NavigationRail(
                                containerColor = NavySurface,
                                contentColor = TextPrimary,
                                modifier = Modifier.statusBarsPadding().navigationBarsPadding(),
                            ) {
                                tabs.forEach { tab ->
                                    val selected = currentTab == tab.tab
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { currentTab = tab.tab },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label,
                                            )
                                        },
                                        label = { Text(tab.label, maxLines = 1) },
                                        modifier = Modifier.testTag("nav_${tab.tab.name.lowercase()}"),
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = TurquoisePrimary,
                                            selectedTextColor = TurquoisePrimary,
                                            indicatorColor = TurquoisePrimary.copy(alpha = 0.16f),
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary,
                                        ),
                                    )
                                }
                            }
                        }

                        Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                            val screenPadding = if (useRail) {
                                PaddingValues(
                                    top = innerPadding.calculateTopPadding(),
                                    bottom = innerPadding.calculateBottomPadding(),
                                )
                            } else {
                                innerPadding
                            }

                            when (currentTab) {
                                MainTab.HOME -> HomeScreen(
                                    uiState = uiState,
                                    strings = strings,
                                    contentPadding = screenPadding,
                                    onToggleOverlay = viewModel::onToggleOverlayClicked,
                                    onRequestOverlayPermission = { openOverlayPermissionSettings(context) },
                                    onRequestNotificationPermission = requestNotifications,
                                    onOpenBatterySettings = { openBatteryOptimizationSettings(context) },
                                )

                                MainTab.CUSTOMIZE -> CustomizeStatsScreen(
                                    uiState = uiState,
                                    strings = strings,
                                    contentPadding = screenPadding,
                                    onToggleStat = viewModel::toggleStat,
                                    onApplyPreset = viewModel::applyStatPreset,
                                )

                                MainTab.APPEARANCE -> AppearanceScreen(
                                    uiState = uiState,
                                    strings = strings,
                                    contentPadding = screenPadding,
                                    onScaleChange = viewModel::setScalePercent,
                                    onOpacityChange = viewModel::setBackgroundAlpha,
                                    onFontSizeChange = viewModel::setFontSizeSp,
                                    onPositionPresetSelect = viewModel::setPositionPreset,
                                    onStatColorSelect = viewModel::setStatColor,
                                    onResetColors = viewModel::resetColors,
                                )

                                MainTab.SETTINGS -> SettingsScreen(
                                    uiState = uiState,
                                    strings = strings,
                                    contentPadding = screenPadding,
                                    onLanguageChange = viewModel::setLanguage,
                                    onRefreshIntervalChange = viewModel::setRefreshIntervalMs,
                                    onCompositorHzToggle = viewModel::setUseCompositorHzFallback,
                                    onHideDxvkToggle = viewModel::setHideDxvkWhenNotDetected,
                                    onRequestOverlayPermission = { openOverlayPermissionSettings(context) },
                                    onRequestNotificationPermission = requestNotifications,
                                    onOpenBatterySettings = { openBatteryOptimizationSettings(context) },
                                    onOpenAppInfoSettings = { openAppDetailsSettings(context) },
                                )
                            }
                        }
                    }
                }

                if (uiState.showOverlayPermissionDialog) {
                    AlertDialog(
                        onDismissRequest = viewModel::dismissOverlayPermissionDialog,
                        containerColor = NavyElevated,
                        titleContentColor = TextPrimary,
                        textContentColor = TextSecondary,
                        title = { Text(strings.overlayPermDialogTitle) },
                        text = { Text(strings.overlayPermDialogBody) },
                        confirmButton = {
                            Button(
                                onClick = {
                                    viewModel.dismissOverlayPermissionDialog()
                                    openOverlayPermissionSettings(context)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TurquoisePrimary,
                                    contentColor = Color(0xFF04241C),
                                ),
                            ) {
                                Text(strings.openSettingsBtn)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = viewModel::dismissOverlayPermissionDialog) {
                                Text(strings.cancelBtn, color = TextSecondary)
                            }
                        },
                    )
                }
            }
        }
    }
}

private data class TabSpec(
    val tab: MainTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
)

private fun openOverlayPermissionSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}"),
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        openAppDetailsSettings(context)
    }
}

private fun openBatteryOptimizationSettings(context: Context) {
    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        openAppDetailsSettings(context)
    }
}

private fun openAppNotificationSettings(context: Context) {
    val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
    } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
    }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        openAppDetailsSettings(context)
    }
}

private fun openAppDetailsSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.parse("package:${context.packageName}"),
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
