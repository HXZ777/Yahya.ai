package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.automirrored.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Splitscreen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.CreeperEmeraldDark
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineElevatedCard
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.vr.input.PlayStationControllerSnapshot
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControllerKind
import com.example.vr.model.HeadTrackingSnapshot
import com.example.vr.model.MineVrSettingsState
import com.example.vr.model.MinecraftAppStatus
import com.example.vr.model.ShizukuBridgeState
import com.example.vr.model.ShizukuStatus
import com.example.vr.model.VrRenderMode

@Composable
fun MainMenuScreen(
    settings: MineVrSettingsState,
    headState: HeadTrackingSnapshot,
    controllerState: PlayStationControllerSnapshot,
    minecraftStatus: MinecraftAppStatus,
    shizukuState: ShizukuBridgeState = ShizukuBridgeState(),
    strings: MineVrStrings,
    onStartVr: () -> Unit,
    onOpenHeadsetSettings: () -> Unit,
    onOpenControllerSettings: () -> Unit,
    onOpenSensorDiagnostics: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onSelectRenderMode: (VrRenderMode) -> Unit,
    onLaunchMinecraft: (Boolean) -> Unit,
    onRequestShizukuPermission: () -> Unit = {},
    onOpenShizukuApp: () -> Unit = {},
    onToggleLanguage: () -> Unit
) {
    Scaffold(
        containerColor = MineObsidian,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF0E1712),
                            MineObsidian,
                            Color(0xFF0A111A)
                        )
                    )
                )
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .widthIn(max = 640.dp)
                    .align(Alignment.TopCenter),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header: App Logo + VR Minecraft title + Language Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_minevr_logo),
                            contentDescription = strings.appTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(62.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                        Column {
                            Text(
                                text = strings.appTitle,
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = strings.appSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MineTextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .testTag("language_toggle_button")
                    ) {
                        Icon(Icons.Outlined.Language, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.languageToggle)
                    }
                }

                // Live System Status Cards (Gyroscope, PlayStation Controller, Shizuku, Minecraft Bedrock)
                StatusSummaryCard(
                    headState = headState,
                    controllerState = controllerState,
                    minecraftStatus = minecraftStatus,
                    shizukuState = shizukuState,
                    language = settings.language,
                    strings = strings,
                    onLaunchMinecraft = onLaunchMinecraft,
                    onRequestShizukuPermission = onRequestShizukuPermission,
                    onOpenShizukuApp = onOpenShizukuApp
                )

                // VR Display Mode Selector
                RenderModeSelectorCard(
                    selectedMode = settings.preferredRenderMode,
                    strings = strings,
                    onSelectMode = onSelectRenderMode
                )

                // Primary START VR CTA
                Button(
                    onClick = onStartVr,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .testTag("start_vr_button"),
                    shape = MaterialTheme.shapes.large,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CreeperEmerald,
                        contentColor = Color(0xFF04220E)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(30.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = strings.startVr,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // Secondary Action Grid (Headset Settings, Controller Settings, Sensor Test, App Info)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MenuActionTile(
                        title = strings.headsetSettings,
                        icon = Icons.Filled.ViewInAr,
                        accent = DiamondCyan,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("headset_settings_button"),
                        onClick = onOpenHeadsetSettings
                    )
                    MenuActionTile(
                        title = strings.controllerSettings,
                        icon = Icons.Filled.SportsEsports,
                        accent = CreeperEmerald,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("controller_settings_button"),
                        onClick = onOpenControllerSettings
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MenuActionTile(
                        title = strings.sensorDiagnostics,
                        icon = Icons.Filled.Sensors,
                        accent = GoldAmber,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sensor_diagnostics_button"),
                        onClick = onOpenSensorDiagnostics
                    )
                    MenuActionTile(
                        title = strings.appInfoAndFeasibility,
                        icon = Icons.Filled.Info,
                        accent = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("app_info_button"),
                        onClick = onOpenAppInfo
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusSummaryCard(
    headState: HeadTrackingSnapshot,
    controllerState: PlayStationControllerSnapshot,
    minecraftStatus: MinecraftAppStatus,
    shizukuState: ShizukuBridgeState,
    language: AppLanguage,
    strings: MineVrStrings,
    onLaunchMinecraft: (Boolean) -> Unit,
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuApp: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
        border = BorderStroke(1.dp, MineBlockBorder),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatusRow(
                icon = Icons.Filled.Sensors,
                label = if (headState.isGyroSupported) strings.statusGyroReady else strings.statusGyroMissing,
                detail = headState.activeSensorName,
                ok = headState.isGyroSupported
            )

            val ctrlDetail = when {
                !controllerState.isConnected -> if (language == AppLanguage.ARABIC) "بلوتوث / USB" else "Bluetooth / USB"
                controllerState.controllerKind == ControllerKind.DUALSENSE -> "DualSense (${controllerState.transport.name})"
                controllerState.controllerKind == ControllerKind.DUALSHOCK_4 -> "DualShock 4 (${controllerState.transport.name})"
                else -> controllerState.deviceName
            }
            StatusRow(
                icon = Icons.Filled.Gamepad,
                label = if (controllerState.isConnected) strings.statusControllerConnected else strings.statusControllerDisconnected,
                detail = ctrlDetail,
                ok = controllerState.isConnected
            )

            val shizukuOk = shizukuState.status == ShizukuStatus.READY ||
                shizukuState.status == ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE
            val shizukuLabel = when (shizukuState.status) {
                ShizukuStatus.NOT_INSTALLED -> strings.statusShizukuNotInstalled
                ShizukuStatus.NOT_RUNNING -> strings.statusShizukuNotRunning
                ShizukuStatus.PERMISSION_REQUIRED -> strings.statusShizukuPermRequired
                ShizukuStatus.PERMISSION_DENIED -> strings.statusShizukuPermDenied
                ShizukuStatus.BINDING_SERVICE -> strings.statusShizukuBinding
                ShizukuStatus.READY -> strings.statusShizukuReady
                ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE -> strings.statusShizukuActive
                ShizukuStatus.ERROR -> strings.statusShizukuError
            }
            val shizukuDetail = when {
                !shizukuState.lastErrorMessage.isNullOrBlank() -> shizukuState.lastErrorMessage
                shizukuState.status == ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE -> "Display #${shizukuState.virtualDisplayId} (${shizukuState.virtualWidth}x${shizukuState.virtualHeight})"
                shizukuState.isUserServiceConnected -> "UID ${shizukuState.serviceUid}"
                else -> "moe.shizuku.privileged.api"
            }
            StatusRow(
                icon = Icons.Filled.ViewInAr,
                label = shizukuLabel,
                detail = shizukuDetail,
                ok = shizukuOk
            )

            if (shizukuState.status == ShizukuStatus.PERMISSION_REQUIRED ||
                shizukuState.status == ShizukuStatus.PERMISSION_DENIED
            ) {
                FilledTonalButton(
                    onClick = onRequestShizukuPermission,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("request_shizuku_permission_button")
                ) {
                    Text(strings.requestShizukuPermissionBtn)
                }
            } else if (shizukuState.status == ShizukuStatus.NOT_RUNNING && shizukuState.isShizukuInstalled) {
                OutlinedButton(
                    onClick = onOpenShizukuApp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_shizuku_app_button")
                ) {
                    Text(strings.openShizukuAppBtn)
                }
            }

            val mcLabel = when {
                minecraftStatus.isInstalled && minecraftStatus.isTrialOnly -> strings.statusMinecraftTrial
                minecraftStatus.isInstalled -> strings.statusMinecraftInstalled
                else -> strings.statusMinecraftNotInstalled
            }
            StatusRow(
                icon = Icons.Filled.Settings,
                label = mcLabel,
                detail = if (minecraftStatus.isInstalled) "v${minecraftStatus.versionName}" else "com.mojang.minecraftpe",
                ok = minecraftStatus.isInstalled
            )

            if (minecraftStatus.isInstalled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { onLaunchMinecraft(false) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_minecraft_button")
                    ) {
                        Icon(Icons.AutoMirrored.Outlined.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.openMinecraftBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    OutlinedButton(
                        onClick = { onLaunchMinecraft(true) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_minecraft_split_button")
                    ) {
                        Icon(Icons.Outlined.Splitscreen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.openMinecraftSplitBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } else {
                Text(
                    text = strings.launchMinecraftHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = MineTextSecondary
                )
            }
        }
    }
}

@Composable
private fun StatusRow(
    icon: ImageVector,
    label: String,
    detail: String,
    ok: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (ok) CreeperEmerald else GoldAmber,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(text = label, style = MaterialTheme.typography.titleSmall)
                Text(
                    text = detail,
                    style = MaterialTheme.typography.labelSmall,
                    color = MineTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Icon(
            imageVector = if (ok) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
            contentDescription = label,
            tint = if (ok) CreeperEmerald else RedstoneCoral,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun RenderModeSelectorCard(
    selectedMode: VrRenderMode,
    strings: MineVrStrings,
    onSelectMode: (VrRenderMode) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
        border = BorderStroke(1.dp, MineBlockBorder),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = strings.renderModeTitle,
                style = MaterialTheme.typography.titleSmall,
                color = DiamondCyan
            )

            ModeOptionItem(
                title = strings.modeShizukuVirtualDisplay,
                desc = strings.modeShizukuVirtualDisplayDesc,
                selected = selectedMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY,
                modifier = Modifier.testTag("mode_shizuku_virtual_display"),
                onClick = { onSelectMode(VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY) }
            )

            ModeOptionItem(
                title = strings.modeLiveCapture,
                desc = strings.modeLiveCaptureDesc,
                selected = selectedMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE,
                modifier = Modifier.testTag("mode_live_capture"),
                onClick = { onSelectMode(VrRenderMode.MINECRAFT_LIVE_CAPTURE) }
            )

            ModeOptionItem(
                title = strings.modeStereoVoxel,
                desc = strings.modeStereoVoxelDesc,
                selected = selectedMode == VrRenderMode.STEREO_VOXEL_SANDBOX,
                modifier = Modifier.testTag("mode_stereo_voxel"),
                onClick = { onSelectMode(VrRenderMode.STEREO_VOXEL_SANDBOX) }
            )
        }
    }
}

@Composable
private fun ModeOptionItem(
    title: String,
    desc: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = if (selected) CreeperEmeraldDark else MineElevatedCard,
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) CreeperEmerald else MineBlockBorder
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) CreeperEmerald else MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = MineTextSecondary
            )
        }
    }
}

@Composable
private fun MenuActionTile(
    title: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(92.dp),
        shape = MaterialTheme.shapes.large,
        color = MineElevatedCard,
        border = BorderStroke(1.dp, MineBlockBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accent,
                modifier = Modifier.size(26.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
