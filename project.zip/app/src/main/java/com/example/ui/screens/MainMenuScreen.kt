package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.ui.theme.VrSlateSurface
import com.example.vr.input.XboxControllerSnapshot
import com.example.vr.model.AllSettingsState
import com.example.vr.model.ControlScheme
import com.example.vr.model.SaveGameState

@Composable
fun MainMenuScreen(
    settings: AllSettingsState,
    saveGame: SaveGameState?,
    xbox: XboxControllerSnapshot,
    strings: AppStrings,
    onPlayNew: () -> Unit,
    onContinue: () -> Unit,
    onOpenWorldBrowser: () -> Unit,
    onOpenVrSettings: () -> Unit,
    onOpenControls: () -> Unit,
    onOpenGraphics: () -> Unit,
    onToggleLanguage: () -> Unit,
    onExitApp: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(VrObsidian, Color(0xFF0A1428), VrObsidian)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.35f)),
                    colors = CardDefaults.cardColors(containerColor = VrSlateSurface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_supermarket),
                            contentDescription = strings.appTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            VrObsidian.copy(alpha = 0.55f),
                                            VrObsidian.copy(alpha = 0.96f)
                                        )
                                    )
                                )
                        )
                        Surface(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(14.dp),
                            color = VrObsidian.copy(alpha = 0.80f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Visibility,
                                    contentDescription = null,
                                    tint = VrCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = strings.vrModeBadge,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VrCyan
                                )
                            }
                        }
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(18.dp)
                        ) {
                            Text(
                                text = strings.appTitle,
                                style = MaterialTheme.typography.displaySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = strings.subtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Live status strip
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusChip(
                        modifier = Modifier.weight(1f),
                        label = when (settings.controls.activeScheme) {
                            ControlScheme.GAZE -> strings.schemeGaze
                            ControlScheme.XBOX_CONTROLLER -> strings.schemeXbox
                            ControlScheme.HAND_TRACKING -> strings.schemeHand
                        },
                        accent = VrCyan
                    )
                    StatusChip(
                        modifier = Modifier.weight(1f),
                        label = "FOV ${settings.vr.fovDegrees.toInt()}° · ${settings.graphics.targetFps.fps} FPS",
                        accent = VrEmerald
                    )
                    if (xbox.isConnected) {
                        StatusChip(
                            modifier = Modifier.weight(1f),
                            label = "Xbox OK",
                            accent = VrAmber
                        )
                    }
                }
            }

            // Primary Play & Continue Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onPlayNew,
                        modifier = Modifier
                            .weight(1f)
                            .height(58.dp)
                            .testTag("play_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VrCyan,
                            contentColor = VrObsidian
                        )
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = strings.menuPlay,
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = onContinue,
                    enabled = saveGame != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("continue_button"),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        1.dp,
                        if (saveGame != null) VrEmerald else MaterialTheme.colorScheme.outline
                    )
                ) {
                    Icon(
                        Icons.Filled.History,
                        contentDescription = null,
                        tint = if (saveGame != null) VrEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.menuContinue,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (saveGame != null) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (saveGame != null) {
                                "${strings.savedSessionSummary} · $${String.format("%.2f", saveGame.walletBalance)} · ${saveGame.cartProductIds.size} items"
                            } else {
                                strings.noSavedSession
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Menu Grid Items
            item {
                MenuActionCard(
                    title = strings.menuWorldBrowser,
                    subtitle = strings.supportedFormatsHint,
                    icon = Icons.Filled.Public,
                    accent = VrCyan,
                    testTag = "world_browser_button",
                    onClick = onOpenWorldBrowser
                )
            }
            item {
                MenuActionCard(
                    title = strings.menuVrSettings,
                    subtitle = "FOV ${settings.vr.fovDegrees.toInt()}° · IPD ${settings.vr.ipdMm.toInt()}mm · ${if (settings.vr.sideBySideEnabled) "SBS VR" else "Mono"}",
                    icon = Icons.Filled.RemoveRedEye,
                    accent = VrEmerald,
                    testTag = "vr_settings_button",
                    onClick = onOpenVrSettings
                )
            }
            item {
                MenuActionCard(
                    title = strings.menuControls,
                    subtitle = "${strings.schemeGaze} · ${strings.schemeXbox} · ${strings.schemeHand}",
                    icon = Icons.Filled.Gamepad,
                    accent = VrAmber,
                    testTag = "controls_button",
                    onClick = onOpenControls
                )
            }
            item {
                MenuActionCard(
                    title = strings.menuGraphics,
                    subtitle = "${settings.graphics.quality.name} · ${settings.graphics.targetFps.fps} FPS · ${settings.gameMode.name}",
                    icon = Icons.Filled.Tune,
                    accent = Color(0xFFA855F7),
                    testTag = "graphics_settings_button",
                    onClick = onOpenGraphics
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("language_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.Language, contentDescription = null, tint = VrCyan)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.menuLanguage, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    OutlinedButton(
                        onClick = onExitApp,
                        modifier = Modifier
                            .height(52.dp)
                            .testTag("exit_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = strings.menuExit,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(strings.menuExit, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusChip(modifier: Modifier = Modifier, label: String, accent: Color) {
    Surface(
        modifier = modifier,
        color = accent.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun MenuActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
