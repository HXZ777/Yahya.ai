package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppLanguage
import com.example.ui.MainUiState
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoisePrimary

@Composable
fun SettingsScreen(
    uiState: MainUiState,
    strings: AppStrings,
    contentPadding: PaddingValues,
    onLanguageChange: (AppLanguage) -> Unit,
    onRefreshIntervalChange: (Long) -> Unit,
    onCompositorHzToggle: (Boolean) -> Unit,
    onHideDxvkToggle: (Boolean) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAppInfoSettings: () -> Unit,
) {
    val settings = uiState.settings

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 16.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text = strings.settingsTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                )
                Text(
                    text = strings.settingsSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )

                // Language Selection
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = strings.languageSection,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FilterChip(
                                selected = settings.language == AppLanguage.ARABIC,
                                onClick = { onLanguageChange(AppLanguage.ARABIC) },
                                label = { Text(strings.arabicLabel) },
                                modifier = Modifier.testTag("lang_ar_button"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TurquoisePrimary.copy(alpha = 0.2f),
                                    selectedLabelColor = TurquoisePrimary,
                                    containerColor = NavyElevated,
                                    labelColor = TextSecondary,
                                ),
                            )
                            FilterChip(
                                selected = settings.language == AppLanguage.ENGLISH,
                                onClick = { onLanguageChange(AppLanguage.ENGLISH) },
                                label = { Text(strings.englishLabel) },
                                modifier = Modifier.testTag("lang_en_button"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TurquoisePrimary.copy(alpha = 0.2f),
                                    selectedLabelColor = TurquoisePrimary,
                                    containerColor = NavyElevated,
                                    labelColor = TextSecondary,
                                ),
                            )
                        }
                    }
                }

                // Refresh Interval
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = strings.refreshRateSection,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )
                        val intervals = listOf(
                            500L to strings.refreshFast,
                            1000L to strings.refreshBalanced,
                            2000L to strings.refreshSaver,
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            intervals.forEach { (ms, label) ->
                                FilterChip(
                                    selected = settings.refreshIntervalMs == ms,
                                    onClick = { onRefreshIntervalChange(ms) },
                                    label = { Text(label) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = TurquoisePrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = TurquoisePrimary,
                                        containerColor = NavyElevated,
                                        labelColor = TextSecondary,
                                    ),
                                )
                            }
                        }
                    }
                }

                // Sensor Options
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = strings.telemetryOptionsSection,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )

                        ToggleOptionRow(
                            title = strings.compositorHzTitle,
                            description = strings.compositorHzDesc,
                            checked = settings.useCompositorHzFallback,
                            onCheckedChange = onCompositorHzToggle,
                            testTag = "switch_compositor_hz",
                        )

                        HorizontalDivider(color = NavyBorder)

                        ToggleOptionRow(
                            title = strings.hideDxvkTitle,
                            description = strings.hideDxvkDesc,
                            checked = settings.hideDxvkWhenNotDetected,
                            onCheckedChange = onHideDxvkToggle,
                            testTag = "switch_hide_dxvk",
                        )
                    }
                }

                // Permissions & MagicOS 8 Compatibility
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = strings.magicosTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )
                        Text(
                            text = strings.magicosDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = onRequestOverlayPermission,
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, NavyBorder),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                            ) {
                                Text(strings.overlayPermTitle, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = onOpenBatterySettings,
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, NavyBorder),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                            ) {
                                Text(strings.permConfigureBtn, maxLines = 1)
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                OutlinedButton(
                                    onClick = onRequestNotificationPermission,
                                    modifier = Modifier.weight(1f),
                                    border = BorderStroke(1.dp, NavyBorder),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                                ) {
                                    Text(strings.notifPermTitle, maxLines = 1)
                                }
                            }
                            OutlinedButton(
                                onClick = onOpenAppInfoSettings,
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, TurquoisePrimary.copy(alpha = 0.6f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TurquoisePrimary),
                            ) {
                                Text(strings.openAppSettingsBtn, maxLines = 1)
                            }
                        }
                    }
                }

                // About Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = strings.aboutSection,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )
                        Text(
                            text = strings.aboutVersion,
                            style = MaterialTheme.typography.bodySmall,
                            color = TurquoisePrimary,
                        )
                        Text(
                            text = strings.aboutArchNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleOptionRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF04241C),
                checkedTrackColor = TurquoisePrimary,
                uncheckedTrackColor = NavyElevated,
                uncheckedBorderColor = NavyBorder,
            ),
        )
    }
}
