package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.ui.theme.RedstoneCoralDark
import com.example.vr.camera.HeadTracker
import com.example.vr.model.AccessibilityBridgeSnapshot
import com.example.vr.model.HeadTrackingSnapshot
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SensorDiagnosticsScreen(
    headState: HeadTrackingSnapshot,
    accessibilityState: AccessibilityBridgeSnapshot,
    headTracker: HeadTracker,
    strings: MineVrStrings,
    onCalibrateForward: () -> Unit,
    onRecenter: () -> Unit,
    onTestAccessibilityLook: () -> Boolean,
    onBack: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    DisposableEffect(Unit) {
        headTracker.start()
        onDispose { headTracker.stop() }
    }

    Scaffold(
        containerColor = MineObsidian,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(strings.sensorDiagTitle, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("sensors_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MineBedrockSurface),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!headState.isGyroSupported) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = RedstoneCoralDark),
                    border = BorderStroke(1.dp, RedstoneCoral)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = RedstoneCoral)
                        Text(strings.sensorMissingWarning, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Live Horizon & Yaw Compass Visualizer
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Canvas(modifier = Modifier.size(168.dp)) {
                        val r = size.minDimension / 2f - 8f
                        drawCircle(color = MineBlockBorder, radius = r, style = Stroke(width = 4f))

                        // Pitch & Roll Horizon Line
                        val pitchShift = (headState.pitchDeg / 90f) * (r * 0.7f)
                        rotate(degrees = -headState.rollDeg, pivot = center) {
                            drawLine(
                                color = DiamondCyan,
                                start = Offset(center.x - r * 0.8f, center.y + pitchShift),
                                end = Offset(center.x + r * 0.8f, center.y + pitchShift),
                                strokeWidth = 5f
                            )
                        }

                        // Calibrated Yaw Compass Needle
                        rotate(degrees = -headState.calibratedYawDeg, pivot = center) {
                            drawLine(
                                color = CreeperEmerald,
                                start = center,
                                end = Offset(center.x, center.y - r * 0.85f),
                                strokeWidth = 6f
                            )
                        }
                        drawCircle(color = GoldAmber, radius = 8f, center = center)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = onCalibrateForward,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("diag_calibrate_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E))
                        ) {
                            Icon(Icons.Filled.CenterFocusStrong, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.calibrateHead)
                        }
                        OutlinedButton(
                            onClick = onRecenter,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("diag_recenter_button")
                        ) {
                            Text(strings.recenterHead)
                        }
                    }
                }
            }

            // Live Telemetry Readouts
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagRow(strings.activeSensorLabel, headState.activeSensorName)
                    DiagRow(strings.sampleRateLabel, "${headState.sampleRateHz} Hz")
                    DiagRow(strings.jitterLabel, "${"%.3f".format(headState.jitterDeg)}°")
                    DiagRow(strings.rawYawLabel, "${"%.2f".format(headState.rawYawDeg)}°")
                    DiagRow(strings.calibratedYawLabel, "${"%.2f".format(headState.calibratedYawDeg)}°")
                    DiagRow(strings.pitchLabel, "${"%.2f".format(headState.pitchDeg)}°")
                    DiagRow(strings.rollLabel, "${"%.2f".format(headState.rollDeg)}°")
                }
            }

            // Accessibility Look Bridge Diagnostics
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagRow(
                        strings.accessibilityLookBridgeLabel,
                        if (accessibilityState.isServiceEnabled) strings.accessibilityEnabledBadge else strings.accessibilityDisabledBadge
                    )
                    DiagRow("Dispatched Look Gestures", accessibilityState.gesturesDispatchedCount.toString())
                    FilledTonalButton(
                        onClick = {
                            val ok = onTestAccessibilityLook()
                            scope.launch {
                                snackbarHostState.showSnackbar(
                                    if (ok) "Test look gesture dispatched" else strings.accessibilityDisabledBadge
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.TouchApp, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.testHeadLookPulse)
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
        Text(value, style = MaterialTheme.typography.labelMedium, color = DiamondCyan)
    }
}
