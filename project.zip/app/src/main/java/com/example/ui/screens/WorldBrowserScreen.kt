package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.ui.viewmodel.WorldBrowserUiState
import com.example.vr.model.AppLanguage
import com.example.vr.model.WorldEntry
import com.example.vr.world.WorldCatalog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldBrowserScreen(
    state: WorldBrowserUiState,
    language: AppLanguage,
    strings: AppStrings,
    onDownloadWorld: (String) -> Unit,
    onLaunchWorld: (WorldEntry) -> Unit,
    onDeleteWorld: (WorldEntry) -> Unit,
    onImportUri: (android.net.Uri) -> Unit,
    onClearFeedback: () -> Unit,
    onBack: () -> Unit
) {
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportUri(uri)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(strings.menuWorldBrowser) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("world_browser_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Import External 3D File Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onClearFeedback()
                                filePicker.launch(arrayOf("*/*"))
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("import_world_file_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VrCyan,
                                contentColor = VrObsidian
                            )
                        ) {
                            Icon(Icons.Filled.FileOpen, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(strings.importExternalWorld, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            text = strings.supportedFormatsHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        val fbText = if (language == AppLanguage.ARABIC) state.importStatusAr else state.importStatusEn
                        if (!fbText.isNullOrBlank()) {
                            Surface(
                                color = if (state.importIsError) VrCoral.copy(alpha = 0.16f) else VrEmerald.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, if (state.importIsError) VrCoral else VrEmerald)
                            ) {
                                Text(
                                    text = fbText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (state.importIsError) Color(0xFFFCA5A5) else VrEmerald,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // World Cards
            items(state.worlds, key = { it.id }) { world ->
                WorldCard(
                    world = world,
                    isActive = world.id == state.activeWorldId,
                    language = language,
                    strings = strings,
                    onDownload = { onDownloadWorld(world.id) },
                    onLaunch = { onLaunchWorld(world) },
                    onDelete = { onDeleteWorld(world) }
                )
            }

            // Supported Open-License Asset Sources Directory
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(strings.openAssetSourcesTitle, style = MaterialTheme.typography.titleMedium)
                        WorldCatalog.openSources.forEach { src ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(src.name, style = MaterialTheme.typography.titleSmall, color = VrCyan)
                                    Text(
                                        text = if (language == AppLanguage.ARABIC) src.licenseNoteAr else src.licenseNoteEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Surface(
                                    color = VrEmerald.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = src.supportedFormats,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VrEmerald,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorldCard(
    world: WorldEntry,
    isActive: Boolean,
    language: AppLanguage,
    strings: AppStrings,
    onDownload: () -> Unit,
    onLaunch: () -> Unit,
    onDelete: () -> Unit
) {
    val thumbRes = when (world.thumbnailKey) {
        "mall" -> R.drawable.img_world_mall
        "town" -> R.drawable.img_world_town
        else -> R.drawable.img_world_supermarket
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(
            width = if (isActive) 2.dp else 1.dp,
            color = if (isActive) VrCyan else MaterialTheme.colorScheme.outline
        )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
            ) {
                Image(
                    painter = painterResource(id = thumbRes),
                    contentDescription = world.titleEn,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = VrObsidian.copy(alpha = 0.82f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "${String.format("%.1f", world.fileSizeMb)} MB · ${world.formatLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = VrCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        color = VrObsidian.copy(alpha = 0.82f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(Icons.Filled.Star, contentDescription = null, tint = VrAmber, modifier = Modifier.size(13.dp))
                            Text("${world.rating}", style = MaterialTheme.typography.labelSmall, color = VrAmber)
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == AppLanguage.ARABIC) world.titleAr else world.titleEn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    if (isActive) {
                        Text(strings.activeWorldTag, style = MaterialTheme.typography.labelSmall, color = VrEmerald)
                    }
                }
                Text(
                    text = if (language == AppLanguage.ARABIC) world.descAr else world.descEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!world.isDownloaded) {
                        Button(
                            onClick = onDownload,
                            modifier = Modifier.weight(1f).testTag("download_world_${world.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = VrEmerald, contentColor = VrObsidian)
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.download)
                        }
                    } else {
                        Button(
                            onClick = onLaunch,
                            modifier = Modifier.weight(1f).testTag("launch_world_${world.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = VrCyan, contentColor = VrObsidian)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.launchWorld)
                        }
                    }

                    if (!world.isBuiltIn && world.isDownloaded) {
                        OutlinedButton(
                            onClick = onDelete,
                            modifier = Modifier.testTag("delete_world_${world.id}"),
                            border = BorderStroke(1.dp, VrCoral.copy(alpha = 0.6f))
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = strings.delete, tint = VrCoral)
                        }
                    }
                }
            }
        }
    }
}
