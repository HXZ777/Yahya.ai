package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.ui.viewmodel.WorldBrowserUiState
import com.example.vr.model.AppLanguage
import com.example.vr.model.WorldEntry
import com.example.vr.world.WorldCatalog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldBrowserScreen(
    state: WorldBrowserUiState,
    language: AppLanguage,
    strings: AppStrings,
    onDownloadWorld: (String) -> Unit,
    onLaunchWorld: (WorldEntry) -> Unit,
    onOpenWorldEditor: (WorldEntry, String) -> Unit,
    onScaleWorld: (WorldEntry, Float) -> Unit,
    onToggleCollision: (WorldEntry) -> Unit,
    onSaveWorld: (WorldEntry) -> Unit,
    onRestoreOriginalWorld: (WorldEntry) -> Unit,
    onDeleteWorld: (WorldEntry) -> Unit,
    onImportUri: (android.net.Uri) -> Unit,
    onClearFeedback: () -> Unit,
    onBack: () -> Unit
) {
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportUri(uri)
        }
    }

    var settingsMenuWorld by remember { mutableStateOf<WorldEntry?>(null) }
    var scaleDialogWorld by remember { mutableStateOf<WorldEntry?>(null) }
    var scaleSliderVal by remember { mutableFloatStateOf(1.0f) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(strings.menuWorldBrowser) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("world_browser_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Import External 3D File Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onClearFeedback()
                                filePicker.launch(arrayOf("*/*"))
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("import_world_file_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VrCyan,
                                contentColor = VrObsidian
                            )
                        ) {
                            Icon(Icons.Filled.FileOpen, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(strings.importExternalWorld, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            text = strings.supportedFormatsHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        val fbText = if (language == AppLanguage.ARABIC) state.importStatusAr else state.importStatusEn
                        if (!fbText.isNullOrBlank()) {
                            Surface(
                                color = if (state.importIsError) VrCoral.copy(alpha = 0.16f) else VrEmerald.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, if (state.importIsError) VrCoral else VrEmerald)
                            ) {
                                Text(
                                    text = fbText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (state.importIsError) Color(0xFFFCA5A5) else VrEmerald,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // World Cards
            items(state.worlds, key = { it.id }) { world ->
                WorldCard(
                    world = world,
                    isActive = world.id == state.activeWorldId,
                    language = language,
                    strings = strings,
                    onDownload = { onDownloadWorld(world.id) },
                    onOpenEditor = { onOpenWorldEditor(world, "transform") },
                    onOpenSettingsMenu = { settingsMenuWorld = world },
                    onLaunch = { onLaunchWorld(world) },
                    onDelete = { onDeleteWorld(world) }
                )
            }

            // Supported Open-License Asset Sources Directory
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(strings.openAssetSourcesTitle, style = MaterialTheme.typography.titleMedium)
                        WorldCatalog.openSources.forEach { src ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(src.name, style = MaterialTheme.typography.titleSmall, color = VrCyan)
                                    Text(
                                        text = if (language == AppLanguage.ARABIC) src.licenseNoteAr else src.licenseNoteEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Surface(
                                    color = VrEmerald.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = src.supportedFormats,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VrEmerald,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 11-item World Settings Menu ModalBottomSheet
    settingsMenuWorld?.let { targetWorld ->
        ModalBottomSheet(
            onDismissRequest = { settingsMenuWorld = null },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "${strings.worldSettingsMenuTitle}: ${if (language == AppLanguage.ARABIC) targetWorld.titleAr else targetWorld.titleEn}",
                    style = MaterialTheme.typography.titleMedium,
                    color = VrCyan,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                HorizontalDivider()
                WorldSettingMenuItem(Icons.Filled.Build, strings.openWorldEditor, VrCyan) {
                    settingsMenuWorld = null
                    onOpenWorldEditor(targetWorld, "transform")
                }
                WorldSettingMenuItem(Icons.Filled.Preview, strings.previewWorldAction, VrEmerald) {
                    settingsMenuWorld = null
                    onOpenWorldEditor(targetWorld, "transform")
                }
                WorldSettingMenuItem(Icons.Filled.LocationOn, strings.spawnPointEditorTitle, VrEmerald) {
                    settingsMenuWorld = null
                    onOpenWorldEditor(targetWorld, "spawn")
                }
                WorldSettingMenuItem(Icons.Filled.Layers, strings.manageModelsAction, VrCyan) {
                    settingsMenuWorld = null
                    onOpenWorldEditor(targetWorld, "hierarchy")
                }
                WorldSettingMenuItem(Icons.Filled.Palette, strings.manageMaterialsAction, VrAmber) {
                    settingsMenuWorld = null
                    onOpenWorldEditor(targetWorld, "materials")
                }
                WorldSettingMenuItem(Icons.Filled.LightMode, strings.lightingEnvTitle, VrAmber) {
                    settingsMenuWorld = null
                    onOpenWorldEditor(targetWorld, "lighting")
                }
                WorldSettingMenuItem(Icons.Filled.AspectRatio, strings.worldScaleAction, VrCyan) {
                    settingsMenuWorld = null
                    scaleSliderVal = 1.0f
                    scaleDialogWorld = targetWorld
                }
                WorldSettingMenuItem(Icons.Filled.Shield, strings.collisionSettingLabel, VrEmerald) {
                    settingsMenuWorld = null
                    onToggleCollision(targetWorld)
                }
                WorldSettingMenuItem(Icons.Filled.Save, strings.saveWorldAction, VrCyan) {
                    settingsMenuWorld = null
                    onSaveWorld(targetWorld)
                }
                WorldSettingMenuItem(Icons.Filled.Restore, strings.restoreOriginalWorld, VrAmber) {
                    settingsMenuWorld = null
                    onRestoreOriginalWorld(targetWorld)
                }
                if (!targetWorld.isBuiltIn) {
                    WorldSettingMenuItem(Icons.Filled.Delete, strings.delete, VrCoral) {
                        settingsMenuWorld = null
                        onDeleteWorld(targetWorld)
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
    }

    scaleDialogWorld?.let { targetWorld ->
        AlertDialog(
            onDismissRequest = { scaleDialogWorld = null },
            title = { Text(strings.worldScaleAction) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${String.format("%.2fx", scaleSliderVal)}", color = VrCyan, style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = scaleSliderVal,
                        onValueChange = { scaleSliderVal = it },
                        valueRange = 0.25f..3.0f
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onScaleWorld(targetWorld, scaleSliderVal)
                    scaleDialogWorld = null
                }) { Text(strings.apply) }
            },
            dismissButton = {
                TextButton(onClick = { scaleDialogWorld = null }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun WorldSettingMenuItem(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun WorldCard(
    world: WorldEntry,
    isActive: Boolean,
    language: AppLanguage,
    strings: AppStrings,
    onDownload: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenSettingsMenu: () -> Unit,
    onLaunch: () -> Unit,
    onDelete: () -> Unit
) {
    val thumbRes = when (world.thumbnailKey) {
        "mall" -> R.drawable.img_world_mall
        "town" -> R.drawable.img_world_town
        else -> R.drawable.img_world_supermarket
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(
            width = if (isActive) 2.dp else 1.dp,
            color = if (isActive) VrCyan else MaterialTheme.colorScheme.outline
        )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
            ) {
                Image(
                    painter = painterResource(id = thumbRes),
                    contentDescription = world.titleEn,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = VrObsidian.copy(alpha = 0.82f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "${String.format("%.1f", world.fileSizeMb)} MB · ${world.formatLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = VrCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        color = VrObsidian.copy(alpha = 0.82f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(Icons.Filled.Star, contentDescription = null, tint = VrAmber, modifier = Modifier.size(13.dp))
                            Text("${world.rating}", style = MaterialTheme.typography.labelSmall, color = VrAmber)
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == AppLanguage.ARABIC) world.titleAr else world.titleEn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    if (isActive) {
                        Text(strings.activeWorldTag, style = MaterialTheme.typography.labelSmall, color = VrEmerald)
                    }
                }
                Text(
                    text = if (language == AppLanguage.ARABIC) world.descAr else world.descEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!world.isDownloaded) {
                        Button(
                            onClick = onDownload,
                            modifier = Modifier.weight(1f).testTag("download_world_${world.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = VrEmerald, contentColor = VrObsidian)
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.download)
                        }
                    } else {
                        if (world.isCustomImported) {
                            OutlinedButton(
                                onClick = onOpenEditor,
                                modifier = Modifier.weight(1f).testTag("edit_world_${world.id}")
                            ) {
                                Icon(Icons.Filled.Build, contentDescription = null, modifier = Modifier.size(16.dp), tint = VrCyan)
                                Spacer(Modifier.width(4.dp))
                                Text(strings.openWorldEditor, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Button(
                            onClick = onLaunch,
                            modifier = Modifier.weight(1f).testTag("launch_world_${world.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = VrCyan, contentColor = VrObsidian)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.launchWorld, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (world.isCustomImported) {
                            OutlinedButton(
                                onClick = onOpenSettingsMenu,
                                modifier = Modifier.testTag("settings_world_${world.id}")
                            ) {
                                Icon(Icons.Filled.Tune, contentDescription = strings.worldSettingsMenuTitle, tint = VrAmber)
                            }
                        }
                    }

                    if (!world.isBuiltIn && world.isDownloaded) {
                        OutlinedButton(
                            onClick = onDelete,
                            modifier = Modifier.testTag("delete_world_${world.id}"),
                            border = BorderStroke(1.dp, VrCoral.copy(alpha = 0.6f))
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = strings.delete, tint = VrCoral)
                        }
                    }
                }
            }
        }
    }
}
