package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.CreeperEmeraldDark
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.vr.model.AppLanguage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppInfoScreen(
    language: AppLanguage,
    strings: MineVrStrings,
    onBack: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    Scaffold(
        containerColor = MineObsidian,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(strings.infoTitle, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("info_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MineBedrockSurface),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .widthIn(max = 680.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.ic_minevr_logo),
                    contentDescription = strings.appTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Column {
                    Text("VR Minecraft (MineVR)", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        if (isAr) "الإصدار 1.0 · أندرويد 14+ (OpenGL ES 3.0)" else "v1.0 · Android 14+ (OpenGL ES 3.0)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                }
            }

            // Complete Step-by-Step How-to-Run Guide inside the app
            Text(
                text = strings.usageStepsTitle,
                style = MaterialTheme.typography.titleMedium,
                color = CreeperEmerald,
                modifier = Modifier.testTag("usage_guide_header")
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = CreeperEmeraldDark.copy(alpha = 0.55f)),
                border = BorderStroke(1.dp, CreeperEmerald),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GuideStep(
                        title = if (isAr) "1. توصيل يد PlayStation (DualShock 4 / DualSense)" else "1. Connect PlayStation Controller",
                        body = if (isAr) {
                            "• بلوتوث: اضغط زر PS + Share/Create معًا 3 ثوانٍ حتى يومض الضوء، ثم اربطها من بلوتوث الهاتف.\n" +
                                "• سلكي: أوصلها بكابل USB-C / OTG.\n" +
                                "• ادخل (إعدادات يد التحكم) لاختبار الأزرار والعصي وحفظ التخصيص."
                        } else {
                            "• Bluetooth: Hold PS + Share/Create for 3 seconds until the lightbar flashes, then pair in Android Bluetooth.\n" +
                                "• Wired: Plug in via USB-C / OTG.\n" +
                                "• Open Controller Settings to test buttons/sticks and save remappings."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "2. ضبط نظارة VR Box والجيروسكوب" else "2. Calibrate VR Box Optics & Gyroscope",
                        body = if (isAr) {
                            "• افتح (إعدادات النظارة) واضبط المسافة بين العينين (IPD 55-72mm) وتصحيح العدسات (K1/K2) ومجال الرؤية (FOV) وأنت تراقب المعاينة المباشرة.\n" +
                                "• اضغط (معايرة الاتجاه الحالي) ثم (حفظ الإعدادات)."
                        } else {
                            "• Open Headset Settings and tune IPD (55-72mm), Barrel Distortion (K1/K2), and FOV while watching the live preview.\n" +
                                "• Tap Calibrate Forward, then Save Settings."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "3. تفعيل تحريك الكاميرا بالرأس (Accessibility)" else "3. Enable Smooth Head-to-Camera Bridge",
                        body = if (isAr) {
                            "• من أسفل (إعدادات النظارة) فعّل (تحريك كاميرا Minecraft بالرأس) ثم اضغط (فتح إعدادات الوصول) وفعّل خدمة VR Minecraft.\n" +
                                "• داخل إعدادات Minecraft Bedrock فعّل التحكم باللمس (Touch) واضبط حساسية الدوران حسب راحتك."
                        } else {
                            "• At the bottom of Headset Settings, enable Head-to-Minecraft Camera Bridge, open Accessibility Settings, and turn on VR Minecraft.\n" +
                                "• Ensure Touch look is active inside Minecraft Bedrock settings."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "4. تشغيل Minecraft داخل VR Box (منع تكرار الشاشة)" else "4. Run Minecraft Over VR Box (No Mirror Loop)",
                        body = if (isAr) {
                            "• اختر وضع (التقاط Minecraft) ثم اضغط START VR ووافق على مشاركة الشاشة.\n" +
                                "• مهمة جدًا على أندرويد 14+: في نافذة مشاركة الشاشة اختر (تطبيق واحد / A single app) ثم اختر Minecraft.\n" +
                                "• بعدها اضغط زر (عرض VR فوق Minecraft) وامنح صلاحية (الظهور فوق التطبيقات) ليطفو انقسام VR Box فوق اللعبة مباشرة!\n" +
                                "• إذا كنت على أندرويد 13 أو اخترت الشاشة كاملة، استخدم زر (تشغيل مع تقسيم الشاشة) أو جرّب وضع 3D Voxel VR المجسم."
                        } else {
                            "• Select Minecraft Live Capture, tap START VR, and accept Screen Capture.\n" +
                                "• Important on Android 14+: choose 'A single app' and pick Minecraft in the system dialog.\n" +
                                "• Then tap 'Show VR Over Minecraft' and grant Display Over Apps so the VR Box split-screen floats directly over the game!\n" +
                                "• On Android 13 or Entire Screen capture, use Launch Split-Screen or the built-in 3D Voxel VR mode."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "5. طريقة الإطفاء والخروج الآمن" else "5. How to Turn Off & Exit Safely",
                        body = if (isAr) {
                            "• اضغط زر (خروج) في الشريط العائم أسفل الشاشة لإيقاف مشاركة الشاشة والجيروسكوب والنافذة العائمة فورًا.\n" +
                                "• لإطفاء يد التحكم اضغط زر PS باستمرار 10 ثوانٍ."
                        } else {
                            "• Tap Exit on the bottom floating pill to immediately stop screen capture, head tracking, and the VR overlay.\n" +
                                "• Hold the PS button for 10 seconds to power off your controller."
                        }
                    )
                }
            }

            Text(strings.feasibilitySectionTitle, style = MaterialTheme.typography.titleMedium, color = DiamondCyan)

            FeasibilityCard(
                badge = strings.feasibilityFeasibleNow,
                accent = CreeperEmerald,
                body = if (isAr) {
                    "• تقسيم الشاشة لنظارة VR Box بمعايرة المليمتر (IPD، الإزاحة، الحجم، FOV، السطوع، القلب).\n" +
                        "• معالجة عدسات OpenGL ES 3.0 بتصحيح Barrel Distortion (K1/K2) وتنعيم الجيروسكوب السريع.\n" +
                        "• دعم كامل لأزرار وعصي DualShock 4 و DualSense عبر Bluetooth / USB.\n" +
                        "• عالم 3D Voxel VR مجسم حقيقي بعينين منفصلتين لاختبار النظارة والتحكم."
                } else {
                    "• Calibrated VR Box dual-eye optics (IPD, alignment, scale, FOV, brightness, flip).\n" +
                        "• OpenGL ES 3.0 Barrel Distortion shader (K1/K2) & smooth high-rate Gyroscope head tracking.\n" +
                        "• DualShock 4 & DualSense detection, live input tester, and full button remapping.\n" +
                        "• Built-in True Stereoscopic 3D Voxel VR mode with real L/R eye parallax."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityNeedsPermission,
                accent = GoldAmber,
                body = if (isAr) {
                    "• MediaProjection + إشعار الخدمة الأمامية: لالتقاط شاشة Minecraft محليًا عبر GPU SurfaceTexture.\n" +
                        "• الظهور فوق التطبيقات (Overlay): لعرض انقسام VR Box فوق نافذة Minecraft دون لمس اللعبة.\n" +
                        "• AccessibilityService (اختياري): لإرسال إيماءات لمس مستمرة تحرك كاميرا Minecraft عند تحريك الرأس.\n" +
                        "• BLUETOOTH_CONNECT: لعرض حالة يد PlayStation المتصلة."
                } else {
                    "• MediaProjection + Foreground Service: captures Minecraft locally on GPU SurfaceTexture.\n" +
                        "• Display Over Other Apps (Overlay): floats VR split-screen over Minecraft cleanly.\n" +
                        "• AccessibilityService (optional): dispatches continuous touch-look swipes from head motion.\n" +
                        "• BLUETOOTH_CONNECT: reads connected PlayStation controller transport status."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityNeedsGameMod,
                accent = RedstoneCoral,
                body = if (isAr) {
                    "• الرؤية المجسمة الحقيقية داخل محرك Minecraft Bedrock نفسه (تقديم زاويتين مختلفتين لليسار واليمين من داخل اللعبة) غير ممكنة من تطبيق خارجي بدون تعديل ملفات المحرك أو إضافة مكوّن Native/OpenXR داخل اللعبة.\n" +
                        "• وضع التقاط الشاشة يعرض صورة اللعبة الثنائية الأبعاد داخل عدسات VR مع إمكانية تحريك الكاميرا عبر Accessibility."
                } else {
                    "• True dual-camera 3D depth parallax inside Minecraft Bedrock itself requires modifying the game's native engine or an OpenXR mod loader.\n" +
                        "• MediaProjection wraps the 2D game frame into calibrated VR Box lens distortion (cinema/head-tracked VR view)."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityStandaloneLimit,
                accent = MaterialTheme.colorScheme.onSurfaceVariant,
                body = if (isAr) {
                    "• على أندرويد 13 أو عند اختيار (الشاشة الكاملة) في مشاركة الشاشة، أي نافذة فوق الشاشة سيتم التقاطها داخل نفسها؛ لذا استخدم أندرويد 14+ (تطبيق واحد) أو تقسيم الشاشة Split-Screen."
                } else {
                    "• On Android 13 or Entire Screen capture, any overlay on screen is captured recursively; use Android 14+ Single-App capture or Split-Screen."
                }
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(strings.permissionsSectionTitle, style = MaterialTheme.typography.titleSmall, color = CreeperEmerald)
                    Text(
                        text = if (isAr) {
                            "جميع قراءات المستشعرات والتقاط الشاشة تتم محليًا بالكامل على الهاتف. لا يجمع التطبيق أي بيانات ولا يرسل أي بث أو صور لأي خادم خارجي."
                        } else {
                            "All sensor processing and MediaProjection frames remain 100% local on-device. No telemetry or screen captures are ever sent off the phone."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideStep(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = DiamondCyan)
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun FeasibilityCard(badge: String, accent: Color, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(badge, style = MaterialTheme.typography.titleSmall, color = accent)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
        }
    }
}
