package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.CreeperEmeraldDark
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.vr.model.AppLanguage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppInfoScreen(
    language: AppLanguage,
    strings: MineVrStrings,
    onBack: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    Scaffold(
        containerColor = MineObsidian,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(strings.infoTitle, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("info_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MineBedrockSurface),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .widthIn(max = 680.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.ic_minevr_logo),
                    contentDescription = strings.appTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Column {
                    Text("VR Minecraft (MineVR)", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        if (isAr) "الإصدار 1.0 · أندرويد 13+ (Shizuku Virtual Display + OpenGL ES 3.0)" else "v1.0 · Android 13+ (Shizuku Virtual Display + OpenGL ES 3.0)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                }
            }

            // Complete Step-by-Step How-to-Run Guide inside the app
            Text(
                text = strings.usageStepsTitle,
                style = MaterialTheme.typography.titleMedium,
                color = CreeperEmerald,
                modifier = Modifier.testTag("usage_guide_header")
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = CreeperEmeraldDark.copy(alpha = 0.55f)),
                border = BorderStroke(1.dp, CreeperEmerald),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GuideStep(
                        title = if (isAr) "1. توصيل يد PlayStation (DualShock 4 / DualSense)" else "1. Connect PlayStation Controller",
                        body = if (isAr) {
                            "• بلوتوث: اضغط زر PS + Share/Create معًا 3 ثوانٍ حتى يومض الضوء، ثم اربطها من بلوتوث الهاتف.\n" +
                                "• سلكي: أوصلها بكابل USB-C / OTG.\n" +
                                "• ادخل (إعدادات يد التحكم) لاختبار الأزرار والعصي وحفظ التخصيص."
                        } else {
                            "• Bluetooth: Hold PS + Share/Create for 3 seconds until the lightbar flashes, then pair in Android Bluetooth.\n" +
                                "• Wired: Plug in via USB-C / OTG.\n" +
                                "• Open Controller Settings to test buttons/sticks and save remappings."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "2. ضبط نظارة VR Box والجيروسكوب" else "2. Calibrate VR Box Optics & Gyroscope",
                        body = if (isAr) {
                            "• افتح (إعدادات النظارة) واضبط المسافة بين العينين (IPD 55-72mm) وتصحيح العدسات (K1/K2) ومجال الرؤية (FOV) وأنت تراقب المعاينة المباشرة.\n" +
                                "• اضغط (معايرة الاتجاه الحالي) ثم (حفظ الإعدادات)."
                        } else {
                            "• Open Headset Settings and tune IPD (55-72mm), Barrel Distortion (K1/K2), and FOV while watching the live preview.\n" +
                                "• Tap Calibrate Forward, then Save Settings."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "3. تشغيل عبر Shizuku (Android 13 بدون تكرار الشاشة)" else "3. Run via Shizuku Virtual Display (Android 13 Zero-Loop)",
                        body = if (isAr) {
                            "• شغّل تطبيق Shizuku عبر التصحيح اللاسلكي (Wireless Debugging) بدون أي صلاحيات Root.\n" +
                                "• امنح صلاحية Shizuku من الصفحة الرئيسية لـ VR Minecraft.\n" +
                                "• اختر وضع (شاشة VR معزولة عبر Shizuku) واضغط START VR: سيتم تشغيل Minecraft داخل شاشة وهمية مخفية، فتظهر في العدستين بدون أي مرآة متكررة، ويتم تمرير حركة الرأس ويد PlayStation مباشرة إليها."
                        } else {
                            "• Start Shizuku via Wireless Debugging (zero Root required) and grant Shizuku permission on VR Minecraft's home screen.\n" +
                                "• Select Shizuku Virtual Display and tap START VR: Minecraft runs on an isolated off-screen display with zero mirror loop while gyro head-look and PS4/PS5 controller events forward directly to it."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "4. البديل بدون Shizuku (MediaProjection / 3D Voxel)" else "4. Fallback Without Shizuku (MediaProjection / 3D Voxel)",
                        body = if (isAr) {
                            "• إذا لم يتوفر Shizuku على أندرويد 14+: استخدم وضع MediaProjection واختر (تطبيق واحد) ← Minecraft ثم (عرض VR فوق Minecraft).\n" +
                                "• على أندرويد 13 بدون Shizuku: التقاط الشاشة الكامل يلتقط النافذة العائمة مع اللعبة (تكرار مرآة)، لذلك يُنصح دائمًا بوضع Shizuku أو وضع 3D Voxel VR."
                        } else {
                            "• Without Shizuku on Android 14+: use MediaProjection and pick 'A single app' -> Minecraft, then Show VR Over Minecraft.\n" +
                                "• On Android 13 without Shizuku: global capture sees overlays recursively, so use Shizuku Virtual Display or 3D Voxel VR."
                        }
                    )
                    GuideStep(
                        title = if (isAr) "5. طريقة الإطفاء والخروج الآمن" else "5. How to Turn Off & Exit Safely",
                        body = if (isAr) {
                            "• اضغط زر (خروج) في الشريط العائم أسفل الشاشة لإيقاف مشاركة الشاشة والجيروسكوب والنافذة العائمة فورًا.\n" +
                                "• لإطفاء يد التحكم اضغط زر PS باستمرار 10 ثوانٍ."
                        } else {
                            "• Tap Exit on the bottom floating pill to immediately stop screen capture, head tracking, and the VR overlay.\n" +
                                "• Hold the PS button for 10 seconds to power off your controller."
                        }
                    )
                }
            }

            Text(strings.feasibilitySectionTitle, style = MaterialTheme.typography.titleMedium, color = DiamondCyan)

            FeasibilityCard(
                badge = strings.feasibilityFeasibleNow,
                accent = CreeperEmerald,
                body = if (isAr) {
                    "• تقسيم الشاشة لنظارة VR Box بمعايرة المليمتر (IPD، الإزاحة، الحجم، FOV، السطوع، القلب).\n" +
                        "• معالجة عدسات OpenGL ES 3.0 بتصحيح Barrel Distortion (K1/K2) وتنعيم الجيروسكوب السريع.\n" +
                        "• دعم كامل لأزرار وعصي DualShock 4 و DualSense عبر Bluetooth / USB.\n" +
                        "• عالم 3D Voxel VR مجسم حقيقي بعينين منفصلتين لاختبار النظارة والتحكم."
                } else {
                    "• Calibrated VR Box dual-eye optics (IPD, alignment, scale, FOV, brightness, flip).\n" +
                        "• OpenGL ES 3.0 Barrel Distortion shader (K1/K2) & smooth high-rate Gyroscope head tracking.\n" +
                        "• DualShock 4 & DualSense detection, live input tester, and full button remapping.\n" +
                        "• Built-in True Stereoscopic 3D Voxel VR mode with real L/R eye parallax."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityNeedsPermission,
                accent = GoldAmber,
                body = if (isAr) {
                    "• Shizuku UserService (Shell UID 2000 بدون روت): ينشئ شاشة وهمية معزولة VirtualDisplay ويشغّل Minecraft عليها ويمرر أزرار يد PS ولمس الكاميرا مباشرة.\n" +
                        "• MediaProjection + الظهور فوق التطبيقات: خيار ثانوي لالتقاط الشاشة.\n" +
                        "• AccessibilityService (اختياري): بديل لإيماءات اللمس في وضع MediaProjection.\n" +
                        "• BLUETOOTH_CONNECT: لعرض حالة يد PlayStation المتصلة."
                } else {
                    "• Shizuku UserService (Shell UID 2000, No Root): creates an isolated VirtualDisplay, launches Minecraft on it, and injects PS controller & head-look events.\n" +
                        "• MediaProjection + Overlay: fallback screen-capture path.\n" +
                        "• AccessibilityService (optional): gesture fallback in MediaProjection mode.\n" +
                        "• BLUETOOTH_CONNECT: reads connected PlayStation controller status."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityNeedsGameMod,
                accent = RedstoneCoral,
                body = if (isAr) {
                    "• الرؤية المجسمة الحقيقية داخل محرك Minecraft Bedrock نفسه (تقديم زاويتين مختلفتين لليسار واليمين من داخل اللعبة) غير ممكنة من تطبيق خارجي بدون تعديل ملفات المحرك؛ لأن Minecraft تصدر إطار كاميرا ثنائي الأبعاد واحدًا فقط.\n" +
                        "• يقوم VR Minecraft بعرض هذا الإطار بنسبة أبعاد صحيحة داخل عدستي VR Box مع تتبع الرأس (Cinema/Head-Tracked VR)، بينما يوفر وضع 3D Voxel VR مجسمات ثلاثية الأبعاد حقيقية لاختبار النظارة."
                } else {
                    "• True dual-camera 3D depth parallax inside closed-source Minecraft Bedrock requires modifying the game's native C++ engine; the game outputs one 2D camera frame per refresh.\n" +
                        "• VR Minecraft renders that frame with true aspect-fit and VR Box optics (head-tracked VR theater), while 3D Voxel VR demonstrates genuine stereoscopic L/R depth."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityStandaloneLimit,
                accent = MaterialTheme.colorScheme.onSurfaceVariant,
                body = if (isAr) {
                    "• على بعض واجهات الشركات (مثل MIUI/HyperOS) قد يتطلب إنشاء VirtualDisplay أو حقن الإدخال عبر Shizuku تفعيل خيار (USB debugging - Security settings) في خيارات المطور، وفي حال رفض النظام ستظهر رسالة الخطأ الدقيقة."
                } else {
                    "• On some OEM ROMs (e.g., MIUI/HyperOS), Shizuku VirtualDisplay or input injection may require enabling 'USB debugging (Security settings)' in Developer Options; any ROM rejection is surfaced verbatim."
                }
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(strings.permissionsSectionTitle, style = MaterialTheme.typography.titleSmall, color = CreeperEmerald)
                    Text(
                        text = if (isAr) {
                            "جميع قراءات المستشعرات والتقاط الشاشة تتم محليًا بالكامل على الهاتف. لا يجمع التطبيق أي بيانات ولا يرسل أي بث أو صور لأي خادم خارجي."
                        } else {
                            "All sensor processing and MediaProjection frames remain 100% local on-device. No telemetry or screen captures are ever sent off the phone."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideStep(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = DiamondCyan)
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun FeasibilityCard(badge: String, accent: Color, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(badge, style = MaterialTheme.typography.titleSmall, color = accent)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
        }
    }
}
