package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.vr.model.AppLanguage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppInfoScreen(
    language: AppLanguage,
    strings: MineVrStrings,
    onBack: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    Scaffold(
        containerColor = MineObsidian,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(strings.infoTitle, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("info_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MineBedrockSurface),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .widthIn(max = 680.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.ic_minevr_logo),
                    contentDescription = strings.appTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Column {
                    Text("VR Minecraft (MineVR)", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        if (isAr) "الإصدار 1.0 · أندرويد 14+ (OpenGL ES 3.0)" else "v1.0 · Android 14+ (OpenGL ES 3.0)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                }
            }

            Text(strings.feasibilitySectionTitle, style = MaterialTheme.typography.titleMedium, color = DiamondCyan)

            FeasibilityCard(
                badge = strings.feasibilityFeasibleNow,
                accent = CreeperEmerald,
                body = if (isAr) {
                    "• تقسيم الشاشة لنظارة VR Box بمعايرة المليمتر (IPD، الإزاحة، الحجم، FOV، السطوع، القلب).\n" +
                        "• معالجة عدسات OpenGL ES 3.0 بتصحيح Barrel Distortion (K1/K2) وتنعيم الجيروسكوب.\n" +
                        "• دعم كامل لأزرار وعصي DualShock 4 و DualSense عبر Bluetooth / USB.\n" +
                        "• عالم 3D Voxel VR مجسم حقيقي بعينين منفصلتين لاختبار النظارة والتحكم."
                } else {
                    "• Calibrated VR Box dual-eye optics (IPD, alignment, scale, FOV, brightness, flip).\n" +
                        "• OpenGL ES 3.0 Barrel Distortion shader (K1/K2) & filtered Gyroscope head tracking.\n" +
                        "• DualShock 4 & DualSense detection, live input tester, and full button remapping.\n" +
                        "• Built-in True Stereoscopic 3D Voxel VR mode with real L/R eye parallax."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityNeedsPermission,
                accent = GoldAmber,
                body = if (isAr) {
                    "• MediaProjection + إشعار الخدمة الأمامية: لالتقاط شاشة Minecraft محليًا عبر GPU SurfaceTexture.\n" +
                        "• AccessibilityService (اختياري): لإرسال إيماءات لمس تحرك كاميرا Minecraft عند تحريك الرأس.\n" +
                        "• BLUETOOTH_CONNECT: لعرض حالة يد PlayStation المتصلة."
                } else {
                    "• MediaProjection + Foreground Service: captures Minecraft locally on GPU SurfaceTexture.\n" +
                        "• AccessibilityService (optional): dispatches touch-look swipes from gyroscope head motion.\n" +
                        "• BLUETOOTH_CONNECT: reads connected PlayStation controller transport status."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityNeedsGameMod,
                accent = RedstoneCoral,
                body = if (isAr) {
                    "• الرؤية المجسمة الحقيقية داخل محرك Minecraft Bedrock نفسه (تقديم زاويتين مختلفتين لليسار واليمين من داخل اللعبة) غير ممكنة من تطبيق خارجي بدون تعديل ملفات المحرك أو إضافة مكوّن Native/OpenXR داخل اللعبة.\n" +
                        "• وضع التقاط الشاشة يعرض صورة اللعبة الثنائية الأبعاد داخل عدسات VR مع إمكانية تحريك الكاميرا عبر Accessibility."
                } else {
                    "• True dual-camera 3D depth parallax inside Minecraft Bedrock itself requires modifying the game's native engine or an OpenXR mod loader.\n" +
                        "• MediaProjection wraps the 2D game frame into calibrated VR Box lens distortion (cinema/head-tracked VR view)."
                }
            )

            FeasibilityCard(
                badge = strings.feasibilityStandaloneLimit,
                accent = MaterialTheme.colorScheme.onSurfaceVariant,
                body = if (isAr) {
                    "• في الهواتف أحادية الشاشة بدون روت، إبقاء تطبيق MineVR في ملء الشاشة يوقف نشاط Minecraft بالخلفية ما لم تستخدم وضع تقسيم الشاشة (Split-Screen) أو شاشة ثانوية."
                } else {
                    "• On single-screen unrooted phones, putting MineVR fullscreen pauses background apps unless using Android Split-Screen or a secondary display."
                }
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(strings.permissionsSectionTitle, style = MaterialTheme.typography.titleSmall, color = CreeperEmerald)
                    Text(
                        text = if (isAr) {
                            "جميع قراءات المستشعرات والتقاط الشاشة تتم محليًا بالكامل على الهاتف. لا يجمع التطبيق أي بيانات ولا يرسل أي بث أو صور لأي خادم خارجي."
                        } else {
                            "All sensor processing and MediaProjection frames remain 100% local on-device. No telemetry or screen captures are ever sent off the phone."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MineTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun FeasibilityCard(badge: String, accent: Color, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(badge, style = MaterialTheme.typography.titleSmall, color = accent)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
        }
    }
}
