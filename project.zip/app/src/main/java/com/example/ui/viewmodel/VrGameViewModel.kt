package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.VrAudioEngine
import com.example.settings.GameSettingsRepository
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.GameSimulationController
import com.example.vr.engine.VrRenderer
import com.example.vr.input.HandTrackingManager
import com.example.vr.input.XboxControllerManager
import com.example.vr.model.AllSettingsState
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControlScheme
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GraphicsSettingsState
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.SaveGameState
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.VrSettingsState
import com.example.vr.model.WorldEntry
import com.example.vr.model.WorldProjectState
import com.example.vr.world.ImportResult
import com.example.vr.world.WorldAssetImporter
import com.example.vr.world.WorldCatalog
import com.example.vr.world.WorldEditorManager
import com.example.vr.world.WorldProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class WorldBrowserUiState(
    val worlds: List<WorldEntry> = WorldCatalog.builtInWorlds,
    val activeWorldId: String = "world_grand_supermarket",
    val importStatusEn: String? = null,
    val importStatusAr: String? = null,
    val importIsError: Boolean = false
)

class VrGameViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = GameSettingsRepository(application)
    val headTracker = HeadTracker(application)
    val xboxManager = XboxControllerManager()
    val handTracker = HandTrackingManager(application)
    val audioEngine = VrAudioEngine()
    val editorManager = WorldEditorManager()

    val simulationController = GameSimulationController(
        headTracker = headTracker,
        xboxManager = xboxManager,
        audioEngine = audioEngine,
        onAutoSave = { save ->
            viewModelScope.launch(Dispatchers.IO) {
                repo.saveGame(save)
            }
        }
    )

    val renderer = VrRenderer(simulationController).apply {
        displayMetrics = application.resources.displayMetrics
    }

    val settingsState: StateFlow<AllSettingsState> = repo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AllSettingsState())

    val saveGameState: StateFlow<SaveGameState?> = repo.saveGameFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _activeWorldId = MutableStateFlow("world_grand_supermarket")
    private val _importFeedback = MutableStateFlow<Triple<String?, String?, Boolean>>(Triple(null, null, false))
    private val cachedCustomMeshes = mutableMapOf<String, ImportedMeshData>()

    val worldBrowserState: StateFlow<WorldBrowserUiState> = combine(
        repo.downloadedWorldIdsFlow,
        repo.customWorldsFlow,
        _activeWorldId,
        _importFeedback
    ) { downloadedIds, customWorlds, activeId, fb ->
        val builtIns = WorldCatalog.builtInWorlds.map { w ->
            w.copy(isDownloaded = w.isBuiltIn || w.id in downloadedIds)
        }
        WorldBrowserUiState(
            worlds = builtIns + customWorlds,
            activeWorldId = activeId,
            importStatusEn = fb.first,
            importStatusAr = fb.second,
            importIsError = fb.third
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, WorldBrowserUiState())

    init {
        xboxManager.refreshConnectedDevices()

        viewModelScope.launch {
            settingsState.collect { st ->
                headTracker.horizonLockEnabled = st.vr.horizonLockEnabled
                handTracker.updateSensitivity(st.controls.handTrackingSensitivity)
                simulationController.updateSettings(st)
                renderer.settings = st
            }
        }
        viewModelScope.launch {
            handTracker.state.collect { hs ->
                renderer.handState = hs
                simulationController.updateHandTrackingState(hs)
            }
        }
        viewModelScope.launch {
            editorManager.state.collect { ed ->
                renderer.activeProject = ed.project
                renderer.editorSelectedNodeId = ed.selectedNodeId
                renderer.editorSelectedSpawnId = ed.selectedSpawnId
                renderer.editorWholeWorldSelected = ed.wholeWorldSelected
                renderer.editorAxisHighlight = ed.activeAxis
            }
        }
    }

    fun toggleLanguage() {
        val cur = settingsState.value
        val next = if (cur.language == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        updateSettings(cur.copy(language = next))
    }

    fun updateVrSettings(transform: (VrSettingsState) -> VrSettingsState) {
        val cur = settingsState.value
        updateSettings(cur.copy(vr = transform(cur.vr)))
    }

    fun updateControlsSettings(transform: (ControlsSettingsState) -> ControlsSettingsState) {
        val cur = settingsState.value
        updateSettings(cur.copy(controls = transform(cur.controls)))
    }

    fun updateGraphicsSettings(transform: (GraphicsSettingsState) -> GraphicsSettingsState) {
        val cur = settingsState.value
        updateSettings(cur.copy(graphics = transform(cur.graphics)))
    }

    fun updateAllSettings(transform: (AllSettingsState) -> AllSettingsState) {
        updateSettings(transform(settingsState.value))
    }

    private fun updateSettings(updated: AllSettingsState) {
        viewModelScope.launch {
            repo.saveSettings(updated)
        }
    }

    fun calibrateHeadsetYaw() {
        val newOffset = headTracker.calibrateZeroYaw()
        updateVrSettings { it.copy(yawZeroOffsetDeg = newOffset) }
    }

    fun prepareWorldForEditor(worldId: String, onReady: () -> Unit = {}) {
        val entry = worldBrowserState.value.worlds.find { it.id == worldId } ?: return
        _activeWorldId.value = entry.id
        renderer.editorMode = true
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val texQuality = settingsState.value.graphics.textureQuality
            val texDir = WorldProjectRepository.texturesDir(app, entry.id)
            val unpackDir = WorldProjectRepository.unpackedDir(app, entry.id)

            val mesh = cachedCustomMeshes[entry.id] ?: WorldAssetImporter.loadCachedCustomMesh(
                path = entry.customAssetPath,
                texturesOutDir = texDir,
                unpackedOutDir = unpackDir,
                maxTexDimPx = texQuality.maxDimensionPx
            )?.also { cachedCustomMeshes[entry.id] = it }

            var project = WorldProjectRepository.loadProject(app, entry.id)
            if (project == null && mesh != null) {
                project = WorldProjectRepository.buildInitialProject(entry, mesh)
                project = WorldProjectRepository.saveProject(app, project, saveAsOriginalIfMissing = true)
            }

            // Load any extra imported prop meshes referenced by project nodes
            renderer.clearExtraModelMeshes()
            project?.nodes?.forEach { node ->
                val p = node.assetPath
                if (!p.isNullOrBlank() && p != project.rootAssetPath) {
                    val extraMesh = WorldAssetImporter.loadCachedCustomMesh(p, texDir, null, texQuality.maxDimensionPx)
                    if (extraMesh != null) {
                        renderer.registerExtraModelMesh(p, extraMesh)
                    }
                }
            }

            withContext(Dispatchers.Main) {
                renderer.setCustomImportedMesh(mesh)
                if (project != null) {
                    editorManager.openProject(project)
                }
                onReady()
            }
        }
    }

    fun playFromEditor(overrideSpawn: SpawnPointEntry? = null) {
        val proj = editorManager.state.value.project ?: return
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val savedProj = WorldProjectRepository.saveProject(app, proj, saveAsOriginalIfMissing = true)
            val entry = worldBrowserState.value.worlds.find { it.id == savedProj.worldId }
            val mesh = cachedCustomMeshes[savedProj.worldId] ?: WorldAssetImporter.loadCachedCustomMesh(
                path = entry?.customAssetPath ?: savedProj.rootAssetPath,
                texturesOutDir = WorldProjectRepository.texturesDir(app, savedProj.worldId),
                unpackedOutDir = WorldProjectRepository.unpackedDir(app, savedProj.worldId),
                maxTexDimPx = settingsState.value.graphics.textureQuality.maxDimensionPx
            )?.also { cachedCustomMeshes[savedProj.worldId] = it }

            withContext(Dispatchers.Main) {
                renderer.editorMode = false
                renderer.activeProject = savedProj
                renderer.setCustomImportedMesh(mesh)
                simulationController.loadCustomWorld(savedProj.worldId, mesh, saved = null, project = savedProj, overrideSpawn = overrideSpawn)
                simulationController.emitAutoSave()
            }
        }
    }

    fun saveEditorProject(worldId: String? = null) {
        val proj = editorManager.state.value.project ?: return
        if (worldId != null && proj.worldId != worldId) return
        viewModelScope.launch(Dispatchers.IO) {
            WorldProjectRepository.saveProject(getApplication(), proj, saveAsOriginalIfMissing = true)
        }
    }

    fun duplicateWorldAsCopy(entry: WorldEntry, onCreated: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val curProj = editorManager.state.value.project
            if (curProj != null && curProj.worldId == entry.id) {
                WorldProjectRepository.saveProject(getApplication(), curProj, saveAsOriginalIfMissing = true)
            }
            val dup = WorldProjectRepository.duplicateProject(getApplication(), entry) ?: return@launch
            repo.addCustomWorld(dup.first)
            cachedCustomMeshes[entry.id]?.let { cachedCustomMeshes[dup.first.id] = it }
            withContext(Dispatchers.Main) {
                _activeWorldId.value = dup.first.id
                editorManager.openProject(dup.second)
                onCreated(dup.first.id)
            }
        }
    }

    fun restoreOriginalWorld(worldId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val restored = WorldProjectRepository.restoreOriginalProject(getApplication(), worldId)
            if (restored != null) {
                withContext(Dispatchers.Main) {
                    editorManager.replaceProjectStateFromRestore(restored)
                }
            }
        }
    }

    fun setWorldScaleAndSave(entry: WorldEntry, scale: Float) {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val existing = WorldProjectRepository.loadProject(app, entry.id)
                ?: cachedCustomMeshes[entry.id]?.let { WorldProjectRepository.buildInitialProject(entry, it) }
                ?: return@launch
            val clamped = scale.coerceIn(0.1f, 10f)
            val updated = existing.copy(
                worldTransform = existing.worldTransform.copy(scaleX = clamped, scaleY = clamped, scaleZ = clamped)
            )
            WorldProjectRepository.saveProject(app, updated, saveAsOriginalIfMissing = true)
            withContext(Dispatchers.Main) {
                if (editorManager.state.value.project?.worldId == entry.id) {
                    editorManager.setWorldUniformScale(clamped)
                }
                if (renderer.activeProject?.worldId == entry.id) {
                    renderer.activeProject = updated
                }
            }
        }
    }

    fun toggleWorldCollisionAndSave(entry: WorldEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val existing = WorldProjectRepository.loadProject(app, entry.id)
                ?: cachedCustomMeshes[entry.id]?.let { WorldProjectRepository.buildInitialProject(entry, it) }
                ?: return@launch
            val updated = existing.copy(collisionEnabled = !existing.collisionEnabled)
            WorldProjectRepository.saveProject(app, updated, saveAsOriginalIfMissing = true)
            withContext(Dispatchers.Main) {
                if (editorManager.state.value.project?.worldId == entry.id) {
                    editorManager.setWorldCollisionEnabled(updated.collisionEnabled)
                }
                if (renderer.activeProject?.worldId == entry.id) {
                    renderer.activeProject = updated
                }
            }
        }
    }

    fun importAdditionalModelToEditor(uri: Uri) {
        val proj = editorManager.state.value.project ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val res = WorldAssetImporter.importAdditionalModelFromUri(
                context = getApplication(),
                worldId = proj.worldId,
                uri = uri,
                textureQuality = settingsState.value.graphics.textureQuality
            )
            res.onSuccess { added ->
                renderer.registerExtraModelMesh(added.assetPath, added.mesh)
                withContext(Dispatchers.Main) {
                    editorManager.addImportedModelNode(added.nodeName, added.assetPath, added.mesh)
                    saveEditorProject()
                }
            }.onFailure { err ->
                withContext(Dispatchers.Main) {
                    _importFeedback.value = Triple(
                        "Failed to add model: ${err.message}",
                        "تعذر إضافة المجسم: ${err.message}",
                        true
                    )
                }
            }
        }
    }

    fun applyPickedTextureToMaterial(mat: PbrMaterialSpec, uri: Uri) {
        val proj = editorManager.state.value.project ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val path = WorldProjectRepository.copyPickedImageToTexture(
                context = getApplication(),
                worldId = proj.worldId,
                uri = uri,
                textureQuality = settingsState.value.graphics.textureQuality
            )
            if (path != null) {
                withContext(Dispatchers.Main) {
                    editorManager.updateMaterial(
                        mat.copy(
                            texturePath = path,
                            missingTextureName = null,
                            userModified = true
                        )
                    )
                    saveEditorProject()
                }
            }
        }
    }

    fun exportCurrentWorldToZip(uri: Uri, onDone: (Boolean) -> Unit) {
        val proj = editorManager.state.value.project ?: return
        val entry = worldBrowserState.value.worlds.find { it.id == proj.worldId } ?: return
        viewModelScope.launch(Dispatchers.IO) {
            WorldProjectRepository.saveProject(getApplication(), proj)
            val ok = WorldProjectRepository.exportProjectAsZip(getApplication(), proj, entry, uri)
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    fun startNewSession(worldEntry: WorldEntry? = null) {
        renderer.editorMode = false
        val worlds = worldBrowserState.value.worlds
        val target = worldEntry ?: worlds.find { it.id == _activeWorldId.value } ?: worlds.first()
        _activeWorldId.value = target.id
        if (target.isCustomImported) {
            val app = getApplication<Application>()
            val cached = cachedCustomMeshes[target.id]
            val savedProj = WorldProjectRepository.loadProject(app, target.id)
            if (cached != null) {
                renderer.activeProject = savedProj
                renderer.setCustomImportedMesh(cached)
                simulationController.loadCustomWorld(target.id, cached, saved = null, project = savedProj)
                simulationController.emitAutoSave()
            } else {
                renderer.setCustomImportedMesh(null)
                simulationController.loadCustomWorld(target.id, null, saved = null, project = savedProj)
                viewModelScope.launch(Dispatchers.IO) {
                    val texDir = WorldProjectRepository.texturesDir(app, target.id)
                    val unpackDir = WorldProjectRepository.unpackedDir(app, target.id)
                    val mesh = WorldAssetImporter.loadCachedCustomMesh(
                        target.customAssetPath,
                        texDir,
                        unpackDir,
                        settingsState.value.graphics.textureQuality.maxDimensionPx
                    )
                    val proj = savedProj ?: mesh?.let { WorldProjectRepository.buildInitialProject(target, it) }
                    proj?.nodes?.forEach { node ->
                        val p = node.assetPath
                        if (!p.isNullOrBlank() && p != proj.rootAssetPath) {
                            WorldAssetImporter.loadCachedCustomMesh(p, texDir, null, settingsState.value.graphics.textureQuality.maxDimensionPx)
                                ?.let { renderer.registerExtraModelMesh(p, it) }
                        }
                    }
                    if (mesh != null) {
                        cachedCustomMeshes[target.id] = mesh
                        withContext(Dispatchers.Main) {
                            renderer.activeProject = proj
                            renderer.setCustomImportedMesh(mesh)
                            simulationController.loadCustomWorld(target.id, mesh, saved = null, project = proj)
                            simulationController.emitAutoSave()
                        }
                    }
                }
            }
        } else {
            renderer.activeProject = null
            renderer.setCustomImportedMesh(null)
            simulationController.loadWorld(target.id, target.type, saved = null)
            simulationController.emitAutoSave()
        }
    }

    fun continueSavedSession() {
        renderer.editorMode = false
        val saved = saveGameState.value
        val worlds = worldBrowserState.value.worlds
        val match = worlds.find { it.id == saved?.activeWorldId }
            ?: worlds.find { it.id == _activeWorldId.value }
            ?: worlds.first()
        _activeWorldId.value = match.id
        if (match.isCustomImported) {
            val app = getApplication<Application>()
            val savedProj = WorldProjectRepository.loadProject(app, match.id)
            val cached = cachedCustomMeshes[match.id]
            if (cached != null) {
                renderer.activeProject = savedProj
                renderer.setCustomImportedMesh(cached)
                simulationController.loadCustomWorld(match.id, cached, saved, project = savedProj)
            } else {
                renderer.setCustomImportedMesh(null)
                simulationController.loadCustomWorld(match.id, null, saved, project = savedProj)
                viewModelScope.launch(Dispatchers.IO) {
                    val texDir = WorldProjectRepository.texturesDir(app, match.id)
                    val unpackDir = WorldProjectRepository.unpackedDir(app, match.id)
                    val mesh = WorldAssetImporter.loadCachedCustomMesh(
                        match.customAssetPath, texDir, unpackDir, settingsState.value.graphics.textureQuality.maxDimensionPx
                    )
                    if (mesh != null) {
                        cachedCustomMeshes[match.id] = mesh
                        withContext(Dispatchers.Main) {
                            renderer.activeProject = savedProj
                            renderer.setCustomImportedMesh(mesh)
                            simulationController.loadCustomWorld(match.id, mesh, saved, project = savedProj)
                        }
                    }
                }
            }
        } else {
            renderer.activeProject = null
            renderer.setCustomImportedMesh(null)
            simulationController.loadWorld(match.id, match.type, saved)
        }
    }

    fun downloadWorld(worldId: String) {
        viewModelScope.launch {
            repo.markWorldDownloaded(worldId, true)
        }
    }

    fun deleteWorld(entry: WorldEntry) {
        viewModelScope.launch {
            if (entry.isCustomImported) {
                cachedCustomMeshes.remove(entry.id)
                WorldAssetImporter.deleteCustomFile(entry.customAssetPath)
                WorldProjectRepository.deleteProjectDir(getApplication(), entry.id)
                repo.removeCustomWorld(entry.id)
            } else if (!entry.isBuiltIn) {
                repo.markWorldDownloaded(entry.id, false)
            }
            if (_activeWorldId.value == entry.id) {
                _activeWorldId.value = "world_grand_supermarket"
                renderer.activeProject = null
                renderer.setCustomImportedMesh(null)
            }
        }
    }

    fun importWorldFromUri(uri: Uri, onImportedOpenEditor: (String) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = WorldAssetImporter.importFromUri(
                context = getApplication(),
                uri = uri,
                textureQuality = settingsState.value.graphics.textureQuality
            )) {
                is ImportResult.Success -> {
                    cachedCustomMeshes[result.worldEntry.id] = result.mesh
                    _activeWorldId.value = result.worldEntry.id
                    repo.addCustomWorld(result.worldEntry)
                    _importFeedback.value = Triple(
                        "Imported '${result.worldEntry.titleEn}': ${result.mesh.diagnostics.summaryEn}",
                        "تم استيراد '${result.worldEntry.titleEn}': ${result.mesh.diagnostics.summaryAr}",
                        false
                    )
                    withContext(Dispatchers.Main) {
                        renderer.clearExtraModelMeshes()
                        renderer.setCustomImportedMesh(result.mesh)
                        editorManager.openProject(result.projectState)
                        renderer.editorMode = true
                        onImportedOpenEditor(result.worldEntry.id)
                    }
                }
                is ImportResult.Rejected -> {
                    _importFeedback.value = Triple(result.reasonEn, result.reasonAr, true)
                }
            }
        }
    }

    fun clearImportFeedback() {
        _importFeedback.value = Triple(null, null, false)
    }

    fun resetSaveData() {
        viewModelScope.launch {
            repo.clearSaveGame()
        }
    }

    fun switchControlScheme(scheme: ControlScheme) {
        updateControlsSettings { it.copy(activeScheme = scheme) }
    }

    override fun onCleared() {
        super.onCleared()
        headTracker.stop()
        handTracker.release()
        audioEngine.release()
        simulationController.release()
    }
}
