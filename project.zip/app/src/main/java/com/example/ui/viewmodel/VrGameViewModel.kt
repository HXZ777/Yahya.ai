package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.VrAudioEngine
import com.example.settings.GameSettingsRepository
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.GameSimulationController
import com.example.vr.engine.VrRenderer
import com.example.vr.input.HandTrackingManager
import com.example.vr.input.XboxControllerManager
import com.example.vr.model.AllSettingsState
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControlScheme
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GraphicsSettingsState
import com.example.vr.model.SaveGameState
import com.example.vr.model.VrSettingsState
import com.example.vr.model.WorldEntry
import com.example.vr.model.WorldType
import com.example.vr.world.ImportResult
import com.example.vr.world.WorldAssetImporter
import com.example.vr.world.WorldCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WorldBrowserUiState(
    val worlds: List<WorldEntry> = WorldCatalog.builtInWorlds,
    val activeWorldId: String = "world_grand_supermarket",
    val importStatusEn: String? = null,
    val importStatusAr: String? = null,
    val importIsError: Boolean = false
)

class VrGameViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = GameSettingsRepository(application)
    val headTracker = HeadTracker(application)
    val xboxManager = XboxControllerManager()
    val handTracker = HandTrackingManager(application)
    val audioEngine = VrAudioEngine()

    val simulationController = GameSimulationController(
        headTracker = headTracker,
        xboxManager = xboxManager,
        audioEngine = audioEngine,
        onAutoSave = { save ->
            viewModelScope.launch(Dispatchers.IO) {
                repo.saveGame(save)
            }
        }
    )

    val renderer = VrRenderer(simulationController).apply {
        displayMetrics = application.resources.displayMetrics
    }

    val settingsState: StateFlow<AllSettingsState> = repo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AllSettingsState())

    val saveGameState: StateFlow<SaveGameState?> = repo.saveGameFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _activeWorldId = MutableStateFlow("world_grand_supermarket")
    private val _importFeedback = MutableStateFlow<Triple<String?, String?, Boolean>>(Triple(null, null, false))

    val worldBrowserState: StateFlow<WorldBrowserUiState> = combine(
        repo.downloadedWorldIdsFlow,
        repo.customWorldsFlow,
        _activeWorldId,
        _importFeedback
    ) { downloadedIds, customWorlds, activeId, fb ->
        val builtIns = WorldCatalog.builtInWorlds.map { w ->
            w.copy(isDownloaded = w.isBuiltIn || w.id in downloadedIds)
        }
        WorldBrowserUiState(
            worlds = builtIns + customWorlds,
            activeWorldId = activeId,
            importStatusEn = fb.first,
            importStatusAr = fb.second,
            importIsError = fb.third
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, WorldBrowserUiState())

    init {
        xboxManager.refreshConnectedDevices()

        viewModelScope.launch {
            settingsState.collect { st ->
                headTracker.horizonLockEnabled = st.vr.horizonLockEnabled
                handTracker.updateSensitivity(st.controls.handTrackingSensitivity)
                simulationController.updateSettings(st)
                renderer.settings = st
            }
        }
        viewModelScope.launch {
            handTracker.state.collect { hs ->
                renderer.handState = hs
                simulationController.updateHandTrackingState(hs)
            }
        }
    }

    fun toggleLanguage() {
        val cur = settingsState.value
        val next = if (cur.language == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        updateSettings(cur.copy(language = next))
    }

    fun updateVrSettings(transform: (VrSettingsState) -> VrSettingsState) {
        val cur = settingsState.value
        updateSettings(cur.copy(vr = transform(cur.vr)))
    }

    fun updateControlsSettings(transform: (ControlsSettingsState) -> ControlsSettingsState) {
        val cur = settingsState.value
        updateSettings(cur.copy(controls = transform(cur.controls)))
    }

    fun updateGraphicsSettings(transform: (GraphicsSettingsState) -> GraphicsSettingsState) {
        val cur = settingsState.value
        updateSettings(cur.copy(graphics = transform(cur.graphics)))
    }

    fun updateAllSettings(transform: (AllSettingsState) -> AllSettingsState) {
        updateSettings(transform(settingsState.value))
    }

    private fun updateSettings(updated: AllSettingsState) {
        viewModelScope.launch {
            repo.saveSettings(updated)
        }
    }

    fun calibrateHeadsetYaw() {
        val newOffset = headTracker.calibrateZeroYaw()
        updateVrSettings { it.copy(yawZeroOffsetDeg = newOffset) }
    }

    fun startNewSession(worldEntry: WorldEntry? = null) {
        val target = worldEntry ?: worldBrowserState.value.worlds.first()
        _activeWorldId.value = target.id
        if (target.isCustomImported) {
            val mesh = WorldAssetImporter.loadCachedCustomMesh(target.customAssetPath)
            renderer.setCustomImportedMesh(mesh)
        } else {
            renderer.setCustomImportedMesh(null)
        }
        simulationController.loadWorld(target.id, target.type, saved = null)
        simulationController.emitAutoSave()
    }

    fun continueSavedSession() {
        val saved = saveGameState.value
        val worlds = worldBrowserState.value.worlds
        val match = worlds.find { it.id == saved?.activeWorldId } ?: worlds.first()
        _activeWorldId.value = match.id
        if (match.isCustomImported) {
            renderer.setCustomImportedMesh(WorldAssetImporter.loadCachedCustomMesh(match.customAssetPath))
        } else {
            renderer.setCustomImportedMesh(null)
        }
        simulationController.loadWorld(match.id, match.type, saved)
    }

    fun downloadWorld(worldId: String) {
        viewModelScope.launch {
            repo.markWorldDownloaded(worldId, true)
        }
    }

    fun deleteWorld(entry: WorldEntry) {
        viewModelScope.launch {
            if (entry.isCustomImported) {
                WorldAssetImporter.deleteCustomFile(entry.customAssetPath)
                repo.removeCustomWorld(entry.id)
            } else if (!entry.isBuiltIn) {
                repo.markWorldDownloaded(entry.id, false)
            }
            if (_activeWorldId.value == entry.id) {
                _activeWorldId.value = "world_grand_supermarket"
                renderer.setCustomImportedMesh(null)
            }
        }
    }

    fun importWorldFromUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = WorldAssetImporter.importFromUri(getApplication(), uri)) {
                is ImportResult.Success -> {
                    repo.addCustomWorld(result.worldEntry)
                    _importFeedback.value = Triple(
                        "Imported '${result.worldEntry.titleEn}' (${result.mesh.vertexCount} vertices) successfully!",
                        "تم استيراد '${result.worldEntry.titleEn}' بنجاح (${result.mesh.vertexCount} نقطة)!",
                        false
                    )
                }
                is ImportResult.Rejected -> {
                    _importFeedback.value = Triple(result.reasonEn, result.reasonAr, true)
                }
            }
        }
    }

    fun clearImportFeedback() {
        _importFeedback.value = Triple(null, null, false)
    }

    fun resetSaveData() {
        viewModelScope.launch {
            repo.clearSaveGame()
        }
    }

    fun switchControlScheme(scheme: ControlScheme) {
        updateControlsSettings { it.copy(activeScheme = scheme) }
    }

    override fun onCleared() {
        super.onCleared()
        headTracker.stop()
        handTracker.release()
        audioEngine.release()
        simulationController.release()
    }
}
