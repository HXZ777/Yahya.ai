package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DragIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DxvkStatus
import com.example.domain.model.OverlaySettings
import com.example.domain.model.StatType
import com.example.domain.model.SystemStatsSnapshot
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.OverlayDivider
import com.example.ui.theme.OverlayPillBg
import com.example.ui.theme.OverlayPillBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoisePrimary
import java.util.Locale

@Composable
fun BrandLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
) {
    val corner = size * 0.24f
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(Color(0xFF202938))
            .border(1.dp, NavyBorder, RoundedCornerShape(corner)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(size * 0.68f)) {
            val w = this.size.width
            val h = this.size.height
            val barWidth = w * 0.21f
            val radius = CornerRadius(barWidth / 2f, barWidth / 2f)
            val bottom = h * 0.90f

            // Left medium-tall bar
            drawRoundRect(
                color = TurquoisePrimary,
                topLeft = Offset(w * 0.11f, h * 0.34f),
                size = Size(barWidth, bottom - h * 0.34f),
                cornerRadius = radius,
            )
            // Center tallest bar
            drawRoundRect(
                color = TurquoisePrimary,
                topLeft = Offset(w * 0.395f, h * 0.10f),
                size = Size(barWidth, bottom - h * 0.10f),
                cornerRadius = radius,
            )
            // Right shortest bar
            drawRoundRect(
                color = TurquoisePrimary,
                topLeft = Offset(w * 0.68f, h * 0.54f),
                size = Size(barWidth, bottom - h * 0.54f),
                cornerRadius = radius,
            )
        }
    }
}

@Composable
fun LiveOverlayPreviewCard(
    settings: OverlaySettings,
    snapshot: SystemStatsSnapshot,
    strings: AppStrings,
    modifier: Modifier = Modifier,
    showDragHint: Boolean = true,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = NavySurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyBorder),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = strings.livePreviewTitle,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                )
                Icon(
                    imageVector = Icons.Outlined.DragIndicator,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp),
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Subtle gaming-backdrop stage so transparency changes are clearly visible
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF17253D),
                                Color(0xFF102A30),
                                Color(0xFF1E1B38),
                            ),
                        ),
                    )
                    .border(1.dp, Color(0xFF283A5A), RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 18.dp),
                contentAlignment = Alignment.Center,
            ) {
                LiveOverlayBarPill(
                    settings = settings,
                    snapshot = snapshot,
                )
            }

            if (showDragHint) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = strings.dragHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
        }
    }
}

@Composable
fun LiveOverlayBarPill(
    settings: OverlaySettings,
    snapshot: SystemStatsSnapshot,
    modifier: Modifier = Modifier,
) {
    val scale = settings.scalePercent / 100f
    val visibleStats = StatType.ORDERED.filter { stat ->
        if (!settings.enabledStats.contains(stat)) return@filter false
        if (stat == StatType.DXVK && settings.hideDxvkWhenNotDetected &&
            snapshot.dxvkStatus == DxvkStatus.NOT_DETECTED
        ) {
            return@filter false
        }
        true
    }

    // Force LTR inside the performance monitor pill so units & values match reference format
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = modifier
                .horizontalScroll(rememberScrollState()),
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape((8f * scale).dp))
                    .background(OverlayPillBg.copy(alpha = settings.backgroundAlpha))
                    .border(
                        width = 1.dp,
                        color = OverlayPillBorder.copy(alpha = (settings.backgroundAlpha * 0.85f + 0.15f)),
                        shape = RoundedCornerShape((8f * scale).dp),
                    )
                    .padding(
                        horizontal = (10f * scale).dp,
                        vertical = (6f * scale).dp,
                    ),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (visibleStats.isEmpty()) {
                    Text(
                        text = "STATS OFF",
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = (settings.fontSizeSp * scale).sp,
                        color = TextMuted,
                    )
                } else {
                    visibleStats.forEachIndexed { index, stat ->
                        if (index > 0) {
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = (6f * scale).dp)
                                    .width(1.dp)
                                    .height((13f * scale).dp)
                                    .background(OverlayDivider),
                            )
                        }
                        val labelColor = Color(settings.statColors[stat] ?: 0xFFFFFFFFL)
                        val (label, value, unavailable) = formatStatPair(stat, snapshot)
                        Text(
                            text = buildAnnotatedString {
                                withStyle(
                                    SpanStyle(
                                        color = labelColor,
                                        fontWeight = FontWeight.Medium,
                                    ),
                                ) {
                                    append(label)
                                }
                                if (value.isNotEmpty()) {
                                    append(" ")
                                    withStyle(
                                        SpanStyle(
                                            color = if (unavailable) TextSecondary else TextPrimary,
                                            fontWeight = FontWeight.Normal,
                                        ),
                                    ) {
                                        append(value)
                                    }
                                }
                            },
                            fontFamily = JetBrainsMonoFamily,
                            fontSize = (settings.fontSizeSp * scale).sp,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

fun formatStatPair(stat: StatType, snapshot: SystemStatsSnapshot): Triple<String, String, Boolean> {
    return when (stat) {
        StatType.DXVK -> if (snapshot.dxvkStatus == DxvkStatus.DETECTED) {
            Triple("DXVK", "", false)
        } else {
            Triple("DXVK", "N/A", true)
        }
        StatType.CPU -> {
            val v = snapshot.cpuPercent?.let { "$it%" } ?: "N/A"
            Triple("CPU", v, snapshot.cpuPercent == null)
        }
        StatType.RAM -> {
            val v = snapshot.ramPercent?.let { "$it%" } ?: "N/A"
            Triple("RAM", v, snapshot.ramPercent == null)
        }
        StatType.PWR -> {
            val v = snapshot.powerWatts?.let { String.format(Locale.US, "%.1fW", it) } ?: "N/A"
            Triple("PWR", v, snapshot.powerWatts == null)
        }
        StatType.TMP -> {
            val v = snapshot.tempCelsius?.let { String.format(Locale.US, "%.1f°C", it) } ?: "N/A"
            Triple("TMP", v, snapshot.tempCelsius == null)
        }
        StatType.FPS -> {
            val v = snapshot.fpsValue?.toString() ?: "N/A"
            Triple("FPS", v, snapshot.fpsValue == null)
        }
    }
}
