package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.StatType
import com.example.ui.MainUiState
import com.example.ui.components.LiveOverlayPreviewCard
import com.example.ui.components.formatStatPair
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoisePrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomizeStatsScreen(
    uiState: MainUiState,
    strings: AppStrings,
    contentPadding: PaddingValues,
    onToggleStat: (StatType, Boolean) -> Unit,
    onApplyPreset: (Set<StatType>) -> Unit,
) {
    val settings = uiState.settings
    val displayOrder = listOf(
        StatType.FPS,
        StatType.CPU,
        StatType.RAM,
        StatType.PWR,
        StatType.TMP,
        StatType.DXVK,
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 16.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = strings.customizeTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                )
                Text(
                    text = strings.customizeSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )

                LiveOverlayPreviewCard(
                    settings = settings,
                    snapshot = uiState.snapshot,
                    strings = strings,
                    showDragHint = false,
                )

                // Quick Presets Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = strings.quickPresetsLabel,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                            )
                            Text(
                                text = String.format(strings.enabledCountFormat, settings.enabledStats.size),
                                style = MaterialTheme.typography.bodySmall,
                                color = TurquoisePrimary,
                            )
                        }

                        val presets = listOf(
                            strings.presetFpsOnly to setOf(StatType.FPS),
                            strings.presetCpuRam to setOf(StatType.CPU, StatType.RAM),
                            strings.presetFpsTmp to setOf(StatType.FPS, StatType.TMP),
                            strings.presetCore4 to setOf(StatType.CPU, StatType.RAM, StatType.PWR, StatType.TMP),
                            strings.presetAll to StatType.entries.toSet(),
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            presets.forEach { (label, presetSet) ->
                                val selected = settings.enabledStats == presetSet
                                FilterChip(
                                    selected = selected,
                                    onClick = { onApplyPreset(presetSet) },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = TurquoisePrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = TurquoisePrimary,
                                        containerColor = NavyElevated,
                                        labelColor = TextSecondary,
                                    ),
                                )
                            }
                        }
                    }
                }
            }
        }

        items(displayOrder, key = { it.key }) { stat ->
            val enabled = settings.enabledStats.contains(stat)
            val statColor = Color(settings.statColors[stat] ?: 0xFFFFFFFFL)
            val (_, currentValue, _) = formatStatPair(stat, uiState.snapshot)

            Surface(
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = NavySurface,
                border = BorderStroke(
                    width = 1.dp,
                    color = if (enabled) statColor.copy(alpha = 0.45f) else NavyBorder,
                ),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(statColor),
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = strings.statTitle(stat),
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                            )
                            Surface(
                                color = NavyElevated,
                                shape = RoundedCornerShape(6.dp),
                            ) {
                                Text(
                                    text = currentValue.ifEmpty { strings.activeShort },
                                    fontFamily = JetBrainsMonoFamily,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = statColor,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = strings.statDescription(stat),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }

                    Switch(
                        checked = enabled,
                        onCheckedChange = { checked -> onToggleStat(stat, checked) },
                        modifier = Modifier.testTag("switch_stat_${stat.key}"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF04241C),
                            checkedTrackColor = TurquoisePrimary,
                            uncheckedTrackColor = NavyElevated,
                            uncheckedBorderColor = NavyBorder,
                        ),
                    )
                }
            }
        }
    }
}
