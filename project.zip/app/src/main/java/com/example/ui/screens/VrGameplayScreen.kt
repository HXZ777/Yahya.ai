package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineTextSecondary
import com.example.vr.engine.MineVrRenderer
import com.example.vr.model.MineVrSettingsState
import com.example.vr.model.ProjectionCaptureState
import com.example.vr.model.VrRenderMode

@Composable
fun VrGameplayScreen(
    settings: MineVrSettingsState,
    projectionState: ProjectionCaptureState,
    isPaused: Boolean,
    renderer: MineVrRenderer,
    strings: MineVrStrings,
    onStartSensors: () -> Unit,
    onStopSensors: () -> Unit,
    onRecenterHead: () -> Unit,
    onTogglePause: () -> Unit,
    onStartProjection: (Int, Intent) -> Unit,
    onStopProjection: () -> Unit,
    onSwitchTo3dTest: () -> Unit,
    onLaunchMinecraftSplit: () -> Unit,
    onExitToMenu: () -> Unit
) {
    val context = LocalContext.current

    BackHandler {
        onStopProjection()
        onExitToMenu()
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            onStartProjection(result.resultCode, result.data!!)
        }
    }

    fun launchCaptureConsent() {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            mgr.createScreenCaptureIntent(MediaProjectionConfig.createConfigForUserChoice())
        } else {
            mgr.createScreenCaptureIntent()
        }
        mediaProjectionLauncher.launch(intent)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        launchCaptureConsent()
    }

    fun requestCaptureFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        launchCaptureConsent()
    }

    DisposableEffect(Unit) {
        renderer.isPreviewMode = false
        onStartSensors()
        onDispose {
            onStopSensors()
        }
    }

    LaunchedEffect(settings.preferredRenderMode) {
        if (settings.preferredRenderMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE &&
            !projectionState.isServiceRunning
        ) {
            requestCaptureFlow()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Fullscreen Hardware-Accelerated OpenGL ES 3.0 VR Surface
        AndroidView(
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(3)
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("vr_gl_surface")
        )

        // Subtle center divider line when SBS is active
        if (settings.vr.sideBySideEnabled) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(2.dp)
                    .fillMaxSize()
                    .background(Color(0x55FFFFFF))
            )
        }

        // Actionable guidance overlay only when waiting for capture or paused
        if (settings.preferredRenderMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE && !projectionState.isServiceRunning) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface.copy(alpha = 0.94f)),
                border = BorderStroke(1.dp, MineBlockBorder),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .widthIn(max = 460.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.awaitingCaptureTitle, style = MaterialTheme.typography.titleMedium, color = DiamondCyan)
                    Text(strings.awaitingCaptureDesc, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { requestCaptureFlow() },
                            colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("grant_capture_button")
                        ) {
                            Icon(Icons.Filled.Cast, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.grantScreenCapture)
                        }
                        OutlinedButton(
                            onClick = onSwitchTo3dTest,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("switch_to_3d_button")
                        ) {
                            Icon(Icons.Filled.ViewInAr, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.switchModeTo3dTest)
                        }
                    }
                }
            }
        } else if (settings.preferredRenderMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE && projectionState.isSelfMirrorWarning) {
            Surface(
                color = MineBedrockSurface.copy(alpha = 0.85f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GoldAmber.copy(alpha = 0.7f)),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp, start = 16.dp, end = 16.dp)
                    .widthIn(max = 580.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(strings.loopbackWarningTitle, style = MaterialTheme.typography.labelMedium, color = GoldAmber)
                        Text(strings.loopbackWarningDesc, style = MaterialTheme.typography.labelSmall, color = MineTextSecondary)
                    }
                    FilledTonalButton(onClick = onLaunchMinecraftSplit) {
                        Text(strings.openMinecraftSplitBtn, style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(onClick = onSwitchTo3dTest) {
                        Text(strings.switchModeTo3dTest, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        if (isPaused) {
            Surface(
                color = Color.Black.copy(alpha = 0.75f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, DiamondCyan),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = strings.vrPausedOverlay,
                    style = MaterialTheme.typography.titleMedium,
                    color = DiamondCyan,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)
                )
            }
        }

        // Minimalist Gameplay HUD: ONLY Recenter, Pause/Resume, Exit
        Surface(
            color = MineBedrockSurface.copy(alpha = 0.78f),
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, MineBlockBorder),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = onRecenterHead,
                    modifier = Modifier.testTag("hud_recenter_button")
                ) {
                    Icon(Icons.Filled.CenterFocusStrong, contentDescription = strings.recenterHead, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.recenterHead, style = MaterialTheme.typography.labelMedium)
                }

                FilledTonalButton(
                    onClick = onTogglePause,
                    modifier = Modifier.testTag("hud_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = if (isPaused) strings.resumeVr else strings.pauseVr,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (isPaused) strings.resumeVr else strings.pauseVr, style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = {
                        onStopProjection()
                        onExitToMenu()
                    },
                    modifier = Modifier.testTag("hud_exit_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = strings.exitVr, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.exitVr, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
