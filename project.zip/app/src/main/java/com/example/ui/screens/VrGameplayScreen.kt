package com.example.ui.screens

import android.opengl.GLSurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Height
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.GameSimulationController
import com.example.vr.engine.SimulationSnapshot
import com.example.vr.engine.TargetStationType
import com.example.vr.engine.VrRenderer
import com.example.vr.input.HandTrackingManager
import com.example.vr.model.AllSettingsState
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControlScheme
import com.example.vr.model.GameMode
import com.example.vr.model.HandTrackingHealth
import com.example.vr.model.HandTrackingState
import com.example.vr.model.MovementMode

@Composable
fun VrGameplayScreen(
    settings: AllSettingsState,
    strings: AppStrings,
    renderer: VrRenderer,
    controller: GameSimulationController,
    headTracker: HeadTracker,
    handTracker: HandTrackingManager,
    handState: HandTrackingState,
    onSwitchScheme: (ControlScheme) -> Unit,
    onExitToMenu: () -> Unit
) {
    val snap by controller.snapshot.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    var showInVrPauseMenu by remember { mutableStateOf(false) }

    BackHandler {
        if (showInVrPauseMenu) {
            showInVrPauseMenu = false
        } else {
            controller.emitAutoSave()
            onExitToMenu()
        }
    }

    DisposableEffect(Unit) {
        headTracker.start()
        onDispose {
            headTracker.stop()
            handTracker.stopCameraTracking()
            controller.emitAutoSave()
        }
    }

    DisposableEffect(settings.controls.activeScheme, settings.controls.handUseFrontCamera) {
        if (settings.controls.activeScheme == ControlScheme.HAND_TRACKING && handTracker.hasCameraPermission()) {
            handTracker.startCameraTracking(lifecycleOwner, settings.controls.handUseFrontCamera, previewView = null)
        } else {
            handTracker.stopCameraTracking()
        }
        onDispose { }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. OpenGL ES 3.0 Stereoscopic / Mono 3D Surface
        AndroidView(
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(3)
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        controller.touchLookDeltaYaw -= dragAmount.x * 0.20f
                        controller.touchLookDeltaPitch -= dragAmount.y * 0.16f
                    }
                }
        )

        // 2. Stereoscopic Split-Screen HUD (Mirrored Left & Right Eyes) or Mono HUD
        if (settings.vr.sideBySideEnabled) {
            Row(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    EyeHudOverlay(snap, settings, handState, strings, onSwitchScheme)
                }
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(Color.Black)
                )
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    EyeHudOverlay(snap, settings, handState, strings, onSwitchScheme)
                }
            }
        } else {
            EyeHudOverlay(snap, settings, handState, strings, onSwitchScheme)
        }

        // 3. Touch / Phone Gameplay Action Bar (for touch testing & quick actions)
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            // Left Walk / Move cluster
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TouchHoldIconBtn(
                    icon = Icons.Filled.ArrowUpward,
                    desc = "Forward",
                    onPressChange = { pressed -> controller.touchMoveForward = if (pressed) 1f else 0f }
                )
                TouchHoldIconBtn(
                    icon = Icons.Filled.ArrowDownward,
                    desc = "Back",
                    onPressChange = { pressed -> controller.touchMoveForward = if (pressed) -1f else 0f }
                )
                if (settings.controls.movementMode == MovementMode.TELEPORT) {
                    SmallHudActionChip(label = strings.teleportAction, onClick = { controller.executeTeleportIfReady() })
                }
                SmallHudActionChip(label = strings.toggleCrouchAction, onClick = { controller.toggleCrouch() })
            }

            // Center / Right Context Actions
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SmallHudActionChip(
                    label = strings.grabAction,
                    highlight = snap.targetedProduct != null || snap.targetedStation != TargetStationType.NONE || snap.targetedNpc != null,
                    onClick = { controller.performPrimaryInteraction() }
                )

                if (snap.heldProduct != null) {
                    SmallHudActionChip(label = strings.putInCartAction, highlight = true, onClick = { controller.putHeldItemInCartOrBasket() })
                    SmallHudActionChip(label = strings.inspectAction, onClick = { controller.rotateHeldProduct(45f, 0f) })
                    SmallHudActionChip(label = strings.placeOnBeltAction, onClick = { controller.placeHeldItemOnBelt() })
                } else {
                    if (snap.cartItems.isNotEmpty() && snap.beltItems.isEmpty()) {
                        SmallHudActionChip(label = strings.placeOnBeltAction, onClick = { controller.moveAllCartItemsToBelt() })
                    }
                    if (snap.beltItems.any { !it.isScanned }) {
                        SmallHudActionChip(label = strings.scanItemAction, highlight = true, onClick = { controller.scanNextBeltItem() })
                    }
                    if (snap.beltItems.isNotEmpty()) {
                        SmallHudActionChip(label = strings.payCardAction, highlight = true, onClick = { controller.payAtCheckout(byCard = true) })
                        SmallHudActionChip(label = strings.payCashAction, onClick = { controller.payAtCheckout(byCard = false) })
                    }
                }

                SmallHudActionChip(label = strings.shoppingListTitle, onClick = { controller.toggleShoppingList() })
                IconButton(
                    onClick = { showInVrPauseMenu = true },
                    modifier = Modifier
                        .size(44.dp)
                        .background(VrObsidian.copy(alpha = 0.78f), CircleShape)
                        .testTag("vr_menu_button")
                ) {
                    Icon(Icons.Filled.Menu, contentDescription = strings.exitToMenuAction, tint = VrCyan)
                }
            }
        }

        // 4. In-VR Pause & Quick Switcher Overlay
        if (showInVrPauseMenu) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(VrObsidian.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.width(340.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.appTitle, style = MaterialTheme.typography.titleMedium)
                            IconButton(onClick = { showInVrPauseMenu = false }) {
                                Icon(Icons.Filled.Close, contentDescription = strings.cancel)
                            }
                        }
                        Text("${strings.walletLabel}: $${String.format("%.2f", snap.walletBalance)} · ${snap.measuredFps} FPS", style = MaterialTheme.typography.bodySmall, color = VrCyan)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onSwitchScheme(ControlScheme.GAZE) }, modifier = Modifier.weight(1f)) {
                                Text("Gaze", maxLines = 1)
                            }
                            OutlinedButton(onClick = { onSwitchScheme(ControlScheme.XBOX_CONTROLLER) }, modifier = Modifier.weight(1f)) {
                                Text("Xbox", maxLines = 1)
                            }
                            OutlinedButton(onClick = { onSwitchScheme(ControlScheme.HAND_TRACKING) }, modifier = Modifier.weight(1f)) {
                                Text("Hand", maxLines = 1)
                            }
                        }
                        OutlinedButton(onClick = { controller.toggleMissionsOverlay(); showInVrPauseMenu = false }, modifier = Modifier.fillMaxWidth()) {
                            Text(strings.missionsTitle)
                        }
                        Button(
                            onClick = {
                                controller.emitAutoSave()
                                onExitToMenu()
                            },
                            modifier = Modifier.fillMaxWidth().testTag("vr_exit_to_menu_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = VrCoral, contentColor = Color.White)
                        ) {
                            Text(strings.exitToMenuAction)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EyeHudOverlay(
    snap: SimulationSnapshot,
    settings: AllSettingsState,
    handState: HandTrackingState,
    strings: AppStrings,
    onSwitchScheme: (ControlScheme) -> Unit
) {
    val isAr = settings.language == AppLanguage.ARABIC
    val hudScale = settings.graphics.hudScale.coerceIn(0.75f, 1.3f)
    val yOffset = settings.graphics.hudVerticalOffset.dp

    Box(modifier = Modifier.fillMaxSize()) {
        // Center Gaze / Pointing Reticle & Dwell Ring
        Canvas(
            modifier = Modifier
                .align(Alignment.Center)
                .size(34.dp)
        ) {
            val hasTarget = snap.targetedProduct != null || snap.targetedStation != TargetStationType.NONE || snap.targetedNpc != null
            drawCircle(
                color = if (hasTarget) VrCyan else Color.White.copy(alpha = 0.72f),
                radius = if (hasTarget) 5.5f else 3.5f
            )
            if (snap.gazeDwellProgress > 0.02f) {
                drawArc(
                    color = VrEmerald,
                    startAngle = -90f,
                    sweepAngle = 360f * snap.gazeDwellProgress,
                    useCenter = false,
                    style = Stroke(width = 4.5f)
                )
            }
        }

        // Top Stereo HUD Bar (Wallet, Cart, FPS)
        Surface(
            color = VrObsidian.copy(alpha = 0.68f),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 10.dp)
                .offset(y = yOffset)
                .scale(hudScale)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$${String.format("%.2f", snap.walletBalance)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = VrEmerald,
                    fontWeight = FontWeight.Bold
                )
                if (snap.gameMode == GameMode.BUDGET_CHALLENGE) {
                    Text(
                        text = "/$${snap.budgetLimit.toInt()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = VrAmber
                    )
                }
                Text(
                    text = "${if (snap.hasCart) "🛒" else if (snap.hasBasket) "🧺" else "🛍️"} ${snap.cartItems.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = VrCyan
                )
                Text(
                    text = "${snap.measuredFps} FPS",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.78f)
                )
            }
        }

        // Targeted Product / Station / Held Item Inspection Card
        val targetProd = snap.heldProduct ?: snap.targetedProduct
        if (targetProd != null) {
            Surface(
                color = VrObsidian.copy(alpha = 0.78f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.55f)),
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 66.dp + yOffset)
                    .scale(hudScale)
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)) {
                    Text(
                        text = if (isAr) targetProd.nameAr else targetProd.nameEn,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "$${String.format("%.2f", targetProd.effectivePrice)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = VrEmerald
                        )
                        if (targetProd.discountPercent > 0) {
                            Text(
                                text = "-${targetProd.discountPercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = VrAmber
                            )
                        }
                        Text(
                            text = "#${targetProd.barcode.takeLast(6)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = VrCyan
                        )
                    }
                    if (snap.heldProduct != null && snap.isInspectingDetails) {
                        Text(
                            text = if (isAr) targetProd.ingredientsAr else targetProd.ingredientsEn,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f),
                            maxLines = 2
                        )
                    }
                }
            }
        } else if (snap.targetedStation != TargetStationType.NONE) {
            Surface(
                color = VrObsidian.copy(alpha = 0.78f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 58.dp + yOffset)
                    .scale(hudScale)
            ) {
                Text(
                    text = stationLabel(snap.targetedStation, strings),
                    style = MaterialTheme.typography.labelMedium,
                    color = VrCyan,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        // NPC Dialog Banner
        val npcMsg = if (isAr) snap.activeNpcDialogAr else snap.activeNpcDialogEn
        if (!npcMsg.isNullOrBlank()) {
            Surface(
                color = VrObsidian.copy(alpha = 0.85f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, VrEmerald),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 48.dp, start = 14.dp, end = 14.dp)
            ) {
                Text(
                    text = npcMsg,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        // Receipt / Shopping List / Missions Mini-Card
        val receipt = snap.receipt
        if (receipt != null) {
            Surface(
                color = VrObsidian.copy(alpha = 0.88f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, VrEmerald),
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-54).dp)
                    .padding(horizontal = 18.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(strings.receiptTitle, style = MaterialTheme.typography.labelLarge, color = VrEmerald)
                    Text(
                        text = "${receipt.items.size} items · $${String.format("%.2f", receipt.subtotal)} (${if (isAr) receipt.paymentMethodLabelAr else receipt.paymentMethodLabelEn})",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }
            }
        } else if (snap.showShoppingListOverlay) {
            Surface(
                color = VrObsidian.copy(alpha = 0.86f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, VrCyan),
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-50).dp)
                    .padding(horizontal = 14.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("${strings.shoppingListTitle} (${snap.cartItems.size})", style = MaterialTheme.typography.labelLarge, color = VrCyan)
                    snap.cartItems.take(4).forEach { item ->
                        Text(
                            text = "• ${if (isAr) item.nameAr else item.nameEn} ($${String.format("%.2f", item.effectivePrice)})",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }
        } else if (snap.showMissionsOverlay) {
            Surface(
                color = VrObsidian.copy(alpha = 0.86f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, VrAmber),
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-50).dp)
                    .padding(horizontal = 14.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(strings.missionsTitle, style = MaterialTheme.typography.labelLarge, color = VrAmber)
                    snap.missions.forEach { m ->
                        Text(
                            text = "${if (m.isCompleted) "✓" else "○"} ${if (isAr) m.titleAr else m.titleEn}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (m.isCompleted) VrEmerald else Color.White
                        )
                    }
                }
            }
        }

        // VR Box Camera Occlusion Warning inside VR View
        if (settings.controls.activeScheme == ControlScheme.HAND_TRACKING &&
            handState.health == HandTrackingHealth.VR_BOX_OCCLUDED
        ) {
            Surface(
                color = VrCoral.copy(alpha = 0.90f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 50.dp, start = 12.dp, end = 12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(strings.vrBoxOccludedInGame, style = MaterialTheme.typography.labelSmall, color = Color.White)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallHudActionChip(label = strings.switchToGaze, highlight = true) {
                            onSwitchScheme(ControlScheme.GAZE)
                        }
                        SmallHudActionChip(label = strings.switchToXbox) {
                            onSwitchScheme(ControlScheme.XBOX_CONTROLLER)
                        }
                    }
                }
            }
        }

        // Feedback Toast
        val fb = if (isAr) snap.feedbackAr else snap.feedbackEn
        if (!fb.isNullOrBlank()) {
            Surface(
                color = if (snap.feedbackIsError) VrCoral.copy(alpha = 0.88f) else VrObsidian.copy(alpha = 0.82f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 58.dp)
            ) {
                Text(
                    text = fb,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

private fun stationLabel(station: TargetStationType, s: AppStrings): String = when (station) {
    TargetStationType.CART_BAY -> s.pushCartAction
    TargetStationType.BASKET_BAY -> s.basketLabel
    TargetStationType.CHECKOUT_BELT -> s.placeOnBeltAction
    TargetStationType.LASER_SCANNER -> s.scanItemAction
    TargetStationType.POS_TERMINAL -> "${s.payCardAction} / ${s.payCashAction}"
    TargetStationType.BAGGING_ZONE -> s.takeBagAction
    TargetStationType.NONE -> ""
}

@Composable
private fun TouchHoldIconBtn(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onPressChange: (Boolean) -> Unit
) {
    Surface(
        onClick = { onPressChange(true) },
        color = VrObsidian.copy(alpha = 0.72f),
        shape = CircleShape,
        border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.45f)),
        modifier = Modifier
            .size(44.dp)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.any { it.pressed }
                        onPressChange(pressed)
                    }
                }
            }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = desc, tint = VrCyan, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun SmallHudActionChip(
    label: String,
    highlight: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = if (highlight) VrCyan else VrObsidian.copy(alpha = 0.76f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (highlight) VrCyan else Color.White.copy(alpha = 0.25f))
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (highlight) VrObsidian else Color.White,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}
