package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.MotionEvent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineTextSecondary
import com.example.ui.theme.RedstoneCoral
import com.example.vr.engine.MineVrRenderer
import com.example.vr.model.MineVrSettingsState
import com.example.vr.model.MinecraftAppStatus
import com.example.vr.model.ProjectionCaptureState
import com.example.vr.model.ShizukuBridgeState
import com.example.vr.model.ShizukuStatus
import com.example.vr.model.VrRenderMode

@Composable
fun VrGameplayScreen(
    settings: MineVrSettingsState,
    projectionState: ProjectionCaptureState,
    shizukuState: ShizukuBridgeState = ShizukuBridgeState(),
    minecraftStatus: MinecraftAppStatus = MinecraftAppStatus(),
    isControllerConnected: Boolean = false,
    isPaused: Boolean,
    renderer: MineVrRenderer,
    strings: MineVrStrings,
    canDrawOverlay: Boolean,
    onStartSensors: () -> Unit,
    onStopSensorsIfInactive: () -> Unit,
    onRecenterHead: () -> Unit,
    onTogglePause: () -> Unit,
    onStartProjection: (Int, Intent) -> Unit,
    onStopProjection: () -> Unit,
    onStartShizukuVrSession: () -> Unit = {},
    onRequestShizukuPermission: () -> Unit = {},
    onOpenShizukuApp: () -> Unit = {},
    onRelaunchMinecraftOnVirtualDisplay: () -> Unit = {},
    onForwardGameTouch: (normX: Float, normY: Float, action: Int, downTimeMs: Long) -> Unit = { _, _, _, _ -> },
    onStopAllVrSessions: () -> Unit = onStopProjection,
    onLaunchVrOverlayOverMinecraft: () -> Unit,
    onSwitchTo3dTest: () -> Unit,
    onLaunchMinecraftSplit: () -> Unit,
    onExitToMenu: () -> Unit
) {
    val context = LocalContext.current
    var gameTouchEnabled by remember { mutableStateOf(false) }
    var wasControllerConnected by remember { mutableStateOf(isControllerConnected) }
    LaunchedEffect(isControllerConnected) {
        if (isControllerConnected) wasControllerConnected = true
    }

    BackHandler {
        onStopAllVrSessions()
        onExitToMenu()
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            onStartProjection(result.resultCode, result.data!!)
        }
    }

    fun launchCaptureConsent() {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            mgr.createScreenCaptureIntent(MediaProjectionConfig.createConfigForUserChoice())
        } else {
            mgr.createScreenCaptureIntent()
        }
        mediaProjectionLauncher.launch(intent)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        launchCaptureConsent()
    }

    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(context)) {
            onLaunchVrOverlayOverMinecraft()
        }
    }

    fun requestCaptureFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        launchCaptureConsent()
    }

    fun requestOverlayAndShowOverMinecraft() {
        if (!canDrawOverlay && !Settings.canDrawOverlays(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            onLaunchVrOverlayOverMinecraft()
        }
    }

    DisposableEffect(Unit) {
        renderer.isPreviewMode = false
        renderer.isOverlayMode = false
        onStartSensors()
        onDispose {
            onStopSensorsIfInactive()
        }
    }

    LaunchedEffect(settings.preferredRenderMode) {
        if (settings.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY) {
            onStartShizukuVrSession()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Fullscreen Hardware-Accelerated OpenGL ES 3.0 VR Surface
        AndroidView(
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(3)
                    setEGLConfigChooser(8, 8, 8, 8, 16, 0)
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("vr_gl_surface")
        )

        // Optional touch passthrough layer onto Minecraft's isolated VirtualDisplay (either eye half maps 0..1)
        if (settings.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY &&
            gameTouchEnabled &&
            shizukuState.virtualDisplayId > 0
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(settings.vr.sideBySideEnabled, shizukuState.virtualDisplayId) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val downTime = SystemClock.uptimeMillis()
                            fun toNorm(x: Float, y: Float): Pair<Float, Float> {
                                val w = size.width.coerceAtLeast(2).toFloat()
                                val h = size.height.coerceAtLeast(2).toFloat()
                                val nx = if (settings.vr.sideBySideEnabled) {
                                    val halfW = w * 0.5f
                                    if (x >= halfW) ((x - halfW) / halfW) else (x / halfW)
                                } else {
                                    x / w
                                }
                                return nx.coerceIn(0f, 1f) to (y / h).coerceIn(0f, 1f)
                            }
                            val (dnx, dny) = toNorm(down.position.x, down.position.y)
                            onForwardGameTouch(dnx, dny, MotionEvent.ACTION_DOWN, downTime)

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull() ?: break
                                val (nx, ny) = toNorm(change.position.x, change.position.y)
                                if (!change.pressed) {
                                    onForwardGameTouch(nx, ny, MotionEvent.ACTION_UP, downTime)
                                    break
                                } else if (change.position != change.previousPosition) {
                                    onForwardGameTouch(nx, ny, MotionEvent.ACTION_MOVE, downTime)
                                }
                            }
                        }
                    }
            )
        }

        // Subtle center divider line when SBS is active
        if (settings.vr.sideBySideEnabled) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(2.dp)
                    .fillMaxSize()
                    .background(Color(0x55FFFFFF))
            )
        }

        // Controller Disconnected Top Alert if connection drops mid-session
        if (wasControllerConnected && !isControllerConnected) {
            Surface(
                color = RedstoneCoral.copy(alpha = 0.85f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp)
                    .testTag("hud_controller_disconnected_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Filled.Gamepad, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Text(strings.hudControllerDisconnectedBadge, style = MaterialTheme.typography.labelSmall, color = Color.White)
                }
            }
        }

        // Shizuku Virtual Display Status / Error / Relaunch Overlays
        if (settings.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY) {
            if (!minecraftStatus.isInstalled) {
                ShizukuStatusDialogCard(
                    title = strings.statusMinecraftNotInstalled,
                    body = strings.launchMinecraftHint,
                    isError = true,
                    primaryLabel = strings.switchModeTo3dTest,
                    onPrimaryClick = onSwitchTo3dTest,
                    secondaryLabel = null,
                    onSecondaryClick = null,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .testTag("shizuku_status_card")
                )
            } else if (shizukuState.status != ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE) {
                val (title, body, primaryLabel, primaryAction, isLoading) = when (shizukuState.status) {
                    ShizukuStatus.NOT_INSTALLED,
                    ShizukuStatus.NOT_RUNNING -> Quinto(
                        strings.statusShizukuNotRunning,
                        strings.shizukuNotRunningDesc,
                        strings.openShizukuAppBtn,
                        onOpenShizukuApp,
                        false
                    )
                    ShizukuStatus.PERMISSION_REQUIRED,
                    ShizukuStatus.PERMISSION_DENIED -> Quinto(
                        strings.shizukuConnectingTitle,
                        strings.shizukuPermNeededDesc,
                        strings.requestShizukuPermissionBtn,
                        onRequestShizukuPermission,
                        false
                    )
                    ShizukuStatus.BINDING_SERVICE,
                    ShizukuStatus.READY -> Quinto(
                        strings.shizukuConnectingTitle,
                        strings.statusShizukuBinding,
                        strings.shizukuRetryBtn,
                        onStartShizukuVrSession,
                        true
                    )
                    ShizukuStatus.ERROR -> Quinto(
                        strings.shizukuErrorTitle,
                        shizukuState.lastErrorMessage ?: strings.statusShizukuError,
                        strings.shizukuRetryBtn,
                        onStartShizukuVrSession,
                        false
                    )
                    ShizukuStatus.VIRTUAL_DISPLAY_ACTIVE -> Quinto("", "", "", {}, false)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MineBedrockSurface.copy(alpha = 0.94f)),
                    border = BorderStroke(
                        1.dp,
                        if (shizukuState.status == ShizukuStatus.ERROR) RedstoneCoral else MineBlockBorder
                    ),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                        .widthIn(max = 540.dp)
                        .testTag("shizuku_status_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = DiamondCyan)
                            }
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (shizukuState.status == ShizukuStatus.ERROR) RedstoneCoral else DiamondCyan
                            )
                        }
                        Text(text = body, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = primaryAction,
                                colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("shizuku_primary_action_button")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(primaryLabel, style = MaterialTheme.typography.labelSmall)
                            }
                            OutlinedButton(
                                onClick = onSwitchTo3dTest,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("switch_to_3d_button")
                            ) {
                                Icon(Icons.Filled.ViewInAr, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.switchModeTo3dTest, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            } else if (shizukuState.isMinecraftLaunchedOnDisplay && !shizukuState.isMinecraftRunningOnDisplay) {
                Surface(
                    color = MineBedrockSurface.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GoldAmber.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 44.dp, start = 16.dp, end = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(strings.shizukuMinecraftStoppedTitle, style = MaterialTheme.typography.labelSmall, color = GoldAmber)
                        FilledTonalButton(onClick = onRelaunchMinecraftOnVirtualDisplay) {
                            Text(strings.shizukuRelaunchMinecraftBtn, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        } else if (settings.preferredRenderMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE && !projectionState.isServiceRunning) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface.copy(alpha = 0.94f)),
                border = BorderStroke(1.dp, MineBlockBorder),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .widthIn(max = 520.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.awaitingCaptureTitle, style = MaterialTheme.typography.titleMedium, color = DiamondCyan)
                    Text(strings.awaitingCaptureDesc, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { requestCaptureFlow() },
                            colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("grant_capture_button")
                        ) {
                            Icon(Icons.Filled.Cast, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.grantScreenCapture, style = MaterialTheme.typography.labelSmall)
                        }
                        FilledTonalButton(
                            onClick = onLaunchMinecraftSplit,
                            modifier = Modifier.testTag("open_minecraft_for_capture_button")
                        ) {
                            Text(strings.openMinecraftSplitBtn, style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = onSwitchTo3dTest,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("switch_to_3d_button")
                        ) {
                            Icon(Icons.Filled.ViewInAr, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.switchModeTo3dTest, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        } else if (settings.preferredRenderMode == VrRenderMode.MINECRAFT_LIVE_CAPTURE && projectionState.isSelfMirrorWarning) {
            Surface(
                color = MineBedrockSurface.copy(alpha = 0.90f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, GoldAmber.copy(alpha = 0.7f)),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp, start = 16.dp, end = 16.dp)
                    .widthIn(max = 640.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(strings.loopbackWarningTitle, style = MaterialTheme.typography.labelMedium, color = GoldAmber)
                    Text(strings.loopbackWarningDesc, style = MaterialTheme.typography.labelSmall, color = MineTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { requestOverlayAndShowOverMinecraft() },
                            colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E)),
                            modifier = Modifier.testTag("show_overlay_over_minecraft_button")
                        ) {
                            Icon(Icons.Filled.Layers, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = if (canDrawOverlay || Settings.canDrawOverlays(context)) {
                                    strings.showVrOverMinecraft
                                } else {
                                    strings.grantOverlayPermission
                                },
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        FilledTonalButton(onClick = onLaunchMinecraftSplit) {
                            Text(strings.openMinecraftSplitBtn, style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(onClick = onSwitchTo3dTest) {
                            Text(strings.switchModeTo3dTest, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        if (isPaused) {
            Surface(
                color = Color.Black.copy(alpha = 0.75f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, DiamondCyan),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = strings.vrPausedOverlay,
                    style = MaterialTheme.typography.titleMedium,
                    color = DiamondCyan,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)
                )
            }
        }

        // Minimalist Gameplay HUD: Recenter, Game Touch (when VirtualDisplay active), Pause/Resume, Exit
        Surface(
            color = MineBedrockSurface.copy(alpha = 0.78f),
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, MineBlockBorder),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = onRecenterHead,
                    modifier = Modifier.testTag("hud_recenter_button")
                ) {
                    Icon(Icons.Filled.CenterFocusStrong, contentDescription = strings.recenterHead, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.recenterHead, style = MaterialTheme.typography.labelMedium)
                }

                if (settings.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY && shizukuState.virtualDisplayId > 0) {
                    FilledTonalButton(
                        onClick = { gameTouchEnabled = !gameTouchEnabled },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (gameTouchEnabled) CreeperEmerald else MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = if (gameTouchEnabled) Color(0xFF04220E) else MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        modifier = Modifier.testTag("hud_game_touch_button")
                    ) {
                        Icon(Icons.Filled.TouchApp, contentDescription = strings.hudGameTouchOff, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (gameTouchEnabled) strings.hudGameTouchOn else strings.hudGameTouchOff, style = MaterialTheme.typography.labelMedium)
                    }
                }

                FilledTonalButton(
                    onClick = onTogglePause,
                    modifier = Modifier.testTag("hud_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = if (isPaused) strings.resumeVr else strings.pauseVr,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (isPaused) strings.resumeVr else strings.pauseVr, style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = {
                        onStopAllVrSessions()
                        onExitToMenu()
                    },
                    modifier = Modifier.testTag("hud_exit_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = strings.exitVr, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.exitVr, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

private data class Quinto<A, B, C, D, E>(
    val a: A,
    val b: B,
    val c: C,
    val d: D,
    val e: E
)

@Composable
private fun ShizukuStatusDialogCard(
    title: String,
    body: String,
    isError: Boolean,
    primaryLabel: String,
    onPrimaryClick: () -> Unit,
    secondaryLabel: String?,
    onSecondaryClick: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MineBedrockSurface.copy(alpha = 0.94f)),
        border = BorderStroke(1.dp, if (isError) RedstoneCoral else MineBlockBorder),
        modifier = modifier
            .padding(24.dp)
            .widthIn(max = 520.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = if (isError) RedstoneCoral else DiamondCyan)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onPrimaryClick,
                    colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(primaryLabel, style = MaterialTheme.typography.labelSmall)
                }
                if (secondaryLabel != null && onSecondaryClick != null) {
                    OutlinedButton(onClick = onSecondaryClick, modifier = Modifier.weight(1f)) {
                        Text(secondaryLabel, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
