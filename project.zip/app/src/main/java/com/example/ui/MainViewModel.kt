package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.apk.ApkInspectorAndVerifier
import com.example.data.inspector.AndroidProjectInspector
import com.example.data.preferences.BuildSettingsRepository
import com.example.data.remote.RemoteGradleBuildClient
import com.example.data.remote.RunnerHealthResult
import com.example.data.toolchain.ToolchainEnvironmentProbe
import com.example.data.workspace.SandboxWorkspaceManager
import com.example.domain.model.BuildEngineMode
import com.example.domain.model.BuildEngineSettings
import com.example.domain.model.BuildExecutionState
import com.example.domain.model.BuildLogEntry
import com.example.domain.model.BuildStage
import com.example.domain.model.BuildStepState
import com.example.domain.model.DeviceToolchainProbe
import com.example.domain.model.LogLevel
import com.example.domain.model.ProjectInspection
import com.example.domain.model.StageStatus
import com.example.domain.model.ZipSelectionInfo
import com.example.domain.util.Formatters
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val zipSelection: ZipSelectionInfo? = null,
    val isInspecting: Boolean = false,
    val inspectionError: String? = null,
    val projectInspection: ProjectInspection? = null,
    val deviceProbe: DeviceToolchainProbe? = null,
    val tempStorageBytes: Long = 0L,
    val runnerHealth: RunnerHealthResult? = null,
    val isTestingRunner: Boolean = false,
    val showUploadConsentDialog: Boolean = false,
    val statusBannerMessage: String? = null,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val workspaceManager = SandboxWorkspaceManager(application)
    private val projectInspector = AndroidProjectInspector()
    private val toolchainProbe = ToolchainEnvironmentProbe(application)
    private val apkVerifier = ApkInspectorAndVerifier(application)
    private val remoteClient = RemoteGradleBuildClient()
    private val settingsRepo = BuildSettingsRepository(application)

    val settings: StateFlow<BuildEngineSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, BuildEngineSettings())

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _buildState = MutableStateFlow<BuildExecutionState>(BuildExecutionState.Idle)
    val buildState: StateFlow<BuildExecutionState> = _buildState.asStateFlow()

    private var buildJob: Job? = null

    init {
        refreshEnvironmentAndStorage()
    }

    fun refreshEnvironmentAndStorage() {
        viewModelScope.launch {
            val probe = toolchainProbe.probeDeviceEnvironment()
            val storage = workspaceManager.getTempStorageBytes()
            _uiState.update {
                it.copy(
                    deviceProbe = probe,
                    tempStorageBytes = storage,
                )
            }
        }
    }

    fun onZipUriSelected(uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isInspecting = true,
                    inspectionError = null,
                    projectInspection = null,
                    statusBannerMessage = null,
                )
            }
            _buildState.value = BuildExecutionState.Idle

            val importResult = workspaceManager.importZipFromUri(uri)
            importResult.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isInspecting = false,
                        zipSelection = null,
                        inspectionError = err.localizedMessage ?: "Failed to import ZIP archive.",
                    )
                }
                refreshEnvironmentAndStorage()
                return@launch
            }

            val selection = importResult.getOrThrow()
            _uiState.update { it.copy(zipSelection = selection) }

            val zipFile = File(selection.localZipFilePath)
            val extractResult = workspaceManager.extractZipSafely(zipFile)
            extractResult.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isInspecting = false,
                        inspectionError = err.localizedMessage ?: "Failed to extract ZIP archive.",
                    )
                }
                refreshEnvironmentAndStorage()
                return@launch
            }

            val extractedDir = extractResult.getOrThrow()
            val workspaceId = zipFile.parentFile?.name ?: "sandbox"
            val inspection = projectInspector.inspectExtractedProject(workspaceId, extractedDir)
            val storageBytes = workspaceManager.getTempStorageBytes()

            _uiState.update {
                it.copy(
                    isInspecting = false,
                    projectInspection = inspection,
                    tempStorageBytes = storageBytes,
                )
            }
        }
    }

    fun clearSelectedProject() {
        viewModelScope.launch {
            buildJob?.cancel()
            workspaceManager.clearAllWorkspaces(keepApkFilePath = null)
            _buildState.value = BuildExecutionState.Idle
            val storage = workspaceManager.getTempStorageBytes()
            _uiState.update {
                it.copy(
                    zipSelection = null,
                    isInspecting = false,
                    inspectionError = null,
                    projectInspection = null,
                    tempStorageBytes = storage,
                    statusBannerMessage = "Workspace cleared.",
                )
            }
        }
    }

    fun cleanTempCache() {
        viewModelScope.launch {
            val activeApk = (_buildState.value as? BuildExecutionState.Succeeded)?.result?.apkFilePath
            val remaining = workspaceManager.clearAllWorkspaces(keepApkFilePath = activeApk)
            _uiState.update {
                it.copy(
                    tempStorageBytes = remaining,
                    zipSelection = if (activeApk == null) null else it.zipSelection,
                    projectInspection = if (activeApk == null) null else it.projectInspection,
                    statusBannerMessage = "Temporary workspace cache cleaned (${Formatters.formatBytes(remaining)} remaining).",
                )
            }
        }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun updateEngineSettings(transform: (BuildEngineSettings) -> BuildEngineSettings) {
        viewModelScope.launch {
            settingsRepo.updateSettings(transform)
            _uiState.update { it.copy(runnerHealth = null) }
        }
    }

    fun testRemoteRunnerHealth() {
        val current = settings.value
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingRunner = true, runnerHealth = null) }
            val result = remoteClient.checkHealth(current.remoteRunnerUrl, current.remoteAuthToken)
            _uiState.update { it.copy(isTestingRunner = false, runnerHealth = result) }
        }
    }

    fun dismissUploadConsentDialog() {
        _uiState.update { it.copy(showUploadConsentDialog = false) }
    }

    fun confirmUploadConsentAndStartBuild(onNavigateToProgress: () -> Unit) {
        viewModelScope.launch {
            settingsRepo.updateSettings { it.copy(uploadConsentGranted = true) }
            _uiState.update { it.copy(showUploadConsentDialog = false) }
            startBuildApk(bypassConsentCheck = true, onNavigateToProgress = onNavigateToProgress)
        }
    }

    fun startBuildApk(
        bypassConsentCheck: Boolean = false,
        onNavigateToProgress: () -> Unit,
    ) {
        val selection = _uiState.value.zipSelection ?: return
        val inspection = _uiState.value.projectInspection ?: return
        val activeSettings = settings.value

        if (activeSettings.mode == BuildEngineMode.REMOTE_RUNNER &&
            !activeSettings.uploadConsentGranted &&
            !bypassConsentCheck
        ) {
            _uiState.update { it.copy(showUploadConsentDialog = true) }
            return
        }

        onNavigateToProgress()
        buildJob?.cancel()
        buildJob = viewModelScope.launch {
            executeBuildPipeline(selection, inspection, activeSettings)
        }
    }

    fun extractEmbeddedPrebuiltApk(onNavigateToResult: () -> Unit) {
        val inspection = _uiState.value.projectInspection ?: return
        val firstRelApk = inspection.embeddedApkPaths.firstOrNull() ?: return
        viewModelScope.launch {
            val logs = mutableListOf<BuildLogEntry>()
            fun log(level: LogLevel, msg: String) {
                logs.add(BuildLogEntry(Formatters.nowTimestamp(), level, msg))
            }

            val steps = defaultSteps().map { step ->
                when (step.stage) {
                    BuildStage.SANDBOX_PREP -> step.copy(status = StageStatus.SUCCEEDED, detail = "Extracted archive")
                    BuildStage.PROJECT_VALIDATION -> step.copy(status = StageStatus.SUCCEEDED, detail = "Found pre-built APK")
                    BuildStage.TOOLCHAIN_CHECK -> step.copy(status = StageStatus.SUCCEEDED, detail = "Skipped (pre-built artifact)")
                    BuildStage.GRADLE_BUILD -> step.copy(status = StageStatus.SUCCEEDED, detail = "Copied $firstRelApk")
                    BuildStage.APK_VERIFICATION -> step.copy(status = StageStatus.RUNNING, detail = "Verifying APK signature & manifest")
                }
            }
            log(LogLevel.INFO, "Extracting verified pre-built APK: $firstRelApk")
            _buildState.value = BuildExecutionState.Running(0.8f, "Verifying pre-built APK...", steps, logs.toList())

            val srcApk = File(File(inspection.workspaceDirPath, "src"), firstRelApk)
            val destApk = workspaceManager.createOutputApkFile("${inspection.projectName}_prebuilt.apk")
            runCatching {
                withContext(Dispatchers.IO) { srcApk.copyTo(destApk, overwrite = true) }
            }.onFailure { err ->
                log(LogLevel.ERROR, "Failed to copy pre-built APK: ${err.localizedMessage}")
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.8f,
                    errorTitle = "APK Extraction Failed",
                    errorDetail = err.localizedMessage ?: "Unable to copy pre-built APK.",
                    missingRequirements = emptyList(),
                    steps = steps.map {
                        if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.FAILED, detail = "Copy failed") else it
                    },
                    logs = logs.toList(),
                )
                return@launch
            }

            val verified = apkVerifier.verifyAndInspectApk(
                destApk,
                sourceNote = "Extracted verified pre-built APK from ZIP archive (not compiled on device)",
            )
            verified.onSuccess { info ->
                log(LogLevel.SUCCESS, "Verified APK: ${info.packageName} (${Formatters.formatBytes(info.sizeBytes)})")
                val finalSteps = steps.map { it.copy(status = StageStatus.SUCCEEDED) }
                _buildState.value = BuildExecutionState.Succeeded(1.0f, finalSteps, logs.toList(), info)
                refreshEnvironmentAndStorage()
                onNavigateToResult()
            }.onFailure { err ->
                log(LogLevel.ERROR, err.localizedMessage ?: "Invalid APK")
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.85f,
                    errorTitle = "Invalid APK Archive",
                    errorDetail = err.localizedMessage ?: "The embedded .apk failed structural verification.",
                    missingRequirements = emptyList(),
                    steps = steps.map {
                        if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.FAILED, detail = "Invalid APK") else it
                    },
                    logs = logs.toList(),
                )
            }
        }
    }

    fun saveApkToSafUri(apkFilePath: String, targetUri: Uri) {
        viewModelScope.launch {
            workspaceManager.copyApkToSafUri(File(apkFilePath), targetUri)
                .onSuccess { bytes ->
                    _uiState.update {
                        it.copy(statusBannerMessage = "Saved APK (${Formatters.formatBytes(bytes)}) to selected destination.")
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(statusBannerMessage = "Save failed: ${err.localizedMessage}")
                    }
                }
        }
    }

    private suspend fun executeBuildPipeline(
        selection: ZipSelectionInfo,
        inspection: ProjectInspection,
        activeSettings: BuildEngineSettings,
    ) {
        val logs = mutableListOf<BuildLogEntry>()
        var steps = defaultSteps()

        fun addLog(level: LogLevel, msg: String) {
            logs.add(BuildLogEntry(Formatters.nowTimestamp(), level, msg))
        }

        fun updateStep(stage: BuildStage, status: StageStatus, detail: String) {
            steps = steps.map { if (it.stage == stage) it.copy(status = status, detail = detail) else it }
        }

        fun emitRunning(progress: Float, label: String) {
            _buildState.value = BuildExecutionState.Running(
                progress = progress,
                currentStageLabel = label,
                steps = steps,
                logs = logs.toList(),
            )
        }

        // Stage 1: Sandbox Prep
        updateStep(BuildStage.SANDBOX_PREP, StageStatus.RUNNING, "Verifying isolated workspace ${inspection.workspaceId}")
        addLog(LogLevel.INFO, "Sandbox workspace: ${inspection.workspaceDirPath}")
        addLog(LogLevel.INFO, "Archive: ${selection.displayName} (${Formatters.formatBytes(selection.sizeBytes)})")
        emitRunning(0.15f, "Preparing isolated sandbox...")
        delay(220)

        val srcDir = File(inspection.workspaceDirPath, "src")
        if (!srcDir.isDirectory) {
            updateStep(BuildStage.SANDBOX_PREP, StageStatus.FAILED, "Extracted project directory missing")
            addLog(LogLevel.ERROR, "Extracted source directory does not exist.")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.15f,
                errorTitle = "Sandbox Workspace Missing",
                errorDetail = "Please re-select the ZIP project file.",
                missingRequirements = listOf("Extracted workspace directory"),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }
        updateStep(BuildStage.SANDBOX_PREP, StageStatus.SUCCEEDED, "${inspection.totalExtractedFiles} files isolated")
        addLog(LogLevel.SUCCESS, "Isolated ${inspection.totalExtractedFiles} files (${Formatters.formatBytes(inspection.extractedSizeBytes)}).")

        // Stage 2: Project Validation
        updateStep(BuildStage.PROJECT_VALIDATION, StageStatus.RUNNING, "Validating Gradle & Android Manifest")
        emitRunning(0.32f, "Inspecting project structure...")
        delay(220)

        addLog(LogLevel.INFO, "Detected type: ${inspection.projectType.displayLabel}")
        inspection.gradleVersion?.let { addLog(LogLevel.INFO, "Required Gradle: $it") }
        inspection.compileSdk?.let { addLog(LogLevel.INFO, "Target compileSdk: $it | minSdk: ${inspection.minSdk ?: "default"}") }
        inspection.javaCompatibility?.let { addLog(LogLevel.INFO, "Java / JVM Target: $it") }

        if (!inspection.isValidAndroidProject) {
            updateStep(BuildStage.PROJECT_VALIDATION, StageStatus.FAILED, "Missing required Gradle/Manifest files")
            inspection.missingRequirements.forEach { addLog(LogLevel.ERROR, it) }
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.35f,
                errorTitle = "Invalid or Incomplete Android Studio Project",
                errorDetail = inspection.readinessSummary,
                missingRequirements = inspection.missingRequirements,
                steps = steps,
                logs = logs.toList(),
                canExtractPrebuiltApk = inspection.embeddedApkPaths.isNotEmpty(),
            )
            return
        }
        updateStep(BuildStage.PROJECT_VALIDATION, StageStatus.SUCCEEDED, "${inspection.projectName} verified")
        addLog(LogLevel.SUCCESS, "Project validation passed (${inspection.kotlinFileCount} .kt, ${inspection.javaFileCount} .java).")

        // Stage 3: Toolchain Check
        updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.RUNNING, "Checking ${activeSettings.mode.label}")
        emitRunning(0.50f, "Checking build toolchain...")

        if (activeSettings.mode == BuildEngineMode.LOCAL_DEVICE) {
            val probe = toolchainProbe.probeDeviceEnvironment()
            _uiState.update { it.copy(deviceProbe = probe) }
            addLog(LogLevel.INFO, "Device ABI: ${probe.deviceAbi} | Android API ${probe.androidSdkInt}")
            addLog(LogLevel.INFO, "Free internal storage: ${Formatters.formatBytes(probe.freeSpaceBytes)}")

            if (!probe.localToolchainReady) {
                updateStep(
                    BuildStage.TOOLCHAIN_CHECK,
                    StageStatus.FAILED,
                    "Missing Android SDK & Gradle on device",
                )
                probe.missingToolchainItems.forEach { item ->
                    addLog(LogLevel.ERROR, "Missing on device: $item")
                }
                addLog(
                    LogLevel.WARN,
                    "Android devices do not ship JDK (javac/kotlinc), Gradle CLI, aapt2, d8, or android.jar platforms. " +
                        "Build halted honestly without creating a fake APK.",
                )
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.55f,
                    errorTitle = "On-Device Android SDK & Gradle Unavailable",
                    errorDetail = "Compiling a real Android Studio project requires JDK, Gradle, Android SDK platform (android.jar), " +
                        "aapt2, and d8/apksigner, which are not installed on standard Android devices. " +
                        "Connect a Self-Hosted Gradle Build Runner in Build Engine settings (with your explicit upload consent) to compile a real signed APK.",
                    missingRequirements = probe.missingToolchainItems,
                    steps = steps,
                    logs = logs.toList(),
                    canExtractPrebuiltApk = inspection.embeddedApkPaths.isNotEmpty(),
                )
                return
            }

            // If an exotic environment genuinely provides local CLI binaries, execute real Gradle in isolated sandbox:
            updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.SUCCEEDED, "Local toolchain found")
            updateStep(BuildStage.GRADLE_BUILD, StageStatus.RUNNING, "Running gradle assemble${activeSettings.buildVariant.replaceFirstChar { it.uppercase() }}")
            emitRunning(0.72f, "Compiling project with local Gradle...")

            val projectDir = if (inspection.projectRootRelativePath == "/") {
                srcDir
            } else {
                File(srcDir, inspection.projectRootRelativePath.trimStart('/'))
            }

            val localBuildResult = runLocalGradleSubprocess(projectDir, activeSettings.buildVariant) { line ->
                addLog(LogLevel.INFO, line)
                emitRunning(0.76f, "Compiling with local Gradle...")
            }

            if (localBuildResult == null) {
                updateStep(BuildStage.GRADLE_BUILD, StageStatus.FAILED, "Local Gradle execution failed")
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.78f,
                    errorTitle = "Local Gradle Build Failed",
                    errorDetail = "The local Gradle process exited with errors or did not produce an APK.",
                    missingRequirements = emptyList(),
                    steps = steps,
                    logs = logs.toList(),
                )
                return
            }

            finalizeVerifiedApk(
                producedApk = localBuildResult,
                sourceNote = "Compiled locally via on-device Gradle toolchain",
                steps = steps,
                logs = logs,
                updateStep = ::updateStep,
                addLog = ::addLog,
                emitRunning = ::emitRunning,
            )
            return
        }

        // Mode: REMOTE_RUNNER (Explicit User Consent Verified)
        if (activeSettings.remoteRunnerUrl.isBlank()) {
            updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.FAILED, "Runner URL not configured")
            addLog(LogLevel.ERROR, "Self-Hosted Gradle Build Runner URL is empty.")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.50f,
                errorTitle = "Build Runner URL Required",
                errorDetail = "Open Build Engine settings and enter your self-hosted Gradle Build Runner URL (for example, http://192.168.1.25:8787).",
                missingRequirements = listOf("Gradle Build Runner URL"),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }

        addLog(LogLevel.INFO, "Checking runner health at ${activeSettings.remoteRunnerUrl}...")
        val health = remoteClient.checkHealth(activeSettings.remoteRunnerUrl, activeSettings.remoteAuthToken)
        if (!health.reachable) {
            updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.FAILED, "Build Runner unreachable")
            addLog(LogLevel.ERROR, "Runner health check failed: ${health.message}")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.52f,
                errorTitle = "Build Runner Unreachable",
                errorDetail = health.message,
                missingRequirements = listOf("Reachable Gradle Build Runner endpoint"),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }

        updateStep(
            BuildStage.TOOLCHAIN_CHECK,
            StageStatus.SUCCEEDED,
            health.sdkPlatform ?: health.message,
        )
        addLog(
            LogLevel.SUCCESS,
            "Runner online (${health.message}${health.gradleVersion?.let { ", Gradle $it" }.orEmpty()}).",
        )

        // Stage 4: Remote Gradle APK Assembly
        updateStep(BuildStage.GRADLE_BUILD, StageStatus.RUNNING, "Uploading project & building ${activeSettings.buildVariant} APK")
        addLog(LogLevel.INFO, "User consent verified. Uploading ${selection.displayName} for ${activeSettings.buildVariant} build...")
        emitRunning(0.60f, "Uploading ZIP to Gradle Build Runner...")

        val destApk = workspaceManager.createOutputApkFile("${inspection.projectName}-${activeSettings.buildVariant}.apk")
        val remoteOutcome = remoteClient.uploadAndBuildApk(
            baseUrl = activeSettings.remoteRunnerUrl,
            authToken = activeSettings.remoteAuthToken,
            zipFile = File(selection.localZipFilePath),
            variant = activeSettings.buildVariant,
            destinationApkFile = destApk,
            onUploadProgress = { ratio ->
                val overall = 0.60f + ratio * 0.15f
                emitRunning(overall, "Uploading ZIP (${(ratio * 100).toInt()}%)...")
            },
            onLogLine = { msg ->
                addLog(LogLevel.INFO, msg)
                emitRunning(0.82f, "Building APK on Gradle Runner...")
            },
        )

        remoteOutcome.serverLogs.forEach { line ->
            val lvl = if (line.contains("error", ignoreCase = true) || line.contains("failed", ignoreCase = true)) {
                LogLevel.ERROR
            } else LogLevel.INFO
            addLog(lvl, line)
        }

        if (!remoteOutcome.success || remoteOutcome.outputApkFile == null) {
            updateStep(BuildStage.GRADLE_BUILD, StageStatus.FAILED, "Gradle build failed")
            addLog(LogLevel.ERROR, remoteOutcome.errorMessage ?: "Remote Gradle build failed.")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.82f,
                errorTitle = "Gradle Build Failed",
                errorDetail = remoteOutcome.errorMessage ?: "The build runner failed to compile the project.",
                missingRequirements = emptyList(),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }

        updateStep(BuildStage.GRADLE_BUILD, StageStatus.SUCCEEDED, "APK artifact compiled")
        finalizeVerifiedApk(
            producedApk = remoteOutcome.outputApkFile,
            sourceNote = "Compiled via Self-Hosted Gradle Build Runner (${activeSettings.buildVariant})",
            steps = steps,
            logs = logs,
            updateStep = ::updateStep,
            addLog = ::addLog,
            emitRunning = ::emitRunning,
        )
    }

    private suspend fun finalizeVerifiedApk(
        producedApk: File,
        sourceNote: String,
        steps: List<BuildStepState>,
        logs: MutableList<BuildLogEntry>,
        updateStep: (BuildStage, StageStatus, String) -> Unit,
        addLog: (LogLevel, String) -> Unit,
        emitRunning: (Float, String) -> Unit,
    ) {
        updateStep(BuildStage.APK_VERIFICATION, StageStatus.RUNNING, "Inspecting APK manifest & checksum")
        emitRunning(0.92f, "Verifying produced APK...")

        val verified = apkVerifier.verifyAndInspectApk(producedApk, sourceNote)
        verified.onSuccess { apkInfo ->
            updateStep(BuildStage.APK_VERIFICATION, StageStatus.SUCCEEDED, "${apkInfo.packageName} (${Formatters.formatBytes(apkInfo.sizeBytes)})")
            addLog(LogLevel.SUCCESS, "APK verified: ${apkInfo.appName} | ${apkInfo.packageName} v${apkInfo.versionName}")
            addLog(LogLevel.INFO, "SHA-256: ${apkInfo.sha256}")
            val completedSteps = steps.map {
                if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.SUCCEEDED, detail = "${Formatters.formatBytes(apkInfo.sizeBytes)} verified")
                else it
            }
            _buildState.value = BuildExecutionState.Succeeded(
                progress = 1.0f,
                steps = completedSteps,
                logs = logs.toList(),
                result = apkInfo,
            )
            refreshEnvironmentAndStorage()
        }.onFailure { err ->
            updateStep(BuildStage.APK_VERIFICATION, StageStatus.FAILED, "APK verification failed")
            addLog(LogLevel.ERROR, "APK verification failed: ${err.localizedMessage}")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.94f,
                errorTitle = "Invalid Output APK",
                errorDetail = err.localizedMessage ?: "The generated file is not a valid Android APK.",
                missingRequirements = emptyList(),
                steps = steps.map {
                    if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.FAILED, detail = "Invalid APK") else it
                },
                logs = logs.toList(),
            )
        }
    }

    private suspend fun runLocalGradleSubprocess(
        projectDir: File,
        variant: String,
        onLine: (String) -> Unit,
    ): File? = withContext(Dispatchers.IO) {
        runCatching {
            val task = if (variant.equals("release", ignoreCase = true)) "assembleRelease" else "assembleDebug"
            val gradleHome = File(projectDir.parentFile, ".gradle_home").apply { mkdirs() }
            val pb = ProcessBuilder("gradle", task, "--no-daemon")
                .directory(projectDir)
                .redirectErrorStream(true)
            pb.environment()["GRADLE_USER_HOME"] = gradleHome.absolutePath
            val process = pb.start()
            process.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { onLine(it) }
            }
            val finished = process.waitFor(10, TimeUnit.MINUTES)
            if (!finished || process.exitValue() != 0) return@runCatching null

            val apk = projectDir.walkTopDown()
                .firstOrNull { it.isFile && it.extension.equals("apk", ignoreCase = true) && it.path.contains("outputs/apk") }
                ?: return@runCatching null
            val out = workspaceManager.createOutputApkFile(apk.name)
            apk.copyTo(out, overwrite = true)
            out
        }.getOrNull()
    }

    private fun defaultSteps(): List<BuildStepState> = BuildStage.entries.map {
        BuildStepState(stage = it, status = StageStatus.PENDING, detail = "Waiting...")
    }
}
