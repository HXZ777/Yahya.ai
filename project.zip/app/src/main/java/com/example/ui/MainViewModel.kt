package com.example.ui

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.preferences.StatsPreferencesRepository
import com.example.data.telemetry.SystemTelemetryReader
import com.example.domain.model.AppLanguage
import com.example.domain.model.OverlayPositionPreset
import com.example.domain.model.OverlaySettings
import com.example.domain.model.PermissionStatus
import com.example.domain.model.StatType
import com.example.domain.model.SystemStatsSnapshot
import com.example.overlay.OverlayMonitorService
import com.example.overlay.OverlayStateHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val settings: OverlaySettings = OverlaySettings(),
    val snapshot: SystemStatsSnapshot = SystemStatsSnapshot(),
    val isOverlayRunning: Boolean = false,
    val permissions: PermissionStatus = PermissionStatus(),
    val showOverlayPermissionDialog: Boolean = false,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val prefsRepository = StatsPreferencesRepository(appContext)
    private val telemetryReader = SystemTelemetryReader(appContext)

    private val _permissions = MutableStateFlow(readPermissionStatus(appContext))
    private val _previewSnapshot = MutableStateFlow(SystemStatsSnapshot())
    private val _showOverlayPermissionDialog = MutableStateFlow(false)

    private var previewJob: Job? = null

    val uiState: StateFlow<MainUiState> = combine(
        prefsRepository.settingsFlow,
        OverlayStateHolder.isOverlayRunning,
        OverlayStateHolder.latestSnapshot,
        _previewSnapshot,
        combine(_permissions, _showOverlayPermissionDialog) { perms, dialog -> perms to dialog },
    ) { settings, isRunning, serviceSnapshot, previewSnapshot, (perms, showDialog) ->
        val activeSnapshot = if (isRunning && serviceSnapshot.timestampMs > 0L) {
            serviceSnapshot
        } else {
            previewSnapshot
        }
        MainUiState(
            settings = settings,
            snapshot = activeSnapshot,
            isOverlayRunning = isRunning,
            permissions = perms,
            showOverlayPermissionDialog = showDialog,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = MainUiState(permissions = _permissions.value),
    )

    fun refreshPermissions() {
        _permissions.value = readPermissionStatus(appContext)
    }

    /**
     * Runs lightweight telemetry preview ONLY while the app UI is on-screen
     * and the floating service is not already polling. Stops immediately onPause.
     */
    fun startForegroundPreview() {
        refreshPermissions()
        if (previewJob?.isActive == true) return
        previewJob = viewModelScope.launch {
            while (isActive) {
                if (!OverlayStateHolder.isOverlayRunning.value) {
                    val snap = withContext(Dispatchers.Default) {
                        telemetryReader.readSnapshot(
                            compositorFps = null,
                            allowCompositorFallback = false,
                        )
                    }
                    _previewSnapshot.value = snap
                }
                val interval = uiState.value.settings.refreshIntervalMs.coerceAtLeast(500L)
                delay(interval)
            }
        }
    }

    fun stopForegroundPreview() {
        previewJob?.cancel()
        previewJob = null
    }

    fun onToggleOverlayClicked() {
        refreshPermissions()
        val currentlyRunning = OverlayStateHolder.isOverlayRunning.value
        if (currentlyRunning) {
            OverlayMonitorService.stop(appContext)
        } else {
            if (Settings.canDrawOverlays(appContext)) {
                OverlayMonitorService.start(appContext)
            } else {
                _showOverlayPermissionDialog.value = true
            }
        }
    }

    fun dismissOverlayPermissionDialog() {
        _showOverlayPermissionDialog.value = false
    }

    fun toggleStat(statType: StatType, enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.toggleStat(statType, enabled)
        }
    }

    fun applyStatPreset(stats: Set<StatType>) {
        viewModelScope.launch {
            prefsRepository.setEnabledStats(stats)
        }
    }

    fun setStatColor(statType: StatType, argbColor: Long) {
        viewModelScope.launch {
            prefsRepository.setStatColor(statType, argbColor)
        }
    }

    fun resetColors() {
        viewModelScope.launch {
            prefsRepository.resetColors()
        }
    }

    fun setScalePercent(scale: Int) {
        viewModelScope.launch {
            prefsRepository.setScalePercent(scale)
        }
    }

    fun setBackgroundAlpha(alpha: Float) {
        viewModelScope.launch {
            prefsRepository.setBackgroundAlpha(alpha)
        }
    }

    fun setFontSizeSp(sizeSp: Float) {
        viewModelScope.launch {
            prefsRepository.setFontSizeSp(sizeSp)
        }
    }

    fun setPositionPreset(preset: OverlayPositionPreset) {
        viewModelScope.launch {
            prefsRepository.setPositionPreset(preset)
        }
    }

    fun setRefreshIntervalMs(intervalMs: Long) {
        viewModelScope.launch {
            prefsRepository.setRefreshIntervalMs(intervalMs)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepository.setLanguage(language)
        }
    }

    fun setUseCompositorHzFallback(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setUseCompositorHzFallback(enabled)
        }
    }

    fun setHideDxvkWhenNotDetected(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setHideDxvkWhenNotDetected(enabled)
        }
    }

    companion object {
        fun readPermissionStatus(context: Context): PermissionStatus {
            val hasOverlay = Settings.canDrawOverlays(context)
            val hasNotifications = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS,
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val batteryIgnored = pm?.isIgnoringBatteryOptimizations(context.packageName) ?: false

            return PermissionStatus(
                hasOverlayPermission = hasOverlay,
                hasNotificationPermission = hasNotifications,
                isBatteryOptimizationIgnored = batteryIgnored,
            )
        }
    }
}
