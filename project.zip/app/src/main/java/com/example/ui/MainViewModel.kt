package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.apk.ApkInspectorAndVerifier
import com.example.data.inspector.AndroidProjectInspector
import com.example.data.preferences.BuildSettingsRepository
import com.example.data.remote.RemoteGradleBuildClient
import com.example.data.remote.RunnerHealthResult
import com.example.data.toolchain.ToolchainEnvironmentProbe
import com.example.data.workspace.SandboxWorkspaceManager
import com.example.domain.model.BuildEngineMode
import com.example.domain.model.BuildEngineSettings
import com.example.domain.model.BuildExecutionState
import com.example.domain.model.BuildLogEntry
import com.example.domain.model.BuildStage
import com.example.domain.model.BuildStepState
import com.example.domain.model.DeviceToolchainProbe
import com.example.domain.model.LogLevel
import com.example.domain.model.ProjectInspection
import com.example.domain.model.StageStatus
import com.example.domain.model.ZipSelectionInfo
import com.example.domain.util.Formatters
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val zipSelection: ZipSelectionInfo? = null,
    val isInspecting: Boolean = false,
    val inspectionError: String? = null,
    val projectInspection: ProjectInspection? = null,
    val deviceProbe: DeviceToolchainProbe? = null,
    val tempStorageBytes: Long = 0L,
    val runnerHealth: RunnerHealthResult? = null,
    val isTestingRunner: Boolean = false,
    val showUploadConsentDialog: Boolean = false,
    val statusBannerMessage: String? = null,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val workspaceManager = SandboxWorkspaceManager(application)
    private val projectInspector = AndroidProjectInspector()
    private val toolchainProbe = ToolchainEnvironmentProbe(application)
    private val apkVerifier = ApkInspectorAndVerifier(application)
    private val remoteClient = RemoteGradleBuildClient()
    private val settingsRepo = BuildSettingsRepository(application)

    val settings: StateFlow<BuildEngineSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, BuildEngineSettings())

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _buildState = MutableStateFlow<BuildExecutionState>(BuildExecutionState.Idle)
    val buildState: StateFlow<BuildExecutionState> = _buildState.asStateFlow()

    private var buildJob: Job? = null

    init {
        refreshEnvironmentAndStorage()
    }

    fun refreshEnvironmentAndStorage() {
        viewModelScope.launch {
            val probe = toolchainProbe.probeDeviceEnvironment()
            val storage = workspaceManager.getTempStorageBytes()
            _uiState.update {
                it.copy(
                    deviceProbe = probe,
                    tempStorageBytes = storage,
                )
            }
        }
    }

    fun onZipUriSelected(uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isInspecting = true,
                    inspectionError = null,
                    projectInspection = null,
                    statusBannerMessage = null,
                )
            }
            _buildState.value = BuildExecutionState.Idle

            val importResult = workspaceManager.importZipFromUri(uri)
            importResult.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isInspecting = false,
                        zipSelection = null,
                        inspectionError = err.localizedMessage ?: "فشل استيراد ملف ZIP.",
                    )
                }
                refreshEnvironmentAndStorage()
                return@launch
            }

            val selection = importResult.getOrThrow()
            _uiState.update { it.copy(zipSelection = selection) }

            val zipFile = File(selection.localZipFilePath)
            val extractResult = workspaceManager.extractZipSafely(zipFile)
            extractResult.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isInspecting = false,
                        inspectionError = err.localizedMessage ?: "فشل فك ضغط ملف ZIP.",
                    )
                }
                refreshEnvironmentAndStorage()
                return@launch
            }

            val extractedDir = extractResult.getOrThrow()
            val workspaceId = zipFile.parentFile?.name ?: "sandbox"
            val inspection = projectInspector.inspectExtractedProject(workspaceId, extractedDir)
            val storageBytes = workspaceManager.getTempStorageBytes()

            _uiState.update {
                it.copy(
                    isInspecting = false,
                    projectInspection = inspection,
                    tempStorageBytes = storageBytes,
                )
            }
        }
    }

    fun clearSelectedProject() {
        viewModelScope.launch {
            buildJob?.cancel()
            workspaceManager.clearAllWorkspaces(keepApkFilePath = null)
            _buildState.value = BuildExecutionState.Idle
            val storage = workspaceManager.getTempStorageBytes()
            _uiState.update {
                it.copy(
                    zipSelection = null,
                    isInspecting = false,
                    inspectionError = null,
                    projectInspection = null,
                    tempStorageBytes = storage,
                    statusBannerMessage = "تم مسح مساحة العمل المؤقتة.",
                )
            }
        }
    }

    fun cleanTempCache() {
        viewModelScope.launch {
            val activeApk = (_buildState.value as? BuildExecutionState.Succeeded)?.result?.apkFilePath
            val remaining = workspaceManager.clearAllWorkspaces(keepApkFilePath = activeApk)
            _uiState.update {
                it.copy(
                    tempStorageBytes = remaining,
                    zipSelection = if (activeApk == null) null else it.zipSelection,
                    projectInspection = if (activeApk == null) null else it.projectInspection,
                    statusBannerMessage = "تم تنظيف الملفات المؤقتة (${Formatters.formatBytes(remaining)} متبقية).",
                )
            }
        }
    }

    fun showBannerMessage(message: String) {
        _uiState.update { it.copy(statusBannerMessage = message) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun updateEngineSettings(transform: (BuildEngineSettings) -> BuildEngineSettings) {
        viewModelScope.launch {
            settingsRepo.updateSettings(transform)
            _uiState.update { it.copy(runnerHealth = null) }
        }
    }

    fun testRemoteRunnerHealth() {
        val current = settings.value
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingRunner = true, runnerHealth = null) }
            val result = remoteClient.checkHealth(current.remoteRunnerUrl, current.remoteAuthToken)
            _uiState.update { it.copy(isTestingRunner = false, runnerHealth = result) }
        }
    }

    fun dismissUploadConsentDialog() {
        _uiState.update { it.copy(showUploadConsentDialog = false) }
    }

    fun confirmUploadConsentAndStartBuild(onNavigateToProgress: () -> Unit) {
        viewModelScope.launch {
            settingsRepo.updateSettings { it.copy(uploadConsentGranted = true) }
            _uiState.update { it.copy(showUploadConsentDialog = false) }
            startBuildApk(bypassConsentCheck = true, onNavigateToProgress = onNavigateToProgress)
        }
    }

    fun startBuildApk(
        bypassConsentCheck: Boolean = false,
        onNavigateToProgress: () -> Unit,
    ) {
        val selection = _uiState.value.zipSelection ?: return
        val inspection = _uiState.value.projectInspection ?: return
        val activeSettings = settings.value

        if (activeSettings.mode == BuildEngineMode.REMOTE_RUNNER &&
            !activeSettings.uploadConsentGranted &&
            !bypassConsentCheck
        ) {
            _uiState.update { it.copy(showUploadConsentDialog = true) }
            return
        }

        onNavigateToProgress()
        buildJob?.cancel()
        buildJob = viewModelScope.launch {
            executeBuildPipeline(selection, inspection, activeSettings)
        }
    }

    fun extractEmbeddedPrebuiltApk(onNavigateToResult: () -> Unit) {
        val inspection = _uiState.value.projectInspection ?: return
        val firstRelApk = inspection.embeddedApkPaths.firstOrNull() ?: return
        viewModelScope.launch {
            val logs = mutableListOf<BuildLogEntry>()
            fun log(level: LogLevel, msg: String) {
                logs.add(BuildLogEntry(Formatters.nowTimestamp(), level, msg))
            }

            val steps = defaultSteps().map { step ->
                when (step.stage) {
                    BuildStage.SANDBOX_PREP -> step.copy(status = StageStatus.SUCCEEDED, detail = "تم فك ضغط الأرشيف")
                    BuildStage.PROJECT_VALIDATION -> step.copy(status = StageStatus.SUCCEEDED, detail = "تم العثور على APK جاهز")
                    BuildStage.TOOLCHAIN_CHECK -> step.copy(status = StageStatus.SUCCEEDED, detail = "تم التخطي (ملف APK جاهز)")
                    BuildStage.GRADLE_BUILD -> step.copy(status = StageStatus.SUCCEEDED, detail = "تم استخراج $firstRelApk")
                    BuildStage.APK_VERIFICATION -> step.copy(status = StageStatus.RUNNING, detail = "جاري فحص التوقيع والبيانات")
                }
            }
            log(LogLevel.INFO, "استخراج ملف APK الجاهز من الأرشيف: $firstRelApk")
            _buildState.value = BuildExecutionState.Running(0.8f, "جاري التحقق من ملف APK...", steps, logs.toList())

            val srcApk = File(File(inspection.workspaceDirPath, "src"), firstRelApk)
            val destApk = workspaceManager.createOutputApkFile("${inspection.projectName}_prebuilt.apk")
            runCatching {
                withContext(Dispatchers.IO) { srcApk.copyTo(destApk, overwrite = true) }
            }.onFailure { err ->
                log(LogLevel.ERROR, "فشل نسخ APK: ${err.localizedMessage}")
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.8f,
                    errorTitle = "فشل استخراج APK",
                    errorDetail = err.localizedMessage ?: "تعذر نسخ ملف APK.",
                    missingRequirements = emptyList(),
                    steps = steps.map {
                        if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.FAILED, detail = "فشل النسخ") else it
                    },
                    logs = logs.toList(),
                )
                return@launch
            }

            val verified = apkVerifier.verifyAndInspectApk(
                destApk,
                sourceNote = "تم استخراج APK جاهز من الأرشيف (بدون إعادة بناء)",
            )
            verified.onSuccess { info ->
                log(LogLevel.SUCCESS, "تم التحقق: ${info.packageName} (${Formatters.formatBytes(info.sizeBytes)})")
                val finalSteps = steps.map { it.copy(status = StageStatus.SUCCEEDED) }
                _buildState.value = BuildExecutionState.Succeeded(1.0f, finalSteps, logs.toList(), info)
                refreshEnvironmentAndStorage()
                onNavigateToResult()
            }.onFailure { err ->
                log(LogLevel.ERROR, err.localizedMessage ?: "ملف APK غير صالح")
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.85f,
                    errorTitle = "ملف APK غير صالح",
                    errorDetail = err.localizedMessage ?: "فشل التحقق من بنية ملف APK.",
                    missingRequirements = emptyList(),
                    steps = steps.map {
                        if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.FAILED, detail = "غير صالح") else it
                    },
                    logs = logs.toList(),
                )
            }
        }
    }

    fun saveApkToSafUri(apkFilePath: String, targetUri: Uri) {
        viewModelScope.launch {
            workspaceManager.copyApkToSafUri(File(apkFilePath), targetUri)
                .onSuccess { bytes ->
                    _uiState.update {
                        it.copy(statusBannerMessage = "تم حفظ ملف APK (${Formatters.formatBytes(bytes)}) في المسار المختار.")
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(statusBannerMessage = "فشل حفظ الملف: ${err.localizedMessage}")
                    }
                }
        }
    }

    private suspend fun executeBuildPipeline(
        selection: ZipSelectionInfo,
        inspection: ProjectInspection,
        activeSettings: BuildEngineSettings,
    ) {
        val logs = mutableListOf<BuildLogEntry>()
        var steps = defaultSteps()

        fun addLog(level: LogLevel, msg: String) {
            logs.add(BuildLogEntry(Formatters.nowTimestamp(), level, msg))
        }

        fun updateStep(stage: BuildStage, status: StageStatus, detail: String) {
            steps = steps.map { if (it.stage == stage) it.copy(status = status, detail = detail) else it }
        }

        fun emitRunning(progress: Float, label: String) {
            _buildState.value = BuildExecutionState.Running(
                progress = progress,
                currentStageLabel = label,
                steps = steps,
                logs = logs.toList(),
            )
        }

        // 1. Sandbox Prep
        updateStep(BuildStage.SANDBOX_PREP, StageStatus.RUNNING, "تجهيز مساحة العمل ${inspection.workspaceId}")
        addLog(LogLevel.INFO, "Sandbox workspace: ${inspection.workspaceDirPath}")
        addLog(LogLevel.INFO, "Archive: ${selection.displayName} (${Formatters.formatBytes(selection.sizeBytes)})")
        emitRunning(0.15f, "جاري تجهيز البيئة المعزولة...")
        delay(200)

        val srcDir = File(inspection.workspaceDirPath, "src")
        if (!srcDir.isDirectory) {
            updateStep(BuildStage.SANDBOX_PREP, StageStatus.FAILED, "مجلد المشروع المفكوك غير موجود")
            addLog(LogLevel.ERROR, "Extracted source directory does not exist.")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.15f,
                errorTitle = "مساحة العمل مفقودة",
                errorDetail = "يرجى إعادة اختيار ملف ZIP الخاص بالمشروع.",
                missingRequirements = listOf("مجلد المشروع المستخرج"),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }
        updateStep(BuildStage.SANDBOX_PREP, StageStatus.SUCCEEDED, "تم عزل ${inspection.totalExtractedFiles} ملفًا")
        addLog(LogLevel.SUCCESS, "تم عزل ${inspection.totalExtractedFiles} ملفًا (${Formatters.formatBytes(inspection.extractedSizeBytes)}).")

        // 2. Project Validation
        updateStep(BuildStage.PROJECT_VALIDATION, StageStatus.RUNNING, "التحقق من ملفات Gradle وManifest")
        emitRunning(0.32f, "جاري فحص هيكل المشروع والمكتبات...")
        delay(200)

        addLog(LogLevel.INFO, "نوع المشروع: ${inspection.projectType.displayLabel}")
        inspection.gradleVersion?.let { addLog(LogLevel.INFO, "إصدار Gradle المطلوب: $it") }
        inspection.compileSdk?.let { addLog(LogLevel.INFO, "compileSdk: $it | minSdk: ${inspection.minSdk ?: "default"}") }
        inspection.javaCompatibility?.let { addLog(LogLevel.INFO, "إصدار Java / JVM: $it") }
        if (inspection.detectedDependencies.isNotEmpty()) {
            addLog(LogLevel.INFO, "المكتبات المكتشفة (${inspection.detectedDependencies.size}): ${inspection.detectedDependencies.take(6).joinToString(", ")}")
        }

        if (!inspection.isValidAndroidProject) {
            updateStep(BuildStage.PROJECT_VALIDATION, StageStatus.FAILED, "نقص في ملفات Gradle أو Manifest")
            inspection.missingRequirements.forEach { addLog(LogLevel.ERROR, it) }
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.35f,
                errorTitle = "مشروع Android Studio غير مكتمل",
                errorDetail = inspection.readinessSummary,
                missingRequirements = inspection.missingRequirements,
                steps = steps,
                logs = logs.toList(),
                canExtractPrebuiltApk = inspection.embeddedApkPaths.isNotEmpty(),
            )
            return
        }
        updateStep(BuildStage.PROJECT_VALIDATION, StageStatus.SUCCEEDED, "تم التحقق من ${inspection.projectName}")
        addLog(LogLevel.SUCCESS, "نجح فحص المشروع (${inspection.kotlinFileCount} Kotlin, ${inspection.javaFileCount} Java).")

        // 3. Toolchain Check
        updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.RUNNING, "فحص ${activeSettings.mode.label}")
        emitRunning(0.50f, "جاري فحص أدوات البناء...")

        if (activeSettings.mode == BuildEngineMode.LOCAL_DEVICE) {
            val probe = toolchainProbe.probeDeviceEnvironment()
            _uiState.update { it.copy(deviceProbe = probe) }
            addLog(LogLevel.INFO, "معمارية الجهاز: ${probe.deviceAbi} | Android API ${probe.androidSdkInt}")
            addLog(LogLevel.INFO, "المساحة الحرة: ${Formatters.formatBytes(probe.freeSpaceBytes)}")

            if (!probe.localToolchainReady) {
                updateStep(
                    BuildStage.TOOLCHAIN_CHECK,
                    StageStatus.FAILED,
                    "أدوات Android SDK وGradle غير متوفرة على الهاتف",
                )
                probe.missingToolchainItems.forEach { item ->
                    addLog(LogLevel.ERROR, "غير متوفر على الهاتف: $item")
                }
                addLog(
                    LogLevel.WARN,
                    "هواتف أندرويد لا تأتي بأدوات البناء (JDK / Gradle / android.jar / aapt2 / d8). " +
                        "تم إيقاف البناء بصدق دون إنشاء ملف APK وهمي.",
                )
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.55f,
                    errorTitle = "أدوات البناء غير متوفرة على الهاتف",
                    errorDetail = "بناء مشروع Android Studio حقيقي وتحميل مكتباته يتطلب وجود JDK وGradle ومنصة Android SDK وأدوات aapt2 وd8، وهي غير مثبتة على هواتف أندرويد. لترجمة المشروع وإنتاج APK حقيقي موقّع، شغّل خادم Gradle على جهاز الكمبيوتر من إعدادات محرك البناء.",
                    missingRequirements = probe.missingToolchainItems,
                    steps = steps,
                    logs = logs.toList(),
                    canExtractPrebuiltApk = inspection.embeddedApkPaths.isNotEmpty(),
                )
                return
            }

            updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.SUCCEEDED, "تم العثور على أدوات البناء")
            updateStep(BuildStage.GRADLE_BUILD, StageStatus.RUNNING, "تشغيل gradle assemble")
            emitRunning(0.72f, "جاري الترجمة وتحميل المكتبات...")

            val projectDir = if (inspection.projectRootRelativePath == "/") {
                srcDir
            } else {
                File(srcDir, inspection.projectRootRelativePath.trimStart('/'))
            }

            val localBuildResult = runLocalGradleSubprocess(projectDir, activeSettings.buildVariant) { line ->
                addLog(LogLevel.INFO, line)
                emitRunning(0.76f, "جاري البناء عبر Gradle المحلي...")
            }

            if (localBuildResult == null) {
                updateStep(BuildStage.GRADLE_BUILD, StageStatus.FAILED, "فشلت عملية البناء")
                _buildState.value = BuildExecutionState.Failed(
                    progress = 0.78f,
                    errorTitle = "فشل البناء عبر Gradle المحلي",
                    errorDetail = "توقف أمر Gradle بوجود أخطاء أو لم ينتج ملف APK.",
                    missingRequirements = emptyList(),
                    steps = steps,
                    logs = logs.toList(),
                )
                return
            }

            finalizeVerifiedApk(
                producedApk = localBuildResult,
                sourceNote = "تم البناء محليًا عبر Gradle على الجهاز",
                steps = steps,
                logs = logs,
                updateStep = ::updateStep,
                addLog = ::addLog,
                emitRunning = ::emitRunning,
            )
            return
        }

        // Mode: REMOTE_RUNNER
        if (activeSettings.remoteRunnerUrl.isBlank()) {
            updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.FAILED, "رابط خادم البناء غير محدد")
            addLog(LogLevel.ERROR, "لم يتم إدخال رابط خادم Gradle.")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.50f,
                errorTitle = "مطلوب رابط خادم البناء",
                errorDetail = "افتح إعدادات محرك البناء وأدخل رابط خادم Gradle الخاص بك (مثل http://192.168.1.25:8787).",
                missingRequirements = listOf("عنوان خادم Gradle"),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }

        addLog(LogLevel.INFO, "فحص اتصال خادم البناء: ${activeSettings.remoteRunnerUrl}...")
        val health = remoteClient.checkHealth(activeSettings.remoteRunnerUrl, activeSettings.remoteAuthToken)
        if (!health.reachable) {
            updateStep(BuildStage.TOOLCHAIN_CHECK, StageStatus.FAILED, "تعذر الوصول إلى الخادم")
            addLog(LogLevel.ERROR, "فشل فحص الخادم: ${health.message}")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.52f,
                errorTitle = "خادم البناء غير متصل",
                errorDetail = health.message,
                missingRequirements = listOf("اتصال شغال بخادم Gradle"),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }

        updateStep(
            BuildStage.TOOLCHAIN_CHECK,
            StageStatus.SUCCEEDED,
            health.sdkPlatform ?: health.message,
        )
        addLog(
            LogLevel.SUCCESS,
            "الخادم متصل (${health.message}${health.gradleVersion?.let { " • Gradle $it" }.orEmpty()}).",
        )

        // 4. Remote Gradle Build
        updateStep(BuildStage.GRADLE_BUILD, StageStatus.RUNNING, "جاري تحميل المكتبات وبناء ${activeSettings.buildVariant} APK")
        addLog(LogLevel.INFO, "تم التحقق من الموافقة. جاري رفع ${selection.displayName}...")
        emitRunning(0.60f, "جاري رفع المشروع إلى خادم Gradle...")

        val destApk = workspaceManager.createOutputApkFile("${inspection.projectName}-${activeSettings.buildVariant}.apk")
        val remoteOutcome = remoteClient.uploadAndBuildApk(
            baseUrl = activeSettings.remoteRunnerUrl,
            authToken = activeSettings.remoteAuthToken,
            zipFile = File(selection.localZipFilePath),
            variant = activeSettings.buildVariant,
            destinationApkFile = destApk,
            onUploadProgress = { ratio ->
                val overall = 0.60f + ratio * 0.15f
                emitRunning(overall, "جاري رفع المشروع (${(ratio * 100).toInt()}%)...")
            },
            onLogLine = { msg ->
                addLog(LogLevel.INFO, msg)
                emitRunning(0.82f, "جاري تحميل المكتبات وبناء APK على الخادم...")
            },
        )

        remoteOutcome.serverLogs.forEach { line ->
            val lvl = if (line.contains("error", ignoreCase = true) || line.contains("failed", ignoreCase = true)) {
                LogLevel.ERROR
            } else LogLevel.INFO
            addLog(lvl, line)
        }

        if (!remoteOutcome.success || remoteOutcome.outputApkFile == null) {
            updateStep(BuildStage.GRADLE_BUILD, StageStatus.FAILED, "فشلت عملية بناء Gradle")
            addLog(LogLevel.ERROR, remoteOutcome.errorMessage ?: "فشل البناء على الخادم.")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.82f,
                errorTitle = "فشل بناء Gradle",
                errorDetail = remoteOutcome.errorMessage ?: "فشل الخادم في ترجمة المشروع.",
                missingRequirements = emptyList(),
                steps = steps,
                logs = logs.toList(),
            )
            return
        }

        updateStep(BuildStage.GRADLE_BUILD, StageStatus.SUCCEEDED, "تم إنتاج ملف APK بنجاح")
        finalizeVerifiedApk(
            producedApk = remoteOutcome.outputApkFile,
            sourceNote = "تم البناء عبر خادم Gradle الخاص بك (${activeSettings.buildVariant})",
            steps = steps,
            logs = logs,
            updateStep = ::updateStep,
            addLog = ::addLog,
            emitRunning = ::emitRunning,
        )
    }

    private suspend fun finalizeVerifiedApk(
        producedApk: File,
        sourceNote: String,
        steps: List<BuildStepState>,
        logs: MutableList<BuildLogEntry>,
        updateStep: (BuildStage, StageStatus, String) -> Unit,
        addLog: (LogLevel, String) -> Unit,
        emitRunning: (Float, String) -> Unit,
    ) {
        updateStep(BuildStage.APK_VERIFICATION, StageStatus.RUNNING, "فحص التوقيع والبيانات والتوافق")
        emitRunning(0.92f, "جاري التحقق من سلامة وتوقيع ملف APK...")

        val verified = apkVerifier.verifyAndInspectApk(producedApk, sourceNote)
        verified.onSuccess { apkInfo ->
            updateStep(BuildStage.APK_VERIFICATION, StageStatus.SUCCEEDED, "${apkInfo.packageName} (${Formatters.formatBytes(apkInfo.sizeBytes)})")
            addLog(LogLevel.SUCCESS, "تم التحقق من APK: ${apkInfo.appName} | ${apkInfo.packageName} v${apkInfo.versionName}")
            addLog(LogLevel.INFO, "التوقيع: ${if (apkInfo.isSigned) "موقّع" else "غير موقّع"} | SHA-256: ${apkInfo.sha256}")
            val completedSteps = steps.map {
                if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.SUCCEEDED, detail = "${Formatters.formatBytes(apkInfo.sizeBytes)} جاهز")
                else it
            }
            _buildState.value = BuildExecutionState.Succeeded(
                progress = 1.0f,
                steps = completedSteps,
                logs = logs.toList(),
                result = apkInfo,
            )
            refreshEnvironmentAndStorage()
        }.onFailure { err ->
            updateStep(BuildStage.APK_VERIFICATION, StageStatus.FAILED, "ملف APK غير صالح")
            addLog(LogLevel.ERROR, "فشل التحقق من APK: ${err.localizedMessage}")
            _buildState.value = BuildExecutionState.Failed(
                progress = 0.94f,
                errorTitle = "ملف APK ناتج غير صالح",
                errorDetail = err.localizedMessage ?: "الملف الناتج لا يطابق مواصفات APK الصالحة.",
                missingRequirements = emptyList(),
                steps = steps.map {
                    if (it.stage == BuildStage.APK_VERIFICATION) it.copy(status = StageStatus.FAILED, detail = "غير صالح") else it
                },
                logs = logs.toList(),
            )
        }
    }

    private suspend fun runLocalGradleSubprocess(
        projectDir: File,
        variant: String,
        onLine: (String) -> Unit,
    ): File? = withContext(Dispatchers.IO) {
        runCatching {
            val task = if (variant.equals("release", ignoreCase = true)) "assembleRelease" else "assembleDebug"
            val gradleHome = File(projectDir.parentFile, ".gradle_home").apply { mkdirs() }
            val pb = ProcessBuilder("gradle", task, "--no-daemon")
                .directory(projectDir)
                .redirectErrorStream(true)
            pb.environment()["GRADLE_USER_HOME"] = gradleHome.absolutePath
            val process = pb.start()
            process.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { onLine(it) }
            }
            val finished = process.waitFor(10, TimeUnit.MINUTES)
            if (!finished || process.exitValue() != 0) return@runCatching null

            val apk = projectDir.walkTopDown()
                .filter { it.isFile && it.extension.equals("apk", ignoreCase = true) && it.path.contains("outputs/apk") }
                .sortedBy { it.name.contains("unsigned", ignoreCase = true) }
                .firstOrNull()
                ?: return@runCatching null
            val out = workspaceManager.createOutputApkFile(apk.name)
            apk.copyTo(out, overwrite = true)
            out
        }.getOrNull()
    }

    private fun defaultSteps(): List<BuildStepState> = BuildStage.entries.map {
        BuildStepState(stage = it, status = StageStatus.PENDING, detail = "في الانتظار...")
    }
}
