package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.YahyaCompanionApp
import com.example.data.preferences.PairingPayloadCodec
import com.example.domain.model.AccessibilityHealth
import com.example.domain.model.AssistantSettings
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.ConnectionState
import com.example.domain.model.DiscoveredBrainDevice
import com.example.domain.model.MicStatus
import com.example.domain.model.PendingConfirmation
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val coordinator = (application as YahyaCompanionApp).coordinator

    val settings: StateFlow<AssistantSettings> = coordinator.settings
    val connectionState: StateFlow<ConnectionState> = coordinator.connectionState
    val micStatus: StateFlow<MicStatus> = coordinator.micStatus
    val partialTranscript: StateFlow<String> = coordinator.partialTranscript
    val rmsLevel: StateFlow<Float> = coordinator.rmsLevel
    val isForegroundServiceRunning: StateFlow<Boolean> = coordinator.isForegroundServiceRunning
    val logs: StateFlow<List<CommandExecutionLog>> = coordinator.logs
    val pendingConfirmation: StateFlow<PendingConfirmation?> = coordinator.pendingConfirmation
    val accessibilityHealth: StateFlow<AccessibilityHealth> = coordinator.accessibilityHealth
    val localIp: StateFlow<String?> = coordinator.localIp
    val discoveredDevices: StateFlow<List<DiscoveredBrainDevice>> = coordinator.discoveredDevices
    val isNsdScanning: StateFlow<Boolean> = coordinator.isNsdScanning

    val deviceModelLabel: String = coordinator.deviceModelLabel

    fun refreshDeviceHealth() = coordinator.refreshDeviceHealth()
    fun toggleMicrophone() = coordinator.toggleMicrophone()
    fun startMicrophone() = coordinator.startMicrophone()
    fun stopMicrophone() = coordinator.stopMicrophone()
    fun sendManualTranscript(text: String) = coordinator.sendManualTextTranscript(text)

    fun approvePendingConfirmation() = coordinator.approvePendingConfirmation()
    fun rejectPendingConfirmation() = coordinator.rejectPendingConfirmation()

    fun pairAndConnect(
        deviceName: String,
        host: String,
        port: Int,
        pairingCode: String,
        secret: String,
        useTls: Boolean,
    ) = coordinator.pairAndConnect(deviceName, host, port, pairingCode, secret, useTls)

    fun parseAndPairQrPayload(raw: String): Boolean {
        val parsed = PairingPayloadCodec.parseBrainPayload(raw) ?: return false
        coordinator.pairAndConnect(
            deviceName = parsed.deviceName,
            host = parsed.host,
            port = parsed.port,
            pairingCode = parsed.pairingCode,
            secret = parsed.secret,
            useTls = parsed.useTls,
        )
        return true
    }

    fun reconnectPairedDevice() = coordinator.reconnectPairedDevice()
    fun disconnectAndUnpair() = coordinator.disconnectAndUnpair()
    fun sendPingTest() = coordinator.sendPingTest()
    fun rotateLocalPairingCredentials() = coordinator.rotateLocalPairingCredentials()

    fun startNsdDiscovery() = coordinator.nsdDiscovery.startDiscovery()
    fun stopNsdDiscovery() = coordinator.nsdDiscovery.stopDiscovery()

    fun updateAssistantIdentity(name: String, wakePhrase: String) =
        coordinator.updateAssistantIdentity(name, wakePhrase)

    fun updateSpeechSettings(
        language: String,
        continuousListening: Boolean,
        foregroundServiceEnabled: Boolean,
        autoSpeakReplies: Boolean,
    ) = coordinator.updateSpeechSettings(
        language = language,
        continuousListening = continuousListening,
        foregroundServiceEnabled = foregroundServiceEnabled,
        autoSpeakReplies = autoSpeakReplies,
    )

    fun updateSafetyAndUi(confirmSensitiveActions: Boolean, rtlEnabled: Boolean) =
        coordinator.updateSafetyAndUi(confirmSensitiveActions, rtlEnabled)

    fun clearLogs() = coordinator.clearLogs()
    fun testSafeUrlPreview() = coordinator.testSafeUrlPreview()
    fun testSensitiveGuardrailPreview() = coordinator.testSensitiveGuardrailPreview()
}
