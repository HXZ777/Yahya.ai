package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.MineVrStrings
import com.example.ui.theme.CreeperEmerald
import com.example.ui.theme.CreeperEmeraldDark
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.MineBedrockSurface
import com.example.ui.theme.MineBlockBorder
import com.example.ui.theme.MineElevatedCard
import com.example.ui.theme.MineObsidian
import com.example.ui.theme.MineTextSecondary
import com.example.vr.input.PlayStationControllerSnapshot
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControllerKind
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GameAction
import com.example.vr.model.PsButton
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ControlsScreen(
    controls: ControlsSettingsState,
    controller: PlayStationControllerSnapshot,
    language: AppLanguage,
    strings: MineVrStrings,
    onRefreshDevices: () -> Unit,
    onSaveControls: (ControlsSettingsState) -> Unit,
    onResetDefaults: () -> Unit,
    onBack: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var draft by remember(controls) { mutableStateOf(controls) }
    var editingButton by remember { mutableStateOf<PsButton?>(null) }

    Scaffold(
        containerColor = MineObsidian,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(strings.controllerSettingsTitle, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("controls_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MineBedrockSurface),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .widthIn(max = 680.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Connection & Latency Status Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                Icons.Filled.SportsEsports,
                                contentDescription = null,
                                tint = if (controller.isConnected) CreeperEmerald else GoldAmber
                            )
                            Text(
                                text = if (controller.isConnected) strings.statusControllerConnected else strings.statusControllerDisconnected,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        FilledTonalButton(
                            onClick = onRefreshDevices,
                            modifier = Modifier.testTag("refresh_controllers_button")
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.refreshDevices)
                        }
                    }

                    val kindName = when (controller.controllerKind) {
                        ControllerKind.DUALSENSE -> "PlayStation 5 DualSense"
                        ControllerKind.DUALSHOCK_4 -> "PlayStation 4 DualShock 4"
                        ControllerKind.XBOX_OR_GENERIC -> controller.deviceName.ifEmpty { "Gamepad" }
                        ControllerKind.NONE -> "--"
                    }
                    Text("${strings.controllerTypeLabel}: $kindName", style = MaterialTheme.typography.bodySmall, color = DiamondCyan)
                    Text(
                        "${strings.transportLabel}: ${controller.transport.name}  |  ${strings.responseLatencyLabel}: ${controller.lastResponseLatencyMs} ms",
                        style = MaterialTheme.typography.labelMedium,
                        color = MineTextSecondary
                    )
                }
            }

            // Live Button & Stick Tester
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.liveInputTester, style = MaterialTheme.typography.titleSmall, color = CreeperEmerald)
                    Text(strings.pressAnyButtonHint, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        AnalogStickVisualizer(
                            label = strings.leftStickLabel,
                            x = controller.leftX,
                            y = controller.leftY
                        )
                        AnalogStickVisualizer(
                            label = strings.rightStickLabel,
                            x = controller.rightX,
                            y = controller.rightY
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("L2: ${(controller.l2Trigger * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                            LinearProgressIndicator(
                                progress = { controller.l2Trigger },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp),
                                color = DiamondCyan
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("R2: ${(controller.r2Trigger * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                            LinearProgressIndicator(
                                progress = { controller.r2Trigger },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp),
                                color = CreeperEmerald
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PsButton.entries.forEach { btn ->
                            val isPressed = btn in controller.pressedButtons
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = if (isPressed) CreeperEmerald else MineElevatedCard,
                                border = BorderStroke(1.dp, if (isPressed) CreeperEmerald else MineBlockBorder)
                            ) {
                                Text(
                                    text = if (language == AppLanguage.ARABIC) btn.defaultLabelAr else btn.defaultLabelEn,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isPressed) Color(0xFF03230E) else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Column {
                        Text(
                            text = "Deadzone: ${(draft.stickDeadzone * 100).toInt()}%",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = draft.stickDeadzone,
                            onValueChange = { draft = draft.copy(stickDeadzone = it) },
                            valueRange = 0.05f..0.35f
                        )
                    }
                }
            }

            // Full Button Remapping List
            Card(
                colors = CardDefaults.cardColors(containerColor = MineBedrockSurface),
                border = BorderStroke(1.dp, MineBlockBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.buttonRemappingTitle, style = MaterialTheme.typography.titleSmall, color = DiamondCyan)
                    Text(strings.tapToRemapHint, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)

                    PsButton.entries.forEach { btn ->
                        val assigned = draft.mapping.actionFor(btn)
                        Surface(
                            onClick = { editingButton = btn },
                            shape = MaterialTheme.shapes.medium,
                            color = MineElevatedCard,
                            border = BorderStroke(1.dp, MineBlockBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("remap_btn_${btn.name}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (language == AppLanguage.ARABIC) btn.defaultLabelAr else btn.defaultLabelEn,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = if (language == AppLanguage.ARABIC) assigned.labelAr else assigned.labelEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CreeperEmerald
                                    )
                                    Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = MineTextSecondary)
                                }
                            }
                        }
                    }
                }
            }

            // Pairing & Native Routing Note
            Card(
                colors = CardDefaults.cardColors(containerColor = CreeperEmeraldDark),
                border = BorderStroke(1.dp, CreeperEmerald)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(strings.pairingGuideTitle, style = MaterialTheme.typography.titleSmall, color = CreeperEmerald)
                    Text(strings.pairingGuideBody, style = MaterialTheme.typography.bodySmall)
                    Text(strings.controllerRoutingNote, style = MaterialTheme.typography.bodySmall, color = MineTextSecondary)
                }
            }

            // Save & Reset
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        onResetDefaults()
                        draft = ControlsSettingsState()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.resetDefaults)
                }
                Button(
                    onClick = {
                        onSaveControls(draft)
                        scope.launch { snackbarHostState.showSnackbar(strings.savedToast) }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_controls_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CreeperEmerald, contentColor = Color(0xFF04220E))
                ) {
                    Icon(Icons.Filled.Save, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.save)
                }
            }
        }
    }

    editingButton?.let { btn ->
        AlertDialog(
            onDismissRequest = { editingButton = null },
            title = {
                val btnLabel = if (language == AppLanguage.ARABIC) btn.defaultLabelAr else btn.defaultLabelEn
                Text("${strings.selectActionFor}: $btnLabel")
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GameAction.entries.forEach { action ->
                        val isCurrent = draft.mapping.actionFor(btn) == action
                        Surface(
                            onClick = {
                                draft = draft.copy(mapping = draft.mapping.withAction(btn, action))
                                editingButton = null
                            },
                            shape = MaterialTheme.shapes.small,
                            color = if (isCurrent) CreeperEmeraldDark else MineElevatedCard,
                            border = BorderStroke(1.dp, if (isCurrent) CreeperEmerald else MineBlockBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (language == AppLanguage.ARABIC) action.labelAr else action.labelEn,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { editingButton = null }) {
                    Text(strings.back)
                }
            }
        )
    }
}

@Composable
private fun AnalogStickVisualizer(label: String, x: Float, y: Float) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Canvas(modifier = Modifier.size(86.dp)) {
            val r = size.minDimension / 2f - 4f
            drawCircle(color = MineBlockBorder, radius = r, style = Stroke(width = 3f))
            drawLine(MineBlockBorder, Offset(center.x - r, center.y), Offset(center.x + r, center.y), strokeWidth = 1.5f)
            drawLine(MineBlockBorder, Offset(center.x, center.y - r), Offset(center.x, center.y + r), strokeWidth = 1.5f)
            val dotPos = Offset(center.x + x * (r * 0.78f), center.y + y * (r * 0.78f))
            drawCircle(color = CreeperEmerald, radius = 10f, center = dotPos)
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = MineTextSecondary)
        Text("${"%.2f".format(x)}, ${"%.2f".format(y)}", style = MaterialTheme.typography.labelSmall, color = DiamondCyan)
    }
}
