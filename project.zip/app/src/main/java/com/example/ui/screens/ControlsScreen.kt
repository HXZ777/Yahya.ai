package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.vr.input.HandTrackingManager
import com.example.vr.input.XboxControllerSnapshot
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControlScheme
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.FlySpeed
import com.example.vr.model.FlyToggleButton
import com.example.vr.model.HandTrackingHealth
import com.example.vr.model.HandTrackingState
import com.example.vr.model.MovementMode
import com.example.vr.model.XboxAction

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ControlsScreen(
    controls: ControlsSettingsState,
    language: AppLanguage,
    xbox: XboxControllerSnapshot,
    handState: HandTrackingState,
    handTracker: HandTrackingManager,
    strings: AppStrings,
    onUpdateControls: ((ControlsSettingsState) -> ControlsSettingsState) -> Unit,
    onRefreshXbox: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(handTracker.hasCameraPermission()) }
    var isCameraTesting by remember { mutableStateOf(false) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) {
            isCameraTesting = true
        }
    }

    DisposableEffect(Unit) {
        onRefreshXbox()
        onDispose {
            handTracker.stopCameraTracking()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(strings.controlsTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("controls_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Control Scheme Selector (Gaze / Xbox / Camera Hand Tracking)
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(strings.activeControlSchemeTitle, style = MaterialTheme.typography.titleMedium)

                        SchemeOptionCard(
                            title = strings.schemeGaze,
                            desc = strings.schemeGazeDesc,
                            icon = Icons.Filled.Visibility,
                            selected = controls.activeScheme == ControlScheme.GAZE,
                            testTag = "scheme_gaze",
                            onClick = { onUpdateControls { it.copy(activeScheme = ControlScheme.GAZE) } }
                        )
                        SchemeOptionCard(
                            title = strings.schemeXbox,
                            desc = strings.schemeXboxDesc,
                            icon = Icons.Filled.Gamepad,
                            selected = controls.activeScheme == ControlScheme.XBOX_CONTROLLER,
                            testTag = "scheme_xbox",
                            onClick = { onUpdateControls { it.copy(activeScheme = ControlScheme.XBOX_CONTROLLER) } }
                        )
                        SchemeOptionCard(
                            title = strings.schemeHand,
                            desc = strings.schemeHandDesc,
                            icon = Icons.Filled.PanTool,
                            selected = controls.activeScheme == ControlScheme.HAND_TRACKING,
                            testTag = "scheme_hand",
                            onClick = { onUpdateControls { it.copy(activeScheme = ControlScheme.HAND_TRACKING) } }
                        )
                    }
                }
            }

            // 2. Movement & Sensitivity Settings
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(strings.movementSectionTitle, style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = controls.movementMode == MovementMode.SMOOTH,
                                onClick = { onUpdateControls { it.copy(movementMode = MovementMode.SMOOTH) } },
                                label = { Text(strings.movementSmooth) },
                                modifier = Modifier.testTag("move_smooth_chip")
                            )
                            FilterChip(
                                selected = controls.movementMode == MovementMode.TELEPORT,
                                onClick = { onUpdateControls { it.copy(movementMode = MovementMode.TELEPORT) } },
                                label = { Text(strings.movementTeleport) },
                                modifier = Modifier.testTag("move_teleport_chip")
                            )
                        }

                        SettingSliderRow(
                            title = strings.moveSpeedTitle,
                            valueText = String.format("%.1f m/s", controls.moveSpeed),
                            value = controls.moveSpeed,
                            range = 1.5f..6.0f,
                            onValueChange = { v -> onUpdateControls { it.copy(moveSpeed = v) } }
                        )
                        SettingSliderRow(
                            title = strings.turnSensitivityTitle,
                            valueText = String.format("%.1fx", controls.turnSensitivity),
                            value = controls.turnSensitivity,
                            range = 0.4f..2.5f,
                            onValueChange = { v -> onUpdateControls { it.copy(turnSensitivity = v) } }
                        )
                        SettingSliderRow(
                            title = strings.gazeDwellTitle,
                            valueText = String.format("%.1fs", controls.gazeDwellSeconds),
                            value = controls.gazeDwellSeconds,
                            range = 0.6f..2.5f,
                            onValueChange = { v -> onUpdateControls { it.copy(gazeDwellSeconds = v) } }
                        )
                    }
                }
            }

            // 3. Xbox Controller Status & Button Remapping
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, if (xbox.isConnected) VrEmerald else MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(strings.xboxSectionTitle, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = if (xbox.isConnected) "${strings.xboxConnected} ${xbox.deviceName}" else strings.xboxNotConnected,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (xbox.isConnected) VrEmerald else VrAmber
                        )
                        if (xbox.isConnected) {
                            Text(
                                text = "LS(${String.format("%.2f", xbox.leftX)}, ${String.format("%.2f", xbox.leftY)}) · RS(${String.format("%.2f", xbox.rightX)}, ${String.format("%.2f", xbox.rightY)}) · LT ${String.format("%.1f", xbox.leftTrigger)} · RT ${String.format("%.1f", xbox.rightTrigger)} ${xbox.pressedButtons}",
                                style = MaterialTheme.typography.labelSmall,
                                color = VrCyan
                            )
                        }
                        Text(strings.xboxRemapTitle, style = MaterialTheme.typography.titleSmall)

                        val m = controls.xboxMapping
                        XboxRemapRow("A", m.buttonA, language) { act ->
                            onUpdateControls { it.copy(xboxMapping = it.xboxMapping.copy(buttonA = act)) }
                        }
                        XboxRemapRow("B", m.buttonB, language) { act ->
                            onUpdateControls { it.copy(xboxMapping = it.xboxMapping.copy(buttonB = act)) }
                        }
                        XboxRemapRow("X", m.buttonX, language) { act ->
                            onUpdateControls { it.copy(xboxMapping = it.xboxMapping.copy(buttonX = act)) }
                        }
                        XboxRemapRow("Y", m.buttonY, language) { act ->
                            onUpdateControls { it.copy(xboxMapping = it.xboxMapping.copy(buttonY = act)) }
                        }
                        XboxRemapRow("LT", m.leftTrigger, language) { act ->
                            onUpdateControls { it.copy(xboxMapping = it.xboxMapping.copy(leftTrigger = act)) }
                        }
                        XboxRemapRow("RT", m.rightTrigger, language) { act ->
                            onUpdateControls { it.copy(xboxMapping = it.xboxMapping.copy(rightTrigger = act)) }
                        }
                    }
                }
            }

            // 3b. Fly Mode Settings & Customization
            item {
                var flyMenuExpanded by remember { mutableStateOf(false) }
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, VrCyan.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(strings.flyModeTitle, style = MaterialTheme.typography.titleMedium, color = VrCyan)
                        Text(
                            text = strings.flyControlsHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.flyToggleBtnLabel, style = MaterialTheme.typography.labelLarge)
                            Box {
                                OutlinedButton(
                                    onClick = { flyMenuExpanded = true },
                                    modifier = Modifier.testTag("fly_toggle_dropdown")
                                ) {
                                    Text(flyToggleLabel(controls.flyToggleButton, language), style = MaterialTheme.typography.bodySmall)
                                }
                                DropdownMenu(expanded = flyMenuExpanded, onDismissRequest = { flyMenuExpanded = false }) {
                                    FlyToggleButton.entries.forEach { btn ->
                                        DropdownMenuItem(
                                            text = { Text(flyToggleLabel(btn, language)) },
                                            onClick = {
                                                flyMenuExpanded = false
                                                onUpdateControls { it.copy(flyToggleButton = btn) }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Text(strings.flySpeedLabel, style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FlySpeed.entries.forEach { sp ->
                                val label = when (sp) {
                                    FlySpeed.SLOW -> if (language == AppLanguage.ARABIC) "بطيء (${sp.metersPerSec}m/s)" else "Slow (${sp.metersPerSec}m/s)"
                                    FlySpeed.NORMAL -> if (language == AppLanguage.ARABIC) "عادي (${sp.metersPerSec}m/s)" else "Normal (${sp.metersPerSec}m/s)"
                                    FlySpeed.FAST -> if (language == AppLanguage.ARABIC) "سريع (${sp.metersPerSec}m/s)" else "Fast (${sp.metersPerSec}m/s)"
                                }
                                FilterChip(
                                    selected = controls.defaultFlySpeed == sp,
                                    onClick = { onUpdateControls { it.copy(defaultFlySpeed = sp) } },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("fly_speed_${sp.name}")
                                )
                            }
                        }
                    }
                }
            }

            // 4. Camera Hand Tracking Tester, VR Box Occlusion Check & MediaPipe Model
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, VrAmber.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(strings.handTrackingSectionTitle, style = MaterialTheme.typography.titleMedium)

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = VrAmber)
                            Text(strings.handOcclusionWarningTitle, style = MaterialTheme.typography.titleSmall, color = VrAmber)
                        }
                        Text(strings.handOcclusionWarningBody, style = MaterialTheme.typography.bodySmall)

                        if (!handState.modelDownloaded) {
                            OutlinedButton(
                                onClick = { handTracker.downloadHandModel() },
                                modifier = Modifier.fillMaxWidth().testTag("download_hand_model_btn")
                            ) {
                                Icon(Icons.Filled.Download, contentDescription = null, tint = VrCyan)
                                Spacer(Modifier.width(8.dp))
                                Text(strings.handDownloadModelBtn)
                            }
                            handState.modelDownloadProgress?.let { prog ->
                                LinearProgressIndicator(
                                    progress = { prog },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        } else {
                            Text("✓ ${strings.handModelReady}", style = MaterialTheme.typography.labelMedium, color = VrEmerald)
                        }

                        SettingSwitchRow(
                            title = strings.handFrontCameraToggle,
                            checked = controls.handUseFrontCamera,
                            testTag = "hand_front_cam_switch",
                            onCheckedChange = { front ->
                                onUpdateControls { it.copy(handUseFrontCamera = front) }
                                isCameraTesting = false
                                handTracker.stopCameraTracking()
                            }
                        )

                        SettingSliderRow(
                            title = strings.handSensitivityTitle,
                            valueText = "${(controls.handTrackingSensitivity * 100).toInt()}%",
                            value = controls.handTrackingSensitivity,
                            range = 0.35f..1.0f,
                            onValueChange = { v -> onUpdateControls { it.copy(handTrackingSensitivity = v) } }
                        )

                        SettingSliderRow(
                            title = strings.handCalibrateBtn,
                            valueText = String.format("%.2fx", controls.handCalibrationScale),
                            value = controls.handCalibrationScale,
                            range = 0.65f..1.5f,
                            onValueChange = { v -> onUpdateControls { it.copy(handCalibrationScale = v) } }
                        )

                        if (!hasPermission) {
                            Button(
                                onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                modifier = Modifier.fillMaxWidth().testTag("camera_perm_btn")
                            ) {
                                Icon(Icons.Filled.CameraAlt, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(strings.handCameraPermissionBtn)
                            }
                        } else {
                            Button(
                                onClick = {
                                    if (isCameraTesting) {
                                        isCameraTesting = false
                                        handTracker.stopCameraTracking()
                                    } else {
                                        isCameraTesting = true
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().testTag("test_hand_tracking_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCameraTesting) VrCoral else VrCyan,
                                    contentColor = if (isCameraTesting) Color.White else VrObsidian
                                )
                            ) {
                                Icon(Icons.Filled.PanTool, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (isCameraTesting) strings.handStopCameraBtn else strings.handTestCameraBtn)
                            }
                        }

                        if (isCameraTesting && hasPermission) {
                            val previewView = remember(controls.handUseFrontCamera) { PreviewView(context) }
                            DisposableEffect(controls.handUseFrontCamera, isCameraTesting) {
                                handTracker.startCameraTracking(
                                    lifecycleOwner = lifecycleOwner,
                                    useFrontCamera = controls.handUseFrontCamera,
                                    previewView = previewView
                                )
                                onDispose {
                                    handTracker.stopCameraTracking()
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color.Black)
                            ) {
                                AndroidView(
                                    factory = { previewView },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            val statusColor = when (handState.health) {
                                HandTrackingHealth.TRACKING_ACTIVE -> VrEmerald
                                HandTrackingHealth.VR_BOX_OCCLUDED -> VrCoral
                                else -> VrAmber
                            }
                            Text(
                                text = if (language == AppLanguage.ARABIC) handState.statusNoteAr else handState.statusNoteEn,
                                style = MaterialTheme.typography.bodySmall,
                                color = statusColor
                            )
                            if (handState.health == HandTrackingHealth.VR_BOX_OCCLUDED) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        onUpdateControls { it.copy(activeScheme = ControlScheme.GAZE) }
                                    }) {
                                        Text(strings.switchToGaze)
                                    }
                                    OutlinedButton(onClick = {
                                        onUpdateControls { it.copy(activeScheme = ControlScheme.XBOX_CONTROLLER) }
                                    }) {
                                        Text(strings.switchToXbox)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SchemeOptionCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) VrCyan else MaterialTheme.colorScheme.outline
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) VrCyan.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = if (selected) VrCyan else MaterialTheme.colorScheme.onSurfaceVariant)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun XboxRemapRow(
    buttonName: String,
    currentAction: XboxAction,
    language: AppLanguage,
    onSelect: (XboxAction) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Button $buttonName", style = MaterialTheme.typography.labelLarge, color = VrAmber)
        Box {
            OutlinedButton(onClick = { expanded = true }) {
                Text(actionLabel(currentAction, language), style = MaterialTheme.typography.bodySmall)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                XboxAction.entries.forEach { act ->
                    DropdownMenuItem(
                        text = { Text(actionLabel(act, language)) },
                        onClick = {
                            expanded = false
                            onSelect(act)
                        }
                    )
                }
            }
        }
    }
}

private fun actionLabel(action: XboxAction, lang: AppLanguage): String = when (action) {
    XboxAction.INTERACT_GRAB -> if (lang == AppLanguage.ARABIC) "إمساك / تفاعل" else "Grab / Interact"
    XboxAction.CANCEL_BACK -> if (lang == AppLanguage.ARABIC) "إلغاء / رجوع" else "Cancel / Back"
    XboxAction.USE_INSPECT -> if (lang == AppLanguage.ARABIC) "فحص / وضع بالعربة" else "Inspect / Add to Cart"
    XboxAction.INVENTORY_LIST -> if (lang == AppLanguage.ARABIC) "قائمة المشتريات" else "Shopping List"
    XboxAction.CART_HOLD_PUSH -> if (lang == AppLanguage.ARABIC) "إمساك العربة" else "Hold / Push Cart"
    XboxAction.SPRINT_CROUCH -> if (lang == AppLanguage.ARABIC) "جلوس / ركض" else "Crouch / Sprint"
}

private fun flyToggleLabel(btn: FlyToggleButton, lang: AppLanguage): String = when (btn) {
    FlyToggleButton.DOUBLE_A_CROSS -> if (lang == AppLanguage.ARABIC) "ضغطتين A / Cross" else "Double-Press A / Cross"
    FlyToggleButton.DOUBLE_Y_TRIANGLE -> if (lang == AppLanguage.ARABIC) "ضغطتين Y / Triangle" else "Double-Press Y / Triangle"
    FlyToggleButton.LB_L1 -> if (lang == AppLanguage.ARABIC) "زر LB / L1" else "LB / L1 Button"
    FlyToggleButton.RB_R1 -> if (lang == AppLanguage.ARABIC) "زر RB / R1" else "RB / R1 Button"
}
