package com.example.ui.screens

import android.net.Uri
import android.opengl.GLSurfaceView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.VrAmber
import com.example.ui.theme.VrCoral
import com.example.ui.theme.VrCyan
import com.example.ui.theme.VrEmerald
import com.example.ui.theme.VrObsidian
import com.example.vr.engine.EditorCameraState
import com.example.vr.engine.VrRenderer
import com.example.vr.input.XboxControllerManager
import com.example.vr.model.AppLanguage
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.WorldEntry
import com.example.vr.world.EditorTransformTool
import com.example.vr.world.WorldEditorManager
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WorldEditorScreen(
    worldId: String,
    initialTab: String,
    worldEntry: WorldEntry?,
    language: AppLanguage,
    strings: AppStrings,
    renderer: VrRenderer,
    editorManager: WorldEditorManager,
    xboxManager: XboxControllerManager,
    onPrepareWorld: (String) -> Unit,
    onSaveProject: () -> Unit,
    onPlayFromEditor: (SpawnPointEntry?) -> Unit,
    onDuplicateWorld: (WorldEntry, (String) -> Unit) -> Unit,
    onRestoreOriginal: (String) -> Unit,
    onImportAdditionalModel: (Uri) -> Unit,
    onPickTextureForMaterial: (PbrMaterialSpec, Uri) -> Unit,
    onExportZip: (Uri, (Boolean) -> Unit) -> Unit,
    onNavigateToWorld: (String) -> Unit,
    onBack: () -> Unit
) {
    val editorState by editorManager.state.collectAsStateWithLifecycle()
    val xbox by xboxManager.snapshot.collectAsStateWithLifecycle()

    var selectedTab by remember(initialTab) {
        mutableIntStateOf(
            when (initialTab) {
                "hierarchy" -> 1
                "spawn" -> 2
                "materials" -> 3
                "lighting" -> 4
                "project" -> 5
                else -> 0
            }
        )
    }
    var dragEditsObject by remember { mutableStateOf(false) }
    var feedbackNotice by remember { mutableStateOf<String?>(null) }

    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onImportAdditionalModel(uri)
    }

    val zipExporter = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            onExportZip(uri) { ok ->
                feedbackNotice = if (ok) {
                    if (language == AppLanguage.ARABIC) "تم تصدير العالم بنجاح" else "World exported as ZIP!"
                } else {
                    if (language == AppLanguage.ARABIC) "فشل تصدير العالم" else "ZIP export failed"
                }
            }
        }
    }

    BackHandler {
        onSaveProject()
        renderer.editorMode = false
        onBack()
    }

    LaunchedEffect(worldId) {
        renderer.editorMode = true
        onPrepareWorld(worldId)
    }

    DisposableEffect(Unit) {
        onDispose {
            renderer.editorMode = false
        }
    }

    // Allow Xbox/PlayStation gamepad sticks in World Editor to move/rotate selected object or orbit camera
    LaunchedEffect(xbox.leftX, xbox.leftY, xbox.rightX, xbox.rightY, editorState.activeTool, editorState.activeAxis) {
        while (kotlin.math.abs(xbox.leftX) > 0.1f || kotlin.math.abs(xbox.leftY) > 0.1f || kotlin.math.abs(xbox.rightX) > 0.1f) {
            when (editorState.activeTool) {
                EditorTransformTool.MOVE -> editorManager.applyTransformDelta(
                    dx = xbox.leftX * 0.25f,
                    dy = if (editorState.activeAxis == 1) -xbox.leftY * 0.25f else 0f,
                    dz = if (editorState.activeAxis != 1) xbox.leftY * 0.25f else 0f,
                    recordUndo = false
                )
                EditorTransformTool.ROTATE -> editorManager.applyTransformDelta(
                    dRotY = xbox.leftX * 3.5f,
                    dRotX = xbox.leftY * 2.5f,
                    recordUndo = false
                )
                EditorTransformTool.SCALE -> editorManager.applyTransformDelta(
                    dScaleAll = -xbox.leftY * 0.04f,
                    recordUndo = false
                )
            }
            if (kotlin.math.abs(xbox.rightX) > 0.1f || kotlin.math.abs(xbox.rightY) > 0.1f) {
                val c = renderer.editorCamera
                renderer.editorCamera = c.copy(
                    yawDeg = (c.yawDeg - xbox.rightX * 2.8f) % 360f,
                    pitchDeg = (c.pitchDeg + xbox.rightY * 2.0f).coerceIn(5f, 82f)
                )
            }
            delay(33L)
        }
    }

    val project = editorState.project

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.worldEditorTitle,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            onSaveProject()
                            renderer.editorMode = false
                            onBack()
                        },
                        modifier = Modifier.testTag("editor_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { editorManager.undo() },
                        enabled = editorState.canUndo,
                        modifier = Modifier.testTag("editor_undo_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = strings.undoAction)
                    }
                    IconButton(
                        onClick = { editorManager.redo() },
                        enabled = editorState.canRedo,
                        modifier = Modifier.testTag("editor_redo_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = strings.redoAction)
                    }
                    IconButton(
                        onClick = {
                            onSaveProject()
                            feedbackNotice = if (language == AppLanguage.ARABIC) "تم حفظ تعديلات العالم ✓" else "World saved ✓"
                        },
                        modifier = Modifier.testTag("editor_save_btn")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = strings.save, tint = VrCyan)
                    }
                    Button(
                        onClick = { onPlayFromEditor(null) },
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .testTag("editor_play_vr_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = VrEmerald, contentColor = VrObsidian)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Play", style = MaterialTheme.typography.labelLarge)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            // 1. Live 3D Editor Viewport (Orbit + Direct Finger Drag Transform + XYZ Gizmo + Spawn Markers)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.46f)
                    .background(Color.Black)
            ) {
                AndroidView(
                    factory = { ctx ->
                        GLSurfaceView(ctx).apply {
                            setEGLContextClientVersion(3)
                            setRenderer(renderer)
                            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(dragEditsObject, editorState.activeTool, editorState.activeAxis) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                if (dragEditsObject) {
                                    applyScreenDragTransform(
                                        dxPx = dragAmount.x,
                                        dyPx = dragAmount.y,
                                        tool = editorState.activeTool,
                                        axis = editorState.activeAxis,
                                        editorManager = editorManager
                                    )
                                } else {
                                    val c = renderer.editorCamera
                                    renderer.editorCamera = c.copy(
                                        yawDeg = (c.yawDeg - dragAmount.x * 0.35f) % 360f,
                                        pitchDeg = (c.pitchDeg + dragAmount.y * 0.28f).coerceIn(5f, 84f)
                                    )
                                }
                            }
                        }
                )

                // Top-start Selection Pill + Whole World toggle
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = editorState.wholeWorldSelected,
                        onClick = { editorManager.selectWholeWorld() },
                        label = { Text(strings.wholeWorldTarget, style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = { Icon(Icons.Filled.Public, contentDescription = null, modifier = Modifier.size(14.dp)) },
                        modifier = Modifier.testTag("select_whole_world_chip")
                    )
                    FilterChip(
                        selected = dragEditsObject,
                        onClick = { dragEditsObject = !dragEditsObject },
                        label = {
                            Text(
                                text = if (dragEditsObject) {
                                    if (language == AppLanguage.ARABIC) "سحب: تحريك المجسم" else "Drag: Transform"
                                } else {
                                    if (language == AppLanguage.ARABIC) "سحب: تدوير الكاميرا" else "Drag: Orbit"
                                },
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        modifier = Modifier.testTag("drag_mode_toggle_chip")
                    )
                }

                // Top-end Zoom & Reset Camera buttons
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(color = VrObsidian.copy(alpha = 0.75f), shape = RoundedCornerShape(10.dp)) {
                        Row {
                            IconButton(
                                onClick = {
                                    val c = renderer.editorCamera
                                    renderer.editorCamera = c.copy(distance = (c.distance * 0.82f).coerceIn(3f, 95f))
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(Icons.Filled.ZoomIn, contentDescription = "Zoom In", tint = VrCyan)
                            }
                            IconButton(
                                onClick = {
                                    val c = renderer.editorCamera
                                    renderer.editorCamera = c.copy(distance = (c.distance * 1.22f).coerceIn(3f, 95f))
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(Icons.Filled.ZoomOut, contentDescription = "Zoom Out", tint = VrCyan)
                            }
                            IconButton(
                                onClick = { renderer.editorCamera = EditorCameraState() },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(Icons.Filled.CenterFocusStrong, contentDescription = "Reset Camera", tint = VrEmerald)
                            }
                        }
                    }
                }

                // Bottom-start active feedback banner
                val banner = feedbackNotice ?: if (language == AppLanguage.ARABIC) editorState.statusBannerAr else editorState.statusBannerEn
                if (!banner.isNullOrBlank()) {
                    Surface(
                        color = VrObsidian.copy(alpha = 0.86f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, VrEmerald),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(8.dp)
                    ) {
                        Text(banner, color = VrEmerald, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                }
            }

            // 2. Editor Tab Strip
            val tabs = listOf(
                if (language == AppLanguage.ARABIC) "التحكم والأدوات" else "Transform",
                "Hierarchy",
                "Spawn",
                "Materials",
                if (language == AppLanguage.ARABIC) "الإضاءة" else "Lighting",
                if (language == AppLanguage.ARABIC) "حفظ / تصدير" else "Save / Export"
            )
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = VrCyan,
                edgePadding = 8.dp
            ) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(title, maxLines = 1) }
                    )
                }
            }

            // 3. Active Panel Content
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.54f)
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (project == null) {
                    Text(
                        text = if (language == AppLanguage.ARABIC) "جاري تحميل بيانات العالم ثلاثي الأبعاد..." else "Loading 3D world project...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VrCyan
                    )
                } else {
                    when (selectedTab) {
                        0 -> TransformToolsPanel(
                            editorState = editorState,
                            editorManager = editorManager,
                            language = language,
                            strings = strings,
                            onImportModelClick = { modelPicker.launch(arrayOf("*/*")) },
                            onMutated = { onSaveProject() }
                        )
                        1 -> SceneHierarchyPanel(
                            editorState = editorState,
                            editorManager = editorManager,
                            language = language,
                            strings = strings,
                            onMutated = { onSaveProject() }
                        )
                        2 -> SpawnPointsPanel(
                            project = project,
                            editorState = editorState,
                            editorManager = editorManager,
                            strings = strings,
                            onTestSpawn = { sp -> onPlayFromEditor(sp) },
                            onMutated = { onSaveProject() }
                        )
                        3 -> MaterialInspectorPanel(
                            project = project,
                            editorManager = editorManager,
                            language = language,
                            strings = strings,
                            onPickTextureForMaterial = onPickTextureForMaterial,
                            onMutated = { onSaveProject() }
                        )
                        4 -> LightingSettingsPanel(
                            project = project,
                            editorManager = editorManager,
                            strings = strings,
                            onMutated = { onSaveProject() }
                        )
                        else -> ProjectActionsPanel(
                            worldId = worldId,
                            worldEntry = worldEntry,
                            language = language,
                            strings = strings,
                            onSave = {
                                onSaveProject()
                                feedbackNotice = if (language == AppLanguage.ARABIC) "تم حفظ التعديلات بنجاح" else "Saved successfully"
                            },
                            onDuplicate = {
                                if (worldEntry != null) {
                                    onDuplicateWorld(worldEntry) { newId -> onNavigateToWorld(newId) }
                                }
                            },
                            onRestoreOriginal = {
                                onRestoreOriginal(worldId)
                                feedbackNotice = strings.restoreOriginalWorld
                            },
                            onExportZip = {
                                val safeName = (project.titleEn.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "world" }) + "_edited.zip"
                                zipExporter.launch(safeName)
                            },
                            onImportModelClick = { modelPicker.launch(arrayOf("*/*")) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TransformToolsPanel(
    editorState: com.example.vr.world.WorldEditorUiState,
    editorManager: WorldEditorManager,
    language: AppLanguage,
    strings: AppStrings,
    onImportModelClick: () -> Unit,
    onMutated: () -> Unit
) {
    val activeTool = editorState.activeTool
    val activeAxis = editorState.activeAxis

    Text(
        text = when {
            editorState.wholeWorldSelected -> "${strings.wholeWorldTarget} (${if (language == AppLanguage.ARABIC) "تحريك العالم كوحدة واحدة" else "Moving entire world"})"
            editorState.selectedSpawnId != null -> "Spawn Point: ${editorState.project?.spawnPoints?.find { it.id == editorState.selectedSpawnId }?.name ?: ""}"
            else -> editorState.project?.nodes?.find { it.id == editorState.selectedNodeId }?.name ?: strings.wholeWorldTarget
        },
        style = MaterialTheme.typography.titleSmall,
        color = VrCyan
    )

    // Tool selector: Move / Rotate / Scale
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = activeTool == EditorTransformTool.MOVE,
            onClick = { editorManager.setTool(EditorTransformTool.MOVE) },
            label = { Text(strings.toolMove) },
            modifier = Modifier.testTag("tool_move_chip")
        )
        FilterChip(
            selected = activeTool == EditorTransformTool.ROTATE,
            onClick = { editorManager.setTool(EditorTransformTool.ROTATE) },
            label = { Text(strings.toolRotate) },
            modifier = Modifier.testTag("tool_rotate_chip")
        )
        FilterChip(
            selected = activeTool == EditorTransformTool.SCALE,
            onClick = { editorManager.setTool(EditorTransformTool.SCALE) },
            label = { Text(strings.toolScale) },
            modifier = Modifier.testTag("tool_scale_chip")
        )
    }

    // XYZ Axis selector
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(-1 to "Free", 0 to "Axis X", 1 to "Axis Y", 2 to "Axis Z").forEach { (axisId, label) ->
            FilterChip(
                selected = activeAxis == axisId,
                onClick = { editorManager.setAxis(axisId) },
                label = { Text(label) },
                modifier = Modifier.testTag("axis_chip_$axisId")
            )
        }
    }

    // Step nudge buttons (- / +)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { applyStep(editorManager, activeTool, activeAxis, -1f); onMutated() },
            modifier = Modifier.weight(1f).height(48.dp).testTag("transform_minus_btn")
        ) {
            Text(if (activeTool == EditorTransformTool.ROTATE) "-15°" else if (activeTool == EditorTransformTool.SCALE) "-10%" else "-0.5m")
        }
        OutlinedButton(
            onClick = { applyStep(editorManager, activeTool, activeAxis, +1f); onMutated() },
            modifier = Modifier.weight(1f).height(48.dp).testTag("transform_plus_btn")
        ) {
            Text(if (activeTool == EditorTransformTool.ROTATE) "+15°" else if (activeTool == EditorTransformTool.SCALE) "+10%" else "+0.5m")
        }
    }

    // Quick 90 / 180 / 360 rotate buttons
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        listOf(90f, 180f, 360f).forEach { deg ->
            OutlinedButton(
                onClick = { editorManager.rotateQuick(deg); onMutated() },
                modifier = Modifier.weight(1f)
            ) {
                Text("${deg.toInt()}°")
            }
        }
    }

    // Reset / Duplicate / Delete row
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { editorManager.resetSelectedTransform(); onMutated() },
            modifier = Modifier.weight(1f).testTag("editor_reset_transform_btn")
        ) {
            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.resetTransform, maxLines = 1)
        }
        OutlinedButton(
            onClick = { editorManager.duplicateSelectedNode(); onMutated() },
            enabled = editorState.selectedNodeId != null,
            modifier = Modifier.weight(1f).testTag("editor_duplicate_node_btn")
        ) {
            Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.duplicateAction, maxLines = 1)
        }
        OutlinedButton(
            onClick = { editorManager.deleteSelected(); onMutated() },
            enabled = editorState.selectedNodeId != null || editorState.selectedSpawnId != null,
            modifier = Modifier.weight(1f).testTag("editor_delete_node_btn"),
            border = BorderStroke(1.dp, VrCoral.copy(alpha = 0.6f))
        ) {
            Icon(Icons.Filled.Delete, contentDescription = null, tint = VrCoral, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.delete, color = VrCoral, maxLines = 1)
        }
    }

    // Import additional 3D model button
    Button(
        onClick = onImportModelClick,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("editor_import_model_btn"),
        colors = ButtonDefaults.buttonColors(containerColor = VrCyan, contentColor = VrObsidian)
    ) {
        Icon(Icons.Filled.AddBox, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(strings.importModelBtn)
    }
}

@Composable
private fun ProjectActionsPanel(
    worldId: String,
    worldEntry: WorldEntry?,
    language: AppLanguage,
    strings: AppStrings,
    onSave: () -> Unit,
    onDuplicate: () -> Unit,
    onRestoreOriginal: () -> Unit,
    onExportZip: () -> Unit,
    onImportModelClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = onSave,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = VrCyan, contentColor = VrObsidian)
        ) {
            Icon(Icons.Filled.Save, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(strings.saveWorldAction)
        }
        OutlinedButton(
            onClick = onImportModelClick,
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Icon(Icons.Filled.AddBox, contentDescription = null, tint = VrCyan)
            Spacer(Modifier.width(8.dp))
            Text(strings.importModelBtn)
        }
        if (worldEntry != null && worldEntry.isCustomImported) {
            OutlinedButton(
                onClick = onDuplicate,
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("editor_save_as_copy_btn")
            ) {
                Icon(Icons.Filled.FileCopy, contentDescription = null, tint = VrEmerald)
                Spacer(Modifier.width(8.dp))
                Text(strings.duplicateWorldCopy)
            }
        }
        OutlinedButton(
            onClick = onExportZip,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("editor_export_zip_btn")
        ) {
            Icon(Icons.Filled.Archive, contentDescription = null, tint = VrAmber)
            Spacer(Modifier.width(8.dp))
            Text(strings.exportZipWorld)
        }
        OutlinedButton(
            onClick = onRestoreOriginal,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("editor_restore_original_btn"),
            border = BorderStroke(1.dp, VrCoral.copy(alpha = 0.65f))
        ) {
            Icon(Icons.Filled.Restore, contentDescription = null, tint = VrCoral)
            Spacer(Modifier.width(8.dp))
            Text(strings.restoreOriginalWorld, color = VrCoral)
        }
        Text(
            text = if (language == AppLanguage.ARABIC) {
                "معرّف المشروع: $worldId"
            } else {
                "Project ID: $worldId"
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun applyStep(
    editorManager: WorldEditorManager,
    tool: EditorTransformTool,
    axis: Int,
    dir: Float
) {
    when (tool) {
        EditorTransformTool.MOVE -> {
            val step = 0.5f * dir
            when (axis) {
                0 -> editorManager.applyTransformDelta(dx = step)
                1 -> editorManager.applyTransformDelta(dy = step)
                2 -> editorManager.applyTransformDelta(dz = step)
                else -> editorManager.applyTransformDelta(dx = step, dz = step)
            }
        }
        EditorTransformTool.ROTATE -> {
            val stepDeg = 15f * dir
            when (axis) {
                0 -> editorManager.applyTransformDelta(dRotX = stepDeg)
                2 -> editorManager.applyTransformDelta(dRotZ = stepDeg)
                else -> editorManager.applyTransformDelta(dRotY = stepDeg)
            }
        }
        EditorTransformTool.SCALE -> {
            editorManager.applyTransformDelta(dScaleAll = 0.1f * dir)
        }
    }
}

private fun applyScreenDragTransform(
    dxPx: Float,
    dyPx: Float,
    tool: EditorTransformTool,
    axis: Int,
    editorManager: WorldEditorManager
) {
    when (tool) {
        EditorTransformTool.MOVE -> {
            val sx = dxPx * 0.022f
            val sy = -dyPx * 0.022f
            when (axis) {
                0 -> editorManager.applyTransformDelta(dx = sx, recordUndo = false)
                1 -> editorManager.applyTransformDelta(dy = sy, recordUndo = false)
                2 -> editorManager.applyTransformDelta(dz = -sy, recordUndo = false)
                else -> editorManager.applyTransformDelta(dx = sx, dz = -sy, recordUndo = false)
            }
        }
        EditorTransformTool.ROTATE -> {
            when (axis) {
                0 -> editorManager.applyTransformDelta(dRotX = dyPx * 0.35f, recordUndo = false)
                2 -> editorManager.applyTransformDelta(dRotZ = dxPx * 0.35f, recordUndo = false)
                else -> editorManager.applyTransformDelta(dRotY = dxPx * 0.45f, recordUndo = false)
            }
        }
        EditorTransformTool.SCALE -> {
            editorManager.applyTransformDelta(dScaleAll = (-dyPx + dxPx) * 0.004f, recordUndo = false)
        }
    }
}
