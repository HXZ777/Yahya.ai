package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.remote.RunnerHealthResult
import com.example.domain.model.BuildEngineMode
import com.example.domain.model.BuildEngineSettings
import com.example.domain.model.DeviceToolchainProbe
import com.example.domain.util.Formatters
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceHighlight
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildEngineSheet(
    settings: BuildEngineSettings,
    deviceProbe: DeviceToolchainProbe?,
    runnerHealth: RunnerHealthResult?,
    isTestingRunner: Boolean,
    tempStorageBytes: Long,
    onUpdateSettings: ((BuildEngineSettings) -> BuildEngineSettings) -> Unit,
    onTestRunner: () -> Unit,
    onCleanCache: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    var copiedScriptBanner by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianSurface,
        contentColor = TextPrimary,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "محرك البناء وأدوات SDK",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                EngineModeCard(
                    title = "على الجهاز",
                    subtitle = "فحص بيئة الهاتف",
                    icon = Icons.Filled.PhoneAndroid,
                    selected = settings.mode == BuildEngineMode.LOCAL_DEVICE,
                    onClick = { onUpdateSettings { it.copy(mode = BuildEngineMode.LOCAL_DEVICE) } },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_local_button"),
                )
                EngineModeCard(
                    title = "خادم Gradle",
                    subtitle = "بناء حقيقي وتنزيل المكتبات",
                    icon = Icons.Filled.CloudUpload,
                    selected = settings.mode == BuildEngineMode.REMOTE_RUNNER,
                    onClick = { onUpdateSettings { it.copy(mode = BuildEngineMode.REMOTE_RUNNER) } },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_remote_button"),
                )
            }

            if (deviceProbe != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, ObsidianOutline),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "حالة أدوات البناء على الهاتف",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                            )
                            StatusBadgePill(
                                text = if (deviceProbe.localToolchainReady) "جاهز" else "غير متوفر",
                                accentColor = if (deviceProbe.localToolchainReady) EmeraldBright else AmberWarning,
                                containerColor = if (deviceProbe.localToolchainReady) EmeraldContainer else AmberContainer,
                            )
                        }
                        Text(
                            text = "المعمارية: ${deviceProbe.deviceAbi} • أندرويد API ${deviceProbe.androidSdkInt} • المتاح: ${Formatters.formatBytes(deviceProbe.freeSpaceBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                        )
                        if (!deviceProbe.localToolchainReady) {
                            Text(
                                text = "لا تتوفر أدوات Android SDK وJDK وGradle على هواتف أندرويد بشكل افتراضي. لبناء أي مشروع وتحميل مكتباته وإنتاج APK موقّع، استخدم خادم Gradle على جهاز الكمبيوتر أو Termux.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                        }
                    }
                }
            }

            if (settings.mode == BuildEngineMode.REMOTE_RUNNER) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f)),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = "إعدادات خادم Gradle الخاص بك",
                            style = MaterialTheme.typography.titleSmall,
                            color = EmeraldBright,
                        )

                        OutlinedTextField(
                            value = settings.remoteRunnerUrl,
                            onValueChange = { url ->
                                onUpdateSettings { it.copy(remoteRunnerUrl = url) }
                            },
                            label = { Text("رابط الخادم (URL)") },
                            placeholder = { Text("http://192.168.1.25:8787") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("runner_url_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = ObsidianOutline,
                                focusedLabelColor = EmeraldBright,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                            ),
                        )

                        OutlinedTextField(
                            value = settings.remoteAuthToken,
                            onValueChange = { token ->
                                onUpdateSettings { it.copy(remoteAuthToken = token) }
                            },
                            label = { Text("رمز الحماية (اختياري)") },
                            placeholder = { Text("Bearer Token") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = ObsidianOutline,
                                focusedLabelColor = EmeraldBright,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                            ),
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "نوع النسخة:",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                            listOf("debug" to "تجريبية (Debug)", "release" to "نهائية (Release)").forEach { (variant, label) ->
                                FilterChip(
                                    selected = settings.buildVariant == variant,
                                    onClick = { onUpdateSettings { it.copy(buildVariant = variant) } },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldContainer,
                                        selectedLabelColor = EmeraldBright,
                                    ),
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الموافقة على رفع المشروع",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextPrimary,
                                )
                                Text(
                                    text = "إرسال ملف ZIP إلى العنوان المحدد أعلاه فقط.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted,
                                )
                            }
                            Switch(
                                checked = settings.uploadConsentGranted,
                                onCheckedChange = { granted ->
                                    onUpdateSettings { it.copy(uploadConsentGranted = granted) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = OnEmerald,
                                    checkedTrackColor = EmeraldPrimary,
                                ),
                                modifier = Modifier.testTag("upload_consent_switch"),
                            )
                        }

                        OutlinedButton(
                            onClick = onTestRunner,
                            enabled = settings.remoteRunnerUrl.isNotBlank() && !isTestingRunner,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_runner_button"),
                            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.6f)),
                        ) {
                            if (isTestingRunner) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = EmeraldBright,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("جاري فحص الاتصال...", color = EmeraldBright)
                            } else {
                                Text("اختبار الاتصال بالخادم", color = EmeraldBright)
                            }
                        }

                        if (runnerHealth != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (runnerHealth.reachable) EmeraldContainer else ErrorContainer,
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        imageVector = if (runnerHealth.reachable) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                                        contentDescription = null,
                                        tint = if (runnerHealth.reachable) EmeraldBright else ErrorRed,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    Text(
                                        text = buildString {
                                            append(runnerHealth.message)
                                            runnerHealth.gradleVersion?.let { append(" • Gradle $it") }
                                            runnerHealth.sdkPlatform?.let { append(" • $it") }
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (runnerHealth.reachable) EmeraldBright else ErrorRed,
                                    )
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ObsidianSurfaceHighlight.copy(alpha = 0.6f),
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        imageVector = Icons.Filled.Info,
                                        contentDescription = null,
                                        tint = TextSecondary,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Text(
                                        text = "يقوم هذا السكربت بتحميل جميع مكتبات المشروع تلقائيًا عبر Gradle وبناء ملف APK موقّع وجاهز للتثبيت.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(SELF_HOSTED_RUNNER_PYTHON_SCRIPT))
                                        copiedScriptBanner = true
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("copy_runner_script_button"),
                                    border = BorderStroke(1.dp, ObsidianOutline),
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = null,
                                        tint = EmeraldBright,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (copiedScriptBanner) "تم نسخ سكربت runner.py!" else "نسخ سكربت خادم البناء (runner.py)",
                                        color = EmeraldBright,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            TempCacheBar(
                tempBytes = tempStorageBytes,
                onCleanCache = onCleanCache,
            )

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = OnEmerald,
                ),
            ) {
                Text("حفظ وإغلاق")
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun EngineModeCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) EmeraldContainer.copy(alpha = 0.8f) else ObsidianSurfaceElevated,
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) EmeraldPrimary else ObsidianOutline,
        ),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) EmeraldBright else TextSecondary,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) EmeraldBright else TextPrimary,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
        }
    }
}

@Composable
fun UploadConsentDialog(
    runnerUrl: String,
    zipName: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianSurfaceElevated,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = { Text(stringResource(R.string.upload_consent_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.upload_consent_message))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ObsidianSurfaceHighlight,
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = "الأرشيف: $zipName",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                        )
                        Text(
                            text = "الوجهة: ${runnerUrl.ifBlank { "(غير محدد)" }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldBright,
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = OnEmerald,
                ),
                modifier = Modifier.testTag("confirm_upload_consent_button"),
            ) {
                Text("موافقة وبناء")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondary)
            }
        },
    )
}

private const val SELF_HOSTED_RUNNER_PYTHON_SCRIPT = """# Save as runner.py on a PC/Mac/Linux with JDK + Android SDK installed, then run:
#   python3 runner.py
import email.parser, json, os, subprocess, tempfile, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = 8787

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT") or "Detected"
            body = json.dumps({"status": "الخادم جاهز", "androidSdk": sdk}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path != "/build":
            self.send_error(404); return
        length = int(self.headers.get("Content-Length", "0"))
        raw = b"Content-Type: " + self.headers.get("Content-Type", "").encode() + b"\r\n\r\n" + self.rfile.read(length)
        msg = email.parser.BytesParser().parsebytes(raw)
        variant, zip_bytes = "debug", None
        for part in msg.get_payload():
            name = part.get_param("name", header="content-disposition")
            if name == "variant": variant = part.get_payload(decode=True).decode().strip()
            elif name == "project": zip_bytes = part.get_payload(decode=True)
        if not zip_bytes:
            self.send_error(400, "Missing project zip"); return
        with tempfile.TemporaryDirectory() as tmp:
            zpath = Path(tmp) / "project.zip"
            zpath.write_bytes(zip_bytes)
            src = Path(tmp) / "src"
            with zipfile.ZipFile(zpath) as zf: zf.extractall(src)
            root = next((p.parent for p in src.rglob("settings.gradle*")), src)
            task = "assembleRelease" if variant.lower() == "release" else "assembleDebug"
            cmd = ["./gradlew" if (root / "gradlew").exists() else "gradle", task, "--refresh-dependencies", "--no-daemon"]
            if (root / "gradlew").exists(): os.chmod(root / "gradlew", 0o755)
            proc = subprocess.run(cmd, cwd=root, capture_output=True, text=True)
            apks = sorted(root.rglob("*.apk"), key=lambda p: ("unsigned" in p.name.lower(), p.name))
            apk = apks[0] if apks else None
            if proc.returncode != 0 or not apk:
                err = json.dumps({"error": "Gradle failed", "logs": (proc.stdout + "\n" + proc.stderr).splitlines()[-40:]}).encode()
                self.send_response(500); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(err); return
            data = apk.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
"""
