package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.remote.RunnerHealthResult
import com.example.domain.model.BuildEngineMode
import com.example.domain.model.BuildEngineSettings
import com.example.domain.model.DeviceToolchainProbe
import com.example.domain.util.Formatters
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceHighlight
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildEngineSheet(
    settings: BuildEngineSettings,
    deviceProbe: DeviceToolchainProbe?,
    runnerHealth: RunnerHealthResult?,
    isTestingRunner: Boolean,
    tempStorageBytes: Long,
    onUpdateSettings: ((BuildEngineSettings) -> BuildEngineSettings) -> Unit,
    onTestRunner: () -> Unit,
    onCleanCache: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianSurface,
        contentColor = TextPrimary,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "Build Engine & Toolchain",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
            )

            // Mode selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                EngineModeCard(
                    title = "On-Device",
                    subtitle = "Local SDK Probe",
                    icon = Icons.Filled.PhoneAndroid,
                    selected = settings.mode == BuildEngineMode.LOCAL_DEVICE,
                    onClick = { onUpdateSettings { it.copy(mode = BuildEngineMode.LOCAL_DEVICE) } },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_local_button"),
                )
                EngineModeCard(
                    title = "Gradle Runner",
                    subtitle = "Self-Hosted LAN/HTTPS",
                    icon = Icons.Filled.CloudUpload,
                    selected = settings.mode == BuildEngineMode.REMOTE_RUNNER,
                    onClick = { onUpdateSettings { it.copy(mode = BuildEngineMode.REMOTE_RUNNER) } },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_remote_button"),
                )
            }

            // Device Probe Diagnostic Card
            if (deviceProbe != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, ObsidianOutline),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Device Toolchain Status",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                            )
                            StatusBadgePill(
                                text = if (deviceProbe.localToolchainReady) "SDK Ready" else "SDK Missing",
                                accentColor = if (deviceProbe.localToolchainReady) EmeraldBright else AmberWarning,
                                containerColor = if (deviceProbe.localToolchainReady) EmeraldContainer else AmberContainer,
                            )
                        }
                        Text(
                            text = "ABI: ${deviceProbe.deviceAbi} • Android API ${deviceProbe.androidSdkInt} • Free: ${Formatters.formatBytes(deviceProbe.freeSpaceBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                        )
                        if (!deviceProbe.localToolchainReady) {
                            Text(
                                text = "Standard Android phones do not include JDK (javac/kotlinc), Gradle CLI, android.jar, aapt2, or d8. To compile source ZIPs into real signed APKs, connect a Self-Hosted Gradle Runner on your PC/server.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                        }
                    }
                }
            }

            // Remote Runner Configuration
            if (settings.mode == BuildEngineMode.REMOTE_RUNNER) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f)),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = "Self-Hosted Gradle Build Runner",
                            style = MaterialTheme.typography.titleSmall,
                            color = EmeraldBright,
                        )

                        OutlinedTextField(
                            value = settings.remoteRunnerUrl,
                            onValueChange = { url ->
                                onUpdateSettings { it.copy(remoteRunnerUrl = url) }
                            },
                            label = { Text("Runner Endpoint URL") },
                            placeholder = { Text("http://192.168.1.25:8787") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("runner_url_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = ObsidianOutline,
                                focusedLabelColor = EmeraldBright,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                            ),
                        )

                        OutlinedTextField(
                            value = settings.remoteAuthToken,
                            onValueChange = { token ->
                                onUpdateSettings { it.copy(remoteAuthToken = token) }
                            },
                            label = { Text("Bearer Token (Optional)") },
                            placeholder = { Text("Optional API secret") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = ObsidianOutline,
                                focusedLabelColor = EmeraldBright,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                            ),
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "Build Variant:",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                            listOf("debug", "release").forEach { variant ->
                                FilterChip(
                                    selected = settings.buildVariant == variant,
                                    onClick = { onUpdateSettings { it.copy(buildVariant = variant) } },
                                    label = { Text(variant.replaceFirstChar { it.uppercase() }) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldContainer,
                                        selectedLabelColor = EmeraldBright,
                                    ),
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Allow Project Upload",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextPrimary,
                                )
                                Text(
                                    text = "Explicit consent to send ZIP only to the URL above.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted,
                                )
                            }
                            Switch(
                                checked = settings.uploadConsentGranted,
                                onCheckedChange = { granted ->
                                    onUpdateSettings { it.copy(uploadConsentGranted = granted) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = OnEmerald,
                                    checkedTrackColor = EmeraldPrimary,
                                ),
                                modifier = Modifier.testTag("upload_consent_switch"),
                            )
                        }

                        OutlinedButton(
                            onClick = onTestRunner,
                            enabled = settings.remoteRunnerUrl.isNotBlank() && !isTestingRunner,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_runner_button"),
                            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.6f)),
                        ) {
                            if (isTestingRunner) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = EmeraldBright,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Testing /health...", color = EmeraldBright)
                            } else {
                                Text("Test Runner Connection (/health)", color = EmeraldBright)
                            }
                        }

                        if (runnerHealth != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (runnerHealth.reachable) EmeraldContainer else ErrorContainer,
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        imageVector = if (runnerHealth.reachable) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                                        contentDescription = null,
                                        tint = if (runnerHealth.reachable) EmeraldBright else ErrorRed,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    Text(
                                        text = buildString {
                                            append(runnerHealth.message)
                                            runnerHealth.gradleVersion?.let { append(" • Gradle $it") }
                                            runnerHealth.sdkPlatform?.let { append(" • $it") }
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (runnerHealth.reachable) EmeraldBright else ErrorRed,
                                    )
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ObsidianSurfaceHighlight.copy(alpha = 0.6f),
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Info,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Text(
                                    text = "Runner API Contract: GET /health -> {status, gradleVersion, androidSdk}. POST /build (multipart 'project' ZIP + 'variant') -> APK binary stream or {apkUrl, logs[]}.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                )
                            }
                        }
                    }
                }
            }

            TempCacheBar(
                tempBytes = tempStorageBytes,
                onCleanCache = onCleanCache,
            )

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = OnEmerald,
                ),
            ) {
                Text("Done")
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun EngineModeCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) EmeraldContainer.copy(alpha = 0.8f) else ObsidianSurfaceElevated,
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) EmeraldPrimary else ObsidianOutline,
        ),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) EmeraldBright else TextSecondary,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) EmeraldBright else TextPrimary,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
            )
        }
    }
}

@Composable
fun UploadConsentDialog(
    runnerUrl: String,
    zipName: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianSurfaceElevated,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = { Text(stringResource(R.string.upload_consent_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.upload_consent_message))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ObsidianSurfaceHighlight,
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = "Archive: $zipName",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                        )
                        Text(
                            text = "Target: ${runnerUrl.ifBlank { "(Not configured)" }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldBright,
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = OnEmerald,
                ),
                modifier = Modifier.testTag("confirm_upload_consent_button"),
            ) {
                Text("Approve & Build")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
    )
}
