package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.ApkResultInfo
import com.example.domain.util.Formatters
import com.example.ui.components.SpecMetricTile
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceHighlight
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ResultScreen(
    result: ApkResultInfo,
    contentPadding: PaddingValues,
    onBackToHome: () -> Unit,
    onSaveApkClick: (ApkResultInfo) -> Unit,
    onInstallApkApproved: (ApkResultInfo) -> Unit,
) {
    BackHandler(onBack = onBackToHome)

    var showInstallConsentDialog by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(contentPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                IconButton(
                    onClick = onBackToHome,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("result_back_button"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Home",
                        tint = TextPrimary,
                    )
                }
                Text(
                    text = "APK Output Ready",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary,
                )
            }

            // Verified APK Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("apk_result_card"),
                shape = RoundedCornerShape(22.dp),
                color = ObsidianSurface,
                border = BorderStroke(1.2.dp, EmeraldPrimary.copy(alpha = 0.55f)),
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(EmeraldContainer, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Android,
                                contentDescription = "Verified APK",
                                tint = EmeraldBright,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(3.dp),
                        ) {
                            Text(
                                text = result.appName,
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = result.packageName,
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldBright,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    StatusBadgePill(
                        text = result.sourceNote,
                        accentColor = EmeraldBright,
                        containerColor = EmeraldContainer.copy(alpha = 0.7f),
                        icon = Icons.Filled.CheckCircle,
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        SpecMetricTile(
                            label = "APK Size",
                            value = Formatters.formatBytes(result.sizeBytes),
                            highlight = true,
                            modifier = Modifier.weight(1f),
                        )
                        SpecMetricTile(
                            label = "Version",
                            value = "v${result.versionName} (${result.versionCode})",
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        SpecMetricTile(
                            label = "Min SDK",
                            value = result.minSdk?.let { "API $it" } ?: "Default",
                            modifier = Modifier.weight(1f),
                        )
                        SpecMetricTile(
                            label = "Target SDK",
                            value = result.targetSdk?.let { "API $it" } ?: "Default",
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ObsidianSurfaceHighlight.copy(alpha = 0.7f),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "SHA-256 CHECKSUM",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted,
                                )
                                Text(
                                    text = result.sha256,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(
                                onClick = { clipboard.setText(AnnotatedString(result.sha256)) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ContentCopy,
                                    contentDescription = "Copy SHA-256",
                                    tint = EmeraldBright,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }
                }
            }

            // Primary Export & Install Actions
            Button(
                onClick = { onSaveApkClick(result) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_apk_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = OnEmerald,
                ),
            ) {
                Icon(
                    imageVector = Icons.Filled.Download,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.action_save_apk),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                )
            }

            OutlinedButton(
                onClick = { showInstallConsentDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("install_apk_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.2.dp, EmeraldPrimary),
            ) {
                Icon(
                    imageVector = Icons.Filled.InstallMobile,
                    contentDescription = null,
                    tint = EmeraldBright,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.action_install_apk),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = EmeraldBright,
                )
            }

            TextButton(
                onClick = onBackToHome,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) {
                Text("Convert Another ZIP Project", color = TextSecondary)
            }
        }
    }

    if (showInstallConsentDialog) {
        AlertDialog(
            onDismissRequest = { showInstallConsentDialog = false },
            containerColor = ObsidianSurfaceElevated,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = { Text(stringResource(R.string.install_consent_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.install_consent_message))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = ObsidianSurfaceHighlight,
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text(
                                text = "App: ${result.appName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary,
                            )
                            Text(
                                text = "Package: ${result.packageName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldBright,
                            )
                            Text(
                                text = "Size: ${Formatters.formatBytes(result.sizeBytes)} • v${result.versionName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showInstallConsentDialog = false
                        onInstallApkApproved(result)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = OnEmerald,
                    ),
                    modifier = Modifier.testTag("confirm_install_apk_button"),
                ) {
                    Text("Approve & Install")
                }
            },
            dismissButton = {
                TextButton(onClick = { showInstallConsentDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
        )
    }
}
