package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.settings.GameSettingsRepository
import com.example.ui.i18n.stringsFor
import com.example.vr.bridge.MineVrAccessibilityService
import com.example.vr.camera.HeadTracker
import com.example.vr.capture.MinecraftIntegrationManager
import com.example.vr.capture.VrOverlayController
import com.example.vr.capture.VrProjectionService
import com.example.vr.engine.MineVrRenderer
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GameAction
import com.example.vr.model.MineVrSettingsState
import com.example.vr.model.MinecraftAppStatus
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import com.example.vr.shizuku.ShizukuVrManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MineVrViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameSettingsRepository(application)
    val headTracker = HeadTracker(application)
    val controllerManager = PlayStationControllerManager(application)
    val renderer = MineVrRenderer(application, headTracker, controllerManager)
    val overlayController = VrOverlayController(application, headTracker, controllerManager)
    val shizukuVrManager = ShizukuVrManager(application)

    val settingsState: StateFlow<MineVrSettingsState> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = MineVrSettingsState()
    )

    private val _minecraftStatus = MutableStateFlow(MinecraftIntegrationManager.inspectInstallation(application))
    val minecraftStatus: StateFlow<MinecraftAppStatus> = _minecraftStatus.asStateFlow()

    private val _isVrPaused = MutableStateFlow(false)
    val isVrPaused: StateFlow<Boolean> = _isVrPaused.asStateFlow()

    @Volatile
    private var wantShizukuSession: Boolean = false

    val projectionState = VrProjectionService.state
    val overlayActiveState = overlayController.isOverlayActive
    val shizukuState = shizukuVrManager.state
    val headState = headTracker.snapshot
    val controllerState = controllerManager.snapshot
    val accessibilityState = MineVrAccessibilityService.snapshot

    private val actionListener: (GameAction) -> Unit = { action ->
        when (action) {
            GameAction.RECENTER_HEAD -> recenterHead()
            GameAction.TOGGLE_VR_PAUSE -> toggleVrPaused()
            else -> Unit
        }
    }

    init {
        shizukuVrManager.initialize()
        controllerManager.startListening()
        controllerManager.addActionListener(actionListener)

        renderer.shizukuFrameListener = {
            shizukuVrManager.reportVirtualDisplayFrame()
        }
        renderer.externalSurfaceReadyListener = { surface, w, h ->
            if (wantShizukuSession &&
                settingsState.value.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY &&
                surface != null && surface.isValid
            ) {
                val pkg = _minecraftStatus.value.packageName
                    .ifBlank { MinecraftIntegrationManager.MINECRAFT_BEDROCK_PACKAGE }
                val dpi = getApplication<Application>().resources.displayMetrics.densityDpi
                shizukuVrManager.startVirtualDisplaySession(surface, w, h, dpi, pkg)
            }
        }

        headTracker.setDeltaListener { dYaw, dPitch ->
            val cfg = settingsState.value
            val vr = cfg.vr
            if (_isVrPaused.value) return@setDeltaListener

            if (cfg.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY &&
                shizukuVrManager.state.value.virtualDisplayId > 0
            ) {
                shizukuVrManager.submitHeadLookDelta(
                    deltaYawDeg = dYaw,
                    deltaPitchDeg = dPitch,
                    sensitivity = vr.accessibilityLookSensitivity,
                    invertY = vr.accessibilityInvertY,
                    enabled = vr.shizukuHeadLookEnabled
                )
            } else if (vr.accessibilityHeadLookEnabled) {
                MineVrAccessibilityService.instance?.submitHeadDelta(
                    deltaYawDeg = dYaw,
                    deltaPitchDeg = dPitch,
                    sensitivity = vr.accessibilityLookSensitivity,
                    invertY = vr.accessibilityInvertY,
                    enabled = true
                )
            }
        }

        viewModelScope.launch {
            settingsState.collect { cfg ->
                renderer.vrSettings = cfg.vr
                renderer.renderMode = cfg.preferredRenderMode
                overlayController.updateSettings(cfg.vr)
                headTracker.applyConfig(
                    horizonLock = cfg.vr.horizonLockEnabled,
                    headSensitivity = cfg.vr.headSensitivity,
                    headSmoothing = cfg.vr.headSmoothing,
                    savedZeroOffsetDeg = cfg.vr.zeroYawOffsetDeg
                )
                controllerManager.updateSettings(cfg.controls)
            }
        }
    }

    fun refreshDiagnostics() {
        _minecraftStatus.value = MinecraftIntegrationManager.inspectInstallation(getApplication())
        controllerManager.refreshConnectedDevices()
        MineVrAccessibilityService.refreshSystemEnabledState(getApplication())
        shizukuVrManager.refreshStatus()
    }

    fun toggleLanguage() {
        val current = settingsState.value
        val next = if (current.language == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        saveSettings(current.copy(language = next))
    }

    fun setRenderMode(mode: VrRenderMode) {
        val current = settingsState.value
        if (current.preferredRenderMode == VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY && mode != VrRenderMode.SHIZUKU_VIRTUAL_DISPLAY) {
            stopShizukuVrSession()
        }
        saveSettings(current.copy(preferredRenderMode = mode))
    }

    fun updateVrSettings(vr: VrSettingsState) {
        val current = settingsState.value
        saveSettings(current.copy(vr = vr))
    }

    fun updateControlsSettings(controls: ControlsSettingsState) {
        val current = settingsState.value
        saveSettings(current.copy(controls = controls))
    }

    fun resetVrDefaults() {
        val current = settingsState.value
        saveSettings(current.copy(vr = VrSettingsState()))
    }

    fun resetControlDefaults() {
        val current = settingsState.value
        saveSettings(current.copy(controls = ControlsSettingsState()))
    }

    fun calibrateHeadForward() {
        val zeroOffset = headTracker.calibrateZeroYaw()
        val current = settingsState.value
        saveSettings(current.copy(vr = current.vr.copy(zeroYawOffsetDeg = zeroOffset)))
    }

    fun recenterHead() {
        headTracker.resetToCenter()
    }

    fun toggleVrPaused() {
        setVrPaused(!_isVrPaused.value)
    }

    fun setVrPaused(paused: Boolean) {
        _isVrPaused.value = paused
        renderer.isPaused = paused
        if (paused) {
            shizukuVrManager.submitHeadLookDelta(0f, 0f, 1f, invertY = false, enabled = false)
        }
    }

    fun startSensors() {
        headTracker.start()
    }

    fun stopSensorsIfSessionInactive() {
        if (!overlayController.isOverlayActive.value &&
            !projectionState.value.isServiceRunning &&
            shizukuState.value.virtualDisplayId <= 0
        ) {
            headTracker.stop()
        }
    }

    fun launchMinecraft(splitScreen: Boolean = false): Boolean =
        MinecraftIntegrationManager.launchMinecraft(getApplication(), splitScreenAdjacent = splitScreen)

    fun requestShizukuPermission() {
        shizukuVrManager.requestPermission()
    }

    fun openShizukuApp() {
        shizukuVrManager.openShizukuApp()
    }

    fun startShizukuVrSession() {
        wantShizukuSession = true
        refreshDiagnostics()
        val mc = _minecraftStatus.value
        if (!mc.isInstalled) return

        val surface = renderer.getCaptureSurface()
        val (w, h) = renderer.getCaptureDimensions()
        val dpi = getApplication<Application>().resources.displayMetrics.densityDpi
        if (surface != null && surface.isValid) {
            shizukuVrManager.startVirtualDisplaySession(surface, w, h, dpi, mc.packageName)
        }
    }

    fun relaunchMinecraftOnVirtualDisplay() {
        val pkg = _minecraftStatus.value.packageName.ifBlank { MinecraftIntegrationManager.MINECRAFT_BEDROCK_PACKAGE }
        shizukuVrManager.relaunchTargetOnVirtualDisplay(pkg)
    }

    fun stopShizukuVrSession() {
        wantShizukuSession = false
        shizukuVrManager.stopVirtualDisplaySession()
        renderer.clearLiveCaptureFrame()
    }

    fun startMediaProjection(resultCode: Int, dataIntent: Intent) {
        VrProjectionService.setResizeListener { w, h ->
            renderer.onCapturedContentResized(w, h)
        }
        VrProjectionService.startService(getApplication(), resultCode, dataIntent)
    }

    fun stopMediaProjection() {
        overlayController.hideOverlay()
        VrProjectionService.setResizeListener(null)
        VrProjectionService.stopService(getApplication())
        renderer.clearLiveCaptureFrame()
        headTracker.stop()
    }

    fun stopAllVrSessions() {
        stopShizukuVrSession()
        stopMediaProjection()
    }

    fun canDrawOverlay(): Boolean = overlayController.canDrawOverlays()

    fun startVrOverlayOverMinecraft(): Boolean {
        val cfg = settingsState.value
        val strings = stringsFor(cfg.language)
        val shown = overlayController.showOverlay(
            vrSettings = cfg.vr,
            strings = strings,
            onRecenter = { recenterHead() },
            onExitOverlay = {
                VrProjectionService.setResizeListener(null)
                VrProjectionService.stopService(getApplication())
                headTracker.stop()
            },
            onOverlayDetached = {
                if (projectionState.value.isServiceRunning) {
                    VrProjectionService.setResizeListener { w, h ->
                        renderer.onCapturedContentResized(w, h)
                    }
                    renderer.reattachCaptureSurface()
                }
            }
        )
        if (shown) {
            MinecraftIntegrationManager.launchMinecraft(getApplication(), splitScreenAdjacent = false)
        }
        return shown
    }

    fun stopVrOverlay() {
        overlayController.hideOverlay()
    }

    fun sendAccessibilityTestLook(): Boolean =
        MineVrAccessibilityService.instance?.sendDiagnosticTestSwipe() == true

    fun handleControllerKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val localHandled = controllerManager.onKeyDown(keyCode, event)
        val forwarded = if (!_isVrPaused.value && shizukuState.value.virtualDisplayId > 0) {
            shizukuVrManager.forwardControllerKey(event, settingsState.value.controls)
        } else {
            false
        }
        return localHandled || forwarded
    }

    fun handleControllerKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val localHandled = controllerManager.onKeyUp(keyCode, event)
        val forwarded = if (!_isVrPaused.value && shizukuState.value.virtualDisplayId > 0) {
            shizukuVrManager.forwardControllerKey(event, settingsState.value.controls)
        } else {
            false
        }
        return localHandled || forwarded
    }

    fun handleControllerGenericMotion(event: MotionEvent): Boolean {
        val localHandled = controllerManager.onGenericMotionEvent(event)
        val forwarded = if (!_isVrPaused.value && shizukuState.value.virtualDisplayId > 0) {
            shizukuVrManager.forwardControllerMotion(event)
        } else {
            false
        }
        return localHandled || forwarded
    }

    fun forwardGameTouchToVirtualDisplay(normX: Float, normY: Float, action: Int, downTimeMs: Long) {
        shizukuVrManager.forwardNormalizedTouch(normX, normY, action, downTimeMs)
    }

    private fun saveSettings(updated: MineVrSettingsState) {
        viewModelScope.launch {
            repository.saveSettings(updated)
        }
    }

    override fun onCleared() {
        wantShizukuSession = false
        shizukuVrManager.release()
        overlayController.hideOverlay()
        controllerManager.removeActionListener(actionListener)
        controllerManager.stopListening()
        headTracker.stop()
        super.onCleared()
    }
}
