package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.settings.GameSettingsRepository
import com.example.ui.i18n.stringsFor
import com.example.vr.bridge.MineVrAccessibilityService
import com.example.vr.camera.HeadTracker
import com.example.vr.capture.MinecraftIntegrationManager
import com.example.vr.capture.VrOverlayController
import com.example.vr.capture.VrProjectionService
import com.example.vr.engine.MineVrRenderer
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GameAction
import com.example.vr.model.MineVrSettingsState
import com.example.vr.model.MinecraftAppStatus
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MineVrViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameSettingsRepository(application)
    val headTracker = HeadTracker(application)
    val controllerManager = PlayStationControllerManager(application)
    val renderer = MineVrRenderer(application, headTracker, controllerManager)
    val overlayController = VrOverlayController(application, headTracker, controllerManager)

    val settingsState: StateFlow<MineVrSettingsState> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = MineVrSettingsState()
    )

    private val _minecraftStatus = MutableStateFlow(MinecraftIntegrationManager.inspectInstallation(application))
    val minecraftStatus: StateFlow<MinecraftAppStatus> = _minecraftStatus.asStateFlow()

    private val _isVrPaused = MutableStateFlow(false)
    val isVrPaused: StateFlow<Boolean> = _isVrPaused.asStateFlow()

    val projectionState = VrProjectionService.state
    val overlayActiveState = overlayController.isOverlayActive
    val headState = headTracker.snapshot
    val controllerState = controllerManager.snapshot
    val accessibilityState = MineVrAccessibilityService.snapshot

    private val actionListener: (GameAction) -> Unit = { action ->
        when (action) {
            GameAction.RECENTER_HEAD -> recenterHead()
            GameAction.TOGGLE_VR_PAUSE -> toggleVrPaused()
            else -> Unit
        }
    }

    init {
        controllerManager.startListening()
        controllerManager.addActionListener(actionListener)

        headTracker.setDeltaListener { dYaw, dPitch ->
            val vr = settingsState.value.vr
            if (vr.accessibilityHeadLookEnabled && !_isVrPaused.value) {
                MineVrAccessibilityService.instance?.submitHeadDelta(
                    deltaYawDeg = dYaw,
                    deltaPitchDeg = dPitch,
                    sensitivity = vr.accessibilityLookSensitivity,
                    invertY = vr.accessibilityInvertY,
                    enabled = true
                )
            }
        }

        viewModelScope.launch {
            settingsState.collect { cfg ->
                renderer.vrSettings = cfg.vr
                renderer.renderMode = cfg.preferredRenderMode
                overlayController.updateSettings(cfg.vr)
                headTracker.applyConfig(
                    horizonLock = cfg.vr.horizonLockEnabled,
                    headSensitivity = cfg.vr.headSensitivity,
                    headSmoothing = cfg.vr.headSmoothing,
                    savedZeroOffsetDeg = cfg.vr.zeroYawOffsetDeg
                )
                controllerManager.updateSettings(cfg.controls)
            }
        }
    }

    fun refreshDiagnostics() {
        _minecraftStatus.value = MinecraftIntegrationManager.inspectInstallation(getApplication())
        controllerManager.refreshConnectedDevices()
        MineVrAccessibilityService.refreshSystemEnabledState(getApplication())
    }

    fun toggleLanguage() {
        val current = settingsState.value
        val next = if (current.language == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        saveSettings(current.copy(language = next))
    }

    fun setRenderMode(mode: VrRenderMode) {
        val current = settingsState.value
        saveSettings(current.copy(preferredRenderMode = mode))
    }

    fun updateVrSettings(vr: VrSettingsState) {
        val current = settingsState.value
        saveSettings(current.copy(vr = vr))
    }

    fun updateControlsSettings(controls: ControlsSettingsState) {
        val current = settingsState.value
        saveSettings(current.copy(controls = controls))
    }

    fun resetVrDefaults() {
        val current = settingsState.value
        saveSettings(current.copy(vr = VrSettingsState()))
    }

    fun resetControlDefaults() {
        val current = settingsState.value
        saveSettings(current.copy(controls = ControlsSettingsState()))
    }

    fun calibrateHeadForward() {
        val zeroOffset = headTracker.calibrateZeroYaw()
        val current = settingsState.value
        saveSettings(current.copy(vr = current.vr.copy(zeroYawOffsetDeg = zeroOffset)))
    }

    fun recenterHead() {
        headTracker.resetToCenter()
    }

    fun toggleVrPaused() {
        val next = !_isVrPaused.value
        _isVrPaused.value = next
        renderer.isPaused = next
    }

    fun setVrPaused(paused: Boolean) {
        _isVrPaused.value = paused
        renderer.isPaused = paused
    }

    fun startSensors() {
        headTracker.start()
    }

    fun stopSensorsIfSessionInactive() {
        if (!overlayController.isOverlayActive.value && !projectionState.value.isServiceRunning) {
            headTracker.stop()
        }
    }

    fun launchMinecraft(splitScreen: Boolean = false): Boolean =
        MinecraftIntegrationManager.launchMinecraft(getApplication(), splitScreenAdjacent = splitScreen)

    fun startMediaProjection(resultCode: Int, dataIntent: Intent) {
        VrProjectionService.startService(getApplication(), resultCode, dataIntent)
    }

    fun stopMediaProjection() {
        overlayController.hideOverlay()
        VrProjectionService.stopService(getApplication())
        headTracker.stop()
    }

    fun canDrawOverlay(): Boolean = overlayController.canDrawOverlays()

    fun startVrOverlayOverMinecraft(): Boolean {
        val cfg = settingsState.value
        val strings = stringsFor(cfg.language)
        val shown = overlayController.showOverlay(
            vrSettings = cfg.vr,
            strings = strings,
            onRecenter = { recenterHead() },
            onExitOverlay = {
                VrProjectionService.stopService(getApplication())
                headTracker.stop()
            }
        )
        if (shown) {
            MinecraftIntegrationManager.launchMinecraft(getApplication(), splitScreenAdjacent = false)
        }
        return shown
    }

    fun stopVrOverlay() {
        overlayController.hideOverlay()
    }

    fun sendAccessibilityTestLook(): Boolean =
        MineVrAccessibilityService.instance?.sendDiagnosticTestSwipe() == true

    private fun saveSettings(updated: MineVrSettingsState) {
        viewModelScope.launch {
            repository.saveSettings(updated)
        }
    }

    override fun onCleared() {
        overlayController.hideOverlay()
        controllerManager.removeActionListener(actionListener)
        controllerManager.stopListening()
        headTracker.stop()
        super.onCleared()
    }
}
