package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val MineVrColorScheme = darkColorScheme(
    primary = CreeperEmerald,
    onPrimary = Color(0xFF03230E),
    primaryContainer = CreeperEmeraldDark,
    onPrimaryContainer = Color(0xFFB7F7C8),
    secondary = DiamondCyan,
    onSecondary = Color(0xFF042233),
    secondaryContainer = DiamondCyanDark,
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = GoldAmber,
    onTertiary = Color(0xFF2B1900),
    tertiaryContainer = GoldAmberDark,
    onTertiaryContainer = Color(0xFFFDE68A),
    background = MineObsidian,
    onBackground = MineTextPrimary,
    surface = MineBedrockSurface,
    onSurface = MineTextPrimary,
    surfaceVariant = MineElevatedCard,
    onSurfaceVariant = MineTextSecondary,
    outline = MineBlockBorder,
    outlineVariant = Color(0xFF1F2A36),
    error = RedstoneCoral,
    onError = Color.White,
    errorContainer = RedstoneCoralDark,
    onErrorContainer = Color(0xFFFCA5A5)
)

private val MineVrShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun MineVrTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MineVrColorScheme,
        typography = MineVrTypography,
        shapes = MineVrShapes,
        content = content
    )
}
