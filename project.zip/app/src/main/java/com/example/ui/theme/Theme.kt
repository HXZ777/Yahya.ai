package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val VrColorScheme = darkColorScheme(
    primary = VrCyan,
    onPrimary = Color(0xFF00242B),
    primaryContainer = VrCyanContainer,
    onPrimaryContainer = Color(0xFFBDF7FF),
    secondary = VrEmerald,
    onSecondary = Color(0xFF022619),
    secondaryContainer = VrEmeraldContainer,
    onSecondaryContainer = Color(0xFFA7F3D0),
    tertiary = VrAmber,
    onTertiary = Color(0xFF2B1900),
    background = VrObsidian,
    onBackground = VrTextPrimary,
    surface = VrSlateSurface,
    onSurface = VrTextPrimary,
    surfaceVariant = VrElevatedCard,
    onSurfaceVariant = VrTextSecondary,
    outline = VrGlassBorder,
    outlineVariant = Color(0xFF1D2B47),
    error = VrCoral,
    onError = Color.White,
    errorContainer = VrCoralContainer,
    onErrorContainer = Color(0xFFFCA5A5)
)

private val VrShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun VrSupermarketTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VrColorScheme,
        typography = VrSupermarketTypography,
        shapes = VrShapes,
        content = content
    )
}
