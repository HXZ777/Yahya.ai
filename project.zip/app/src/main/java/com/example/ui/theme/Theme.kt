package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val StatisticsDarkColorScheme = darkColorScheme(
    primary = TurquoisePrimary,
    onPrimary = Color(0xFF04241C),
    primaryContainer = Color(0xFF0A3A31),
    onPrimaryContainer = Color(0xFF9DF7DE),
    secondary = CyanAccent,
    onSecondary = Color(0xFF041D29),
    secondaryContainer = Color(0xFF102C44),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = Color(0xFFA855F7),
    background = NavyDeep,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavyElevated,
    onSurfaceVariant = TextSecondary,
    outline = NavyBorder,
    outlineVariant = Color(0xFF1E2B45),
    error = StopCoral,
    onError = Color.White,
    errorContainer = StopCoralContainer,
    onErrorContainer = Color(0xFFFCA5A5),
)

private val StatisticsShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun StatisticsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StatisticsDarkColorScheme,
        typography = StatisticsTypography,
        shapes = StatisticsShapes,
        content = content,
    )
}
