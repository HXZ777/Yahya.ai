package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class YahyaStatusColors(
    val online: Color = EmeraldOnline,
    val onlineContainer: Color = EmeraldSurface,
    val warning: Color = WarmAmber,
    val warningContainer: Color = WarmAmberDark,
    val danger: Color = CoralAlert,
    val dangerContainer: Color = CoralSurface,
    val borderSubtle: Color = SlateBorder,
    val surfaceDeep: Color = ObsidianCanvas,
    val surfaceCard: Color = SlateSurface,
    val surfaceElevated: Color = SlateSurfaceElevated,
    val accentTeal: Color = CyberTeal,
    val accentTealSoft: Color = CyberTealMuted,
)

val LocalYahyaColors = staticCompositionLocalOf { YahyaStatusColors() }

private val YahyaDarkColorScheme = darkColorScheme(
    primary = CyberTeal,
    onPrimary = ObsidianCanvas,
    primaryContainer = CyberTealMuted,
    onPrimaryContainer = CyberTeal,
    secondary = WarmAmber,
    onSecondary = ObsidianCanvas,
    secondaryContainer = WarmAmberDark,
    onSecondaryContainer = WarmAmber,
    tertiary = SoftIndigo,
    onTertiary = ObsidianCanvas,
    tertiaryContainer = SoftIndigoDark,
    onTertiaryContainer = SoftIndigo,
    background = ObsidianCanvas,
    onBackground = InkPrimary,
    surface = SlateSurface,
    onSurface = InkPrimary,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = InkSecondary,
    surfaceContainerLowest = ObsidianCanvas,
    surfaceContainerLow = SlateSurface,
    surfaceContainer = SlateSurfaceElevated,
    surfaceContainerHigh = SlateSurfaceBright,
    surfaceContainerHighest = SlateBorder,
    outline = SlateBorder,
    outlineVariant = SlateSurfaceBright,
    error = CoralAlert,
    onError = ObsidianCanvas,
    errorContainer = CoralSurface,
    onErrorContainer = CoralAlert,
)

private val YahyaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun YahyaCompanionTheme(
    content: @Composable () -> Unit,
) {
    val statusColors = YahyaStatusColors()
    CompositionLocalProvider(LocalYahyaColors provides statusColors) {
        MaterialTheme(
            colorScheme = YahyaDarkColorScheme,
            typography = YahyaTypography,
            shapes = YahyaShapes,
            content = content,
        )
    }
}
