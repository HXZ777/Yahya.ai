package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.speech.SpeechRecognizer
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FindInPage
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.SwipeVertical
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.domain.model.AccessibilityHealth
import com.example.domain.model.AssistantSettings
import com.example.ui.theme.LocalYahyaColors

@Composable
fun ControlScreen(
    settings: AssistantSettings,
    accessibilityHealth: AccessibilityHealth,
    hasInternet: Boolean,
    canDrawOverlays: Boolean,
    isSystemOverlayRunning: Boolean,
    onToggleSystemOverlay: (Boolean) -> Unit,
    onToggleConfirmSensitive: (Boolean) -> Unit,
    onRequestMicPermission: () -> Unit,
    onTestSafeUrl: () -> Unit,
    onTestGuardrail: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val yColors = LocalYahyaColors.current

    val hasMicPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO,
    ) == PackageManager.PERMISSION_GRANTED

    val hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }

    val speechAvailable = SpeechRecognizer.isRecognitionAvailable(context)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                text = "التحكم بالجهاز والأمان",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "يدير ${AssistantSettings.APP_OFFICIAL_NAME} أوامر الشاشة محلياً عبر خدمة تسهيل الوصول الاختيارية، مع منع أي إجراء حساس دون موافقتك.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // System-Wide Floating Button Over Other Apps Card
        item {
            val overlayAccent = if (isSystemOverlayRunning) yColors.accentTeal else yColors.warning
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, overlayAccent.copy(alpha = 0.45f)),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Layers,
                                contentDescription = "الزر العائم فوق التطبيقات",
                                tint = overlayAccent,
                                modifier = Modifier.size(26.dp),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "الزر العائم فوق جميع التطبيقات",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = when {
                                        isSystemOverlayRunning -> "نشط — يظهر فوق كل تطبيقات الهاتف"
                                        canDrawOverlays -> "الإذن ممنوح — جاهز للتشغيل"
                                        else -> "يتطلب إذن الظهور فوق التطبيقات الأخرى"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = overlayAccent,
                                )
                            }
                        }
                        Switch(
                            checked = settings.systemOverlayEnabled && canDrawOverlays && isSystemOverlayRunning,
                            onCheckedChange = onToggleSystemOverlay,
                            modifier = Modifier.testTag("switch_system_overlay"),
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "يتيح لك سحب زر ${AssistantSettings.APP_OFFICIAL_NAME} العائم والضغط عليه لكتم أو تشغيل ${settings.assistantName} فوق أي تطبيق آخر.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // Optional Accessibility Service Card
        item {
            val isOp = accessibilityHealth.isOperational
            val accent = if (isOp) yColors.online else yColors.warning
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.AccessibilityNew,
                                contentDescription = "خدمة تسهيل الوصول",
                                tint = accent,
                                modifier = Modifier.size(26.dp),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "خدمة تسهيل الوصول (اختيارية)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = when {
                                        isOp -> "مفعّلة ونشطة — جاهزة للقراءة والنقر والتمرير والكتابة"
                                        accessibilityHealth.isEnabledInSettings -> "مفعّلة في الإعدادات وبانتظار الارتباط بالنظام"
                                        else -> "غير مفعّلة — فتح التطبيقات والروابط والبحث يعمل بدونها"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = accent,
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "لتفعيلها على شاومي (HyperOS / Android 13): افتح الإعدادات ← التطبيقات التي تم تنزيلها ← ${AssistantSettings.APP_OFFICIAL_NAME} - التحكم بالجهاز.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            runCatching { context.startActivity(intent) }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOp) yColors.surfaceElevated else yColors.accentTeal,
                            contentColor = if (isOp) yColors.accentTeal else MaterialTheme.colorScheme.onPrimary,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("open_accessibility_settings_button"),
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isOp) "فتح إعدادات تسهيل الوصول" else "تفعيل يدوي من إعدادات أندرويد",
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }

        // Capabilities Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = "قدرات التحكم المدعومة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    CapabilityRow(
                        icon = Icons.Rounded.Apps,
                        title = "فتح التطبيقات",
                        subtitle = "يعمل مباشرة عبر مدير الحزم دون الحاجة لتسهيل الوصول.",
                        available = true,
                    )
                    CapabilityRow(
                        icon = Icons.Rounded.Language,
                        title = "فتح الروابط والبحث في الإنترنت",
                        subtitle = "بحث موثق عبر Google Search أو فتح الروابط في المتصفح.",
                        available = true,
                    )
                    CapabilityRow(
                        icon = Icons.Rounded.FindInPage,
                        title = "قراءة محتوى الشاشة",
                        subtitle = "قراءة عناصر الشاشة للمساعد الذكي مع استبعاد كلمات المرور.",
                        available = accessibilityHealth.isOperational,
                    )
                    CapabilityRow(
                        icon = Icons.Rounded.TouchApp,
                        title = "النقر على العناصر",
                        subtitle = "يتطلب تفعيل خدمة تسهيل الوصول اختيارياً.",
                        available = accessibilityHealth.isOperational,
                    )
                    CapabilityRow(
                        icon = Icons.Rounded.SwipeVertical,
                        title = "التمرير والتنقل",
                        subtitle = "تمرير القوائم أو الرجوع والشاشة الرئيسية والإشعارات.",
                        available = accessibilityHealth.isOperational,
                    )
                    CapabilityRow(
                        icon = Icons.Rounded.Keyboard,
                        title = "الكتابة داخل الحقول",
                        subtitle = "إدخال النص في الحقل المحدد بعد موافقتك.",
                        available = accessibilityHealth.isOperational,
                    )
                }
            }
        }

        // Safety Policy & Guardrail Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.warning.copy(alpha = 0.35f)),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Security,
                            contentDescription = "سياسة الأمان",
                            tint = yColors.warning,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حاجز أمان الإجراءات الحساسة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Text(
                        text = "لا يتم تنفيذ أي أمر يتضمن الإرسال، النشر، الحذف، الدفع، الشراء، التحويل، أو إدخال بيانات حساسة دون موافقتك المباشرة، ولا يتم إرسال كلمات المرور للذكاء الاصطناعي.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "تأكيد أوامر النقر والكتابة مسبقاً",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                        )
                        Switch(
                            checked = settings.confirmSensitiveActions,
                            onCheckedChange = onToggleConfirmSensitive,
                            modifier = Modifier.testTag("confirm_sensitive_switch"),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onTestGuardrail,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("test_guardrail_button"),
                        ) {
                            Text("اختبار حاجز التأكيد")
                        }
                        OutlinedButton(
                            onClick = onTestSafeUrl,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("test_safe_url_button"),
                        ) {
                            Text("اختبار فتح رابط")
                        }
                    }
                }
            }
        }

        // Xiaomi HyperOS & Android 13 System Readiness Checklist
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = "جاهزية الجهاز (Redmi Note 11 Pro / HyperOS)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    ChecklistRow("اتصال الإنترنت (Gemini والبحث الحي)", hasInternet)
                    ChecklistRow("صلاحية الميكروفون (RECORD_AUDIO)", hasMicPermission)
                    ChecklistRow("صلاحية الإشعارات (Android 13)", hasNotificationPermission)
                    ChecklistRow("صلاحية الظهور فوق التطبيقات الأخرى (Overlay)", canDrawOverlays)
                    ChecklistRow("توفر محرك التعرف الصوتي (SpeechRecognizer)", speechAvailable)
                    ChecklistRow("خدمة تسهيل الوصول (اختيارية)", accessibilityHealth.isOperational)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!hasMicPermission || !hasNotificationPermission) {
                            Button(
                                onClick = onRequestMicPermission,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                            ) {
                                Text("منح الصلاحيات")
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                runCatching { context.startActivity(intent) }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                        ) {
                            Icon(Icons.Rounded.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إعدادات البطارية والتطبيق")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilityRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    available: Boolean,
) {
    val yColors = LocalYahyaColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (available) yColors.accentTeal else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(
            color = if (available) yColors.onlineContainer else yColors.surfaceElevated,
            shape = MaterialTheme.shapes.small,
        ) {
            Text(
                text = if (available) "جاهز" else "يتطلب تفعيل",
                style = MaterialTheme.typography.labelMedium,
                color = if (available) yColors.online else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

@Composable
private fun ChecklistRow(label: String, ok: Boolean) {
    val yColors = LocalYahyaColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
            contentDescription = null,
            tint = if (ok) yColors.online else yColors.warning,
            modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}
