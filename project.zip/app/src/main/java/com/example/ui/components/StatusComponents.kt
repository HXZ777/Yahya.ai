package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.AiStatus
import com.example.domain.model.ChatRole
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.ConversationMessage
import com.example.domain.model.LogDirection
import com.example.domain.model.LogStatus
import com.example.domain.model.MicStatus
import com.example.domain.model.PendingConfirmation
import com.example.ui.theme.LocalYahyaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatusSummaryGrid(
    aiStatus: AiStatus,
    hasApiKey: Boolean,
    hasInternet: Boolean,
    geminiModelId: String,
    micStatus: MicStatus,
    isForegroundServiceRunning: Boolean,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current

    val (aiLabel, aiDetail, aiColor) = when (aiStatus) {
        AiStatus.MISSING_API_KEY -> Triple("مفتاح مفقود", "أضف مفتاح Gemini في الإعدادات", yColors.warning)
        AiStatus.NO_INTERNET -> Triple("بدون إنترنت", "تحقق من الشبكة للاتصال بـ Gemini", yColors.danger)
        AiStatus.THINKING -> Triple("يفكر...", geminiModelId, yColors.accentTeal)
        AiStatus.EXECUTING -> Triple("ينفذ أمراً", "التحكم أو البحث قيد التنفيذ", yColors.accentTeal)
        AiStatus.SPEAKING -> Triple("يتحدث", "نطق الرد باللغة العربية", yColors.online)
        AiStatus.ERROR -> Triple("تنبيه", "تعذر إتمام الطلب — راجع التفاصيل", yColors.danger)
        AiStatus.READY -> Triple(
            if (hasApiKey) "جاهز (Gemini)" else "بحاجة إعداد",
            geminiModelId,
            yColors.online,
        )
    }

    val (micLabel, micDetail, micColor) = when {
        micStatus == MicStatus.LISTENING -> Triple("نشط - يستمع", "التعرف العربي يعمل", yColors.accentTeal)
        micStatus == MicStatus.WAKE_ARMED -> Triple("مراقبة التنبيه", "الاستماع لكلمة التنبيه", yColors.warning)
        micStatus == MicStatus.PROCESSING -> Triple("يعالج الصوت", "تحويل الكلام إلى نص", MaterialTheme.colorScheme.tertiary)
        micStatus == MicStatus.PERMISSION_MISSING -> Triple("بدون صلاحية", "مطلوب إذن الميكروفون", yColors.danger)
        micStatus == MicStatus.UNAVAILABLE -> Triple("غير متاح", "محرك الصوت معطّل", yColors.danger)
        micStatus == MicStatus.ERROR -> Triple("خطأ ميكروفون", "حاول مرة أخرى", yColors.danger)
        !hasInternet -> Triple("جاهز (أوفلاين)", "الميكروفون جاهز • لا يوجد إنترنت", yColors.warning)
        else -> Triple(
            "جاهز",
            if (isForegroundServiceRunning) "الخدمة الأمامية نشطة" else "متصل بالإنترنت ومستعد",
            yColors.online,
        )
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StatusMiniCard(
            title = "الذكاء الاصطناعي",
            statusText = aiLabel,
            detailText = aiDetail,
            accentColor = aiColor,
            icon = if (!hasInternet) Icons.Rounded.WifiOff else Icons.Rounded.AutoAwesome,
            onClick = onOpenSettings,
            modifier = Modifier
                .weight(1f)
                .testTag("ai_status_card"),
        )
        StatusMiniCard(
            title = "الصوت والاتصال",
            statusText = micLabel,
            detailText = micDetail,
            accentColor = micColor,
            icon = Icons.Rounded.Mic,
            onClick = null,
            modifier = Modifier
                .weight(1f)
                .testTag("mic_status_card"),
        )
    }
}

@Composable
private fun StatusMiniCard(
    title: String,
    statusText: String,
    detailText: String,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val cardColors = CardDefaults.cardColors(containerColor = yColors.surfaceCard)
    val border = BorderStroke(1.dp, accentColor.copy(alpha = 0.28f))

    val content: @Composable () -> Unit = {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accentColor),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = detailText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }

    if (onClick != null) {
        Card(
            onClick = onClick,
            colors = cardColors,
            border = border,
            shape = MaterialTheme.shapes.medium,
            modifier = modifier,
        ) { content() }
    } else {
        Card(
            colors = cardColors,
            border = border,
            shape = MaterialTheme.shapes.medium,
            modifier = modifier,
        ) { content() }
    }
}

@Composable
fun PendingConfirmationCard(
    pending: PendingConfirmation,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pending_confirmation_card"),
        colors = CardDefaults.cardColors(containerColor = yColors.warningContainer.copy(alpha = 0.55f)),
        border = BorderStroke(1.5.dp, yColors.warning),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Security,
                    contentDescription = pending.title,
                    tint = yColors.warning,
                    modifier = Modifier.size(22.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = pending.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = yColors.warning,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = pending.explanation,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = yColors.online,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("approve_sensitive_button"),
                ) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد التنفيذ")
                }
                OutlinedButton(
                    onClick = onReject,
                    border = BorderStroke(1.dp, yColors.danger),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = yColors.danger),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("reject_sensitive_button"),
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("رفض")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConversationMessageCard(
    message: ConversationMessage,
    assistantName: String,
    onOpenSourceUrl: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val timeText = SimpleDateFormat("HH:mm", Locale.US).format(Date(message.timestamp))

    val (containerColor, borderColor, roleLabel) = when (message.role) {
        ChatRole.USER -> Triple(
            yColors.accentTealSoft.copy(alpha = 0.55f),
            yColors.accentTeal.copy(alpha = 0.40f),
            "أنت",
        )
        ChatRole.ASSISTANT -> Triple(
            if (message.isError) yColors.danger.copy(alpha = 0.12f) else yColors.surfaceCard,
            if (message.isError) yColors.danger.copy(alpha = 0.45f) else yColors.borderSubtle,
            "HXZ AI • $assistantName",
        )
        ChatRole.TOOL -> Triple(
            yColors.surfaceElevated.copy(alpha = 0.72f),
            if (message.isError) yColors.danger.copy(alpha = 0.35f) else yColors.online.copy(alpha = 0.30f),
            message.toolSummary ?: "تنفيذ أداة",
        )
        ChatRole.SYSTEM -> Triple(
            yColors.surfaceCard,
            yColors.borderSubtle,
            "النظام",
        )
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (message.role == ChatRole.TOOL) {
                        Icon(
                            imageVector = Icons.Rounded.Build,
                            contentDescription = null,
                            tint = if (message.isError) yColors.danger else yColors.online,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    } else if (message.role == ChatRole.ASSISTANT) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = if (message.isError) yColors.danger else yColors.accentTeal,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = roleLabel,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = when (message.role) {
                            ChatRole.USER -> yColors.accentTeal
                            ChatRole.TOOL -> if (message.isError) yColors.danger else yColors.online
                            else -> if (message.isError) yColors.danger else MaterialTheme.colorScheme.onSurface
                        },
                    )
                }
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = message.text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )

            if (message.sources.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "المصادر:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    message.sources.take(5).forEach { source ->
                        Surface(
                            color = yColors.surfaceElevated,
                            shape = MaterialTheme.shapes.small,
                            border = BorderStroke(1.dp, yColors.accentTeal.copy(alpha = 0.35f)),
                            modifier = Modifier.clickable { onOpenSourceUrl(source.url) },
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Public,
                                    contentDescription = null,
                                    tint = yColors.accentTeal,
                                    modifier = Modifier.size(13.dp),
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = source.title.take(36),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = yColors.accentTeal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActivityLogItemCard(
    item: CommandExecutionLog,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val badgeColor = when (item.status) {
        LogStatus.SENT, LogStatus.EXECUTED -> yColors.online
        LogStatus.QUEUED, LogStatus.AWAITING_CONFIRMATION -> yColors.warning
        LogStatus.REJECTED, LogStatus.FAILED -> yColors.danger
        LogStatus.INFO -> yColors.accentTeal
    }
    val statusBadgeText = when (item.status) {
        LogStatus.SENT -> "طلب"
        LogStatus.QUEUED -> "مؤجل"
        LogStatus.AWAITING_CONFIRMATION -> "بانتظار التأكيد"
        LogStatus.EXECUTED -> "نُفّذ"
        LogStatus.REJECTED -> "مرفوض"
        LogStatus.FAILED -> "فشل"
        LogStatus.INFO -> "نظام"
    }
    val directionLabel = when (item.direction) {
        LogDirection.OUTBOUND_SPEECH -> "طلب المستخدم"
        LogDirection.INBOUND_COMMAND -> "تخطيط AI"
        LogDirection.EXECUTION_RESULT -> "نتيجة التنفيذ"
        LogDirection.SYSTEM -> "النظام"
    }
    val timeText = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(item.timestamp))

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
        border = BorderStroke(1.dp, yColors.borderSubtle),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                ) {
                    if (item.isSensitive) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = "إجراء حساس",
                            tint = yColors.warning,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = badgeColor.copy(alpha = 0.14f),
                    shape = MaterialTheme.shapes.small,
                ) {
                    Text(
                        text = statusBadgeText,
                        style = MaterialTheme.typography.labelMedium,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.detail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = directionLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                )
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                )
            }
        }
    }
}
