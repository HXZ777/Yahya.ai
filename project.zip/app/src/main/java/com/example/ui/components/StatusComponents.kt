package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.ConnectionState
import com.example.domain.model.ConnectionStatus
import com.example.domain.model.LogDirection
import com.example.domain.model.LogStatus
import com.example.domain.model.MicStatus
import com.example.domain.model.PendingConfirmation
import com.example.ui.theme.LocalYahyaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatusSummaryGrid(
    connectionState: ConnectionState,
    micStatus: MicStatus,
    isForegroundServiceRunning: Boolean,
    onOpenPairing: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current

    val (connLabel, connDetail, connColor) = when (connectionState.status) {
        ConnectionStatus.CONNECTED -> Triple(
            "متصل",
            buildString {
                append(connectionState.pairedDeviceName.ifBlank { "الهاتف الرئيسي" })
                connectionState.latencyMs?.let { append(" • ${it}ms") }
            },
            yColors.online,
        )
        ConnectionStatus.CONNECTING -> Triple(
            "جاري الاتصال...",
            connectionState.pairedDeviceName.ifBlank { "محاولة الربط" },
            yColors.warning,
        )
        ConnectionStatus.DISCOVERING -> Triple(
            "جاري البحث...",
            "البحث في الشبكة المحلية",
            yColors.warning,
        )
        ConnectionStatus.ERROR -> Triple(
            "تعذر الاتصال",
            connectionState.errorMessage ?: "تحقق من الشبكة",
            yColors.danger,
        )
        ConnectionStatus.DISCONNECTED -> Triple(
            "غير متصل",
            if (connectionState.pairedDeviceName.isNotBlank()) {
                "مقترن بـ ${connectionState.pairedDeviceName}"
            } else {
                "اضغط لإقران الهاتف الثاني"
            },
            yColors.danger,
        )
    }

    val (micLabel, micDetail, micColor) = when (micStatus) {
        MicStatus.LISTENING -> Triple("نشط - يستمع", "التعرف العربي يعمل", yColors.accentTeal)
        MicStatus.WAKE_ARMED -> Triple("مراقبة التنبيه", "الخدمة في الخلفية", yColors.warning)
        MicStatus.PROCESSING -> Triple("يعالج الصوت", "تجهيز الإرسال", MaterialTheme.colorScheme.tertiary)
        MicStatus.PERMISSION_MISSING -> Triple("بدون صلاحية", "مطلوب إذن الميكروفون", yColors.danger)
        MicStatus.UNAVAILABLE -> Triple("غير متاح", "محرك الصوت معطّل", yColors.danger)
        MicStatus.ERROR -> Triple("خطأ ميكروفون", "حاول مرة أخرى", yColors.danger)
        MicStatus.READY -> Triple(
            "جاهز",
            if (isForegroundServiceRunning) "الخدمة الأمامية نشطة" else "اضغط زر الميكروفون",
            yColors.online,
        )
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StatusMiniCard(
            title = "الهاتف الرئيسي",
            statusText = connLabel,
            detailText = connDetail,
            accentColor = connColor,
            icon = if (connectionState.status == ConnectionStatus.CONNECTED) Icons.Rounded.Link else Icons.Rounded.LinkOff,
            onClick = onOpenPairing,
            modifier = Modifier
                .weight(1f)
                .testTag("connection_status_card"),
        )
        StatusMiniCard(
            title = "حالة الميكروفون",
            statusText = micLabel,
            detailText = micDetail,
            accentColor = micColor,
            icon = Icons.Rounded.Mic,
            onClick = null,
            modifier = Modifier
                .weight(1f)
                .testTag("mic_status_card"),
        )
    }
}

@Composable
private fun StatusMiniCard(
    title: String,
    statusText: String,
    detailText: String,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val cardColors = CardDefaults.cardColors(containerColor = yColors.surfaceCard)
    val border = BorderStroke(1.dp, accentColor.copy(alpha = 0.28f))

    val content: @Composable () -> Unit = {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accentColor),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = detailText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }

    if (onClick != null) {
        Card(
            onClick = onClick,
            colors = cardColors,
            border = border,
            shape = MaterialTheme.shapes.medium,
            modifier = modifier,
        ) { content() }
    } else {
        Card(
            colors = cardColors,
            border = border,
            shape = MaterialTheme.shapes.medium,
            modifier = modifier,
        ) { content() }
    }
}

@Composable
fun PendingConfirmationCard(
    pending: PendingConfirmation,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pending_confirmation_card"),
        colors = CardDefaults.cardColors(containerColor = yColors.warningContainer.copy(alpha = 0.55f)),
        border = BorderStroke(1.5.dp, yColors.warning),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Security,
                    contentDescription = pending.title,
                    tint = yColors.warning,
                    modifier = Modifier.size(22.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = pending.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = yColors.warning,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = pending.explanation,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = yColors.online,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("approve_sensitive_button"),
                ) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد التنفيذ")
                }
                OutlinedButton(
                    onClick = onReject,
                    border = BorderStroke(1.dp, yColors.danger),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = yColors.danger),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("reject_sensitive_button"),
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("رفض")
                }
            }
        }
    }
}

@Composable
fun ActivityLogItemCard(
    item: CommandExecutionLog,
    modifier: Modifier = Modifier,
) {
    val yColors = LocalYahyaColors.current
    val badgeColor = when (item.status) {
        LogStatus.SENT, LogStatus.EXECUTED -> yColors.online
        LogStatus.QUEUED, LogStatus.AWAITING_CONFIRMATION -> yColors.warning
        LogStatus.REJECTED, LogStatus.FAILED -> yColors.danger
        LogStatus.INFO -> yColors.accentTeal
    }
    val statusBadgeText = when (item.status) {
        LogStatus.SENT -> "مُرسل"
        LogStatus.QUEUED -> "محلي فقط"
        LogStatus.AWAITING_CONFIRMATION -> "بانتظار التأكيد"
        LogStatus.EXECUTED -> "نُفّذ"
        LogStatus.REJECTED -> "مرفوض"
        LogStatus.FAILED -> "فشل"
        LogStatus.INFO -> "نظام"
    }
    val directionLabel = when (item.direction) {
        LogDirection.OUTBOUND_SPEECH -> "صوت صادر"
        LogDirection.INBOUND_COMMAND -> "أمر وارد"
        LogDirection.EXECUTION_RESULT -> "نتيجة التنفيذ"
        LogDirection.SYSTEM -> "النظام"
    }
    val timeText = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(item.timestamp))

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
        border = BorderStroke(1.dp, yColors.borderSubtle),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.isSensitive) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = "إجراء حساس",
                            tint = yColors.warning,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
                Surface(
                    color = badgeColor.copy(alpha = 0.14f),
                    shape = MaterialTheme.shapes.small,
                ) {
                    Text(
                        text = statusBadgeText,
                        style = MaterialTheme.typography.labelMedium,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.detail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = directionLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                )
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                )
            }
        }
    }
}
