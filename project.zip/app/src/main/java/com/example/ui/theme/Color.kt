package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VrObsidian = Color(0xFF070B14)
val VrSlateSurface = Color(0xFF0F172A)
val VrElevatedCard = Color(0xFF17223B)
val VrGlassBorder = Color(0xFF283A5E)

val VrCyan = Color(0xFF00E5FF)
val VrCyanContainer = Color(0xFF063647)
val VrEmerald = Color(0xFF10B981)
val VrEmeraldContainer = Color(0xFF063B2B)
val VrAmber = Color(0xFFF59E0B)
val VrCoral = Color(0xFFEF4444)
val VrCoralContainer = Color(0xFF3F131A)
val VrViolet = Color(0xFFA855F7)

val VrTextPrimary = Color(0xFFF8FAFC)
val VrTextSecondary = Color(0xFF94A3B8)
val VrTextMuted = Color(0xFF64748B)
