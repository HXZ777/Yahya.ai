package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian & Slate surfaces inspired by Minecraft Night / Netherite
val MineObsidian = Color(0xFF0A0D11)
val MineBedrockSurface = Color(0xFF12171E)
val MineElevatedCard = Color(0xFF1A222C)
val MineBlockBorder = Color(0xFF2B3848)

// Minecraft accents: Creeper Emerald, Diamond Cyan, Gold Ingot, Redstone
val CreeperEmerald = Color(0xFF34D058)
val CreeperEmeraldDark = Color(0xFF0B3B1E)
val DiamondCyan = Color(0xFF38BDF8)
val DiamondCyanDark = Color(0xFF0A3247)
val GoldAmber = Color(0xFFF59E0B)
val GoldAmberDark = Color(0xFF3D2705)
val RedstoneCoral = Color(0xFFEF4444)
val RedstoneCoralDark = Color(0xFF3F131A)
val AmethystPurple = Color(0xFFA855F7)

val MineTextPrimary = Color(0xFFF3F6FA)
val MineTextSecondary = Color(0xFF9AA8BA)
val MineTextMuted = Color(0xFF64748B)
