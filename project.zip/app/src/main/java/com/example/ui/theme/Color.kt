package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian & Cyber-Teal Dark Palette
val ObsidianCanvas = Color(0xFF070B12)
val SlateSurface = Color(0xFF0F1623)
val SlateSurfaceElevated = Color(0xFF162032)
val SlateSurfaceBright = Color(0xFF1E2B42)
val SlateBorder = Color(0xFF26354F)

val CyberTeal = Color(0xFF2EE6D6)
val CyberTealDark = Color(0xFF004F48)
val CyberTealMuted = Color(0xFF153D3B)

val WarmAmber = Color(0xFFFFB547)
val WarmAmberDark = Color(0xFF4A2E00)

val SoftIndigo = Color(0xFF8AA4FF)
val SoftIndigoDark = Color(0xFF1E2B57)

val EmeraldOnline = Color(0xFF38E59B)
val EmeraldSurface = Color(0xFF0E3829)

val CoralAlert = Color(0xFFFF5C6C)
val CoralSurface = Color(0xFF42151C)

val InkPrimary = Color(0xFFF2F6FC)
val InkSecondary = Color(0xFFA0AEC4)
val InkMuted = Color(0xFF6B7B94)
