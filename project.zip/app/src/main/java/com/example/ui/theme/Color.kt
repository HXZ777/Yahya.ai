package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian + Terminal Emerald Palette
val ObsidianCanvas = Color(0xFF070C0A)
val ObsidianSurface = Color(0xFF0E1613)
val ObsidianSurfaceElevated = Color(0xFF15211C)
val ObsidianSurfaceHighlight = Color(0xFF1D2E27)
val ObsidianOutline = Color(0xFF283D34)
val ObsidianOutlineSubtle = Color(0xFF1B2B24)

val EmeraldPrimary = Color(0xFF22C55E)
val EmeraldBright = Color(0xFF4ADE80)
val EmeraldContainer = Color(0xFF0F3D24)
val OnEmerald = Color(0xFF041C0E)
val OnEmeraldContainer = Color(0xFFBBF7D0)

val MintSecondary = Color(0xFF34D399)
val MintContainer = Color(0xFF0D3327)
val OnMintContainer = Color(0xFFA7F3D0)

val CyanTertiary = Color(0xFF2DD4BF)
val CyanContainer = Color(0xFF0F2F2D)

val TextPrimary = Color(0xFFECFDF5)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AmberWarning = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF2E2108)
val ErrorRed = Color(0xFFF87171)
val ErrorContainer = Color(0xFF3A1215)
