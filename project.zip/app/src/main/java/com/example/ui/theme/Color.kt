package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDeep = Color(0xFF0B1220)
val NavySurface = Color(0xFF131E33)
val NavyElevated = Color(0xFF1B2842)
val NavyBorder = Color(0xFF263654)

val TurquoisePrimary = Color(0xFF11E5B2)
val TurquoiseDim = Color(0xFF0BB88E)
val CyanAccent = Color(0xFF38BDF8)

val StopCoral = Color(0xFFEF4444)
val StopCoralContainer = Color(0xFF3B151D)
val WarningAmber = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val OverlayPillBg = Color(0xFF0A0B0E)
val OverlayPillBorder = Color(0xFF2A2D34)
val OverlayDivider = Color(0xFF2D3139)
