package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed interface VrRoute {
    @Serializable data object MainMenu : VrRoute
    @Serializable data object VrGameplay : VrRoute
    @Serializable data object WorldBrowser : VrRoute
    @Serializable data object VrSettings : VrRoute
    @Serializable data object ControlsSettings : VrRoute
    @Serializable data object GraphicsSettings : VrRoute
}
