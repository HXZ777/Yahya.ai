package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed interface MineVrRoute {
    @Serializable data object MainMenu : MineVrRoute
    @Serializable data object VrSettings : MineVrRoute
    @Serializable data object ControlsSettings : MineVrRoute
    @Serializable data object SensorDiagnostics : MineVrRoute
    @Serializable data object AppInfo : MineVrRoute
    @Serializable data object VrGameplay : MineVrRoute
}
