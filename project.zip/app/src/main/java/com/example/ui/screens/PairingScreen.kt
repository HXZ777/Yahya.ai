package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.network.QrCodeUtils
import com.example.data.network.QrFrameAnalyzer
import com.example.data.preferences.PairingPayloadCodec
import com.example.domain.model.AssistantSettings
import com.example.domain.model.ConnectionState
import com.example.domain.model.ConnectionStatus
import com.example.domain.model.DiscoveredBrainDevice
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalYahyaColors
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PairingScreen(
    settings: AssistantSettings,
    connectionState: ConnectionState,
    localIp: String?,
    deviceModelLabel: String,
    discoveredDevices: List<DiscoveredBrainDevice>,
    isNsdScanning: Boolean,
    onPairAndConnect: (deviceName: String, host: String, port: Int, code: String, secret: String, useTls: Boolean) -> Unit,
    onScanPayload: (String) -> Boolean,
    onReconnect: () -> Unit,
    onUnpair: () -> Unit,
    onPingTest: () -> Unit,
    onRotateCredentials: () -> Unit,
    onStartNsd: () -> Unit,
    onStopNsd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val yColors = LocalYahyaColors.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) } // 0 = Connect to Brain, 1 = My QR
    var showQrScanner by rememberSaveable { mutableStateOf(false) }
    var feedbackMessage by rememberSaveable { mutableStateOf<String?>(null) }

    var hostInput by rememberSaveable(settings.pairedHost) { mutableStateOf(settings.pairedHost) }
    var portInput by rememberSaveable(settings.pairedPort) { mutableStateOf(settings.pairedPort.toString()) }
    var nameInput by rememberSaveable(settings.pairedDeviceName) {
        mutableStateOf(settings.pairedDeviceName.ifBlank { "هاتف الذكاء الاصطناعي" })
    }
    var codeInput by rememberSaveable(settings.pairingCode) { mutableStateOf(settings.pairingCode) }
    var secretInput by rememberSaveable(settings.pairingSecret) { mutableStateOf(settings.pairingSecret) }
    var useTls by rememberSaveable(settings.useTls) { mutableStateOf(settings.useTls) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            showQrScanner = true
        } else {
            feedbackMessage = "يرجى منح صلاحية الكاميرا لمسح رمز QR أو استخدام الإدخال اليدوي."
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                text = "إقران الهاتفين",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "اربط هذا الهاتف (الأذن واليد) بالهاتف الثاني (العقل الذكي) عبر الشبكة المحلية مع مصادقة HMAC-SHA256.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // Live Connection Banner
        item {
            val statusColor = when (connectionState.status) {
                ConnectionStatus.CONNECTED -> yColors.online
                ConnectionStatus.CONNECTING, ConnectionStatus.DISCOVERING -> yColors.warning
                ConnectionStatus.ERROR, ConnectionStatus.DISCONNECTED -> yColors.danger
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.45f)),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (connectionState.status == ConnectionStatus.CONNECTED) {
                                    Icons.Rounded.Link
                                } else {
                                    Icons.Rounded.LinkOff
                                },
                                contentDescription = "حالة الإقران",
                                tint = statusColor,
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = when (connectionState.status) {
                                        ConnectionStatus.CONNECTED -> "متصل بـ ${connectionState.pairedDeviceName}"
                                        ConnectionStatus.CONNECTING -> "جاري الاتصال بالهاتف الرئيسي..."
                                        ConnectionStatus.DISCOVERING -> "جاري البحث في الشبكة..."
                                        ConnectionStatus.ERROR -> "خطأ اتصال"
                                        ConnectionStatus.DISCONNECTED -> "غير متصل"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                )
                                if (connectionState.endpointLabel.isNotBlank()) {
                                    Text(
                                        text = connectionState.endpointLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                        connectionState.latencyMs?.let { rtt ->
                            Surface(
                                color = yColors.onlineContainer,
                                shape = MaterialTheme.shapes.small,
                            ) {
                                Text(
                                    text = "${rtt}ms",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = yColors.online,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                )
                            }
                        }
                    }

                    if (!connectionState.errorMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = connectionState.errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = yColors.danger,
                        )
                    }

                    if (settings.isPaired) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onPingTest,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                            ) {
                                Icon(Icons.Rounded.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اختبار Ping")
                            }
                            OutlinedButton(
                                onClick = onReconnect,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إعادة اتصال")
                            }
                            TextButton(
                                onClick = onUnpair,
                                modifier = Modifier.height(44.dp),
                            ) {
                                Text("إلغاء", color = yColors.danger)
                            }
                        }
                    }
                }
            }
        }

        // Mode Switcher
        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    icon = { Icon(Icons.Rounded.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp)) },
                ) {
                    Text("الربط بالهاتف الرئيسي")
                }
                SegmentedButton(
                    selected = selectedTab == 1,
                    onClick = {
                        showQrScanner = false
                        selectedTab = 1
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    icon = { Icon(Icons.Rounded.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp)) },
                ) {
                    Text("رمز QR الخاص بي")
                }
            }
        }

        if (!feedbackMessage.isNullOrBlank()) {
            item {
                Surface(
                    color = yColors.accentTealSoft,
                    shape = MaterialTheme.shapes.medium,
                    border = BorderStroke(1.dp, yColors.accentTeal.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = feedbackMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = yColors.accentTeal,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
        }

        if (selectedTab == 0) {
            // QR Scanner Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                    border = BorderStroke(1.dp, yColors.borderSubtle),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "مسح رمز QR من الهاتف الرئيسي",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Button(
                                onClick = {
                                    if (showQrScanner) {
                                        showQrScanner = false
                                    } else {
                                        val granted = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.CAMERA,
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (granted) {
                                            showQrScanner = true
                                        } else {
                                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .height(44.dp)
                                    .testTag("toggle_qr_scanner_button"),
                            ) {
                                Icon(
                                    imageVector = if (showQrScanner) Icons.Rounded.Close else Icons.Rounded.CameraAlt,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (showQrScanner) "إغلاق" else "مسح QR")
                            }
                        }

                        if (showQrScanner) {
                            Spacer(modifier = Modifier.height(12.dp))
                            QrCameraScannerBox(
                                onQrScanned = { raw ->
                                    val ok = onScanPayload(raw)
                                    if (ok) {
                                        showQrScanner = false
                                        feedbackMessage = "تم قراءة رمز الإقران وبدء الاتصال بالهاتف الرئيسي."
                                    } else {
                                        feedbackMessage = "الرمز المقروء لا يحتوي على بيانات إقران صالحة."
                                    }
                                },
                            )
                        }
                    }
                }
            }

            // NSD LAN Discovery Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                    border = BorderStroke(1.dp, yColors.borderSubtle),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.WifiFind,
                                    contentDescription = null,
                                    tint = yColors.accentTeal,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "اكتشاف الشبكة المحلية (NSD)",
                                    style = MaterialTheme.typography.titleMedium,
                                )
                            }
                            OutlinedButton(
                                onClick = { if (isNsdScanning) onStopNsd() else onStartNsd() },
                                modifier = Modifier.height(40.dp),
                            ) {
                                Icon(Icons.Rounded.Radar, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isNsdScanning) "إيقاف البحث" else "بحث")
                            }
                        }

                        if (discoveredDevices.isEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isNsdScanning) {
                                    "جاري البحث عن خدمة _yahya-brain._tcp على شبكة Wi-Fi..."
                                } else {
                                    "اضغط \"بحث\" لاكتشاف الهاتف الثاني تلقائياً على نفس الشبكة."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            Spacer(modifier = Modifier.height(10.dp))
                            discoveredDevices.forEach { device ->
                                Surface(
                                    onClick = {
                                        nameInput = device.serviceName
                                        hostInput = device.host
                                        portInput = device.port.toString()
                                        feedbackMessage = "تم تعبئة عنوان ${device.serviceName}. أدخل رمز الإقران واضغط اتصال."
                                    },
                                    color = yColors.surfaceElevated,
                                    shape = MaterialTheme.shapes.small,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(device.serviceName, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            text = "${device.host}:${device.port}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = yColors.accentTeal,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Manual Connection Form
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                    border = BorderStroke(1.dp, yColors.borderSubtle),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = "إدخال بيانات الإقران يدوياً",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )

                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("اسم الهاتف الرئيسي") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = hostInput,
                                onValueChange = { hostInput = it },
                                label = { Text("عنوان IP (مثل 192.168.1.50)") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(2f)
                                    .testTag("pair_host_input"),
                            )
                            OutlinedTextField(
                                value = portInput,
                                onValueChange = { portInput = it.filter { ch -> ch.isDigit() } },
                                label = { Text("المنفذ") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pair_port_input"),
                            )
                        }

                        OutlinedTextField(
                            value = codeInput,
                            onValueChange = { codeInput = it },
                            label = { Text("رمز الإقران (6 أرقام)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pair_code_input"),
                        )

                        OutlinedTextField(
                            value = secretInput,
                            onValueChange = { secretInput = it },
                            label = { Text("المفتاح المشترك (HMAC Secret)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pair_secret_input"),
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تشفير TLS (wss://)", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "فعّله إذا كان الهاتف الرئيسي يستخدم شهادة SSL/TLS.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(checked = useTls, onCheckedChange = { useTls = it })
                        }

                        Button(
                            onClick = {
                                val parsedPort = portInput.toIntOrNull() ?: 8765
                                val effectiveSecret = secretInput.ifBlank { codeInput }
                                if (hostInput.isBlank() || effectiveSecret.isBlank()) {
                                    feedbackMessage = "يرجى إدخال عنوان IP والمفتاح أو رمز الإقران."
                                } else {
                                    onPairAndConnect(
                                        nameInput,
                                        hostInput.trim(),
                                        parsedPort,
                                        codeInput.trim(),
                                        effectiveSecret.trim(),
                                        useTls,
                                    )
                                    feedbackMessage = "تم حفظ الإعدادات وبدء الاتصال بالهاتف الرئيسي."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = yColors.accentTeal,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("connect_pair_button"),
                        ) {
                            Icon(Icons.Rounded.Link, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("حفظ والاتصال بالهاتف الرئيسي", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // My Pairing QR Code Tab
            item {
                val qrPayload = remember(settings.deviceId, localIp, settings.pairingCode, settings.pairingSecret) {
                    PairingPayloadCodec.buildCompanionQrUri(
                        deviceId = settings.deviceId,
                        deviceName = deviceModelLabel,
                        localIp = localIp,
                        pairingCode = settings.pairingCode,
                        secret = settings.pairingSecret,
                    )
                }
                val qrBitmap = remember(qrPayload) {
                    QrCodeUtils.generateQrBitmap(qrPayload, 520)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                    border = BorderStroke(1.dp, yColors.accentTeal.copy(alpha = 0.35f)),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = "امسح هذا الرمز من الهاتف الرئيسي",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "يحتوي رمز QR على معرّف الجهاز ورمز التحقق ومفتاح التوقيع الآمن.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(modifier = Modifier.height(18.dp))

                        if (qrBitmap != null) {
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(MaterialTheme.shapes.medium)
                                    .background(Color.White)
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Image(
                                    bitmap = qrBitmap.asImageBitmap(),
                                    contentDescription = "رمز QR لإقران الهاتف المساعد",
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Surface(
                            color = yColors.surfaceDeep,
                            shape = MaterialTheme.shapes.medium,
                            border = BorderStroke(1.dp, yColors.borderSubtle),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    text = "رمز الإقران",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = settings.pairingCode.ifBlank { "------" },
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                    ),
                                    color = yColors.accentTeal,
                                    fontWeight = FontWeight.Bold,
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "IP المحلي: ${localIp ?: "غير متصل بـ Wi-Fi"}  •  ID: ${settings.deviceId}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedButton(
                            onClick = onRotateCredentials,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("rotate_pairing_code_button"),
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("توليد رمز ومفتاح أمان جديد")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QrCameraScannerBox(
    onQrScanned: (String) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    var handled by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { cameraExecutor.shutdown() }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .clip(MaterialTheme.shapes.medium),
    ) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener(
                    {
                        val provider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        val analysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also { analyzerUseCase ->
                                analyzerUseCase.setAnalyzer(
                                    cameraExecutor,
                                    QrFrameAnalyzer { raw ->
                                        if (!handled) {
                                            handled = true
                                            previewView.post { onQrScanned(raw) }
                                        }
                                    },
                                )
                            }
                        runCatching {
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                analysis,
                            )
                        }
                    },
                    ContextCompat.getMainExecutor(ctx),
                )
                previewView
            },
            modifier = Modifier.fillMaxSize(),
        )
    }
}
