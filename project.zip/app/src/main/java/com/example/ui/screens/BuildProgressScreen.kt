package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.BuildExecutionState
import com.example.domain.model.BuildLogEntry
import com.example.domain.model.BuildStepState
import com.example.domain.model.LogLevel
import com.example.domain.model.StageStatus
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ObsidianCanvas
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceHighlight
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun BuildProgressScreen(
    buildState: BuildExecutionState,
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpenEngineSettings: () -> Unit,
    onExtractPrebuiltApk: () -> Unit,
    onViewResult: () -> Unit,
) {
    BackHandler(onBack = onBack)

    val clipboard = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    val (progress, headline, steps, logs) = when (buildState) {
        is BuildExecutionState.Running -> Quad(
            buildState.progress,
            buildState.currentStageLabel,
            buildState.steps,
            buildState.logs,
        )
        is BuildExecutionState.Succeeded -> Quad(
            buildState.progress,
            "APK Build & Verification Complete",
            buildState.steps,
            buildState.logs,
        )
        is BuildExecutionState.Failed -> Quad(
            buildState.progress,
            buildState.errorTitle,
            buildState.steps,
            buildState.logs,
        )
        BuildExecutionState.Idle -> Quad(0f, "Waiting to start build...", emptyList(), emptyList())
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(contentPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("build_back_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Home",
                            tint = TextPrimary,
                        )
                    }
                    Column {
                        Text(
                            text = "Build Pipeline",
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimary,
                        )
                        Text(
                            text = headline,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (buildState is BuildExecutionState.Failed) ErrorRed else EmeraldBright,
                        )
                    }
                }

                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (buildState is BuildExecutionState.Failed) ErrorRed else EmeraldBright,
                )
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(8.dp)),
                color = if (buildState is BuildExecutionState.Failed) ErrorRed else EmeraldPrimary,
                trackColor = ObsidianSurfaceHighlight,
            )

            // Pipeline Steps Card
            if (steps.isNotEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = ObsidianSurface,
                    border = BorderStroke(1.dp, ObsidianOutline),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        steps.forEach { step ->
                            BuildStepRow(step)
                        }
                    }
                }
            }

            // Honest Failure Diagnostic Card
            if (buildState is BuildExecutionState.Failed) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("build_failure_card"),
                    shape = RoundedCornerShape(18.dp),
                    color = ErrorContainer.copy(alpha = 0.75f),
                    border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.55f)),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Error,
                                contentDescription = null,
                                tint = ErrorRed,
                                modifier = Modifier.size(20.dp),
                            )
                            Text(
                                text = buildState.errorTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = ErrorRed,
                            )
                        }
                        Text(
                            text = buildState.errorDetail,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                        )
                        if (buildState.missingRequirements.isNotEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Missing Requirements:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AmberWarning,
                                )
                                buildState.missingRequirements.forEach { req ->
                                    Text(
                                        text = "• $req",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                onClick = onOpenEngineSettings,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("failure_configure_runner_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldPrimary,
                                    contentColor = OnEmerald,
                                ),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Tune,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Build Engine")
                            }

                            OutlinedButton(
                                onClick = onBack,
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, ObsidianOutline),
                            ) {
                                Text("Back", color = TextPrimary)
                            }
                        }

                        if (buildState.canExtractPrebuiltApk) {
                            OutlinedButton(
                                onClick = onExtractPrebuiltApk,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("extract_prebuilt_apk_button"),
                                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.6f)),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    tint = EmeraldBright,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Extract Pre-Built APK from Archive",
                                    color = EmeraldBright,
                                )
                            }
                        }
                    }
                }
            }

            // Succeeded Action
            if (buildState is BuildExecutionState.Succeeded) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = EmeraldContainer,
                    border = BorderStroke(1.dp, EmeraldPrimary),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = "Verified APK Ready: ${buildState.result.appName}",
                            style = MaterialTheme.typography.titleSmall,
                            color = EmeraldBright,
                        )
                        Button(
                            onClick = onViewResult,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("view_apk_result_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldPrimary,
                                contentColor = OnEmerald,
                            ),
                        ) {
                            Text("Open APK Result & Save / Install")
                        }
                    }
                }
            }

            // Terminal Build Logs
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = ObsidianCanvas,
                border = BorderStroke(1.dp, ObsidianOutline),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "BUILD CONSOLE (${logs.size} lines)",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary,
                        )
                        IconButton(
                            onClick = {
                                val text = logs.joinToString("\n") { "[${it.timestamp}] ${it.level}: ${it.message}" }
                                clipboard.setText(AnnotatedString(text))
                            },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "Copy build logs",
                                tint = EmeraldBright,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp, max = 280.dp)
                            .background(ObsidianSurface, RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        items(logs) { entry ->
                            BuildLogLine(entry)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BuildStepRow(step: BuildStepState) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        when (step.status) {
            StageStatus.PENDING -> Icon(
                imageVector = Icons.Filled.HourglassTop,
                contentDescription = "Pending",
                tint = TextMuted,
                modifier = Modifier.size(20.dp),
            )
            StageStatus.RUNNING -> CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.2.dp,
                color = EmeraldBright,
            )
            StageStatus.SUCCEEDED -> Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = "Succeeded",
                tint = EmeraldPrimary,
                modifier = Modifier.size(20.dp),
            )
            StageStatus.FAILED -> Icon(
                imageVector = Icons.Filled.Error,
                contentDescription = "Failed",
                tint = ErrorRed,
                modifier = Modifier.size(20.dp),
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = step.stage.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = when (step.status) {
                    StageStatus.FAILED -> ErrorRed
                    StageStatus.SUCCEEDED -> EmeraldBright
                    StageStatus.RUNNING -> TextPrimary
                    StageStatus.PENDING -> TextSecondary
                },
            )
            Text(
                text = step.detail,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
            )
        }
    }
}

@Composable
private fun BuildLogLine(entry: BuildLogEntry) {
    val color = when (entry.level) {
        LogLevel.INFO -> TextSecondary
        LogLevel.WARN -> AmberWarning
        LogLevel.ERROR -> ErrorRed
        LogLevel.SUCCESS -> EmeraldBright
    }
    Text(
        text = "[${entry.timestamp}] ${entry.message}",
        style = MaterialTheme.typography.labelSmall,
        color = color,
    )
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
