package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatteryAlert
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.MainUiState
import com.example.ui.components.BrandLogoMark
import com.example.ui.components.LiveOverlayPreviewCard
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavySurface
import com.example.ui.theme.StopCoral
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoisePrimary
import com.example.ui.theme.WarningAmber

@Composable
fun HomeScreen(
    uiState: MainUiState,
    strings: AppStrings,
    contentPadding: PaddingValues,
    onToggleOverlay: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onOpenBatterySettings: () -> Unit,
) {
    val isRunning = uiState.isOverlayRunning
    val buttonColor by animateColorAsState(
        targetValue = if (isRunning) StopCoral else TurquoisePrimary,
        animationSpec = tween(240),
        label = "toggle_btn_color",
    )
    val buttonContentColor by animateColorAsState(
        targetValue = if (isRunning) Color.White else Color(0xFF04241C),
        animationSpec = tween(240),
        label = "toggle_btn_content",
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 16.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                // Header: Logo + App Title + Status Pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f),
                    ) {
                        BrandLogoMark(size = 48.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = strings.appTitle,
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary,
                            )
                            Text(
                                text = strings.appSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    StatusBadge(
                        isActive = isRunning,
                        text = if (isRunning) strings.statusActive else strings.statusStopped,
                    )
                }

                // Hero Control Card with Big Primary Toggle Button
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isRunning) StopCoral.copy(alpha = 0.45f) else NavyBorder,
                    ),
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Button(
                            onClick = onToggleOverlay,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .testTag("toggle_overlay_button"),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = buttonColor,
                                contentColor = buttonContentColor,
                            ),
                        ) {
                            Icon(
                                imageVector = if (isRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                contentDescription = if (isRunning) strings.stopOverlayButton else strings.startOverlayButton,
                                modifier = Modifier.size(28.dp),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isRunning) strings.stopOverlayButton else strings.startOverlayButton,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            )
                        }

                        Text(
                            text = strings.overlayControlHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }

                // Live Preview Card
                LiveOverlayPreviewCard(
                    settings = uiState.settings,
                    snapshot = uiState.snapshot,
                    strings = strings,
                )

                // Honest Sensor Sources Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = strings.sensorTransparencyTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )
                        SensorSourceRow(
                            label = "CPU",
                            detail = strings.cpuSourceLabel(uiState.snapshot.cpuSource),
                        )
                        SensorSourceRow(
                            label = "TMP",
                            detail = strings.tempSourceLabel(
                                uiState.snapshot.tempSource,
                                uiState.snapshot.tempZoneLabel,
                            ),
                        )
                        SensorSourceRow(
                            label = "FPS",
                            detail = strings.fpsSourceLabel(uiState.snapshot.fpsSource),
                        )
                    }
                }

                // Permissions Status Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = NavySurface,
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = strings.permissionsTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                        )

                        PermissionRow(
                            icon = Icons.Outlined.Layers,
                            title = strings.overlayPermTitle,
                            description = strings.overlayPermDesc,
                            isGranted = uiState.permissions.hasOverlayPermission,
                            badgeText = if (uiState.permissions.hasOverlayPermission) {
                                strings.permGranted
                            } else {
                                strings.permRequired
                            },
                            actionText = strings.permGrantBtn,
                            onAction = onRequestOverlayPermission,
                            testTag = "grant_overlay_perm_button",
                        )

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            HorizontalDivider(color = NavyBorder)
                            PermissionRow(
                                icon = Icons.Outlined.Notifications,
                                title = strings.notifPermTitle,
                                description = strings.notifPermDesc,
                                isGranted = uiState.permissions.hasNotificationPermission,
                                badgeText = if (uiState.permissions.hasNotificationPermission) {
                                    strings.permGranted
                                } else {
                                    strings.permOptional
                                },
                                actionText = strings.permGrantBtn,
                                onAction = onRequestNotificationPermission,
                                testTag = "grant_notif_perm_button",
                            )
                        }

                        HorizontalDivider(color = NavyBorder)
                        PermissionRow(
                            icon = Icons.Outlined.BatteryAlert,
                            title = strings.batteryOptTitle,
                            description = strings.batteryOptDesc,
                            isGranted = uiState.permissions.isBatteryOptimizationIgnored,
                            badgeText = if (uiState.permissions.isBatteryOptimizationIgnored) {
                                strings.permGranted
                            } else {
                                strings.permOptional
                            },
                            actionText = strings.permConfigureBtn,
                            onAction = onOpenBatterySettings,
                            testTag = "battery_opt_button",
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(
    isActive: Boolean,
    text: String,
) {
    val dotColor = if (isActive) TurquoisePrimary else TextSecondary
    val bgColor = if (isActive) TurquoisePrimary.copy(alpha = 0.14f) else NavyElevated
    val borderColor = if (isActive) TurquoisePrimary.copy(alpha = 0.4f) else NavyBorder

    Surface(
        shape = RoundedCornerShape(999.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor),
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = if (isActive) TurquoisePrimary else TextSecondary,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun SensorSourceRow(
    label: String,
    detail: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Surface(
            color = NavyElevated,
            shape = RoundedCornerShape(6.dp),
        ) {
            Text(
                text = label,
                fontFamily = JetBrainsMonoFamily,
                style = MaterialTheme.typography.labelMedium,
                color = TurquoisePrimary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
        Text(
            text = detail,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    title: String,
    description: String,
    isGranted: Boolean,
    badgeText: String,
    actionText: String,
    onAction: () -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isGranted) TurquoisePrimary else WarningAmber,
            modifier = Modifier.size(22.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Icon(
                    imageVector = if (isGranted) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
                    contentDescription = badgeText,
                    tint = if (isGranted) TurquoisePrimary else WarningAmber,
                    modifier = Modifier.size(16.dp),
                )
            }
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
        }
        if (!isGranted) {
            OutlinedButton(
                onClick = onAction,
                modifier = Modifier.testTag(testTag),
                border = BorderStroke(1.dp, TurquoisePrimary.copy(alpha = 0.6f)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    text = actionText,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = TurquoisePrimary,
                )
            }
        }
    }
}
