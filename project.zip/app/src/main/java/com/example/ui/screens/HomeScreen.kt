package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AiStatus
import com.example.domain.model.AssistantSettings
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.ConversationMessage
import com.example.domain.model.MicStatus
import com.example.domain.model.OperatingMode
import com.example.domain.model.PendingConfirmation
import com.example.ui.components.ActivityLogItemCard
import com.example.ui.components.ConversationMessageCard
import com.example.ui.components.PendingConfirmationCard
import com.example.ui.components.StatusSummaryGrid
import com.example.ui.components.VoiceOrbButton
import com.example.ui.theme.LocalYahyaColors

@Composable
fun HomeScreen(
    settings: AssistantSettings,
    hasApiKey: Boolean,
    hasInternet: Boolean,
    assistantPowerEnabled: Boolean,
    aiStatus: AiStatus,
    micStatus: MicStatus,
    partialTranscript: String,
    rmsLevel: Float,
    isForegroundServiceRunning: Boolean,
    pendingConfirmation: PendingConfirmation?,
    conversation: List<ConversationMessage>,
    logs: List<CommandExecutionLog>,
    onToggleAssistantPower: () -> Unit,
    onMicClick: () -> Unit,
    onSendManualText: (String) -> Unit,
    onApproveConfirmation: () -> Unit,
    onRejectConfirmation: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onClearConversation: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val yColors = LocalYahyaColors.current
    var manualInput by rememberSaveable { mutableStateOf("") }
    var selectedFeedTab by rememberSaveable { mutableIntStateOf(0) } // 0 = Chat, 1 = System Logs

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Header Row with Official App Name (HXZ AI) & Assistant Power Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = AssistantSettings.APP_OFFICIAL_NAME,
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                        )
                        Surface(
                            color = yColors.accentTealSoft,
                            shape = MaterialTheme.shapes.small,
                        ) {
                            Text(
                                text = settings.assistantName,
                                style = MaterialTheme.typography.labelLarge,
                                color = yColors.accentTeal,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Surface(
                            color = yColors.surfaceElevated,
                            shape = MaterialTheme.shapes.small,
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Hearing,
                                    contentDescription = "كلمة التنبيه",
                                    tint = yColors.accentTeal,
                                    modifier = Modifier.size(14.dp),
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = if (settings.operatingMode == OperatingMode.WAKE_WORD) {
                                        "استدعاء: \"${settings.wakePhrase}\""
                                    } else {
                                        "وضع الضغط للتحدث"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = yColors.accentTeal,
                                )
                            }
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Surface(
                        onClick = onToggleAssistantPower,
                        color = if (assistantPowerEnabled) yColors.onlineContainer else yColors.surfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (assistantPowerEnabled) yColors.online else yColors.borderSubtle,
                        ),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("assistant_power_toggle"),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PowerSettingsNew,
                                contentDescription = if (assistantPowerEnabled) "إيقاف المساعد" else "تشغيل المساعد",
                                tint = if (assistantPowerEnabled) yColors.online else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (assistantPowerEnabled) "مُفعّل" else "متوقف",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (assistantPowerEnabled) yColors.online else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("home_settings_shortcut"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "الإعدادات",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // Missing Gemini API Key Banner
        if (!hasApiKey) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = yColors.warningContainer.copy(alpha = 0.45f)),
                    border = BorderStroke(1.dp, yColors.warning.copy(alpha = 0.7f)),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Key,
                            contentDescription = null,
                            tint = yColors.warning,
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "أضف مفتاح Gemini API لتفعيل الذكاء الاصطناعي",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = "يُحفظ المفتاح مشفراً محلياً على جهازك.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Button(
                            onClick = onNavigateToSettings,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = yColors.warning,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                            ),
                            modifier = Modifier.height(40.dp),
                        ) {
                            Text("إعداد", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Standalone AI & Mic Status Cards
        item {
            StatusSummaryGrid(
                aiStatus = aiStatus,
                hasApiKey = hasApiKey,
                hasInternet = hasInternet,
                geminiModelId = settings.geminiModelId,
                micStatus = micStatus,
                isForegroundServiceRunning = isForegroundServiceRunning,
                onOpenSettings = onNavigateToSettings,
            )
        }

        // Sensitive Action Safety Confirmation Banner
        item {
            AnimatedVisibility(visible = pendingConfirmation != null) {
                pendingConfirmation?.let { pending ->
                    PendingConfirmationCard(
                        pending = pending,
                        onApprove = onApproveConfirmation,
                        onReject = onRejectConfirmation,
                    )
                }
            }
        }

        // Centerpiece Voice Orb & Direct Text Input
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                border = BorderStroke(1.dp, yColors.borderSubtle),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 18.dp, horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    VoiceOrbButton(
                        micStatus = micStatus,
                        aiStatus = aiStatus,
                        rmsLevel = rmsLevel,
                        assistantName = settings.assistantName,
                        wakePhrase = settings.wakePhrase,
                        operatingMode = settings.operatingMode,
                        onClick = onMicClick,
                    )

                    AnimatedVisibility(visible = partialTranscript.isNotBlank()) {
                        Surface(
                            color = yColors.surfaceElevated,
                            shape = MaterialTheme.shapes.medium,
                            border = BorderStroke(1.dp, yColors.accentTeal.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 14.dp, start = 6.dp, end = 6.dp),
                        ) {
                            Text(
                                text = partialTranscript,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(14.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedTextField(
                            value = manualInput,
                            onValueChange = { manualInput = it },
                            placeholder = { Text("اكتب طلبك أو سؤالك لمساعد ${settings.assistantName}...") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = yColors.accentTeal,
                                unfocusedBorderColor = yColors.borderSubtle,
                                focusedContainerColor = yColors.surfaceDeep,
                                unfocusedContainerColor = yColors.surfaceDeep,
                            ),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("manual_command_input"),
                        )
                        Surface(
                            onClick = {
                                if (manualInput.isNotBlank()) {
                                    onSendManualText(manualInput)
                                    manualInput = ""
                                }
                            },
                            color = if (manualInput.isNotBlank()) yColors.accentTeal else yColors.surfaceElevated,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .size(52.dp)
                                .testTag("send_manual_command_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = "إرسال الطلب",
                                tint = if (manualInput.isNotBlank()) {
                                    MaterialTheme.colorScheme.onPrimary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.padding(14.dp),
                            )
                        }
                    }
                }
            }
        }

        // Conversation & Execution Feed Header + Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedFeedTab == 0,
                        onClick = { selectedFeedTab = 0 },
                        label = { Text("المحادثة (${conversation.size})") },
                        modifier = Modifier.testTag("tab_conversation_feed"),
                    )
                    FilterChip(
                        selected = selectedFeedTab == 1,
                        onClick = { selectedFeedTab = 1 },
                        label = { Text("السجل (${logs.size})") },
                        modifier = Modifier.testTag("tab_system_logs"),
                    )
                }

                if (conversation.isNotEmpty() || logs.isNotEmpty()) {
                    TextButton(
                        onClick = onClearConversation,
                        modifier = Modifier.testTag("clear_logs_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteSweep,
                            contentDescription = "مسح المحادثة والسجل",
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مسح")
                    }
                }
            }
        }

        if (selectedFeedTab == 0) {
            if (conversation.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                        border = BorderStroke(1.dp, yColors.borderSubtle),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = yColors.accentTeal.copy(alpha = 0.7f),
                                modifier = Modifier.size(32.dp),
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "مرحباً بك في ${AssistantSettings.APP_OFFICIAL_NAME}",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "اضغط زر الميكروفون أو اكتب سؤالك ليقوم ${settings.assistantName} بالرد وتنفيذ الأوامر على هاتفك.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            } else {
                items(conversation.asReversed(), key = { it.id }) { msg ->
                    ConversationMessageCard(
                        message = msg,
                        assistantName = settings.assistantName,
                        onOpenSourceUrl = { url ->
                            runCatching {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            }
                        },
                    )
                }
            }
        } else {
            if (logs.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = yColors.surfaceCard),
                        border = BorderStroke(1.dp, yColors.borderSubtle),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = "لا توجد أحداث مسجلة بعد.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(20.dp),
                        )
                    }
                }
            } else {
                items(logs, key = { it.id }) { entry ->
                    ActivityLogItemCard(item = entry)
                }
            }
        }
    }
}
