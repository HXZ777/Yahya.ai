package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.BuildEngineMode
import com.example.domain.model.BuildEngineSettings
import com.example.domain.model.ProjectInspection
import com.example.domain.model.ZipSelectionInfo
import com.example.domain.util.Formatters
import com.example.ui.MainUiState
import com.example.ui.components.EssentialFileRow
import com.example.ui.components.SpecMetricTile
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.TempCacheBar
import com.example.ui.components.ZipToApkLogoBadge
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianOutlineSubtle
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceHighlight
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    uiState: MainUiState,
    settings: BuildEngineSettings,
    contentPadding: PaddingValues,
    onSelectZipClick: () -> Unit,
    onBuildApkClick: () -> Unit,
    onClearProject: () -> Unit,
    onCleanCache: () -> Unit,
    onOpenEngineSettings: () -> Unit,
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            EmeraldPrimary.copy(alpha = 0.14f),
                            Color.Transparent,
                        ),
                        center = Offset(size.width * 0.15f, size.height * 0.08f),
                        radius = size.maxDimension * 0.55f,
                    ),
                )
            },
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(contentPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // 1. الشعار وزر محرك البناء
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    ZipToApkLogoBadge(size = 48.dp)
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                        )
                        Text(
                            text = if (settings.mode == BuildEngineMode.REMOTE_RUNNER) {
                                "الوضع: خادم Gradle الخاص"
                            } else {
                                "فحص وبناء مشاريع أندرويد"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldBright,
                        )
                    }
                }

                Surface(
                    onClick = onOpenEngineSettings,
                    shape = RoundedCornerShape(12.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, ObsidianOutline),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("open_engine_settings_button"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = "إعدادات محرك البناء",
                            tint = EmeraldBright,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = stringResource(R.string.action_build_settings),
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary,
                        )
                    }
                }
            }

            // 2. البطاقة الرئيسية البسيطة
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = ObsidianSurface,
                border = BorderStroke(1.dp, ObsidianOutline),
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    StatusBadgePill(
                        text = "بيئة معزولة آمنة • خصوصية كاملة",
                        accentColor = EmeraldBright,
                        containerColor = EmeraldContainer.copy(alpha = 0.7f),
                        icon = Icons.Filled.VerifiedUser,
                    )

                    Text(
                        text = stringResource(R.string.home_headline),
                        style = MaterialTheme.typography.displaySmall,
                        color = TextPrimary,
                    )

                    Text(
                        text = stringResource(R.string.home_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = onSelectZipClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("select_zip_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldPrimary,
                            contentColor = OnEmerald,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.action_select_zip),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                    }
                }
            }

            // حالة جاري الفحص
            AnimatedVisibility(
                visible = uiState.isInspecting,
                enter = fadeIn() + expandVertically(),
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.45f)),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = "جاري فك الضغط وفحص المشروع...",
                            style = MaterialTheme.typography.titleSmall,
                            color = EmeraldBright,
                        )
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = EmeraldPrimary,
                            trackColor = ObsidianSurfaceHighlight,
                        )
                        Text(
                            text = "يتم التحقق من أمان الملفات وفحص ملفات Gradle وManifest والمكتبات.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }
            }

            // خطأ في الأرشيف
            if (uiState.inspectionError != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = ErrorContainer,
                    border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f)),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = ErrorRed,
                            modifier = Modifier.size(20.dp),
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "تعذر فحص ملف ZIP",
                                style = MaterialTheme.typography.titleSmall,
                                color = ErrorRed,
                            )
                            Text(
                                text = uiState.inspectionError,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                            )
                        }
                    }
                }
            }

            // معلومات الملف المختار ونتيجة الفحص
            val selection = uiState.zipSelection
            val inspection = uiState.projectInspection
            if (selection != null) {
                SelectedZipCard(
                    selection = selection,
                    onClear = onClearProject,
                )
            }

            if (inspection != null) {
                ProjectInspectionCard(inspection = inspection)

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.45f)),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "جاهز لبدء عملية البناء",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                )
                                Text(
                                    text = if (settings.mode == BuildEngineMode.REMOTE_RUNNER) {
                                        "المحرك: خادم Gradle (${settings.buildVariant})"
                                    } else {
                                        val localReady = uiState.deviceProbe?.localToolchainReady == true
                                        if (localReady) "المحرك: أدوات البناء المحلية"
                                        else "المحرك: فحص بيئة الهاتف (Android SDK غير متوفر محليًا)"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            if (settings.mode == BuildEngineMode.LOCAL_DEVICE &&
                                uiState.deviceProbe?.localToolchainReady == false
                            ) {
                                OutlinedButton(
                                    onClick = onOpenEngineSettings,
                                    border = BorderStroke(1.dp, ObsidianOutline),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                ) {
                                    Text(
                                        text = "إعداد الخادم",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = EmeraldBright,
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = onBuildApkClick,
                            enabled = !uiState.isInspecting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("build_apk_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldPrimary,
                                contentColor = OnEmerald,
                            ),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Build,
                                contentDescription = null,
                                modifier = Modifier.size(19.dp),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = stringResource(R.string.action_build_apk),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            )
                        }
                    }
                }
            } else if (!uiState.isInspecting && uiState.inspectionError == null) {
                EmptyProjectGuideCard(onOpenEngineSettings = onOpenEngineSettings)
            }

            if (uiState.tempStorageBytes > 0L) {
                TempCacheBar(
                    tempBytes = uiState.tempStorageBytes,
                    onCleanCache = onCleanCache,
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SelectedZipCard(
    selection: ZipSelectionInfo,
    onClear: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("selected_zip_card"),
        shape = RoundedCornerShape(16.dp),
        color = ObsidianSurfaceElevated,
        border = BorderStroke(1.dp, ObsidianOutline),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(EmeraldContainer, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderZip,
                        contentDescription = null,
                        tint = EmeraldBright,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = selection.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "الحجم: ${Formatters.formatBytes(selection.sizeBytes)} • مستورد في البيئة المعزولة",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                }
            }
            IconButton(
                onClick = onClear,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("clear_zip_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "إزالة المشروع المختار",
                    tint = TextSecondary,
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProjectInspectionCard(inspection: ProjectInspection) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("project_inspection_card"),
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurface,
        border = BorderStroke(
            1.dp,
            if (inspection.isValidAndroidProject) EmeraldPrimary.copy(alpha = 0.4f) else AmberWarning.copy(alpha = 0.5f),
        ),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = inspection.projectName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = inspection.applicationId ?: inspection.namespace ?: "الجذر: ${inspection.projectRootRelativePath}",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldBright,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                StatusBadgePill(
                    text = inspection.projectType.displayLabel,
                    accentColor = if (inspection.isValidAndroidProject) EmeraldBright else AmberWarning,
                    containerColor = if (inspection.isValidAndroidProject) EmeraldContainer else AmberContainer,
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (inspection.isValidAndroidProject) {
                    EmeraldContainer.copy(alpha = 0.45f)
                } else {
                    AmberContainer.copy(alpha = 0.65f)
                },
            ) {
                Text(
                    text = inspection.readinessSummary,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    modifier = Modifier.padding(12.dp),
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SpecMetricTile(
                    label = "Gradle",
                    value = inspection.gradleVersion ?: "غير محدد",
                    highlight = inspection.gradleVersion != null,
                    modifier = Modifier.weight(1f),
                )
                SpecMetricTile(
                    label = "Java / JVM",
                    value = inspection.javaCompatibility ?: "افتراضي",
                    modifier = Modifier.weight(1f),
                )
                SpecMetricTile(
                    label = "Compile SDK",
                    value = inspection.compileSdk?.let { "API $it" } ?: "غير محدد",
                    modifier = Modifier.weight(1f),
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SpecMetricTile(
                    label = "AGP / Kotlin",
                    value = listOfNotNull(
                        inspection.agpVersion?.let { "AGP $it" },
                        inspection.kotlinVersion?.let { "KT $it" },
                    ).joinToString(" • ").ifBlank { "قياسي" },
                    modifier = Modifier.weight(1f),
                )
                SpecMetricTile(
                    label = "ملفات الكود",
                    value = "${inspection.kotlinFileCount} kt / ${inspection.javaFileCount} java",
                    modifier = Modifier.weight(1f),
                )
            }

            if (inspection.detectedDependencies.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "المكتبات المطلوبة في المشروع (${inspection.detectedDependencies.size})",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        inspection.detectedDependencies.take(8).forEach { dep ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = ObsidianSurfaceHighlight,
                                border = BorderStroke(1.dp, ObsidianOutlineSubtle),
                            ) {
                                Text(
                                    text = dep,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = ObsidianOutlineSubtle)

            Text(
                text = "الملفات الأساسية للمشروع",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
            )

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                inspection.essentialFiles.forEach { fileStatus ->
                    EssentialFileRow(item = fileStatus)
                }
            }

            if (inspection.embeddedApkPaths.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ObsidianSurfaceHighlight,
                    border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f)),
                ) {
                    Text(
                        text = "تم العثور على ${inspection.embeddedApkPaths.size} ملف APK جاهز داخل الأرشيف: ${inspection.embeddedApkPaths.first()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = EmeraldBright,
                        modifier = Modifier.padding(10.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyProjectGuideCard(onOpenEngineSettings: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurface,
        border = BorderStroke(1.dp, ObsidianOutlineSubtle),
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Description,
                    contentDescription = null,
                    tint = EmeraldBright,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = "كيف يعمل التطبيق؟",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                )
            }
            Text(
                text = "1. اختر ملف مشروع Android Studio المضغوط بصيغة ZIP.\n" +
                    "2. يفك التطبيق الضغط داخل بيئة معزولة آمنة ويفحص ملفات Gradle والمكتبات والملفات الأساسية.\n" +
                    "3. اضغط بناء APK للتحقق من بيئة البناء أو الترجمة عبر خادم Gradle الخاص بك لإنتاج ملف APK موقّع وقابل للتثبيت.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
            OutlinedButton(
                onClick = onOpenEngineSettings,
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(12.dp),
            ) {
                Text("فحص أدوات البناء وإعداد الخادم", color = EmeraldBright)
            }
        }
    }
}
