package com.example

import android.app.Application
import com.example.app.CompanionCoordinator

class YahyaCompanionApp : Application() {

    lateinit var coordinator: CompanionCoordinator
        private set

    override fun onCreate() {
        super.onCreate()
        coordinator = CompanionCoordinator(this)
    }
}
