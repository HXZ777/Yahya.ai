package com.example

import android.app.Application
import com.example.app.AssistantCoordinator

class YahyaCompanionApp : Application() {

    lateinit var coordinator: AssistantCoordinator
        private set

    override fun onCreate() {
        super.onCreate()
        coordinator = AssistantCoordinator(this)
    }
}
