package com.example.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import com.example.accessibility.DeviceCommandExecutor
import com.example.accessibility.YahyaAccessibilityService
import com.example.data.ai.AiGateway
import com.example.data.ai.AiTurnOutcome
import com.example.data.ai.AiTurnToolCall
import com.example.data.ai.GeminiAssistantRepository
import com.example.data.ai.ToolExecutionReport
import com.example.data.preferences.SettingsRepository
import com.example.data.security.ApiKeyVault
import com.example.domain.model.AccessibilityHealth
import com.example.domain.model.AiConnectionTestResult
import com.example.domain.model.AiStatus
import com.example.domain.model.AssistantCommand
import com.example.domain.model.AssistantSettings
import com.example.domain.model.ChatRole
import com.example.domain.model.CloudModelOption
import com.example.domain.model.CommandExecutionLog
import com.example.domain.model.ConversationMessage
import com.example.domain.model.ListeningMode
import com.example.domain.model.LogDirection
import com.example.domain.model.LogStatus
import com.example.domain.model.MicStatus
import com.example.domain.model.OperatingMode
import com.example.domain.model.PendingConfirmation
import com.example.domain.model.TtsVoiceOption
import com.example.domain.model.WebSource
import com.example.domain.policy.CommandSafetyPolicy
import com.example.domain.policy.SensitiveInputFilter
import com.example.domain.voice.ArabicWakeMatcher
import com.example.engine.YahyaCommandEngine
import com.example.voice.ArabicSpeechEngine
import com.example.voice.ArabicTtsEngine
import com.example.voice.FloatingMicOverlayService
import com.example.voice.VoiceListenerForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AssistantCoordinator(
    private val context: Context,
    private val aiGateway: AiGateway = GeminiAssistantRepository(),
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val settingsRepository = SettingsRepository(context)
    val apiKeyVault = ApiKeyVault(context)
    val ttsEngine = ArabicTtsEngine(context)
    private val deviceExecutor = DeviceCommandExecutor(context, ttsEngine)
    private val commandEngine = YahyaCommandEngine(deviceExecutor, aiGateway)

    private val _settings = MutableStateFlow(AssistantSettings())
    val settings: StateFlow<AssistantSettings> = _settings.asStateFlow()

    private val _hasApiKey = MutableStateFlow(false)
    val hasApiKey: StateFlow<Boolean> = _hasApiKey.asStateFlow()

    private val _maskedApiKey = MutableStateFlow("")
    val maskedApiKey: StateFlow<String> = _maskedApiKey.asStateFlow()

    private val _hasInternet = MutableStateFlow(checkInternetAvailable())
    val hasInternet: StateFlow<Boolean> = _hasInternet.asStateFlow()

    private val _assistantPowerEnabled = MutableStateFlow(false)
    val assistantPowerEnabled: StateFlow<Boolean> = _assistantPowerEnabled.asStateFlow()

    private val _aiStatus = MutableStateFlow(AiStatus.MISSING_API_KEY)
    val aiStatus: StateFlow<AiStatus> = _aiStatus.asStateFlow()

    private val _lastAiError = MutableStateFlow<String?>(null)
    val lastAiError: StateFlow<String?> = _lastAiError.asStateFlow()

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    private val _connectionTestResult = MutableStateFlow<AiConnectionTestResult?>(null)
    val connectionTestResult: StateFlow<AiConnectionTestResult?> = _connectionTestResult.asStateFlow()

    private val _availableCloudModels = MutableStateFlow<List<CloudModelOption>>(emptyList())
    val availableCloudModels: StateFlow<List<CloudModelOption>> = _availableCloudModels.asStateFlow()

    private val _isFetchingModels = MutableStateFlow(false)
    val isFetchingModels: StateFlow<Boolean> = _isFetchingModels.asStateFlow()

    private val _modelsFetchError = MutableStateFlow<String?>(null)
    val modelsFetchError: StateFlow<String?> = _modelsFetchError.asStateFlow()

    private val _conversation = MutableStateFlow<List<ConversationMessage>>(emptyList())
    val conversation: StateFlow<List<ConversationMessage>> = _conversation.asStateFlow()

    private val _logs = MutableStateFlow<List<CommandExecutionLog>>(emptyList())
    val logs: StateFlow<List<CommandExecutionLog>> = _logs.asStateFlow()

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation.asStateFlow()

    private val _accessibilityHealth = MutableStateFlow(YahyaAccessibilityService.currentHealth(context))
    val accessibilityHealth: StateFlow<AccessibilityHealth> = _accessibilityHealth.asStateFlow()

    private val _canDrawOverlays = MutableStateFlow(Settings.canDrawOverlays(context))
    val canDrawOverlays: StateFlow<Boolean> = _canDrawOverlays.asStateFlow()

    private var awaitingCommandAfterWake: Boolean = false
    private var isThinking: Boolean = false
    private var isExecutingTool: Boolean = false

    private val pendingToolQueue = ArrayDeque<AiTurnToolCall>()
    private val accumulatedToolReports = mutableListOf<ToolExecutionReport>()
    private var awaitingConfirmedCall: AiTurnToolCall? = null
    private var currentTurnRounds: Int = 0
    private var currentTurnSources = LinkedHashMap<String, WebSource>()

    val speechEngine = ArabicSpeechEngine(
        context = context,
        onTranscriptReady = { transcript, mode ->
            handleRecognizedSpeech(transcript, mode)
        },
        onStatusLog = { title, detail, isError ->
            appendLog(
                direction = LogDirection.SYSTEM,
                title = title,
                detail = detail,
                status = if (isError) LogStatus.FAILED else LogStatus.INFO,
            )
        },
        onSessionEnded = {
            if (VoiceListenerForegroundService.isRunning.value) {
                VoiceListenerForegroundService.stop(context)
            }
        },
    )

    val micStatus: StateFlow<MicStatus> = speechEngine.micStatus
    val isMicListening: StateFlow<Boolean> = speechEngine.isListeningActive
    val partialTranscript: StateFlow<String> = speechEngine.partialTranscript
    val rmsLevel: StateFlow<Float> = speechEngine.rmsLevel
    val isForegroundServiceRunning: StateFlow<Boolean> = VoiceListenerForegroundService.isRunning
    val isSystemOverlayRunning: StateFlow<Boolean> = FloatingMicOverlayService.isRunning
    val availableTtsVoices: StateFlow<List<TtsVoiceOption>> = ttsEngine.availableVoices

    private val connectivityManager =
        runCatching { context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager }.getOrNull()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _hasInternet.value = checkInternetAvailable()
            recomputeAiStatus()
        }

        override fun onLost(network: Network) {
            _hasInternet.value = checkInternetAvailable()
            recomputeAiStatus()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            _hasInternet.value = checkInternetAvailable()
            recomputeAiStatus()
        }
    }

    init {
        VoiceListenerForegroundService.onStopRequestedCallback = {
            stopMicrophone()
        }

        runCatching {
            connectivityManager?.registerDefaultNetworkCallback(networkCallback)
        }

        scope.launch {
            settingsRepository.settingsFlow.collect { updated ->
                _settings.value = updated
                ttsEngine.setSpeechRate(updated.speechRate)
                ttsEngine.setVoice(updated.ttsVoiceName)
                if (updated.systemOverlayEnabled && Settings.canDrawOverlays(context) && !FloatingMicOverlayService.isRunning.value) {
                    FloatingMicOverlayService.start(context)
                }
            }
        }

        scope.launch {
            apiKeyVault.hasApiKeyFlow.collect { present ->
                _hasApiKey.value = present
                recomputeAiStatus()
            }
        }

        scope.launch {
            apiKeyVault.maskedApiKeyFlow.collect { masked ->
                _maskedApiKey.value = masked
            }
        }

        scope.launch {
            ttsEngine.isSpeaking.collect {
                recomputeAiStatus()
            }
        }

        scope.launch {
            YahyaAccessibilityService.isBound.collect {
                refreshDeviceHealth()
            }
        }
    }

    private fun checkInternetAvailable(): Boolean {
        val cm = connectivityManager ?: return false
        return runCatching {
            val active = cm.activeNetwork ?: return@runCatching false
            val caps = cm.getNetworkCapabilities(active) ?: return@runCatching false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }.getOrDefault(false)
    }

    private fun recomputeAiStatus() {
        _aiStatus.value = when {
            !_hasApiKey.value -> AiStatus.MISSING_API_KEY
            !_hasInternet.value -> AiStatus.NO_INTERNET
            isExecutingTool -> AiStatus.EXECUTING
            isThinking -> AiStatus.THINKING
            ttsEngine.isSpeaking.value -> AiStatus.SPEAKING
            _lastAiError.value != null -> AiStatus.ERROR
            else -> AiStatus.READY
        }
    }

    fun refreshDeviceHealth() {
        speechEngine.refreshAvailability()
        ttsEngine.refreshAvailableArabicVoices()
        _accessibilityHealth.value = YahyaAccessibilityService.currentHealth(context)
        _hasInternet.value = checkInternetAvailable()
        val overlayAllowed = Settings.canDrawOverlays(context)
        _canDrawOverlays.value = overlayAllowed
        if (_settings.value.systemOverlayEnabled && overlayAllowed && !FloatingMicOverlayService.isRunning.value) {
            FloatingMicOverlayService.start(context)
        } else if (!overlayAllowed && FloatingMicOverlayService.isRunning.value) {
            FloatingMicOverlayService.stop(context)
        }
        recomputeAiStatus()
    }

    fun setAssistantPower(enabled: Boolean) {
        _assistantPowerEnabled.value = enabled
        if (enabled) {
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم تشغيل المساعد (${_settings.value.assistantName})",
                detail = if (_settings.value.operatingMode == OperatingMode.WAKE_WORD) {
                    "وضع الاستدعاء نشط لكلمة \"${_settings.value.wakePhrase}\""
                } else {
                    "وضع الضغط للتحدث جاهز."
                },
                status = LogStatus.INFO,
            )
            if (_settings.value.operatingMode == OperatingMode.WAKE_WORD && speechEngine.hasRecordPermission()) {
                startListeningWithMode(ListeningMode.CONTINUOUS_WAKE)
            }
        } else {
            stopMicrophone()
            ttsEngine.stop()
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم إيقاف المساعد",
                detail = "الميكروفون مكتوم والنطق متوقف.",
                status = LogStatus.INFO,
            )
        }
    }

    fun toggleAssistantPower() {
        setAssistantPower(!_assistantPowerEnabled.value)
    }

    fun setSystemOverlayEnabled(enabled: Boolean) {
        scope.launch {
            settingsRepository.updateSystemOverlayEnabled(enabled)
            if (enabled && Settings.canDrawOverlays(context)) {
                FloatingMicOverlayService.start(context)
                appendLog(
                    direction = LogDirection.SYSTEM,
                    title = "تم تفعيل الزر العائم فوق التطبيقات",
                    detail = "يمكنك الآن تشغيل وكتم ${_settings.value.assistantName} من فوق أي تطبيق.",
                    status = LogStatus.INFO,
                )
            } else {
                FloatingMicOverlayService.stop(context)
            }
        }
    }

    fun toggleMicrophone() {
        if (isCurrentlyListening()) {
            stopMicrophone()
        } else {
            startMicrophone()
        }
    }

    fun toggleDirectMicrophone() {
        if (isCurrentlyListening()) {
            stopMicrophone()
        } else {
            startDirectListening()
        }
    }

    private fun isCurrentlyListening(): Boolean {
        val current = speechEngine.micStatus.value
        return speechEngine.isListeningActive.value ||
            current == MicStatus.LISTENING ||
            current == MicStatus.WAKE_ARMED ||
            current == MicStatus.PROCESSING
    }

    fun startMicrophone() {
        ttsEngine.stop()
        val currentSettings = _settings.value
        val mode = if (currentSettings.operatingMode == OperatingMode.WAKE_WORD) {
            _assistantPowerEnabled.value = true
            ListeningMode.CONTINUOUS_WAKE
        } else {
            _assistantPowerEnabled.value = true
            ListeningMode.PUSH_TO_TALK
        }
        startListeningWithMode(mode)
    }

    fun startDirectListening() {
        ttsEngine.stop()
        _assistantPowerEnabled.value = true
        startListeningWithMode(ListeningMode.DIRECT_CONTINUOUS)
    }

    private fun startListeningWithMode(mode: ListeningMode) {
        val currentSettings = _settings.value
        if (!speechEngine.hasRecordPermission()) {
            speechEngine.refreshAvailability()
            return
        }
        awaitingCommandAfterWake = false
        if (currentSettings.foregroundServiceEnabled) {
            val notifText = when (mode) {
                ListeningMode.CONTINUOUS_WAKE -> "في انتظار كلمة التنبيه: \"${currentSettings.wakePhrase}\""
                ListeningMode.DIRECT_CONTINUOUS -> "${currentSettings.assistantName} يستمع للأوامر الصوتية الآن..."
                ListeningMode.PUSH_TO_TALK -> "جاري الاستماع باللغة العربية..."
            }
            VoiceListenerForegroundService.startOrUpdate(context, notifText)
        }
        speechEngine.startListening(
            language = currentSettings.speechLanguage,
            mode = mode,
            awaitingFollowUpAfterWake = false,
        )
    }

    fun stopMicrophone() {
        awaitingCommandAfterWake = false
        speechEngine.stopListening()
        if (VoiceListenerForegroundService.isRunning.value) {
            VoiceListenerForegroundService.stop(context)
        }
    }

    fun logMicPermissionDenied() {
        speechEngine.refreshAvailability()
        appendLog(
            direction = LogDirection.SYSTEM,
            title = "تم رفض صلاحية الميكروفون",
            detail = "يتطلب الاستماع الصوتي السماح بالوصول إلى الميكروفون من إعدادات التطبيق.",
            status = LogStatus.FAILED,
        )
    }

    fun sendManualTextTranscript(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        if (!_assistantPowerEnabled.value) {
            _assistantPowerEnabled.value = true
        }
        processUserPrompt(clean)
    }

    private fun handleRecognizedSpeech(transcript: String, mode: ListeningMode) {
        val currentSettings = _settings.value
        if (mode == ListeningMode.PUSH_TO_TALK) {
            if (VoiceListenerForegroundService.isRunning.value) {
                VoiceListenerForegroundService.stop(context)
            }
            processUserPrompt(transcript)
            return
        }

        if (mode == ListeningMode.DIRECT_CONTINUOUS) {
            processUserPrompt(transcript)
            return
        }

        // Wake-Word Mode
        if (awaitingCommandAfterWake) {
            awaitingCommandAfterWake = false
            processUserPrompt(transcript)
            return
        }

        val wakeMatch = ArabicWakeMatcher.matchWakePhrase(transcript, currentSettings.wakePhrase)
        if (!wakeMatch.matched) {
            speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
            return
        }

        if (wakeMatch.remainingCommand.isNotBlank()) {
            processUserPrompt(wakeMatch.remainingCommand)
        } else {
            awaitingCommandAfterWake = true
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم التقاط كلمة التنبيه",
                detail = "\"${currentSettings.wakePhrase}\" — في انتظار أمرك الصوتي...",
                status = LogStatus.INFO,
            )
            if (currentSettings.foregroundServiceEnabled) {
                VoiceListenerForegroundService.startOrUpdate(
                    context,
                    "تحدث الآن — في انتظار الأمر بعد \"${currentSettings.wakePhrase}\"",
                )
            }
            speechEngine.continueListeningCycle(awaitFollowUpCommand = true)
        }
    }

    private fun processUserPrompt(rawPrompt: String) {
        val sanitizedPrompt = SensitiveInputFilter.redactSensitiveText(rawPrompt.trim())
        if (sanitizedPrompt.isBlank()) return

        _lastAiError.value = null
        currentTurnSources.clear()
        pendingToolQueue.clear()
        accumulatedToolReports.clear()
        awaitingConfirmedCall = null
        currentTurnRounds = 0

        appendChatMessage(
            ConversationMessage(
                role = ChatRole.USER,
                text = sanitizedPrompt,
            ),
        )
        appendLog(
            direction = LogDirection.OUTBOUND_SPEECH,
            title = "طلب المستخدم",
            detail = sanitizedPrompt,
            status = LogStatus.SENT,
        )

        scope.launch {
            val apiKey = apiKeyVault.getApiKey()
            if (apiKey.isNullOrBlank()) {
                val msg = "مفتاح Gemini API غير مُعدّ بعد. انتقل إلى الإعدادات لإدخال المفتاح وتشغيل الذكاء الاصطناعي."
                _lastAiError.value = msg
                recomputeAiStatus()
                appendChatMessage(ConversationMessage(role = ChatRole.ASSISTANT, text = msg, isError = true))
                speakReplyThenMaybeResume(msg)
                return@launch
            }

            if (!_hasInternet.value) {
                val msg = "لا يوجد اتصال بالإنترنت حالياً. تحقق من الشبكة ثم أعد المحاولة."
                _lastAiError.value = msg
                recomputeAiStatus()
                appendChatMessage(ConversationMessage(role = ChatRole.ASSISTANT, text = msg, isError = true))
                speakReplyThenMaybeResume(msg)
                return@launch
            }

            isThinking = true
            recomputeAiStatus()
            val outcome = aiGateway.startUserTurn(
                userInput = sanitizedPrompt,
                apiKey = apiKey,
                settings = _settings.value,
                deviceContextSummary = buildDeviceContextSummary(),
            )
            isThinking = false
            recomputeAiStatus()

            handleAiOutcome(outcome)
        }
    }

    private fun buildDeviceContextSummary(): String {
        val health = YahyaAccessibilityService.currentHealth(context)
        val s = _settings.value
        return buildString {
            append("خدمة تسهيل الوصول: ")
            append(if (health.isOperational) "مفعّلة وجاهزة" else "غير مفعّلة")
            append(" | البحث في الويب: ")
            append(if (s.webSearchEnabled) "مفعّل" else "معطّل")
            append(" | تأكيد الإجراءات الحساسة: ")
            append(if (s.confirmSensitiveActions) "مفعّل" else "اختياري")
        }
    }

    private suspend fun handleAiOutcome(outcome: AiTurnOutcome) {
        when (outcome) {
            is AiTurnOutcome.Error -> {
                _lastAiError.value = outcome.arabicMessage
                recomputeAiStatus()
                appendChatMessage(
                    ConversationMessage(
                        role = ChatRole.ASSISTANT,
                        text = outcome.arabicMessage,
                        isError = true,
                    ),
                )
                appendLog(
                    direction = LogDirection.SYSTEM,
                    title = "تعذر إتمام الطلب عبر Gemini",
                    detail = outcome.arabicMessage,
                    status = LogStatus.FAILED,
                )
                speakReplyThenMaybeResume(outcome.arabicMessage)
            }

            is AiTurnOutcome.FinalReply -> {
                _lastAiError.value = null
                outcome.sources.forEach { currentTurnSources.putIfAbsent(it.url, it) }
                val finalSources = currentTurnSources.values.toList()
                appendChatMessage(
                    ConversationMessage(
                        role = ChatRole.ASSISTANT,
                        text = outcome.text,
                        sources = finalSources,
                    ),
                )
                speakReplyThenMaybeResume(outcome.text)
            }

            is AiTurnOutcome.ToolCallsRequested -> {
                outcome.sources.forEach { currentTurnSources.putIfAbsent(it.url, it) }
                if (!outcome.preliminaryText.isNullOrBlank()) {
                    appendLog(
                        direction = LogDirection.INBOUND_COMMAND,
                        title = "خطة التنفيذ",
                        detail = outcome.preliminaryText,
                        status = LogStatus.INFO,
                    )
                }
                pendingToolQueue.clear()
                outcome.calls.forEach { pendingToolQueue.addLast(it) }
                accumulatedToolReports.clear()
                processToolQueue()
            }
        }
    }

    private suspend fun processToolQueue() {
        val currentSettings = _settings.value
        while (pendingToolQueue.isNotEmpty()) {
            val nextCall = pendingToolQueue.removeFirst()

            if (nextCall.command is AssistantCommand.AskClarification) {
                pendingToolQueue.clear()
                accumulatedToolReports.clear()
                val question = nextCall.command.question
                appendChatMessage(
                    ConversationMessage(
                        role = ChatRole.ASSISTANT,
                        text = question,
                    ),
                )
                speakReplyThenMaybeResume(question)
                return
            }

            val safety = CommandSafetyPolicy.assess(
                command = nextCall.command,
                confirmSensitiveActions = currentSettings.confirmSensitiveActions,
            )

            if (safety.requiresUserConfirmation) {
                awaitingConfirmedCall = nextCall
                _pendingConfirmation.value = PendingConfirmation(
                    command = nextCall.command,
                    title = "تأكيد مطلوب قبل التنفيذ",
                    explanation = "${nextCall.command.rawDescription}\nالسبب: ${safety.reasonArabic}",
                    riskLevel = safety.riskLevel,
                )
                appendLog(
                    direction = LogDirection.INBOUND_COMMAND,
                    title = "أمر بانتظار موافقتك",
                    detail = "${nextCall.command.rawDescription} — ${safety.reasonArabic}",
                    status = LogStatus.AWAITING_CONFIRMATION,
                    isSensitive = true,
                )
                return
            }

            executeQueuedCall(nextCall, isSensitive = false)
        }

        if (accumulatedToolReports.isNotEmpty()) {
            submitAccumulatedToolReportsToAi()
        } else {
            resumeVoiceCycleIfAppropriate()
        }
    }

    private suspend fun executeQueuedCall(call: AiTurnToolCall, isSensitive: Boolean) {
        isExecutingTool = true
        recomputeAiStatus()

        val apiKey = apiKeyVault.getApiKey()
        val result = commandEngine.executeCommand(
            command = call.command,
            settings = _settings.value,
            apiKey = apiKey,
        )

        isExecutingTool = false
        recomputeAiStatus()

        result.sources.forEach { currentTurnSources.putIfAbsent(it.url, it) }

        appendLog(
            direction = LogDirection.EXECUTION_RESULT,
            title = if (result.success) "تم تنفيذ الخطوة" else "تعذر تنفيذ الخطوة",
            detail = "${call.command.rawDescription}: ${result.detail}",
            status = if (result.success) LogStatus.EXECUTED else LogStatus.FAILED,
            isSensitive = isSensitive,
        )

        appendChatMessage(
            ConversationMessage(
                role = ChatRole.TOOL,
                text = result.detail,
                sources = result.sources,
                toolSummary = call.command.rawDescription,
                isError = !result.success,
            ),
        )

        accumulatedToolReports.add(
            ToolExecutionReport(
                callId = call.callId,
                functionName = call.functionName,
                success = result.success,
                output = result.detail,
                sources = result.sources,
            ),
        )
    }

    private suspend fun submitAccumulatedToolReportsToAi() {
        currentTurnRounds++
        if (currentTurnRounds > MAX_TOOL_ROUNDS) {
            val fallback = "تم تنفيذ الخطوات المطلوبة."
            appendChatMessage(
                ConversationMessage(
                    role = ChatRole.ASSISTANT,
                    text = fallback,
                    sources = currentTurnSources.values.toList(),
                ),
            )
            speakReplyThenMaybeResume(fallback)
            return
        }

        val apiKey = apiKeyVault.getApiKey().orEmpty()
        val reportsSnapshot = accumulatedToolReports.toList()
        accumulatedToolReports.clear()

        isThinking = true
        recomputeAiStatus()
        val outcome = aiGateway.submitToolResults(
            reports = reportsSnapshot,
            apiKey = apiKey,
            settings = _settings.value,
        )
        isThinking = false
        recomputeAiStatus()

        handleAiOutcome(outcome)
    }

    fun approvePendingConfirmation() {
        val pending = _pendingConfirmation.value ?: return
        val call = awaitingConfirmedCall
        _pendingConfirmation.value = null
        awaitingConfirmedCall = null

        scope.launch {
            if (call != null) {
                executeQueuedCall(call, isSensitive = true)
                processToolQueue()
            } else {
                // Local guardrail preview test case
                val res = commandEngine.executeCommand(
                    command = pending.command,
                    settings = _settings.value,
                    apiKey = apiKeyVault.getApiKey(),
                )
                appendLog(
                    direction = LogDirection.EXECUTION_RESULT,
                    title = if (res.success) "تم تنفيذ الأمر المؤكد" else "تعذر تنفيذ الأمر",
                    detail = "${pending.command.rawDescription}: ${res.detail}",
                    status = if (res.success) LogStatus.EXECUTED else LogStatus.FAILED,
                    isSensitive = true,
                )
            }
        }
    }

    fun rejectPendingConfirmation() {
        val pending = _pendingConfirmation.value ?: return
        val call = awaitingConfirmedCall
        _pendingConfirmation.value = null
        awaitingConfirmedCall = null

        appendLog(
            direction = LogDirection.EXECUTION_RESULT,
            title = "تم رفض الإجراء الحساس",
            detail = pending.command.rawDescription,
            status = LogStatus.REJECTED,
            isSensitive = true,
        )

        if (call != null) {
            accumulatedToolReports.add(
                ToolExecutionReport(
                    callId = call.callId,
                    functionName = call.functionName,
                    success = false,
                    output = "رفض المستخدم تنفيذ هذا الإجراء الحساس.",
                ),
            )
            scope.launch {
                processToolQueue()
            }
        }
    }

    private fun speakReplyThenMaybeResume(text: String) {
        val currentSettings = _settings.value
        if (!currentSettings.autoSpeakReplies || text.isBlank()) {
            resumeVoiceCycleIfAppropriate()
            return
        }

        // Pause microphone while TTS speaks to avoid self-triggering
        val wasContinuous = isCurrentlyListening() &&
            (_settings.value.operatingMode == OperatingMode.WAKE_WORD || _assistantPowerEnabled.value)
        if (isCurrentlyListening()) {
            speechEngine.stopListening()
        }

        ttsEngine.speak(text) {
            if (wasContinuous || (_assistantPowerEnabled.value && _settings.value.operatingMode == OperatingMode.WAKE_WORD)) {
                resumeVoiceCycleIfAppropriate()
            }
        }
    }

    private fun resumeVoiceCycleIfAppropriate() {
        val s = _settings.value
        if (!_assistantPowerEnabled.value) return
        if (!speechEngine.hasRecordPermission()) return
        if (s.operatingMode == OperatingMode.WAKE_WORD) {
            if (isCurrentlyListening()) {
                speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
            } else {
                startListeningWithMode(ListeningMode.CONTINUOUS_WAKE)
            }
        } else if (isCurrentlyListening()) {
            speechEngine.continueListeningCycle(awaitFollowUpCommand = false)
        }
    }

    fun saveApiKey(rawKey: String) {
        scope.launch {
            val clean = rawKey.trim()
            apiKeyVault.saveApiKey(clean)
            _lastAiError.value = null
            _connectionTestResult.value = null
            _modelsFetchError.value = null
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم حفظ مفتاح Gemini API بأمان",
                detail = "تم تشفير المفتاح محلياً عبر Android Keystore.",
                status = LogStatus.INFO,
            )
            fetchAvailableCloudModels(clean)
        }
    }

    fun clearApiKey() {
        scope.launch {
            apiKeyVault.clearApiKey()
            _connectionTestResult.value = null
            _availableCloudModels.value = emptyList()
            _modelsFetchError.value = null
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم حذف مفتاح Gemini API",
                detail = "تمت إزالة المفتاح من الخزنة المشفرة.",
                status = LogStatus.INFO,
            )
        }
    }

    fun fetchAvailableCloudModels(overrideKey: String? = null) {
        scope.launch {
            _isFetchingModels.value = true
            _modelsFetchError.value = null
            val key = overrideKey?.trim()?.takeIf { it.isNotEmpty() } ?: apiKeyVault.getApiKey().orEmpty()
            val result = aiGateway.fetchAvailableModels(key)
            if (result.success) {
                _availableCloudModels.value = result.models
                _modelsFetchError.value = null
                appendLog(
                    direction = LogDirection.SYSTEM,
                    title = "تم تحديث النماذج السحابية المتاحة",
                    detail = "تم العثور على ${result.models.size} نموذج Gemini متاح عبر الإنترنت.",
                    status = LogStatus.INFO,
                )
            } else {
                _modelsFetchError.value = result.errorMessage
                appendLog(
                    direction = LogDirection.SYSTEM,
                    title = "تعذر تحديث قائمة النماذج",
                    detail = result.errorMessage.orEmpty(),
                    status = LogStatus.FAILED,
                )
            }
            _isFetchingModels.value = false
        }
    }

    fun testAiConnection(overrideKey: String? = null, overrideModelId: String? = null) {
        scope.launch {
            _isTestingConnection.value = true
            _connectionTestResult.value = null
            val key = overrideKey?.trim()?.takeIf { it.isNotEmpty() } ?: apiKeyVault.getApiKey().orEmpty()
            val model = overrideModelId?.trim()?.takeIf { it.isNotEmpty() } ?: _settings.value.geminiModelId
            val result = aiGateway.testConnection(key, model)
            _connectionTestResult.value = result
            _isTestingConnection.value = false
            appendLog(
                direction = LogDirection.SYSTEM,
                title = if (result.success) "نجح اختبار Gemini" else "فشل اختبار Gemini",
                detail = result.detail,
                status = if (result.success) LogStatus.EXECUTED else LogStatus.FAILED,
            )
        }
    }

    fun updateAssistantIdentity(name: String, wakePhrase: String) {
        scope.launch {
            settingsRepository.updateAssistantIdentity(name, wakePhrase)
            appendLog(
                direction = LogDirection.SYSTEM,
                title = "تم تحديث هوية المساعد",
                detail = "الاسم: $name | كلمة التنبيه: \"$wakePhrase\"",
                status = LogStatus.INFO,
            )
        }
    }

    fun updateOperatingMode(mode: OperatingMode) {
        scope.launch {
            settingsRepository.updateOperatingMode(mode)
            if (_assistantPowerEnabled.value) {
                if (mode == OperatingMode.WAKE_WORD && speechEngine.hasRecordPermission()) {
                    startListeningWithMode(ListeningMode.CONTINUOUS_WAKE)
                } else {
                    stopMicrophone()
                }
            }
        }
    }

    fun updateGeminiModelId(modelId: String) {
        scope.launch {
            val normalized = modelId.trim().removePrefix("models/").trim()
            if (normalized.isBlank()) return@launch
            settingsRepository.updateGeminiModelId(normalized)
            _lastAiError.value = null
            _connectionTestResult.value = null
            recomputeAiStatus()
        }
    }

    fun updateSpeechSettings(
        language: String,
        operatingMode: OperatingMode,
        foregroundServiceEnabled: Boolean,
        autoSpeakReplies: Boolean,
        speechRate: Float,
        ttsVoiceName: String?,
    ) {
        scope.launch {
            settingsRepository.updateSpeechSettings(
                language = language,
                operatingMode = operatingMode,
                foregroundServiceEnabled = foregroundServiceEnabled,
                autoSpeakReplies = autoSpeakReplies,
                speechRate = speechRate,
                ttsVoiceName = ttsVoiceName,
            )
        }
    }

    fun updateWebSearchEnabled(enabled: Boolean) {
        scope.launch {
            settingsRepository.updateWebSearchEnabled(enabled)
        }
    }

    fun updateSafetyAndUi(confirmSensitiveActions: Boolean, rtlEnabled: Boolean) {
        scope.launch {
            settingsRepository.updateSafetyAndUi(confirmSensitiveActions, rtlEnabled)
        }
    }

    fun clearConversationAndLogs() {
        aiGateway.clearConversation()
        _conversation.value = emptyList()
        _logs.value = emptyList()
        _lastAiError.value = null
        recomputeAiStatus()
    }

    fun testSafeUrlPreview() {
        val cmd = AssistantCommand.OpenUrl(
            commandId = "local-safe-test",
            url = "https://www.wikipedia.org",
            rawDescription = "اختبار فتح رابط آمن",
        )
        scope.launch {
            val res = commandEngine.executeCommand(cmd, _settings.value, apiKeyVault.getApiKey())
            appendLog(
                direction = LogDirection.EXECUTION_RESULT,
                title = if (res.success) "تم فتح الرابط" else "تعذر فتح الرابط",
                detail = res.detail,
                status = if (res.success) LogStatus.EXECUTED else LogStatus.FAILED,
            )
        }
    }

    fun testSensitiveGuardrailPreview() {
        val cmd = AssistantCommand.Tap(
            commandId = "local-guardrail-test",
            targetText = "تأكيد الدفع وحذف الحساب",
            x = null,
            y = null,
        )
        val safety = CommandSafetyPolicy.assess(cmd, _settings.value.confirmSensitiveActions)
        _pendingConfirmation.value = PendingConfirmation(
            command = cmd,
            title = "تأكيد مطلوب قبل التنفيذ",
            explanation = "${cmd.rawDescription}\nالسبب: ${safety.reasonArabic}",
            riskLevel = safety.riskLevel,
        )
    }

    private fun appendChatMessage(message: ConversationMessage) {
        _conversation.value = (_conversation.value + message).takeLast(60)
    }

    private fun appendLog(
        direction: LogDirection,
        title: String,
        detail: String,
        status: LogStatus,
        isSensitive: Boolean = false,
    ) {
        val entry = CommandExecutionLog(
            direction = direction,
            title = title,
            detail = detail,
            status = status,
            isSensitive = isSensitive,
        )
        _logs.value = (listOf(entry) + _logs.value).take(40)
    }

    fun shutdown() {
        runCatching { connectivityManager?.unregisterNetworkCallback(networkCallback) }
        speechEngine.stopListening()
        ttsEngine.shutdown()
    }

    val deviceModelLabel: String
        get() = "${Build.MANUFACTURER} ${Build.MODEL}"

    companion object {
        private const val MAX_TOOL_ROUNDS = 5
    }
}
