package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.ui.MainViewModel
import com.example.ui.YahyaCompanionAppRoot
import com.example.voice.FloatingMicOverlayService

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private var pendingMicPermissionFromOverlay by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleOverlayIntent(intent)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            YahyaCompanionAppRoot(
                viewModel = mainViewModel,
                requestMicPermissionOnSignal = pendingMicPermissionFromOverlay,
                onMicPermissionSignalHandled = { pendingMicPermissionFromOverlay = false },
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOverlayIntent(intent)
    }

    private fun handleOverlayIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(FloatingMicOverlayService.EXTRA_REQUEST_MIC_PERMISSION, false) == true) {
            pendingMicPermissionFromOverlay = true
            intent.removeExtra(FloatingMicOverlayService.EXTRA_REQUEST_MIC_PERMISSION)
        }
    }
}
