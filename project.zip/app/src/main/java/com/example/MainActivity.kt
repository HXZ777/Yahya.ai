package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.i18n.stringsFor
import com.example.ui.navigation.MineVrRoute
import com.example.ui.screens.AppInfoScreen
import com.example.ui.screens.ControlsScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.SensorDiagnosticsScreen
import com.example.ui.screens.VrGameplayScreen
import com.example.ui.screens.VrSettingsScreen
import com.example.ui.theme.MineVrTheme
import com.example.ui.viewmodel.MineVrViewModel
import com.example.vr.model.AppLanguage
import com.example.vr.model.VrRenderMode

class MainActivity : ComponentActivity() {

    private val viewModel: MineVrViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            val settings by viewModel.settingsState.collectAsStateWithLifecycle()
            val headState by viewModel.headState.collectAsStateWithLifecycle()
            val controllerState by viewModel.controllerState.collectAsStateWithLifecycle()
            val minecraftStatus by viewModel.minecraftStatus.collectAsStateWithLifecycle()
            val projectionState by viewModel.projectionState.collectAsStateWithLifecycle()
            val accessibilityState by viewModel.accessibilityState.collectAsStateWithLifecycle()
            val isVrPaused by viewModel.isVrPaused.collectAsStateWithLifecycle()

            val strings = stringsFor(settings.language)
            val layoutDir = if (settings.language == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr
            val navController = rememberNavController()
            val backEntry by navController.currentBackStackEntryAsState()
            val inVrGameplay = backEntry?.destination?.route?.contains("VrGameplay") == true

            LaunchedEffect(inVrGameplay) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                if (inVrGameplay) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.systemBars())
                } else {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    controller.show(WindowInsetsCompat.Type.systemBars())
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
                MineVrTheme {
                    NavHost(
                        navController = navController,
                        startDestination = MineVrRoute.MainMenu
                    ) {
                        composable<MineVrRoute.MainMenu> {
                            MainMenuScreen(
                                settings = settings,
                                headState = headState,
                                controllerState = controllerState,
                                minecraftStatus = minecraftStatus,
                                strings = strings,
                                onStartVr = {
                                    viewModel.setVrPaused(false)
                                    navController.navigate(MineVrRoute.VrGameplay)
                                },
                                onOpenHeadsetSettings = { navController.navigate(MineVrRoute.VrSettings) },
                                onOpenControllerSettings = { navController.navigate(MineVrRoute.ControlsSettings) },
                                onOpenSensorDiagnostics = { navController.navigate(MineVrRoute.SensorDiagnostics) },
                                onOpenAppInfo = { navController.navigate(MineVrRoute.AppInfo) },
                                onSelectRenderMode = { viewModel.setRenderMode(it) },
                                onLaunchMinecraft = { split -> viewModel.launchMinecraft(splitScreen = split) },
                                onToggleLanguage = { viewModel.toggleLanguage() }
                            )
                        }

                        composable<MineVrRoute.VrSettings> {
                            VrSettingsScreen(
                                vr = settings.vr,
                                headState = headState,
                                accessibilityState = accessibilityState,
                                headTracker = viewModel.headTracker,
                                controllerManager = viewModel.controllerManager,
                                strings = strings,
                                onSaveVr = { viewModel.updateVrSettings(it) },
                                onCalibrateForward = { viewModel.calibrateHeadForward() },
                                onRecenter = { viewModel.recenterHead() },
                                onResetDefaults = { viewModel.resetVrDefaults() },
                                onTestSplitScreen = {
                                    viewModel.setRenderMode(VrRenderMode.STEREO_VOXEL_SANDBOX)
                                    viewModel.setVrPaused(false)
                                    navController.navigate(MineVrRoute.VrGameplay)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<MineVrRoute.ControlsSettings> {
                            ControlsScreen(
                                controls = settings.controls,
                                controller = controllerState,
                                language = settings.language,
                                strings = strings,
                                onRefreshDevices = { viewModel.controllerManager.refreshConnectedDevices() },
                                onSaveControls = { viewModel.updateControlsSettings(it) },
                                onResetDefaults = { viewModel.resetControlDefaults() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<MineVrRoute.SensorDiagnostics> {
                            SensorDiagnosticsScreen(
                                headState = headState,
                                accessibilityState = accessibilityState,
                                headTracker = viewModel.headTracker,
                                strings = strings,
                                onCalibrateForward = { viewModel.calibrateHeadForward() },
                                onRecenter = { viewModel.recenterHead() },
                                onTestAccessibilityLook = { viewModel.sendAccessibilityTestLook() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<MineVrRoute.AppInfo> {
                            AppInfoScreen(
                                language = settings.language,
                                strings = strings,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<MineVrRoute.VrGameplay> {
                            viewModel.renderer.isInMultiWindowMode = isInMultiWindowMode
                            VrGameplayScreen(
                                settings = settings,
                                projectionState = projectionState,
                                isPaused = isVrPaused,
                                renderer = viewModel.renderer,
                                strings = strings,
                                canDrawOverlay = viewModel.canDrawOverlay(),
                                onStartSensors = { viewModel.startSensors() },
                                onStopSensorsIfInactive = { viewModel.stopSensorsIfSessionInactive() },
                                onRecenterHead = { viewModel.recenterHead() },
                                onTogglePause = { viewModel.toggleVrPaused() },
                                onStartProjection = { code, intent -> viewModel.startMediaProjection(code, intent) },
                                onStopProjection = { viewModel.stopMediaProjection() },
                                onLaunchVrOverlayOverMinecraft = { viewModel.startVrOverlayOverMinecraft() },
                                onSwitchTo3dTest = { viewModel.setRenderMode(VrRenderMode.STEREO_VOXEL_SANDBOX) },
                                onLaunchMinecraftSplit = { viewModel.launchMinecraft(splitScreen = true) },
                                onExitToMenu = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDiagnostics()
    }

    override fun onGenericMotionEvent(event: MotionEvent?): Boolean {
        if (event != null && viewModel.controllerManager.onGenericMotionEvent(event)) {
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && viewModel.controllerManager.onKeyDown(keyCode, event)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && viewModel.controllerManager.onKeyUp(keyCode, event)) {
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}
