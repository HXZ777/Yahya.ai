package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.i18n.stringsFor
import com.example.ui.navigation.VrRoute
import com.example.ui.screens.ControlsScreen
import com.example.ui.screens.GraphicsSettingsScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.VrGameplayScreen
import com.example.ui.screens.VrSettingsScreen
import com.example.ui.screens.WorldBrowserScreen
import com.example.ui.screens.WorldEditorScreen
import com.example.ui.theme.VrSupermarketTheme
import com.example.ui.viewmodel.VrGameViewModel
import com.example.vr.model.AppLanguage

class MainActivity : ComponentActivity() {

    private val viewModel: VrGameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            val settings by viewModel.settingsState.collectAsStateWithLifecycle()
            val saveGame by viewModel.saveGameState.collectAsStateWithLifecycle()
            val worldBrowserState by viewModel.worldBrowserState.collectAsStateWithLifecycle()
            val xboxState by viewModel.xboxManager.snapshot.collectAsStateWithLifecycle()
            val handState by viewModel.handTracker.state.collectAsStateWithLifecycle()

            val strings = stringsFor(settings.language)
            val layoutDir = if (settings.language == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr
            val navController = rememberNavController()
            val backEntry by navController.currentBackStackEntryAsState()
            val inVrGameplay = backEntry?.destination?.route?.contains("VrGameplay") == true

            // Automatically enter landscape + keep screen on + hide system bars in VR gameplay
            LaunchedEffect(inVrGameplay) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                if (inVrGameplay) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.systemBars())
                } else {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    controller.show(WindowInsetsCompat.Type.systemBars())
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
                VrSupermarketTheme {
                    NavHost(
                        navController = navController,
                        startDestination = VrRoute.MainMenu
                    ) {
                        composable<VrRoute.MainMenu> {
                            MainMenuScreen(
                                settings = settings,
                                saveGame = saveGame,
                                xbox = xboxState,
                                strings = strings,
                                onPlayNew = {
                                    viewModel.startNewSession()
                                    navController.navigate(VrRoute.VrGameplay)
                                },
                                onContinue = {
                                    viewModel.continueSavedSession()
                                    navController.navigate(VrRoute.VrGameplay)
                                },
                                onOpenWorldBrowser = { navController.navigate(VrRoute.WorldBrowser) },
                                onOpenVrSettings = { navController.navigate(VrRoute.VrSettings) },
                                onOpenControls = { navController.navigate(VrRoute.ControlsSettings) },
                                onOpenGraphics = { navController.navigate(VrRoute.GraphicsSettings) },
                                onToggleLanguage = { viewModel.toggleLanguage() },
                                onExitApp = { finish() }
                            )
                        }

                        composable<VrRoute.WorldBrowser> {
                            WorldBrowserScreen(
                                state = worldBrowserState,
                                language = settings.language,
                                strings = strings,
                                onDownloadWorld = { viewModel.downloadWorld(it) },
                                onLaunchWorld = { entry ->
                                    viewModel.startNewSession(entry)
                                    navController.navigate(VrRoute.VrGameplay)
                                },
                                onOpenWorldEditor = { entry, tab ->
                                    navController.navigate(VrRoute.WorldEditor(entry.id, tab))
                                },
                                onScaleWorld = { entry, scale ->
                                    viewModel.setWorldScaleAndSave(entry, scale)
                                },
                                onToggleCollision = { entry ->
                                    viewModel.toggleWorldCollisionAndSave(entry)
                                },
                                onSaveWorld = { entry ->
                                    viewModel.saveEditorProject(entry.id)
                                },
                                onRestoreOriginalWorld = { entry ->
                                    viewModel.restoreOriginalWorld(entry.id)
                                },
                                onDeleteWorld = { viewModel.deleteWorld(it) },
                                onImportUri = { uri ->
                                    viewModel.importWorldFromUri(uri) { importedWorldId ->
                                        navController.navigate(VrRoute.WorldEditor(importedWorldId, "transform"))
                                    }
                                },
                                onClearFeedback = { viewModel.clearImportFeedback() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<VrRoute.WorldEditor> { backStackEntry ->
                            val routeArgs = backStackEntry.toRoute<VrRoute.WorldEditor>()
                            val worldEntry = worldBrowserState.worlds.find { it.id == routeArgs.worldId }
                            WorldEditorScreen(
                                worldId = routeArgs.worldId,
                                initialTab = routeArgs.initialTab,
                                worldEntry = worldEntry,
                                language = settings.language,
                                strings = strings,
                                renderer = viewModel.renderer,
                                editorManager = viewModel.editorManager,
                                xboxManager = viewModel.xboxManager,
                                onPrepareWorld = { wId -> viewModel.prepareWorldForEditor(wId) },
                                onSaveProject = { viewModel.saveEditorProject() },
                                onPlayFromEditor = { overrideSpawn ->
                                    viewModel.playFromEditor(overrideSpawn)
                                    navController.navigate(VrRoute.VrGameplay)
                                },
                                onDuplicateWorld = { entry, onCreated ->
                                    viewModel.duplicateWorldAsCopy(entry, onCreated)
                                },
                                onRestoreOriginal = { wId -> viewModel.restoreOriginalWorld(wId) },
                                onImportAdditionalModel = { uri -> viewModel.importAdditionalModelToEditor(uri) },
                                onPickTextureForMaterial = { mat, uri -> viewModel.applyPickedTextureToMaterial(mat, uri) },
                                onExportZip = { uri, onDone -> viewModel.exportCurrentWorldToZip(uri, onDone) },
                                onNavigateToWorld = { newWorldId ->
                                    navController.navigate(VrRoute.WorldEditor(newWorldId, "transform")) {
                                        popUpTo<VrRoute.WorldEditor> { inclusive = true }
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<VrRoute.VrSettings> {
                            VrSettingsScreen(
                                vr = settings.vr,
                                strings = strings,
                                onUpdateVr = { viewModel.updateVrSettings(it) },
                                onCalibrateHeadset = { viewModel.calibrateHeadsetYaw() },
                                onTestVrNow = {
                                    viewModel.startNewSession()
                                    navController.navigate(VrRoute.VrGameplay)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<VrRoute.ControlsSettings> {
                            ControlsScreen(
                                controls = settings.controls,
                                language = settings.language,
                                xbox = xboxState,
                                handState = handState,
                                handTracker = viewModel.handTracker,
                                strings = strings,
                                onUpdateControls = { viewModel.updateControlsSettings(it) },
                                onRefreshXbox = { viewModel.xboxManager.refreshConnectedDevices() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<VrRoute.GraphicsSettings> {
                            GraphicsSettingsScreen(
                                graphics = settings.graphics,
                                gameMode = settings.gameMode,
                                strings = strings,
                                onUpdateGraphics = { viewModel.updateGraphicsSettings(it) },
                                onUpdateGameMode = { gm -> viewModel.updateAllSettings { it.copy(gameMode = gm) } },
                                onResetSave = { viewModel.resetSaveData() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<VrRoute.VrGameplay> {
                            VrGameplayScreen(
                                settings = settings,
                                strings = strings,
                                renderer = viewModel.renderer,
                                controller = viewModel.simulationController,
                                headTracker = viewModel.headTracker,
                                handTracker = viewModel.handTracker,
                                handState = handState,
                                onSwitchScheme = { viewModel.switchControlScheme(it) },
                                onExitToMenu = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onGenericMotionEvent(event: MotionEvent?): Boolean {
        if (event != null && viewModel.xboxManager.onGenericMotionEvent(event)) {
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && viewModel.xboxManager.onKeyDown(keyCode, event)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        viewModel.audioEngine.stopAmbientMusic()
    }

    override fun onResume() {
        super.onResume()
        val g = viewModel.settingsState.value.graphics
        viewModel.audioEngine.updateSettings(g.sfxEnabled, g.musicEnabled)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && viewModel.xboxManager.onKeyUp(keyCode, event)) {
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}
