package com.example.domain.util

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024.0 && unitIndex < units.lastIndex) {
            value /= 1024.0
            unitIndex++
        }
        val pattern = if (unitIndex == 0) "#,##0" else "#,##0.##"
        return "${DecimalFormat(pattern).format(value)} ${units[unitIndex]}"
    }

    fun nowTimestamp(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    }
}
