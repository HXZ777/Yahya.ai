package com.example.domain.voice

import java.util.Locale

data class WakeMatchResult(
    val matched: Boolean,
    val remainingCommand: String,
)

object ArabicWakeMatcher {

    private val diacriticsRegex = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]")
    private val whitespaceRegex = Regex("\\s+")

    fun normalizeArabic(text: String): String {
        return text
            .replace(diacriticsRegex, "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ى', 'ي')
            .replace('ة', 'ه')
            .replace('ؤ', 'و')
            .replace('ئ', 'ي')
            .replace("ـ", "")
            .lowercase(Locale.ROOT)
            .replace(whitespaceRegex, " ")
            .trim()
    }

    fun matchWakePhrase(transcript: String, wakePhrase: String): WakeMatchResult {
        val cleanTranscript = transcript.trim()
        val normTranscript = normalizeArabic(cleanTranscript)
        val normWake = normalizeArabic(wakePhrase)

        if (normTranscript.isBlank() || normWake.isBlank()) {
            return WakeMatchResult(matched = false, remainingCommand = cleanTranscript)
        }

        val wakeVariants = buildList {
            add(normWake)
            // Handle common Arabic speech recognizer variations of "يا يحيى"
            if (normWake == "يا يحيي") {
                add("يايحيا")
                add("يا يحيا")
                add("يحيي")
                add("يحيا")
                add("يا يحي")
            }
        }

        for (variant in wakeVariants) {
            if (normTranscript == variant) {
                return WakeMatchResult(matched = true, remainingCommand = "")
            }
            if (normTranscript.startsWith("$variant ")) {
                val remainder = stripPrefixWords(cleanTranscript, variant.split(" ").size)
                return WakeMatchResult(matched = true, remainingCommand = remainder)
            }
            val idx = normTranscript.indexOf(variant)
            if (idx >= 0) {
                val afterNorm = normTranscript.substring(idx + variant.length).trim()
                return WakeMatchResult(matched = true, remainingCommand = afterNorm)
            }
        }

        return WakeMatchResult(matched = false, remainingCommand = cleanTranscript)
    }

    private fun stripPrefixWords(original: String, wordCount: Int): String {
        val parts = original.trim().split(whitespaceRegex)
        return if (parts.size > wordCount) {
            parts.drop(wordCount).joinToString(" ").trim()
        } else {
            ""
        }
    }
}
