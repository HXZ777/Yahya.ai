package com.example.domain.model

enum class StatType(val key: String) {
    DXVK("dxvk"),
    CPU("cpu"),
    RAM("ram"),
    PWR("pwr"),
    TMP("tmp"),
    FPS("fps"),
    ;

    companion object {
        val ORDERED: List<StatType> = listOf(DXVK, CPU, RAM, PWR, TMP, FPS)

        fun fromKey(key: String): StatType? = entries.firstOrNull { it.key == key }
    }
}

enum class OverlayPositionPreset(val key: String) {
    TOP_START("top_start"),
    TOP_CENTER("top_center"),
    TOP_END("top_end"),
    CENTER("center"),
    BOTTOM_CENTER("bottom_center"),
    ;

    companion object {
        fun fromKey(key: String?): OverlayPositionPreset =
            entries.firstOrNull { it.key == key } ?: TOP_CENTER
    }
}

enum class AppLanguage(val key: String) {
    ARABIC("ar"),
    ENGLISH("en"),
    ;

    companion object {
        fun fromKey(key: String?): AppLanguage =
            entries.firstOrNull { it.key == key } ?: ARABIC
    }
}

enum class CpuSource {
    PROC_STAT,
    CPU_FREQ_SCALING,
    UNAVAILABLE,
}

enum class TempSource {
    SOC_THERMAL,
    SKIN_THERMAL,
    BATTERY,
    UNAVAILABLE,
}

enum class FpsSource {
    KERNEL_SYSFS,
    COMPOSITOR_HZ,
    UNAVAILABLE,
}

enum class DxvkStatus {
    DETECTED,
    NOT_DETECTED,
}

data class SystemStatsSnapshot(
    val cpuPercent: Int? = null,
    val cpuSource: CpuSource = CpuSource.UNAVAILABLE,
    val ramPercent: Int? = null,
    val ramUsedMb: Long = 0L,
    val ramTotalMb: Long = 0L,
    val powerWatts: Float? = null,
    val isCharging: Boolean = false,
    val tempCelsius: Float? = null,
    val tempSource: TempSource = TempSource.UNAVAILABLE,
    val tempZoneLabel: String? = null,
    val fpsValue: Int? = null,
    val fpsSource: FpsSource = FpsSource.UNAVAILABLE,
    val dxvkStatus: DxvkStatus = DxvkStatus.NOT_DETECTED,
    val dxvkDetail: String? = null,
    val timestampMs: Long = 0L,
)

object DefaultStatColors {
    const val DXVK: Long = 0xFFE94D9DL // Pink
    const val CPU: Long = 0xFFEAB308L  // Golden yellow
    const val RAM: Long = 0xFF38BDF8L  // Sky blue
    const val PWR: Long = 0xFFA855F7L  // Purple
    const val TMP: Long = 0xFFEF4444L  // Red
    const val FPS: Long = 0xFFFDE047L  // Light yellow

    fun defaultMap(): Map<StatType, Long> = mapOf(
        StatType.DXVK to DXVK,
        StatType.CPU to CPU,
        StatType.RAM to RAM,
        StatType.PWR to PWR,
        StatType.TMP to TMP,
        StatType.FPS to FPS,
    )

    val paletteOptions: List<Long> = listOf(
        0xFFE94D9DL, // Pink
        0xFFEAB308L, // Gold
        0xFF38BDF8L, // Sky Blue
        0xFFA855F7L, // Purple
        0xFFEF4444L, // Red
        0xFFFDE047L, // Light Yellow
        0xFF11E5B2L, // Turquoise
        0xFF22C55EL, // Green
        0xFFF97316L, // Orange
        0xFFFFFFFFL, // Pure White
    )
}

data class OverlaySettings(
    val enabledStats: Set<StatType> = StatType.entries.toSet(),
    val statColors: Map<StatType, Long> = DefaultStatColors.defaultMap(),
    val scalePercent: Int = 100,
    val backgroundAlpha: Float = 0.92f,
    val fontSizeSp: Float = 12.5f,
    val refreshIntervalMs: Long = 1000L,
    val positionPreset: OverlayPositionPreset = OverlayPositionPreset.TOP_CENTER,
    val customOffsetX: Int? = null,
    val customOffsetY: Int? = null,
    val language: AppLanguage = AppLanguage.ARABIC,
    val useCompositorHzFallback: Boolean = false,
    val hideDxvkWhenNotDetected: Boolean = false,
)

data class PermissionStatus(
    val hasOverlayPermission: Boolean = false,
    val hasNotificationPermission: Boolean = true,
    val isBatteryOptimizationIgnored: Boolean = false,
)
