package com.example.domain.model

enum class ProjectType(val displayLabel: String) {
    ANDROID_APP_KOTLIN("Android App (Kotlin)"),
    ANDROID_APP_JAVA("Android App (Java)"),
    ANDROID_APP_MIXED("Android App (Kotlin + Java)"),
    ANDROID_MULTI_MODULE("Android Multi-Module Gradle"),
    ANDROID_LIBRARY("Android Library Module"),
    PREBUILT_APK_ARCHIVE("Archive with Pre-Built APK"),
    UNKNOWN_ARCHIVE("Unrecognized / Non-Android ZIP"),
}

data class ZipSelectionInfo(
    val uriString: String,
    val displayName: String,
    val sizeBytes: Long,
    val localZipFilePath: String,
    val selectedAtMillis: Long,
)

data class EssentialFileStatus(
    val label: String,
    val relativePath: String,
    val present: Boolean,
    val detail: String? = null,
)

data class ProjectInspection(
    val workspaceId: String,
    val workspaceDirPath: String,
    val projectRootRelativePath: String,
    val projectName: String,
    val projectType: ProjectType,
    val applicationId: String?,
    val namespace: String?,
    val versionName: String?,
    val versionCode: String?,
    val gradleVersion: String?,
    val agpVersion: String?,
    val kotlinVersion: String?,
    val javaCompatibility: String?,
    val compileSdk: String?,
    val minSdk: String?,
    val targetSdk: String?,
    val modules: List<String>,
    val kotlinFileCount: Int,
    val javaFileCount: Int,
    val xmlFileCount: Int,
    val totalExtractedFiles: Int,
    val extractedSizeBytes: Long,
    val hasGradleWrapper: Boolean,
    val essentialFiles: List<EssentialFileStatus>,
    val embeddedApkPaths: List<String>,
    val missingRequirements: List<String>,
    val readinessSummary: String,
    val isValidAndroidProject: Boolean,
)

data class DeviceToolchainProbe(
    val deviceAbi: String,
    val androidSdkInt: Int,
    val freeSpaceBytes: Long,
    val javaRuntimeVersion: String,
    val hasLocalJavac: Boolean,
    val hasLocalGradle: Boolean,
    val hasAndroidSdk: Boolean,
    val hasAapt2: Boolean,
    val hasD8: Boolean,
    val localToolchainReady: Boolean,
    val missingToolchainItems: List<String>,
)

enum class BuildEngineMode(val label: String) {
    LOCAL_DEVICE("On-Device Toolchain"),
    REMOTE_RUNNER("Self-Hosted Gradle Runner"),
}

data class BuildEngineSettings(
    val mode: BuildEngineMode = BuildEngineMode.LOCAL_DEVICE,
    val remoteRunnerUrl: String = "",
    val remoteAuthToken: String = "",
    val buildVariant: String = "debug",
    val uploadConsentGranted: Boolean = false,
)

enum class BuildStage(val title: String) {
    SANDBOX_PREP("Isolated Sandbox Prep"),
    PROJECT_VALIDATION("Project & Gradle Inspection"),
    TOOLCHAIN_CHECK("SDK & Gradle Toolchain Check"),
    GRADLE_BUILD("Gradle APK Assembly"),
    APK_VERIFICATION("APK Integrity & Signing Check"),
}

enum class StageStatus {
    PENDING,
    RUNNING,
    SUCCEEDED,
    FAILED,
}

data class BuildStepState(
    val stage: BuildStage,
    val status: StageStatus,
    val detail: String,
)

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    SUCCESS,
}

data class BuildLogEntry(
    val timestamp: String,
    val level: LogLevel,
    val message: String,
)

data class ApkResultInfo(
    val apkFilePath: String,
    val fileName: String,
    val sizeBytes: Long,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int?,
    val targetSdk: Int?,
    val sha256: String,
    val isValidApkStructure: Boolean,
    val sourceNote: String,
)

sealed interface BuildExecutionState {
    data object Idle : BuildExecutionState

    data class Running(
        val progress: Float,
        val currentStageLabel: String,
        val steps: List<BuildStepState>,
        val logs: List<BuildLogEntry>,
    ) : BuildExecutionState

    data class Succeeded(
        val progress: Float,
        val steps: List<BuildStepState>,
        val logs: List<BuildLogEntry>,
        val result: ApkResultInfo,
    ) : BuildExecutionState

    data class Failed(
        val progress: Float,
        val errorTitle: String,
        val errorDetail: String,
        val missingRequirements: List<String>,
        val steps: List<BuildStepState>,
        val logs: List<BuildLogEntry>,
        val canExtractPrebuiltApk: Boolean = false,
    ) : BuildExecutionState
}
