package com.example.domain.model

import java.util.UUID

enum class AiStatus {
    READY,
    MISSING_API_KEY,
    NO_INTERNET,
    THINKING,
    SPEAKING,
    EXECUTING,
    ERROR,
}

enum class OperatingMode {
    WAKE_WORD,
    PUSH_TO_TALK,
}

enum class MicStatus {
    PERMISSION_MISSING,
    READY,
    WAKE_ARMED,
    LISTENING,
    PROCESSING,
    UNAVAILABLE,
    ERROR,
}

enum class ListeningMode {
    PUSH_TO_TALK,
    DIRECT_CONTINUOUS,
    CONTINUOUS_WAKE,
}

enum class ScrollDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT,
}

enum class GlobalDeviceAction {
    BACK,
    HOME,
    RECENTS,
    NOTIFICATIONS,
}

enum class RiskLevel {
    SAFE,
    MODERATE,
    SENSITIVE,
}

enum class LogDirection {
    OUTBOUND_SPEECH,
    INBOUND_COMMAND,
    EXECUTION_RESULT,
    SYSTEM,
}

enum class LogStatus {
    SENT,
    QUEUED,
    AWAITING_CONFIRMATION,
    EXECUTED,
    REJECTED,
    FAILED,
    INFO,
}

enum class ChatRole {
    USER,
    ASSISTANT,
    TOOL,
    SYSTEM,
}

data class WebSource(
    val title: String,
    val url: String,
)

data class ConversationMessage(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val role: ChatRole,
    val text: String,
    val sources: List<WebSource> = emptyList(),
    val toolSummary: String? = null,
    val isError: Boolean = false,
)

data class TtsVoiceOption(
    val name: String,
    val displayLabel: String,
    val localeTag: String,
)

data class AiConnectionTestResult(
    val success: Boolean,
    val latencyMs: Long? = null,
    val detail: String,
)

data class AssistantSettings(
    val assistantName: String = "يحيى",
    val wakePhrase: String = "يا يحيى",
    val speechLanguage: String = "ar-SA",
    val operatingMode: OperatingMode = OperatingMode.PUSH_TO_TALK,
    val geminiModelId: String = DEFAULT_GEMINI_MODEL,
    val speechRate: Float = 1.0f,
    val ttsVoiceName: String? = null,
    val webSearchEnabled: Boolean = true,
    val foregroundServiceEnabled: Boolean = true,
    val autoSpeakReplies: Boolean = true,
    val confirmSensitiveActions: Boolean = true,
    val rtlEnabled: Boolean = true,
    val systemOverlayEnabled: Boolean = false,
) {
    val isWakeMode: Boolean
        get() = operatingMode == OperatingMode.WAKE_WORD

    companion object {
        const val APP_OFFICIAL_NAME = "HXZ AI"
        const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
        val RECOMMENDED_MODELS = listOf(
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
            "gemini-2.5-pro",
        )
    }
}

sealed interface AssistantCommand {
    val commandId: String
    val rawDescription: String

    data class OpenApp(
        override val commandId: String = UUID.randomUUID().toString(),
        val packageName: String?,
        val appName: String?,
        override val rawDescription: String = "فتح تطبيق ${appName ?: packageName.orEmpty()}",
    ) : AssistantCommand

    data class OpenUrl(
        override val commandId: String = UUID.randomUUID().toString(),
        val url: String,
        override val rawDescription: String = "فتح رابط $url",
    ) : AssistantCommand

    data class WebSearch(
        override val commandId: String = UUID.randomUUID().toString(),
        val query: String,
        override val rawDescription: String = "بحث في الإنترنت عن: $query",
    ) : AssistantCommand

    data class FetchWebpage(
        override val commandId: String = UUID.randomUUID().toString(),
        val url: String,
        override val rawDescription: String = "قراءة صفحة ويب: $url",
    ) : AssistantCommand

    data class Tap(
        override val commandId: String = UUID.randomUUID().toString(),
        val targetText: String?,
        val x: Float?,
        val y: Float?,
        override val rawDescription: String = when {
            !targetText.isNullOrBlank() -> "النقر على \"$targetText\""
            x != null && y != null -> "النقر عند (${x.toInt()}, ${y.toInt()})"
            else -> "نقر على الشاشة"
        },
    ) : AssistantCommand

    data class Scroll(
        override val commandId: String = UUID.randomUUID().toString(),
        val direction: ScrollDirection,
        override val rawDescription: String = "التمرير للاتجاه ${direction.name}",
    ) : AssistantCommand

    data class TypeText(
        override val commandId: String = UUID.randomUUID().toString(),
        val text: String,
        val targetHint: String?,
        override val rawDescription: String = "كتابة نص (${text.take(24)})",
    ) : AssistantCommand

    data class ReadScreen(
        override val commandId: String = UUID.randomUUID().toString(),
        override val rawDescription: String = "قراءة محتوى الشاشة الحالية",
    ) : AssistantCommand

    data class GlobalAction(
        override val commandId: String = UUID.randomUUID().toString(),
        val action: GlobalDeviceAction,
        override val rawDescription: String = "إجراء نظام: ${action.name}",
    ) : AssistantCommand

    data class AskClarification(
        override val commandId: String = UUID.randomUUID().toString(),
        val question: String,
        override val rawDescription: String = "طلب توضيح من المستخدم",
    ) : AssistantCommand

    data class Speak(
        override val commandId: String = UUID.randomUUID().toString(),
        val text: String,
        override val rawDescription: String = "نطق الرد الصوتي",
    ) : AssistantCommand
}

data class PendingConfirmation(
    val command: AssistantCommand,
    val title: String,
    val explanation: String,
    val riskLevel: RiskLevel,
    val createdAt: Long = System.currentTimeMillis(),
)

data class CommandExecutionLog(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val direction: LogDirection,
    val title: String,
    val detail: String,
    val status: LogStatus,
    val isSensitive: Boolean = false,
)

data class AccessibilityHealth(
    val isEnabledInSettings: Boolean = false,
    val isServiceBound: Boolean = false,
) {
    val isOperational: Boolean get() = isEnabledInSettings && isServiceBound
}
