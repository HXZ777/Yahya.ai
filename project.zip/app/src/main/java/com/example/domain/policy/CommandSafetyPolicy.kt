package com.example.domain.policy

import com.example.domain.model.AssistantCommand
import com.example.domain.model.RiskLevel
import java.util.Locale

data class SafetyAssessment(
    val riskLevel: RiskLevel,
    val requiresUserConfirmation: Boolean,
    val reasonArabic: String,
)

object SensitiveInputFilter {

    private val cardPattern = Regex("\\b(?:\\d[ -]*?){13,19}\\b")
    private val otpContextPattern = Regex(
        "(?i)(otp|pin|passcode|verification\\s*code|كود\\s*التحقق|رمز\\s*التحقق|الرمز\\s*السري|رمز\\s*التفعيل)[:\\s\\-]*\\d{4,8}",
    )
    private val passwordContextPattern = Regex(
        "(?i)(password|passwd|كلمة\\s*المرور|كلمة\\s*السر|الرقم\\s*السري)[:\\s\\-]*\\S+",
    )
    private val bearerOrApiKeyPattern = Regex("\\b(AIza[0-9A-Za-z_\\-]{20,}|sk-[0-9A-Za-z\\-]{16,})\\b")

    fun redactSensitiveText(input: String): String {
        if (input.isBlank()) return input
        var sanitized = input
        sanitized = cardPattern.replace(sanitized, "[بيانات بطاقة محجوبة]")
        sanitized = otpContextPattern.replace(sanitized) { match ->
            val prefix = match.groupValues.getOrNull(1).orEmpty()
            "$prefix: [رمز محجوب]"
        }
        sanitized = passwordContextPattern.replace(sanitized) { match ->
            val prefix = match.groupValues.getOrNull(1).orEmpty()
            "$prefix: [كلمة سر محجوبة]"
        }
        sanitized = bearerOrApiKeyPattern.replace(sanitized, "[مفتاح سري محجوب]")
        return sanitized
    }

    fun containsSensitiveSecret(input: String): Boolean {
        if (input.isBlank()) return false
        return cardPattern.containsMatchIn(input) ||
            otpContextPattern.containsMatchIn(input) ||
            passwordContextPattern.containsMatchIn(input) ||
            bearerOrApiKeyPattern.containsMatchIn(input)
    }
}

object CommandSafetyPolicy {

    private val sensitiveKeywords = listOf(
        // Arabic sensitive terms
        "حذف", "مسح", "إزالة", "إلغاء تثبيت", "فرمتة", "إعادة ضبط",
        "دفع", "شراء", "تحويل", "رصيد", "بنك", "بطاقة", "فاتورة", "سداد",
        "كلمة المرور", "كلمة السر", "رمز التحقق", "تأكيد", "موافقة",
        "إرسال", "نشر", "تغريد", "اتصال", "مكالمة", "حظر", "صلاحيات", "الأمان",
        "تسجيل دخول", "تعديل الحساب",
        // English sensitive terms
        "delete", "remove", "erase", "uninstall", "factory", "reset",
        "pay", "payment", "purchase", "buy", "transfer", "bank", "card",
        "password", "passcode", "otp", "pin", "confirm", "approve", "submit",
        "send", "post", "publish", "tweet", "call", "dial", "block",
        "permission", "security", "checkout", "login", "sign in",
    )

    private val sensitiveAppPackages = listOf(
        "com.android.settings",
        "com.miui.securitycenter",
        "com.android.vending",
        "com.google.android.packageinstaller",
    )

    fun assess(
        command: AssistantCommand,
        confirmSensitiveActions: Boolean,
    ): SafetyAssessment {
        return when (command) {
            is AssistantCommand.Speak,
            is AssistantCommand.AskClarification,
            -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "رد أو استيضاح آمن.",
            )

            is AssistantCommand.ReadScreen -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "قراءة محتوى الشاشة الحالية مع استبعاد حقول كلمات المرور.",
            )

            is AssistantCommand.WebSearch -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "بحث ويب قياسي للقراءة فقط.",
            )

            is AssistantCommand.FetchWebpage -> {
                val urlLower = command.url.trim().lowercase(Locale.ROOT)
                val isHttps = urlLower.startsWith("https://")
                val isSensitive = !isHttps || containsSensitiveKeyword(urlLower)
                SafetyAssessment(
                    riskLevel = if (isSensitive) RiskLevel.SENSITIVE else RiskLevel.SAFE,
                    requiresUserConfirmation = isSensitive,
                    reasonArabic = if (!isHttps) {
                        "قراءة صفحة ويب عبر رابط غير مشفر يتطلب تأكيدك."
                    } else if (isSensitive) {
                        "الرابط يحتوي على كلمات حساسة."
                    } else {
                        "قراءة نص صفحة ويب آمنة (HTTPS)."
                    },
                )
            }

            is AssistantCommand.Scroll -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "تمرير شاشة قياسي.",
            )

            is AssistantCommand.GlobalAction -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "تنقل عام في النظام.",
            )

            is AssistantCommand.OpenApp -> {
                val pkg = command.packageName?.lowercase(Locale.ROOT).orEmpty()
                val label = command.appName?.lowercase(Locale.ROOT).orEmpty()
                val isSensitive = sensitiveAppPackages.any { pkg.contains(it) } ||
                    containsSensitiveKeyword(label) ||
                    containsSensitiveKeyword(pkg)
                if (isSensitive) {
                    SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "فتح تطبيق حساس أو متعلق بإعدادات النظام والأمان.",
                    )
                } else {
                    SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = false,
                        reasonArabic = "فتح تطبيق عادي.",
                    )
                }
            }

            is AssistantCommand.OpenUrl -> {
                val urlLower = command.url.trim().lowercase(Locale.ROOT)
                val isWeb = urlLower.startsWith("https://") || urlLower.startsWith("http://")
                val isSensitiveUrl = !isWeb || containsSensitiveKeyword(urlLower)
                if (isSensitiveUrl) {
                    SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "الرابط غير قياسي أو يحتوي على عملية حساسة.",
                    )
                } else {
                    SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = confirmSensitiveActions && urlLower.startsWith("http://"),
                        reasonArabic = if (urlLower.startsWith("http://")) {
                            "رابط غير مشفر (HTTP) يتطلب تأكيدك."
                        } else {
                            "فتح رابط ويب آمن."
                        },
                    )
                }
            }

            is AssistantCommand.Tap -> {
                val target = command.targetText.orEmpty()
                val isKeywordSensitive = containsSensitiveKeyword(target)
                val isBlindCoordinateTap = target.isBlank() && command.x != null && command.y != null
                when {
                    isKeywordSensitive -> SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "النقر يستهدف عنصراً حساساً (حذف/دفع/إرسال/نشر/تأكيد).",
                    )
                    isBlindCoordinateTap -> SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "النقر بالإحداثيات المباشرة يتطلب تأكيداً لمنع الضغط الخاطئ.",
                    )
                    confirmSensitiveActions -> SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = true,
                        reasonArabic = "تم تفعيل وضع التأكيد المسبق لأوامر التفاعل المباشر.",
                    )
                    else -> SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = false,
                        reasonArabic = "نقر على عنصر واجهة محدد.",
                    )
                }
            }

            is AssistantCommand.TypeText -> {
                val text = command.text
                val hint = command.targetHint.orEmpty()
                val isSensitive = containsSensitiveKeyword(text) ||
                    containsSensitiveKeyword(hint) ||
                    SensitiveInputFilter.containsSensitiveSecret(text)
                SafetyAssessment(
                    riskLevel = if (isSensitive) RiskLevel.SENSITIVE else RiskLevel.MODERATE,
                    requiresUserConfirmation = isSensitive || confirmSensitiveActions,
                    reasonArabic = if (isSensitive) {
                        "النص أو حقل الإدخال يبدو حساساً (كلمة مرور/دفع/إرسال)."
                    } else {
                        "كتابة نص داخل حقل في الشاشة تتطلب تأكيدك."
                    },
                )
            }
        }
    }

    private fun containsSensitiveKeyword(input: String): Boolean {
        if (input.isBlank()) return false
        val normalized = input.lowercase(Locale.ROOT)
        return sensitiveKeywords.any { normalized.contains(it.lowercase(Locale.ROOT)) }
    }
}
