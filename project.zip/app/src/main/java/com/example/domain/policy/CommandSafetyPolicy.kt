package com.example.domain.policy

import com.example.domain.model.CompanionCommand
import com.example.domain.model.RiskLevel
import java.util.Locale

data class SafetyAssessment(
    val riskLevel: RiskLevel,
    val requiresUserConfirmation: Boolean,
    val reasonArabic: String,
)

object CommandSafetyPolicy {

    private val sensitiveKeywords = listOf(
        // Arabic sensitive terms
        "حذف", "مسح", "إزالة", "إلغاء تثبيت", "فرمتة", "إعادة ضبط",
        "دفع", "شراء", "تحويل", "رصيد", "بنك", "بطاقة", "فاتورة",
        "كلمة المرور", "كلمة السر", "رمز التحقق", "تأكيد", "موافقة",
        "إرسال", "اتصال", "مكالمة", "حظر", "صلاحيات", "الأمان",
        // English sensitive terms
        "delete", "remove", "erase", "uninstall", "factory", "reset",
        "pay", "payment", "purchase", "buy", "transfer", "bank", "card",
        "password", "passcode", "otp", "pin", "confirm", "approve",
        "send", "call", "dial", "block", "permission", "security", "checkout",
    )

    private val sensitiveAppPackages = listOf(
        "com.android.settings",
        "com.miui.securitycenter",
        "com.android.vending",
        "com.google.android.packageinstaller",
    )

    fun assess(
        command: CompanionCommand,
        confirmSensitiveActions: Boolean,
    ): SafetyAssessment {
        return when (command) {
            is CompanionCommand.Speak -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "رد صوتي آمن.",
            )

            is CompanionCommand.Scroll -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "تمرير شاشة قياسي.",
            )

            is CompanionCommand.GlobalAction -> SafetyAssessment(
                riskLevel = RiskLevel.SAFE,
                requiresUserConfirmation = false,
                reasonArabic = "تنقل عام في النظام.",
            )

            is CompanionCommand.OpenApp -> {
                val pkg = command.packageName?.lowercase(Locale.ROOT).orEmpty()
                val label = command.appName?.lowercase(Locale.ROOT).orEmpty()
                val isSensitive = sensitiveAppPackages.any { pkg.contains(it) } ||
                    containsSensitiveKeyword(label) ||
                    containsSensitiveKeyword(pkg)
                if (isSensitive) {
                    SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "فتح تطبيق حساس أو متعلق بإعدادات النظام والأمان.",
                    )
                } else {
                    SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = false,
                        reasonArabic = "فتح تطبيق عادي.",
                    )
                }
            }

            is CompanionCommand.OpenUrl -> {
                val urlLower = command.url.trim().lowercase(Locale.ROOT)
                val isWeb = urlLower.startsWith("https://") || urlLower.startsWith("http://")
                val isSensitiveUrl = !isWeb || containsSensitiveKeyword(urlLower)
                if (isSensitiveUrl) {
                    SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "الرابط غير قياسي أو يحتوي على عملية حساسة.",
                    )
                } else {
                    SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = confirmSensitiveActions && urlLower.startsWith("http://"),
                        reasonArabic = if (urlLower.startsWith("http://")) {
                            "رابط غير مشفر (HTTP) يتطلب تأكيدك."
                        } else {
                            "فتح رابط ويب آمن."
                        },
                    )
                }
            }

            is CompanionCommand.Tap -> {
                val target = command.targetText.orEmpty()
                val isKeywordSensitive = containsSensitiveKeyword(target)
                val isBlindCoordinateTap = target.isBlank() && command.x != null && command.y != null
                when {
                    isKeywordSensitive -> SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "النقر يستهدف عنصراً حساساً (حذف/دفع/إرسال/تأكيد).",
                    )
                    isBlindCoordinateTap -> SafetyAssessment(
                        riskLevel = RiskLevel.SENSITIVE,
                        requiresUserConfirmation = true,
                        reasonArabic = "النقر بالإحداثيات المباشرة يتطلب تأكيداً لمنع الضغط الخاطئ.",
                    )
                    confirmSensitiveActions -> SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = true,
                        reasonArabic = "تم تفعيل وضع التأكيد المسبق لأوامر التفاعل المباشر.",
                    )
                    else -> SafetyAssessment(
                        riskLevel = RiskLevel.MODERATE,
                        requiresUserConfirmation = false,
                        reasonArabic = "نقر على عنصر واجهة محدد.",
                    )
                }
            }

            is CompanionCommand.TypeText -> {
                val textLower = command.text
                val hintLower = command.targetHint.orEmpty()
                val isSensitive = containsSensitiveKeyword(textLower) || containsSensitiveKeyword(hintLower)
                SafetyAssessment(
                    riskLevel = if (isSensitive) RiskLevel.SENSITIVE else RiskLevel.MODERATE,
                    requiresUserConfirmation = isSensitive || confirmSensitiveActions,
                    reasonArabic = if (isSensitive) {
                        "النص أو حقل الإدخال يبدو حساساً (كلمة مرور/دفع/إرسال)."
                    } else {
                        "كتابة نص داخل حقل في الشاشة تتطلب تأكيدك."
                    },
                )
            }
        }
    }

    private fun containsSensitiveKeyword(input: String): Boolean {
        if (input.isBlank()) return false
        val normalized = input.lowercase(Locale.ROOT)
        return sensitiveKeywords.any { normalized.contains(it.lowercase(Locale.ROOT)) }
    }
}
