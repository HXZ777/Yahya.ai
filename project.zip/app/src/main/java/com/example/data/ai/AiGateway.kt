package com.example.data.ai

import com.example.domain.model.AiConnectionTestResult
import com.example.domain.model.AssistantCommand
import com.example.domain.model.AssistantSettings
import com.example.domain.model.WebSource

data class AiTurnToolCall(
    val callId: String,
    val functionName: String,
    val command: AssistantCommand,
)

data class ToolExecutionReport(
    val callId: String,
    val functionName: String,
    val success: Boolean,
    val output: String,
    val sources: List<WebSource> = emptyList(),
)

data class GroundedSearchResult(
    val success: Boolean,
    val summaryText: String,
    val sources: List<WebSource> = emptyList(),
    val errorMessage: String? = null,
)

sealed interface AiTurnOutcome {
    data class ToolCallsRequested(
        val calls: List<AiTurnToolCall>,
        val preliminaryText: String? = null,
        val sources: List<WebSource> = emptyList(),
    ) : AiTurnOutcome

    data class FinalReply(
        val text: String,
        val sources: List<WebSource> = emptyList(),
    ) : AiTurnOutcome

    data class Error(
        val arabicMessage: String,
        val isNetworkError: Boolean = false,
        val isAuthError: Boolean = false,
    ) : AiTurnOutcome
}

/**
 * Gateway abstraction for AI reasoning.
 * Currently backed by GeminiAssistantRepository (direct Gemini Developer API with Keystore-protected user key).
 * Designed so a secure backend proxy implementation can replace direct API calls without changing coordinator/UI code.
 */
interface AiGateway {
    suspend fun startUserTurn(
        userInput: String,
        apiKey: String,
        settings: AssistantSettings,
        deviceContextSummary: String,
    ): AiTurnOutcome

    suspend fun submitToolResults(
        reports: List<ToolExecutionReport>,
        apiKey: String,
        settings: AssistantSettings,
    ): AiTurnOutcome

    suspend fun performGroundedWebSearch(
        query: String,
        apiKey: String,
        modelId: String,
    ): GroundedSearchResult

    suspend fun testConnection(
        apiKey: String,
        modelId: String,
    ): AiConnectionTestResult

    fun clearConversation()
}
