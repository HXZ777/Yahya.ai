package com.example.data.remote

import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import org.json.JSONObject

data class RunnerHealthResult(
    val reachable: Boolean,
    val message: String,
    val gradleVersion: String? = null,
    val sdkPlatform: String? = null,
)

data class RemoteBuildOutcome(
    val success: Boolean,
    val outputApkFile: File? = null,
    val serverLogs: List<String> = emptyList(),
    val errorMessage: String? = null,
)

class RemoteGradleBuildClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.MINUTES)
        .writeTimeout(5, TimeUnit.MINUTES)
        .build()

    suspend fun checkHealth(baseUrl: String, authToken: String): RunnerHealthResult =
        withContext(Dispatchers.IO) {
            val normalized = baseUrl.trim().trimEnd('/')
            if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
                return@withContext RunnerHealthResult(false, "URL must start with http:// or https://")
            }
            runCatching {
                val reqBuilder = Request.Builder().url("$normalized/health").get()
                if (authToken.isNotBlank()) {
                    reqBuilder.addHeader("Authorization", "Bearer ${authToken.trim()}")
                }
                client.newCall(reqBuilder.build()).execute().use { response ->
                    val bodyText = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        RunnerHealthResult(false, "Server responded HTTP ${response.code}: ${response.message}")
                    } else {
                        val json = runCatching { JSONObject(bodyText) }.getOrNull()
                        RunnerHealthResult(
                            reachable = true,
                            message = json?.optString("status")?.takeIf { it.isNotBlank() } ?: "Runner Online",
                            gradleVersion = json?.optString("gradleVersion")?.takeIf { it.isNotBlank() },
                            sdkPlatform = json?.optString("androidSdk")?.takeIf { it.isNotBlank() },
                        )
                    }
                }
            }.getOrElse { err ->
                RunnerHealthResult(false, err.localizedMessage ?: "Failed to connect to Build Runner")
            }
        }

    suspend fun uploadAndBuildApk(
        baseUrl: String,
        authToken: String,
        zipFile: File,
        variant: String,
        destinationApkFile: File,
        onUploadProgress: (Float) -> Unit,
        onLogLine: (String) -> Unit,
    ): RemoteBuildOutcome = withContext(Dispatchers.IO) {
        val normalized = baseUrl.trim().trimEnd('/')
        if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
            return@withContext RemoteBuildOutcome(
                success = false,
                errorMessage = "Invalid Gradle Runner URL. Expected http:// or https:// endpoint.",
            )
        }

        val progressBody = object : RequestBody() {
            override fun contentType() = "application/zip".toMediaType()
            override fun contentLength() = zipFile.length()
            override fun writeTo(sink: BufferedSink) {
                val total = zipFile.length().coerceAtLeast(1L)
                var uploaded = 0L
                val buf = ByteArray(16 * 1024)
                zipFile.inputStream().use { fis ->
                    while (true) {
                        val read = fis.read(buf)
                        if (read <= 0) break
                        sink.write(buf, 0, read)
                        uploaded += read
                        onUploadProgress((uploaded.toFloat() / total.toFloat()).coerceIn(0f, 1f))
                    }
                }
            }
        }

        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("variant", variant)
            .addFormDataPart("project", zipFile.name, progressBody)
            .build()

        val reqBuilder = Request.Builder()
            .url("$normalized/build")
            .post(multipart)

        if (authToken.isNotBlank()) {
            reqBuilder.addHeader("Authorization", "Bearer ${authToken.trim()}")
        }

        runCatching {
            client.newCall(reqBuilder.build()).execute().use { response ->
                val contentType = response.header("Content-Type").orEmpty().lowercase()
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty()
                    val parsedMsg = runCatching { JSONObject(errBody).optString("error") }
                        .getOrNull()?.takeIf { it.isNotBlank() }
                        ?: errBody.take(400).ifBlank { "HTTP ${response.code} ${response.message}" }
                    return@use RemoteBuildOutcome(
                        success = false,
                        serverLogs = extractLogsFromJson(errBody),
                        errorMessage = parsedMsg,
                    )
                }

                if (contentType.contains("application/vnd.android.package-archive") ||
                    contentType.contains("application/octet-stream")
                ) {
                    onLogLine("Receiving compiled APK binary stream from build runner...")
                    destinationApkFile.parentFile?.mkdirs()
                    response.body?.byteStream()?.use { input ->
                        FileOutputStream(destinationApkFile).use { out ->
                            input.copyTo(out)
                        }
                    } ?: return@use RemoteBuildOutcome(false, errorMessage = "Empty APK response stream.")
                    RemoteBuildOutcome(
                        success = true,
                        outputApkFile = destinationApkFile,
                        serverLogs = listOf("APK downloaded (${destinationApkFile.length()} bytes)."),
                    )
                } else {
                    val jsonBody = response.body?.string().orEmpty()
                    val json = runCatching { JSONObject(jsonBody) }.getOrNull()
                        ?: return@use RemoteBuildOutcome(false, errorMessage = "Unexpected response from build runner.")
                    val logs = extractLogsFromJson(jsonBody)
                    val apkDownloadUrl = json.optString("apkUrl").takeIf { it.isNotBlank() }
                    if (apkDownloadUrl != null) {
                        val resolvedUrl = if (apkDownloadUrl.startsWith("http")) {
                            apkDownloadUrl
                        } else {
                            "$normalized/${apkDownloadUrl.trimStart('/')}"
                        }
                        onLogLine("Downloading compiled APK from $resolvedUrl...")
                        val dlReq = Request.Builder().url(resolvedUrl).apply {
                            if (authToken.isNotBlank()) addHeader("Authorization", "Bearer ${authToken.trim()}")
                        }.build()
                        client.newCall(dlReq).execute().use { dlResp ->
                            if (!dlResp.isSuccessful) {
                                return@use RemoteBuildOutcome(
                                    success = false,
                                    serverLogs = logs,
                                    errorMessage = "Failed to download APK artifact: HTTP ${dlResp.code}",
                                )
                            }
                            destinationApkFile.parentFile?.mkdirs()
                            dlResp.body?.byteStream()?.use { input ->
                                FileOutputStream(destinationApkFile).use { out -> input.copyTo(out) }
                            }
                        }
                        RemoteBuildOutcome(true, destinationApkFile, logs)
                    } else {
                        RemoteBuildOutcome(
                            success = false,
                            serverLogs = logs,
                            errorMessage = json.optString("error").ifBlank { "Build runner did not return an APK artifact." },
                        )
                    }
                }
            }
        }.getOrElse { err ->
            RemoteBuildOutcome(
                success = false,
                errorMessage = err.localizedMessage ?: "Network error while communicating with Gradle Build Runner.",
            )
        }
    }

    private fun extractLogsFromJson(raw: String): List<String> {
        return runCatching {
            val json = JSONObject(raw)
            val arr = json.optJSONArray("logs") ?: return emptyList()
            List(arr.length()) { idx -> arr.optString(idx) }.filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
    }
}
