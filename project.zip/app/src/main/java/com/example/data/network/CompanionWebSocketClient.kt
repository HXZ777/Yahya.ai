package com.example.data.network

import android.os.Build
import com.example.domain.model.AssistantSettings
import com.example.domain.model.CompanionCommand
import com.example.domain.model.ConnectionState
import com.example.domain.model.ConnectionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

sealed interface TransportEvent {
    data class CommandReceived(val command: CompanionCommand) : TransportEvent
    data class SystemNotice(val title: String, val detail: String, val isError: Boolean) : TransportEvent
}

class CompanionWebSocketClient {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val _connectionState = MutableStateFlow(ConnectionState())
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _events = MutableSharedFlow<TransportEvent>(extraBufferCapacity = 32)
    val events: SharedFlow<TransportEvent> = _events.asSharedFlow()

    private var activeSocket: WebSocket? = null
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private var lastSettings: AssistantSettings? = null
    private var lastAccessibilityEnabled: Boolean = false
    private var manualDisconnect: Boolean = false
    private var reconnectAttempt: Int = 0

    fun connect(settings: AssistantSettings, accessibilityEnabled: Boolean) {
        lastSettings = settings
        lastAccessibilityEnabled = accessibilityEnabled
        manualDisconnect = false

        if (!settings.isPaired) {
            disconnect(clearError = true)
            return
        }

        reconnectJob?.cancel()
        openSocket(settings, accessibilityEnabled)
    }

    private fun openSocket(settings: AssistantSettings, accessibilityEnabled: Boolean) {
        activeSocket?.close(1000, "Reconnecting")
        activeSocket = null
        heartbeatJob?.cancel()

        val scheme = if (settings.useTls) "wss" else "ws"
        val url = "$scheme://${settings.pairedHost}:${settings.pairedPort}/companion"

        _connectionState.value = ConnectionState(
            status = ConnectionStatus.CONNECTING,
            pairedDeviceName = settings.pairedDeviceName.ifBlank { settings.pairedHost },
            endpointLabel = url,
        )

        val request = Request.Builder()
            .url(url)
            .addHeader("X-Companion-Device-Id", settings.deviceId)
            .build()

        activeSocket = okHttpClient.newWebSocket(
            request,
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    reconnectAttempt = 0
                    val handshake = CompanionProtocol.buildHandshake(
                        deviceId = settings.deviceId,
                        deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
                        assistantName = settings.assistantName,
                        wakePhrase = settings.wakePhrase,
                        pairingCode = settings.pairingCode,
                        secret = settings.pairingSecret,
                        accessibilityEnabled = accessibilityEnabled,
                    )
                    webSocket.send(handshake)
                    _connectionState.value = ConnectionState(
                        status = ConnectionStatus.CONNECTED,
                        pairedDeviceName = settings.pairedDeviceName.ifBlank { settings.pairedHost },
                        endpointLabel = url,
                        lastSyncTimestamp = System.currentTimeMillis(),
                    )
                    startHeartbeat(settings)
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    val frame = CompanionProtocol.parseInboundFrame(text, settings.pairingSecret) ?: return
                    when (frame) {
                        is InboundFrame.HandshakeAck -> {
                            if (frame.accepted) {
                                _connectionState.value = _connectionState.value.copy(
                                    status = ConnectionStatus.CONNECTED,
                                    pairedDeviceName = frame.brainDeviceName,
                                    lastSyncTimestamp = System.currentTimeMillis(),
                                    errorMessage = null,
                                )
                                _events.tryEmit(
                                    TransportEvent.SystemNotice(
                                        title = "تم الاتصال بالهاتف الرئيسي",
                                        detail = frame.message,
                                        isError = false,
                                    ),
                                )
                            } else {
                                _connectionState.value = _connectionState.value.copy(
                                    status = ConnectionStatus.ERROR,
                                    errorMessage = frame.message,
                                )
                            }
                        }

                        is InboundFrame.Pong -> {
                            val rtt = (System.currentTimeMillis() - frame.timestampMs).coerceAtLeast(0L)
                            _connectionState.value = _connectionState.value.copy(
                                latencyMs = rtt,
                                lastSyncTimestamp = System.currentTimeMillis(),
                            )
                        }

                        is InboundFrame.AuthRejected -> {
                            _connectionState.value = _connectionState.value.copy(
                                status = ConnectionStatus.ERROR,
                                errorMessage = frame.reason,
                            )
                            _events.tryEmit(
                                TransportEvent.SystemNotice(
                                    title = "رفض التحقق الأمني",
                                    detail = frame.reason,
                                    isError = true,
                                ),
                            )
                        }

                        is InboundFrame.CommandFrame -> {
                            _connectionState.value = _connectionState.value.copy(
                                lastSyncTimestamp = System.currentTimeMillis(),
                            )
                            _events.tryEmit(TransportEvent.CommandReceived(frame.command))
                        }

                        is InboundFrame.Unknown -> Unit
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(code, reason)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    heartbeatJob?.cancel()
                    if (manualDisconnect) {
                        _connectionState.value = ConnectionState(status = ConnectionStatus.DISCONNECTED)
                    } else {
                        _connectionState.value = _connectionState.value.copy(
                            status = ConnectionStatus.DISCONNECTED,
                            errorMessage = reason.ifBlank { "انقطع الاتصال" },
                        )
                        scheduleReconnect()
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    heartbeatJob?.cancel()
                    if (manualDisconnect) {
                        _connectionState.value = ConnectionState(status = ConnectionStatus.DISCONNECTED)
                        return
                    }
                    val message = t.localizedMessage ?: "تعذر الوصول إلى الهاتف الآخر"
                    _connectionState.value = _connectionState.value.copy(
                        status = ConnectionStatus.ERROR,
                        errorMessage = message,
                    )
                    scheduleReconnect()
                }
            },
        )
    }

    private fun startHeartbeat(settings: AssistantSettings) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(15_000L)
                val ping = CompanionProtocol.buildPing(settings.deviceId, settings.pairingSecret)
                activeSocket?.send(ping)
            }
        }
    }

    private fun scheduleReconnect() {
        val settings = lastSettings ?: return
        if (manualDisconnect || !settings.isPaired) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            reconnectAttempt = (reconnectAttempt + 1).coerceAtMost(5)
            val delayMs = (2000L * reconnectAttempt).coerceAtMost(15_000L)
            delay(delayMs)
            if (!manualDisconnect && settings.isPaired) {
                openSocket(settings, lastAccessibilityEnabled)
            }
        }
    }

    fun sendSpeechTranscript(
        settings: AssistantSettings,
        transcript: String,
        triggeredByWakePhrase: Boolean,
    ): Boolean {
        val socket = activeSocket ?: return false
        if (_connectionState.value.status != ConnectionStatus.CONNECTED) return false
        val frame = CompanionProtocol.buildSpeechTranscript(
            deviceId = settings.deviceId,
            secret = settings.pairingSecret,
            transcript = transcript,
            language = settings.speechLanguage,
            triggeredByWakePhrase = triggeredByWakePhrase,
        )
        return socket.send(frame)
    }

    fun sendCommandResult(
        settings: AssistantSettings,
        commandId: String,
        status: String,
        detail: String,
    ): Boolean {
        val socket = activeSocket ?: return false
        val frame = CompanionProtocol.buildCommandResult(
            deviceId = settings.deviceId,
            secret = settings.pairingSecret,
            commandId = commandId,
            status = status,
            detail = detail,
        )
        return socket.send(frame)
    }

    fun sendPing(settings: AssistantSettings): Boolean {
        val socket = activeSocket ?: return false
        return socket.send(CompanionProtocol.buildPing(settings.deviceId, settings.pairingSecret))
    }

    fun disconnect(clearError: Boolean = true) {
        manualDisconnect = true
        reconnectJob?.cancel()
        heartbeatJob?.cancel()
        activeSocket?.close(1000, "User disconnected")
        activeSocket = null
        if (clearError) {
            _connectionState.value = ConnectionState(status = ConnectionStatus.DISCONNECTED)
        }
    }
}
