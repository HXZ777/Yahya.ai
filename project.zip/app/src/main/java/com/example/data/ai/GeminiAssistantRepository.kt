package com.example.data.ai

import com.example.domain.model.AiConnectionTestResult
import com.example.domain.model.AssistantCommand
import com.example.domain.model.AssistantSettings
import com.example.domain.model.CloudModelOption
import com.example.domain.model.GlobalDeviceAction
import com.example.domain.model.ScrollDirection
import com.example.domain.model.WebSource
import com.example.domain.policy.SensitiveInputFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.UnknownHostException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class GeminiAssistantRepository(
    private val httpClient: OkHttpClient = defaultHttpClient(),
) : AiGateway {

    private val historyLock = Any()
    private val conversationHistory = mutableListOf<JSONObject>()

    override suspend fun startUserTurn(
        userInput: String,
        apiKey: String,
        settings: AssistantSettings,
        deviceContextSummary: String,
    ): AiTurnOutcome {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return AiTurnOutcome.Error(
                arabicMessage = "مفتاح Gemini API غير مُعدّ. أضف المفتاح في الإعدادات أولاً.",
                isAuthError = true,
            )
        }

        val redactedInput = SensitiveInputFilter.redactSensitiveText(userInput.trim())
        val userMessageText = buildString {
            append(redactedInput)
            if (deviceContextSummary.isNotBlank()) {
                append("\n\n[حالة الجهاز الحالية: ")
                append(SensitiveInputFilter.redactSensitiveText(deviceContextSummary))
                append("]")
            }
        }

        val userContent = JSONObject().apply {
            put("role", "user")
            put(
                "parts",
                JSONArray().put(JSONObject().put("text", userMessageText)),
            )
        }

        val snapshot = synchronized(historyLock) {
            conversationHistory.add(userContent)
            trimHistoryIfNeeded()
            conversationHistory.map { JSONObject(it.toString()) }
        }

        val requestJson = buildPlannerRequestJson(snapshot, settings)
        val result = executeGenerateContent(
            modelId = settings.geminiModelId,
            apiKey = cleanKey,
            bodyJson = requestJson,
        )

        return handlePlannerHttpResult(result, rollbackLastTurnOnError = true)
    }

    override suspend fun submitToolResults(
        reports: List<ToolExecutionReport>,
        apiKey: String,
        settings: AssistantSettings,
    ): AiTurnOutcome {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return AiTurnOutcome.Error(
                arabicMessage = "مفتاح Gemini API غير موجود.",
                isAuthError = true,
            )
        }

        val responseParts = JSONArray()
        for (report in reports) {
            val responseObj = JSONObject().apply {
                put("success", report.success)
                put("result", SensitiveInputFilter.redactSensitiveText(report.output))
                if (report.sources.isNotEmpty()) {
                    val srcArr = JSONArray()
                    report.sources.forEach { src ->
                        srcArr.put(
                            JSONObject()
                                .put("title", src.title)
                                .put("url", src.url),
                        )
                    }
                    put("sources", srcArr)
                }
            }
            val fnRespPart = JSONObject().apply {
                put(
                    "functionResponse",
                    JSONObject().apply {
                        put("name", report.functionName)
                        put("response", responseObj)
                    },
                )
            }
            responseParts.put(fnRespPart)
        }

        val toolContent = JSONObject().apply {
            put("role", "user")
            put("parts", responseParts)
        }

        val snapshot = synchronized(historyLock) {
            conversationHistory.add(toolContent)
            trimHistoryIfNeeded()
            conversationHistory.map { JSONObject(it.toString()) }
        }

        val requestJson = buildPlannerRequestJson(snapshot, settings)
        val result = executeGenerateContent(
            modelId = settings.geminiModelId,
            apiKey = cleanKey,
            bodyJson = requestJson,
        )

        return handlePlannerHttpResult(result, rollbackLastTurnOnError = false)
    }

    override suspend fun performGroundedWebSearch(
        query: String,
        apiKey: String,
        modelId: String,
    ): GroundedSearchResult {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return GroundedSearchResult(
                success = false,
                summaryText = "",
                errorMessage = "مفتاح Gemini API غير موجود لإجراء البحث.",
            )
        }
        val cleanQuery = SensitiveInputFilter.redactSensitiveText(query.trim())
        if (cleanQuery.isBlank()) {
            return GroundedSearchResult(
                success = false,
                summaryText = "",
                errorMessage = "استعلام البحث فارغ.",
            )
        }

        val body = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(
                        JSONObject().put(
                            "text",
                            "أنت محرك بحث وتلخيص دقيق. استخدم أداة البحث Google Search فقط للإجابة باللغة العربية " +
                                "بمعلومات موثقة ومحدثة، واذكر الوقائع دون اختلاق أي نتائج غير موجودة.",
                        ),
                    ),
                ),
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().put(
                                JSONObject().put("text", "ابحث في الويب ولخّص الإجابة الدقيقة عن: $cleanQuery"),
                            ),
                        )
                    },
                ),
            )
            put(
                "tools",
                JSONArray().put(JSONObject().put("google_search", JSONObject())),
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.2)
                },
            )
        }

        val httpResult = executeGenerateContent(
            modelId = modelId.ifBlank { AssistantSettings.DEFAULT_GEMINI_MODEL },
            apiKey = cleanKey,
            bodyJson = body,
        )

        return when (httpResult) {
            is HttpCallResult.Success -> {
                val parsed = GeminiResponseParser.parseGenerateContentResponse(httpResult.body)
                if (parsed.errorMessage != null) {
                    GroundedSearchResult(
                        success = false,
                        summaryText = "",
                        errorMessage = parsed.errorMessage,
                    )
                } else {
                    GroundedSearchResult(
                        success = parsed.text.isNotBlank(),
                        summaryText = parsed.text.ifBlank { "لم تُعد نتائج بحث واضحة." },
                        sources = parsed.sources,
                    )
                }
            }
            is HttpCallResult.Failure -> {
                GroundedSearchResult(
                    success = false,
                    summaryText = "",
                    errorMessage = httpResult.arabicMessage,
                )
            }
        }
    }

    override suspend fun testConnection(apiKey: String, modelId: String): AiConnectionTestResult {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return AiConnectionTestResult(
                success = false,
                detail = "الرجاء إدخال مفتاح Gemini API أولاً.",
            )
        }
        val effectiveModel = normalizeModelId(modelId)
        val genConfig = JSONObject().apply {
            put("maxOutputTokens", 256)
            put("temperature", 0.0)
            if (effectiveModel.contains("2.5-flash", ignoreCase = true)) {
                put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            }
        }
        val body = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", "أجب بكلمة واحدة فقط: متصل")),
                        )
                    },
                ),
            )
            put("generationConfig", genConfig)
        }

        val startedAt = System.currentTimeMillis()
        return when (val res = executeGenerateContent(effectiveModel, cleanKey, body)) {
            is HttpCallResult.Success -> {
                val latency = System.currentTimeMillis() - startedAt
                val parsed = GeminiResponseParser.parseGenerateContentResponse(res.body)
                if (parsed.errorMessage != null) {
                    AiConnectionTestResult(
                        success = false,
                        latencyMs = latency,
                        detail = parsed.errorMessage,
                    )
                } else {
                    AiConnectionTestResult(
                        success = true,
                        latencyMs = latency,
                        detail = "تم الاتصال السحابي بنجاح بالنموذج $effectiveModel (${latency}ms).",
                    )
                }
            }
            is HttpCallResult.Failure -> AiConnectionTestResult(
                success = false,
                detail = res.arabicMessage,
            )
        }
    }

    override suspend fun fetchAvailableModels(apiKey: String): CloudModelsFetchResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return@withContext CloudModelsFetchResult(
                success = false,
                errorMessage = "أدخل مفتاح Gemini API أولاً لجلب قائمة النماذج السحابية المتاحة.",
            )
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=50")
            .addHeader("x-goog-api-key", cleanKey)
            .get()
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val apiError = GeminiResponseParser.extractApiErrorMessage(rawBody)
                    return@withContext CloudModelsFetchResult(
                        success = false,
                        errorMessage = when (response.code) {
                            401, 403 -> "تعذر التحقق من مفتاح Gemini API (${apiError ?: response.code})."
                            else -> "تعذر جلب النماذج (${response.code}): ${apiError ?: response.message}"
                        },
                    )
                }
                val models = GeminiResponseParser.parseAvailableModelsResponse(rawBody)
                if (models.isEmpty()) {
                    CloudModelsFetchResult(
                        success = false,
                        errorMessage = "لم يُرجع الخادم نماذج متاحة للتوليد النصي لهذا المفتاح.",
                    )
                } else {
                    CloudModelsFetchResult(
                        success = true,
                        models = models,
                    )
                }
            }
        } catch (_: UnknownHostException) {
            CloudModelsFetchResult(
                success = false,
                errorMessage = "لا يوجد اتصال بالإنترنت لجلب النماذج السحابية.",
            )
        } catch (e: IOException) {
            CloudModelsFetchResult(
                success = false,
                errorMessage = "فشل الاتصال الشبكي أثناء جلب النماذج: ${e.localizedMessage ?: "انتهت المهلة"}",
            )
        }
    }

    override fun clearConversation() {
        synchronized(historyLock) {
            conversationHistory.clear()
        }
    }

    private fun handlePlannerHttpResult(
        result: HttpCallResult,
        rollbackLastTurnOnError: Boolean,
    ): AiTurnOutcome {
        return when (result) {
            is HttpCallResult.Failure -> {
                if (rollbackLastTurnOnError) {
                    synchronized(historyLock) {
                        if (conversationHistory.isNotEmpty()) {
                            conversationHistory.removeAt(conversationHistory.lastIndex)
                        }
                    }
                }
                AiTurnOutcome.Error(
                    arabicMessage = result.arabicMessage,
                    isNetworkError = result.isNetworkError,
                    isAuthError = result.isAuthError,
                )
            }
            is HttpCallResult.Success -> {
                val parsed = GeminiResponseParser.parseGenerateContentResponse(result.body)
                if (parsed.errorMessage != null) {
                    return AiTurnOutcome.Error(arabicMessage = parsed.errorMessage)
                }

                parsed.rawModelContent?.let { modelContent ->
                    synchronized(historyLock) {
                        conversationHistory.add(modelContent)
                        trimHistoryIfNeeded()
                    }
                }

                if (parsed.toolCalls.isNotEmpty()) {
                    AiTurnOutcome.ToolCallsRequested(
                        calls = parsed.toolCalls,
                        preliminaryText = parsed.text.takeIf { it.isNotBlank() },
                        sources = parsed.sources,
                    )
                } else {
                    val reply = parsed.text.ifBlank {
                        "تمت معالجة الطلب، هل تحتاج إلى مساعدة إضافية؟"
                    }
                    AiTurnOutcome.FinalReply(
                        text = reply,
                        sources = parsed.sources,
                    )
                }
            }
        }
    }

    private fun trimHistoryIfNeeded() {
        while (conversationHistory.size > MAX_HISTORY_TURNS) {
            conversationHistory.removeAt(0)
        }
        // Ensure history starts on a clean user text turn rather than an orphaned model/functionResponse turn
        while (conversationHistory.isNotEmpty()) {
            val first = conversationHistory.first()
            val role = first.optString("role")
            val parts = first.optJSONArray("parts")
            val isFunctionResponse = parts != null &&
                parts.length() > 0 &&
                parts.optJSONObject(0)?.has("functionResponse") == true
            if (role == "user" && !isFunctionResponse) {
                break
            }
            conversationHistory.removeAt(0)
        }
    }

    private fun buildPlannerRequestJson(
        contents: List<JSONObject>,
        settings: AssistantSettings,
    ): JSONObject {
        val systemText = buildSystemInstruction(settings)
        val contentsArr = JSONArray()
        contents.forEach { contentsArr.put(it) }

        return JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemText)),
                ),
            )
            put("contents", contentsArr)
            put("tools", buildToolsArray(settings.webSearchEnabled))
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.35)
                },
            )
        }
    }

    private fun buildSystemInstruction(settings: AssistantSettings): String {
        val searchInstruction = if (settings.webSearchEnabled) {
            "- إذا سأل المستخدم عن معلومات حديثة أو أخبار أو طقس أو أسعار أو حقائق عامة أو أي بحث على الإنترنت، استخدم أداة web_search.\n" +
                "- إذا طلب المستخدم تلخيص أو قراءة صفحة ويب محددة برابط HTTPS، استخدم fetch_webpage.\n"
        } else {
            "- ميزة البحث في الإنترنت معطلة حالياً من الإعدادات. إذا طلب المستخدم بحثاً حياً على الإنترنت، أخبره بوضوح أن البحث معطّل ويمكنه تفعيله من الإعدادات.\n"
        }
        return """
            أنت المساعد الذكي الشخصي واسمك "${settings.assistantName}" داخل تطبيق "${AssistantSettings.APP_OFFICIAL_NAME}".
            تعمل مباشرة وبشكل مستقل على هاتف المستخدم Xiaomi Redmi Note 11 Pro بنظام Android 13 وHyperOS.
            تفهم اللغة العربية الفصحى واللهجات العربية خصوصاً اللهجة السعودية بطلاقة.

            قواعد العمل الصارمة:
            1. إذا طلب المستخدم إجراءً على الهاتف (فتح تطبيق، فتح رابط، النقر، التمرير، الكتابة، قراءة الشاشة، الرجوع/الرئيسية/الإشعارات)، استخدم الأدوات المنظمة المتاحة بدلاً من التخمين.
            2. افصل بوضوح بين:
               - البحث عن معلومات عبر الإنترنت: استخدم `web_search` أو `fetch_webpage`.
               - فتح رابط في متصفح الهاتف: استخدم `open_url`.
            ${searchInstruction}3. لا تخترع أبداً نتائج بحث أو محتوى شاشة أو تدّعِ أنك نفذت أمراً لم يتم فعلياً. اعتمد فقط على نتائج الأدوات الحقيقية.
            4. إذا فشل أمر (مثلاً خدمة تسهيل الوصول غير مفعّلة أو لم يُعثر على التطبيق/العنصر)، أخبر المستخدم بصراحة بالسبب والبديل المتاح أو استدعِ `read_screen` لفهم الشاشة الحالية إذا أمكن.
            5. إذا كان الطلب غامضاً أو ينقصه تفصيل مهم (مثل اسم التطبيق أو الجهة المقصودة)، استخدم `ask_clarification` لطرح سؤال قصير ومحدد.
            6. لا تطلب كلمات مرور أو رموز تحقق أو أرقام بطاقات، ولا ترسلها أبداً.
            7. اجعل ردودك النهائية باللغة العربية واضحة ومختصرة وطبيعية لتُقرأ وتُنطق صوتياً بسهولة.
        """.trimIndent()
    }

    private fun buildToolsArray(webSearchEnabled: Boolean): JSONArray {
        val declarations = JSONArray()

        declarations.put(
            functionDecl(
                name = FN_OPEN_APP,
                description = "فتح تطبيق مثبت على هاتف المستخدم باستخدام الاسم أو اسم الحزمة.",
                properties = JSONObject()
                    .put("app_name", stringProp("اسم التطبيق بالعربية أو الإنجليزية مثل: واتساب، يوتيوب، الكاميرا"))
                    .put("package_name", stringProp("اسم حزمة أندرويد إن كان معروفاً مثل com.whatsapp")),
                required = listOf("app_name"),
            ),
        )

        declarations.put(
            functionDecl(
                name = FN_OPEN_URL,
                description = "فتح رابط ويب في متصفح الهاتف.",
                properties = JSONObject()
                    .put("url", stringProp("الرابط الكامل يبدأ بـ https://")),
                required = listOf("url"),
            ),
        )

        if (webSearchEnabled) {
            declarations.put(
                functionDecl(
                    name = FN_WEB_SEARCH,
                    description = "البحث الحي في الإنترنت عبر Google Search للحصول على معلومات حديثة ومصادر موثقة.",
                    properties = JSONObject()
                        .put("query", stringProp("عبارة البحث الواضحة")),
                    required = listOf("query"),
                ),
            )
            declarations.put(
                functionDecl(
                    name = FN_FETCH_WEBPAGE,
                    description = "قراءة النص الأساسي لصفحة ويب HTTPS لغرض التلخيص أو الإجابة عن محتواها دون فتح المتصفح.",
                    properties = JSONObject()
                        .put("url", stringProp("رابط HTTPS للصفحة المطلوبة")),
                    required = listOf("url"),
                ),
            )
        }

        declarations.put(
            functionDecl(
                name = FN_READ_SCREEN,
                description = "قراءة ملخص العناصر والنصوص الظاهرة حالياً على شاشة الهاتف عبر خدمة تسهيل الوصول.",
                properties = JSONObject(),
                required = emptyList(),
            ),
        )

        declarations.put(
            functionDecl(
                name = FN_TAP_ELEMENT,
                description = "النقر على زر أو عنصر في الشاشة الحالية عبر نصه الظاهر أو إحداثيات الشاشة.",
                properties = JSONObject()
                    .put("target_text", stringProp("النص الظاهر على الزر أو العنصر المراد النقر عليه"))
                    .put("x", JSONObject().put("type", "NUMBER").put("description", "إحداثي X اختياري"))
                    .put("y", JSONObject().put("type", "NUMBER").put("description", "إحداثي Y اختياري")),
                required = emptyList(),
            ),
        )

        declarations.put(
            functionDecl(
                name = FN_SCROLL_SCREEN,
                description = "تمرير الشاشة الحالية لأعلى أو أسفل أو يمين أو يسار.",
                properties = JSONObject()
                    .put(
                        "direction",
                        JSONObject()
                            .put("type", "STRING")
                            .put("enum", JSONArray(listOf("UP", "DOWN", "LEFT", "RIGHT")))
                            .put("description", "اتجاه التمرير"),
                    ),
                required = listOf("direction"),
            ),
        )

        declarations.put(
            functionDecl(
                name = FN_TYPE_TEXT,
                description = "كتابة نص داخل حقل الإدخال النشط أو المحدد في الشاشة.",
                properties = JSONObject()
                    .put("text", stringProp("النص المطلوب كتابته"))
                    .put("target_hint", stringProp("تلميح أو اسم الحقل المستهدف إن وُجد")),
                required = listOf("text"),
            ),
        )

        declarations.put(
            functionDecl(
                name = FN_SYSTEM_ACTION,
                description = "تنفيذ زر تنقل عام في نظام أندرويد.",
                properties = JSONObject()
                    .put(
                        "action",
                        JSONObject()
                            .put("type", "STRING")
                            .put("enum", JSONArray(listOf("BACK", "HOME", "RECENTS", "NOTIFICATIONS")))
                            .put("description", "إجراء النظام المطلوب"),
                    ),
                required = listOf("action"),
            ),
        )

        declarations.put(
            functionDecl(
                name = FN_ASK_CLARIFICATION,
                description = "طرح سؤال توضيحي قصير للمستخدم عندما يكون الطلب ناقصاً أو غامضاً.",
                properties = JSONObject()
                    .put("question", stringProp("السؤال التوضيحي باللغة العربية")),
                required = listOf("question"),
            ),
        )

        return JSONArray().put(JSONObject().put("functionDeclarations", declarations))
    }

    private fun functionDecl(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String>,
    ): JSONObject {
        val params = JSONObject().apply {
            put("type", "OBJECT")
            put("properties", properties)
            if (required.isNotEmpty()) {
                put("required", JSONArray(required))
            }
        }
        return JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", params)
        }
    }

    private fun stringProp(description: String): JSONObject {
        return JSONObject()
            .put("type", "STRING")
            .put("description", description)
    }

    private sealed interface HttpCallResult {
        data class Success(val body: String) : HttpCallResult
        data class Failure(
            val arabicMessage: String,
            val isNetworkError: Boolean = false,
            val isAuthError: Boolean = false,
        ) : HttpCallResult
    }

    private fun normalizeModelId(modelId: String): String {
        return modelId.trim()
            .removePrefix("models/")
            .trim()
            .ifBlank { AssistantSettings.DEFAULT_GEMINI_MODEL }
    }

    private suspend fun executeGenerateContent(
        modelId: String,
        apiKey: String,
        bodyJson: JSONObject,
    ): HttpCallResult = withContext(Dispatchers.IO) {
        val safeModel = normalizeModelId(modelId)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent"
        val requestBody = bodyJson.toString().toRequestBody(JSON_MEDIA_TYPE)
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .post(requestBody)
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    HttpCallResult.Success(rawBody)
                } else {
                    val apiError = GeminiResponseParser.extractApiErrorMessage(rawBody)
                    when (response.code) {
                        400 -> HttpCallResult.Failure(
                            "رفض خادم Gemini الطلب للنموذج السحابي ($safeModel): ${apiError ?: "تحقق من اسم النموذج أو صيغة الطلب."}",
                        )
                        401, 403 -> HttpCallResult.Failure(
                            arabicMessage = "مفتاح Gemini API غير صالح أو لا يملك الصلاحية: ${apiError ?: "تحقق من المفتاح في الإعدادات."}",
                            isAuthError = true,
                        )
                        404 -> HttpCallResult.Failure(
                            "النموذج السحابي \"$safeModel\" غير متاح عبر Gemini API لهذا المفتاح" +
                                (if (apiError != null) " ($apiError)." else ".") +
                                " اضغط «تحديث النماذج المتاحة» في الإعدادات لاختيار نموذج متاح.",
                        )
                        429 -> HttpCallResult.Failure(
                            "تم تجاوز حد الطلبات مؤقتاً في Gemini API. انتظر قليلاً ثم أعد المحاولة.",
                        )
                        in 500..599 -> HttpCallResult.Failure(
                            "خدمة Gemini السحابية تواجه ضغطاً مؤقتاً (${response.code}). أعد المحاولة بعد لحظات.",
                        )
                        else -> HttpCallResult.Failure(
                            "خطأ من خادم Gemini (${response.code}): ${apiError ?: response.message}",
                        )
                    }
                }
            }
        } catch (_: UnknownHostException) {
            HttpCallResult.Failure(
                arabicMessage = "لا يوجد اتصال بالإنترنت أو تعذر الوصول إلى خادم Gemini.",
                isNetworkError = true,
            )
        } catch (e: IOException) {
            HttpCallResult.Failure(
                arabicMessage = "فشل الاتصال الشبكي بـ Gemini: ${e.localizedMessage ?: "انتهت المهلة"}",
                isNetworkError = true,
            )
        } catch (e: Exception) {
            HttpCallResult.Failure(
                arabicMessage = "حدث خطأ غير متوقع أثناء الاتصال بالذكاء الاصطناعي: ${e.localizedMessage ?: "خطأ غير معروف"}",
            )
        }
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val MAX_HISTORY_TURNS = 24

        const val FN_OPEN_APP = "open_app"
        const val FN_OPEN_URL = "open_url"
        const val FN_WEB_SEARCH = "web_search"
        const val FN_FETCH_WEBPAGE = "fetch_webpage"
        const val FN_READ_SCREEN = "read_screen"
        const val FN_TAP_ELEMENT = "tap_element"
        const val FN_SCROLL_SCREEN = "scroll_screen"
        const val FN_TYPE_TEXT = "type_text"
        const val FN_SYSTEM_ACTION = "system_action"
        const val FN_ASK_CLARIFICATION = "ask_clarification"

        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }
}

data class ParsedGeminiResponse(
    val text: String,
    val toolCalls: List<AiTurnToolCall>,
    val sources: List<WebSource>,
    val rawModelContent: JSONObject?,
    val errorMessage: String? = null,
)

object GeminiResponseParser {

    fun extractApiErrorMessage(rawJson: String): String? {
        if (rawJson.isBlank()) return null
        return runCatching {
            val root = JSONObject(rawJson)
            root.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    fun parseGenerateContentResponse(rawJson: String): ParsedGeminiResponse {
        if (rawJson.isBlank()) {
            return ParsedGeminiResponse("", emptyList(), emptyList(), null, "استجابة فارغة من الخادم.")
        }
        return runCatching {
            val root = JSONObject(rawJson)
            root.optJSONObject("error")?.let { err ->
                val msg = err.optString("message").ifBlank { "خطأ من Gemini API" }
                return ParsedGeminiResponse("", emptyList(), emptyList(), null, msg)
            }

            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                val blockReason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
                val msg = if (blockReason.isNotBlank()) {
                    "تم حجب الاستجابة بسبب سياسة الأمان ($blockReason)."
                } else {
                    "لم يرجع النموذج أي مرشح للإجابة."
                }
                return ParsedGeminiResponse("", emptyList(), emptyList(), null, msg)
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            val textBuilder = StringBuilder()
            val toolCalls = mutableListOf<AiTurnToolCall>()

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i) ?: continue
                    val partText = part.optString("text")
                    if (partText.isNotBlank()) {
                        if (textBuilder.isNotEmpty()) textBuilder.append('\n')
                        textBuilder.append(partText.trim())
                    }
                    val fnCall = part.optJSONObject("functionCall")
                    if (fnCall != null) {
                        val parsedCall = parseFunctionCall(fnCall)
                        if (parsedCall != null) {
                            toolCalls.add(parsedCall)
                        }
                    }
                }
            }

            val sources = parseGroundingSources(firstCandidate.optJSONObject("groundingMetadata"))
            val text = textBuilder.toString().trim()
            val finishReason = firstCandidate.optString("finishReason").trim()
            if (text.isBlank() && toolCalls.isEmpty() && finishReason.isNotBlank() && finishReason != "STOP") {
                return ParsedGeminiResponse(
                    text = "",
                    toolCalls = emptyList(),
                    sources = sources,
                    rawModelContent = content,
                    errorMessage = "لم يُرجع النموذج نصاً مكتوباً (سبب التوقف: $finishReason).",
                )
            }

            ParsedGeminiResponse(
                text = text,
                toolCalls = toolCalls,
                sources = sources,
                rawModelContent = content,
            )
        }.getOrElse { e ->
            ParsedGeminiResponse(
                text = "",
                toolCalls = emptyList(),
                sources = emptyList(),
                rawModelContent = null,
                errorMessage = "تعذر تحليل استجابة Gemini: ${e.localizedMessage ?: "JSON غير صالح"}",
            )
        }
    }

    fun parseAvailableModelsResponse(rawJson: String): List<CloudModelOption> {
        if (rawJson.isBlank()) return emptyList()
        return runCatching {
            val root = JSONObject(rawJson)
            val modelsArr = root.optJSONArray("models") ?: return emptyList()
            val results = mutableListOf<CloudModelOption>()
            for (i in 0 until modelsArr.length()) {
                val obj = modelsArr.optJSONObject(i) ?: continue
                val fullName = obj.optString("name").trim()
                val modelId = fullName.removePrefix("models/").trim()
                if (!modelId.startsWith("gemini", ignoreCase = true)) continue

                val methods = obj.optJSONArray("supportedGenerationMethods") ?: continue
                var supportsGenerateContent = false
                for (m in 0 until methods.length()) {
                    if (methods.optString(m) == "generateContent") {
                        supportsGenerateContent = true
                        break
                    }
                }
                if (!supportsGenerateContent) continue

                val displayName = obj.optString("displayName").trim().ifBlank { modelId }
                results.add(CloudModelOption(modelId = modelId, displayName = displayName))
            }
            results.distinctBy { it.modelId }
        }.getOrDefault(emptyList())
    }

    fun parseGroundingSources(groundingMetadata: JSONObject?): List<WebSource> {
        if (groundingMetadata == null) return emptyList()
        val chunks = groundingMetadata.optJSONArray("groundingChunks") ?: return emptyList()
        val seen = LinkedHashMap<String, WebSource>()
        for (i in 0 until chunks.length()) {
            val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
            val url = web.optString("uri").trim()
            if (url.isBlank()) continue
            val title = web.optString("title").trim().ifBlank { url }
            seen.putIfAbsent(url, WebSource(title = title, url = url))
        }
        return seen.values.toList()
    }

    private fun parseFunctionCall(fnCall: JSONObject): AiTurnToolCall? {
        val name = fnCall.optString("name").trim()
        if (name.isBlank()) return null
        val args = fnCall.optJSONObject("args") ?: JSONObject()
        val callId = UUID.randomUUID().toString()

        val command: AssistantCommand? = when (name) {
            GeminiAssistantRepository.FN_OPEN_APP -> {
                val appName = args.optString("app_name").trim().takeIf { it.isNotBlank() }
                val pkg = args.optString("package_name").trim().takeIf { it.isNotBlank() }
                AssistantCommand.OpenApp(
                    commandId = callId,
                    packageName = pkg,
                    appName = appName,
                )
            }

            GeminiAssistantRepository.FN_OPEN_URL -> {
                val url = args.optString("url").trim()
                if (url.isBlank()) null else AssistantCommand.OpenUrl(commandId = callId, url = url)
            }

            GeminiAssistantRepository.FN_WEB_SEARCH -> {
                val query = args.optString("query").trim()
                if (query.isBlank()) null else AssistantCommand.WebSearch(commandId = callId, query = query)
            }

            GeminiAssistantRepository.FN_FETCH_WEBPAGE -> {
                val url = args.optString("url").trim()
                if (url.isBlank()) null else AssistantCommand.FetchWebpage(commandId = callId, url = url)
            }

            GeminiAssistantRepository.FN_READ_SCREEN -> {
                AssistantCommand.ReadScreen(commandId = callId)
            }

            GeminiAssistantRepository.FN_TAP_ELEMENT -> {
                val targetText = args.optString("target_text").trim().takeIf { it.isNotBlank() }
                val x = if (args.has("x") && !args.isNull("x")) args.optDouble("x").toFloat() else null
                val y = if (args.has("y") && !args.isNull("y")) args.optDouble("y").toFloat() else null
                AssistantCommand.Tap(commandId = callId, targetText = targetText, x = x, y = y)
            }

            GeminiAssistantRepository.FN_SCROLL_SCREEN -> {
                val dirStr = args.optString("direction", "DOWN").trim().uppercase(Locale.ROOT)
                val direction = runCatching { ScrollDirection.valueOf(dirStr) }.getOrDefault(ScrollDirection.DOWN)
                AssistantCommand.Scroll(commandId = callId, direction = direction)
            }

            GeminiAssistantRepository.FN_TYPE_TEXT -> {
                val text = args.optString("text")
                val hint = args.optString("target_hint").trim().takeIf { it.isNotBlank() }
                if (text.isBlank()) null else AssistantCommand.TypeText(commandId = callId, text = text, targetHint = hint)
            }

            GeminiAssistantRepository.FN_SYSTEM_ACTION -> {
                val actStr = args.optString("action", "BACK").trim().uppercase(Locale.ROOT)
                val action = runCatching { GlobalDeviceAction.valueOf(actStr) }.getOrDefault(GlobalDeviceAction.BACK)
                AssistantCommand.GlobalAction(commandId = callId, action = action)
            }

            GeminiAssistantRepository.FN_ASK_CLARIFICATION -> {
                val question = args.optString("question").trim()
                if (question.isBlank()) null else AssistantCommand.AskClarification(commandId = callId, question = question)
            }

            else -> null
        }

        return command?.let { AiTurnToolCall(callId = callId, functionName = name, command = it) }
    }
}
