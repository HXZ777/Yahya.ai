package com.example.data.apk

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.domain.model.ApkResultInfo
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.zip.ZipFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApkInspectorAndVerifier(private val context: Context) {

    suspend fun verifyAndInspectApk(
        apkFile: File,
        sourceNote: String,
    ): Result<ApkResultInfo> = withContext(Dispatchers.IO) {
        runCatching {
            require(apkFile.exists() && apkFile.length() > 0L) {
                "ملف APK الناتج مفقود أو فارغ."
            }

            var hasManifest = false
            var hasDex = false
            var hasResources = false
            var hasV1Signature = false
            val abis = linkedSetOf<String>()

            ZipFile(apkFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val name = entries.nextElement().name
                    when {
                        name == "AndroidManifest.xml" -> hasManifest = true
                        name.startsWith("classes") && name.endsWith(".dex") -> hasDex = true
                        name == "resources.arsc" -> hasResources = true
                        name.startsWith("META-INF/") &&
                            (name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC")) -> {
                            hasV1Signature = true
                        }
                        name.startsWith("lib/") -> {
                            val parts = name.split('/')
                            if (parts.size >= 3 && parts[1].isNotBlank()) {
                                abis.add(parts[1])
                            }
                        }
                    }
                }
            }

            if (!hasManifest) {
                error("ملف APK غير صالح: يفتقد AndroidManifest.xml المترجم داخل الحزمة.")
            }

            val hasV2OrV3Block = hasApkSigningBlock(apkFile)
            val isSigned = hasV1Signature || hasV2OrV3Block

            val sha256 = computeSha256(apkFile)
            val pm = context.packageManager
            val pkgInfo: PackageInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_META_DATA.toLong()),
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.GET_META_DATA)
            }

            val appInfo = pkgInfo?.applicationInfo?.apply {
                sourceDir = apkFile.absolutePath
                publicSourceDir = apkFile.absolutePath
            }

            val appName = appInfo?.let {
                runCatching { pm.getApplicationLabel(it).toString() }.getOrNull()
            }?.takeIf { it.isNotBlank() } ?: apkFile.nameWithoutExtension

            val packageName = pkgInfo?.packageName ?: "unknown.package"
            val versionName = pkgInfo?.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo?.longVersionCode ?: 1L
            } else {
                @Suppress("DEPRECATION")
                (pkgInfo?.versionCode?.toLong() ?: 1L)
            }

            val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                appInfo?.minSdkVersion?.takeIf { it > 0 }
            } else null

            val targetSdk = appInfo?.targetSdkVersion?.takeIf { it > 0 }

            val deviceAbis = Build.SUPPORTED_ABIS.toSet()
            val abiCompatible = abis.isEmpty() || abis.any { it in deviceAbis }
            val sdkCompatible = minSdk == null || Build.VERSION.SDK_INT >= minSdk
            val compatible = isSigned && abiCompatible && sdkCompatible

            val compatibilityNote = when {
                !isSigned -> "تنبيه: ملف APK غير موقّع رقميًا وقد يرفض نظام أندرويد تثبيته."
                !sdkCompatible -> "هذا التطبيق يتطلب أندرويد API $minSdk أو أحدث (جهازك API ${Build.VERSION.SDK_INT})."
                !abiCompatible -> "المعمارية غير متوافقة (${abis.joinToString()})."
                else -> "متوافق وموقّع وجاهز للتثبيت على جهازك."
            }

            ApkResultInfo(
                apkFilePath = apkFile.absolutePath,
                fileName = apkFile.name,
                sizeBytes = apkFile.length(),
                appName = appName,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode,
                minSdk = minSdk,
                targetSdk = targetSdk,
                sha256 = sha256,
                isValidApkStructure = hasManifest && (hasDex || hasResources),
                isSigned = isSigned,
                supportedAbis = abis.toList(),
                isCompatibleWithDevice = compatible,
                compatibilityNote = compatibilityNote,
                sourceNote = sourceNote,
            )
        }
    }

    private fun hasApkSigningBlock(apkFile: File): Boolean {
        return runCatching {
            val size = apkFile.length()
            if (size < 64) return false
            RandomAccessFile(apkFile, "r").use { raf ->
                val searchWindow = minOf(size, 65_536L).toInt()
                val buf = ByteArray(searchWindow)
                raf.seek(size - searchWindow)
                raf.readFully(buf)
                val marker = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)
                val text = buf.toString(Charsets.ISO_8859_1)
                text.contains(marker.toString(Charsets.ISO_8859_1))
            }
        }.getOrDefault(false)
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val read = fis.read(buf)
                if (read <= 0) break
                digest.update(buf, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
