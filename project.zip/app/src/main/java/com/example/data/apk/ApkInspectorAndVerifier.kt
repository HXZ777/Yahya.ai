package com.example.data.apk

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.domain.model.ApkResultInfo
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.zip.ZipFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApkInspectorAndVerifier(private val context: Context) {

    suspend fun verifyAndInspectApk(
        apkFile: File,
        sourceNote: String,
    ): Result<ApkResultInfo> = withContext(Dispatchers.IO) {
        runCatching {
            require(apkFile.exists() && apkFile.length() > 0L) {
                "Produced APK file is missing or empty."
            }

            var hasManifest = false
            var hasDex = false
            var hasResources = false

            ZipFile(apkFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val name = entries.nextElement().name
                    when {
                        name == "AndroidManifest.xml" -> hasManifest = true
                        name.startsWith("classes") && name.endsWith(".dex") -> hasDex = true
                        name == "resources.arsc" -> hasResources = true
                    }
                }
            }

            if (!hasManifest) {
                error("Invalid APK archive: missing compiled AndroidManifest.xml inside package.")
            }

            val sha256 = computeSha256(apkFile)
            val pm = context.packageManager
            val pkgInfo: PackageInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_META_DATA.toLong()),
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.GET_META_DATA)
            }

            val appInfo = pkgInfo?.applicationInfo?.apply {
                sourceDir = apkFile.absolutePath
                publicSourceDir = apkFile.absolutePath
            }

            val appName = appInfo?.let {
                runCatching { pm.getApplicationLabel(it).toString() }.getOrNull()
            }?.takeIf { it.isNotBlank() } ?: apkFile.nameWithoutExtension

            val packageName = pkgInfo?.packageName ?: "unknown.package"
            val versionName = pkgInfo?.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo?.longVersionCode ?: 1L
            } else {
                @Suppress("DEPRECATION")
                (pkgInfo?.versionCode?.toLong() ?: 1L)
            }

            val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                appInfo?.minSdkVersion?.takeIf { it > 0 }
            } else null

            val targetSdk = appInfo?.targetSdkVersion?.takeIf { it > 0 }

            ApkResultInfo(
                apkFilePath = apkFile.absolutePath,
                fileName = apkFile.name,
                sizeBytes = apkFile.length(),
                appName = appName,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode,
                minSdk = minSdk,
                targetSdk = targetSdk,
                sha256 = sha256,
                isValidApkStructure = hasManifest && (hasDex || hasResources),
                sourceNote = sourceNote,
            )
        }
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val read = fis.read(buf)
                if (read <= 0) break
                digest.update(buf, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
