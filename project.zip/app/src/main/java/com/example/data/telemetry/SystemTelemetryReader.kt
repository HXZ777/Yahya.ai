package com.example.data.telemetry

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.example.domain.model.CpuSource
import com.example.domain.model.DxvkStatus
import com.example.domain.model.FpsSource
import com.example.domain.model.SystemStatsSnapshot
import com.example.domain.model.TempSource
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Reads genuine hardware and OS telemetry available without root or ADB.
 * Never fabricates placeholder or random numbers when an OEM/Android SELinux
 * boundary blocks a sensor — returns null / UNAVAILABLE so the UI displays N/A honestly.
 */
class SystemTelemetryReader(private val context: Context) {

    private val activityManager =
        context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    private val batteryManager =
        context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    private var prevCpuTimes: CpuTimes? = null
    private var procStatDenied: Boolean = false

    private data class CachedThermalZone(
        val path: String,
        val source: TempSource,
        val label: String,
    )

    private var thermalZonesScanned: Boolean = false
    private var cachedThermalZone: CachedThermalZone? = null

    private var fpsSysfsScanned: Boolean = false
    private var cachedFpsSysfsPath: String? = null

    private var cachedMaxFreqKhz: LongArray? = null

    fun readSnapshot(compositorFps: Int? = null, allowCompositorFallback: Boolean = false): SystemStatsSnapshot {
        val (cpuPercent, cpuSource) = readCpuUsage()
        val (ramPercent, ramUsedMb, ramTotalMb) = readRamUsage()
        val batteryIntent = readBatteryStickyIntent()
        val (powerWatts, isCharging) = readPowerWatts(batteryIntent)
        val (tempCelsius, tempSource, tempLabel) = readTemperature(batteryIntent)
        val (fpsValue, fpsSource) = readFps(compositorFps, allowCompositorFallback)
        val (dxvkStatus, dxvkDetail) = detectDxvk()

        return SystemStatsSnapshot(
            cpuPercent = cpuPercent,
            cpuSource = cpuSource,
            ramPercent = ramPercent,
            ramUsedMb = ramUsedMb,
            ramTotalMb = ramTotalMb,
            powerWatts = powerWatts,
            isCharging = isCharging,
            tempCelsius = tempCelsius,
            tempSource = tempSource,
            tempZoneLabel = tempLabel,
            fpsValue = fpsValue,
            fpsSource = fpsSource,
            dxvkStatus = dxvkStatus,
            dxvkDetail = dxvkDetail,
            timestampMs = System.currentTimeMillis(),
        )
    }

    private fun readBatteryStickyIntent(): Intent? {
        return try {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Exception) {
            null
        }
    }

    private fun readCpuUsage(): Pair<Int?, CpuSource> {
        if (!procStatDenied) {
            try {
                val statFile = File("/proc/stat")
                if (statFile.canRead()) {
                    val firstLine = statFile.bufferedReader().use { it.readLine() }
                    val parsed = firstLine?.let { parseProcStatLine(it) }
                    if (parsed != null) {
                        val previous = prevCpuTimes
                        prevCpuTimes = parsed
                        if (previous != null) {
                            val totalDelta = parsed.total - previous.total
                            val idleDelta = parsed.idle - previous.idle
                            if (totalDelta > 0L) {
                                val usage = (((totalDelta - idleDelta).toDouble() / totalDelta.toDouble()) * 100.0)
                                    .roundToInt()
                                    .coerceIn(0, 100)
                                return usage to CpuSource.PROC_STAT
                            }
                        } else {
                            // First sample establishes baseline; read fallback if available or wait next tick
                            return 0 to CpuSource.PROC_STAT
                        }
                    }
                } else {
                    procStatDenied = true
                }
            } catch (_: SecurityException) {
                procStatDenied = true
            } catch (_: Exception) {
                procStatDenied = true
            }
        }

        // Secondary real telemetry on Android 8-14 when /proc/stat is SELinux-blocked:
        // Read real per-core scaling_cur_freq vs cpuinfo_max_freq.
        val freqUsage = readCpuFrequencyLoad()
        if (freqUsage != null) {
            return freqUsage to CpuSource.CPU_FREQ_SCALING
        }

        return null to CpuSource.UNAVAILABLE
    }

    private fun readCpuFrequencyLoad(): Int? {
        val coreCount = Runtime.getRuntime().availableProcessors().coerceIn(1, 32)
        if (cachedMaxFreqKhz == null) {
            val maxArr = LongArray(coreCount)
            for (i in 0 until coreCount) {
                maxArr[i] = readLongFromFile("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
                    ?: readLongFromFile("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq")
                    ?: 0L
            }
            cachedMaxFreqKhz = maxArr
        }

        val maxFreqs = cachedMaxFreqKhz ?: return null
        var sumCur = 0L
        var sumMax = 0L
        for (i in 0 until coreCount) {
            val maxFreq = maxFreqs[i]
            if (maxFreq <= 0L) continue
            val curFreq = readLongFromFile("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
            if (curFreq != null && curFreq > 0L) {
                sumCur += curFreq.coerceAtMost(maxFreq)
                sumMax += maxFreq
            }
        }
        if (sumMax <= 0L) return null
        return ((sumCur.toDouble() / sumMax.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)
    }

    private fun readRamUsage(): Triple<Int?, Long, Long> {
        val am = activityManager ?: return Triple(null, 0L, 0L)
        return try {
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            if (memInfo.totalMem <= 0L) {
                Triple(null, 0L, 0L)
            } else {
                val usedBytes = (memInfo.totalMem - memInfo.availMem).coerceAtLeast(0L)
                val percent = ((usedBytes.toDouble() / memInfo.totalMem.toDouble()) * 100.0)
                    .roundToInt()
                    .coerceIn(0, 100)
                val usedMb = usedBytes / (1024L * 1024L)
                val totalMb = memInfo.totalMem / (1024L * 1024L)
                Triple(percent, usedMb, totalMb)
            }
        } catch (_: Exception) {
            Triple(null, 0L, 0L)
        }
    }

    private fun readPowerWatts(batteryIntent: Intent?): Pair<Float?, Boolean> {
        val bm = batteryManager ?: return null to false
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val voltageMv = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        if (voltageMv <= 0) return null to isCharging

        val currentRaw = try {
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (_: Exception) {
            Int.MIN_VALUE
        }
        if (currentRaw == Int.MIN_VALUE || currentRaw == 0) {
            return null to isCharging
        }

        val watts = computePowerWatts(voltageMv, currentRaw)
        return watts to isCharging
    }

    private fun readTemperature(batteryIntent: Intent?): Triple<Float?, TempSource, String?> {
        if (!thermalZonesScanned) {
            thermalZonesScanned = true
            cachedThermalZone = discoverBestThermalZone()
        }

        cachedThermalZone?.let { zone ->
            val raw = readFloatFromFile(zone.path)
            val normalized = raw?.let { normalizeThermalTemp(it) }
            if (normalized != null) {
                return Triple(normalized, zone.source, zone.label)
            }
        }

        // Honest fallback: Battery temperature from ACTION_BATTERY_CHANGED, explicitly tagged as BATTERY
        val rawBatteryTemp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?: Int.MIN_VALUE
        if (rawBatteryTemp != Int.MIN_VALUE && rawBatteryTemp > 0) {
            val celsius = rawBatteryTemp / 10f
            if (celsius in 5f..95f) {
                return Triple(celsius, TempSource.BATTERY, "Battery")
            }
        }

        return Triple(null, TempSource.UNAVAILABLE, null)
    }

    private fun discoverBestThermalZone(): CachedThermalZone? {
        val thermalDir = File("/sys/class/thermal")
        val zones = try {
            thermalDir.listFiles { file -> file.name.startsWith("thermal_zone") }
        } catch (_: Exception) {
            null
        } ?: return null

        var bestSoc: CachedThermalZone? = null
        var bestSkin: CachedThermalZone? = null

        for (zone in zones.sortedBy { it.name }) {
            val typeFile = File(zone, "type")
            val tempFile = File(zone, "temp")
            val type = try {
                if (typeFile.canRead()) typeFile.readText().trim() else continue
            } catch (_: Exception) {
                continue
            }
            val rawTemp = readFloatFromFile(tempFile.absolutePath) ?: continue
            if (normalizeThermalTemp(rawTemp) == null) continue

            val lower = type.lowercase()
            when {
                bestSoc == null && (
                    lower.contains("cpu") ||
                        lower.contains("soc") ||
                        lower.contains("tsens") ||
                        lower.contains("mtktscpu") ||
                        lower.contains("ap_therm") ||
                        lower.contains("cluster") ||
                        lower.contains("big") ||
                        lower.contains("little") ||
                        lower.contains("gpu")
                    ) -> {
                    bestSoc = CachedThermalZone(tempFile.absolutePath, TempSource.SOC_THERMAL, type)
                }

                bestSkin == null && (
                    lower.contains("skin") ||
                        lower.contains("tskin") ||
                        lower.contains("quiet") ||
                        lower.contains("shell")
                    ) -> {
                    bestSkin = CachedThermalZone(tempFile.absolutePath, TempSource.SKIN_THERMAL, type)
                }
            }
        }

        return bestSoc ?: bestSkin
    }

    private fun readFps(compositorFps: Int?, allowCompositorFallback: Boolean): Pair<Int?, FpsSource> {
        if (!fpsSysfsScanned) {
            fpsSysfsScanned = true
            cachedFpsSysfsPath = discoverKernelFpsPath()
        }

        cachedFpsSysfsPath?.let { path ->
            val raw = readKernelFps(path)
            if (raw != null) {
                return raw to FpsSource.KERNEL_SYSFS
            }
        }

        if (allowCompositorFallback && compositorFps != null && compositorFps in 1..240) {
            return compositorFps to FpsSource.COMPOSITOR_HZ
        }

        return null to FpsSource.UNAVAILABLE
    }

    private fun discoverKernelFpsPath(): String? {
        val candidates = listOf(
            "/sys/class/graphics/fb0/measured_fps",
            "/sys/devices/virtual/graphics/fb0/measured_fps",
            "/sys/class/drm/card0/sde-crtc-0/measured_fps",
            "/sys/class/drm/card0/card0-DSI-1/measured_fps",
        )
        for (path in candidates) {
            if (readKernelFps(path) != null) {
                return path
            }
        }
        return null
    }

    private fun readKernelFps(path: String): Int? {
        return try {
            val file = File(path)
            if (!file.canRead()) return null
            val text = file.readText().trim()
            // Formats like "fps: 59.8" or "60.0"
            val match = Regex("""(\d+(?:\.\d+)?)""").find(text) ?: return null
            val fps = match.groupValues[1].toFloatOrNull()?.roundToInt() ?: return null
            if (fps in 1..240) fps else null
        } catch (_: Exception) {
            null
        }
    }

    private fun detectDxvk(): Pair<DxvkStatus, String?> {
        val envKeys = listOf("DXVK_HUD", "DXVK_STATE_CACHE", "DXVK_LOG_LEVEL", "DXVK_CONFIG_FILE")
        for (key in envKeys) {
            val value = System.getenv(key)
            if (!value.isNullOrBlank()) {
                return DxvkStatus.DETECTED to key
            }
        }

        // Check if current process maps any DXVK shared libraries (e.g. inside translation layer)
        try {
            val mapsFile = File("/proc/self/maps")
            if (mapsFile.canRead()) {
                mapsFile.bufferedReader().useLines { lines ->
                    val hit = lines.firstOrNull { line ->
                        line.contains("dxvk", ignoreCase = true) ||
                            line.contains("libd3d11", ignoreCase = true)
                    }
                    if (hit != null) {
                        return DxvkStatus.DETECTED to "Vulkan/DXVK"
                    }
                }
            }
        } catch (_: Exception) {
            // Ignored
        }

        return DxvkStatus.NOT_DETECTED to null
    }

    private fun readLongFromFile(path: String): Long? {
        return try {
            val file = File(path)
            if (!file.canRead()) return null
            file.readText().trim().toLongOrNull()
        } catch (_: Exception) {
            null
        }
    }

    private fun readFloatFromFile(path: String): Float? {
        return try {
            val file = File(path)
            if (!file.canRead()) return null
            file.readText().trim().toFloatOrNull()
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        data class CpuTimes(val total: Long, val idle: Long)

        fun parseProcStatLine(line: String): CpuTimes? {
            val trimmed = line.trim()
            if (!trimmed.startsWith("cpu ")) return null
            val parts = trimmed.split(Regex("""\s+""")).drop(1)
            if (parts.size < 4) return null
            val values = parts.mapNotNull { it.toLongOrNull() }
            if (values.size < 4) return null
            val idle = values[3] + (values.getOrNull(4) ?: 0L)
            val total = values.sum()
            return CpuTimes(total = total, idle = idle)
        }

        fun normalizeThermalTemp(raw: Float): Float? {
            val celsius = when {
                raw > 1000f -> raw / 1000f
                raw > 200f -> raw / 10f
                else -> raw
            }
            return if (celsius in 5f..115f) celsius else null
        }

        fun computePowerWatts(voltageMv: Int, currentRaw: Int): Float? {
            if (voltageMv <= 0 || currentRaw == Int.MIN_VALUE || currentRaw == 0) return null
            val volts = voltageMv / 1000.0
            val absCurrent = abs(currentRaw.toLong())
            // Android BatteryManager specifies µA, though some legacy kernels report mA (< 10,000)
            val amps = if (absCurrent >= 10_000L) {
                absCurrent / 1_000_000.0
            } else {
                absCurrent / 1_000.0
            }
            val watts = (volts * amps).toFloat()
            return if (watts in 0.05f..65.0f) watts else null
        }
    }
}
