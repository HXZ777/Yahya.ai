package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.AppLanguage
import com.example.domain.model.DefaultStatColors
import com.example.domain.model.OverlayPositionPreset
import com.example.domain.model.OverlaySettings
import com.example.domain.model.StatType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.statsDataStore: DataStore<Preferences> by preferencesDataStore(name = "statistics_prefs")

class StatsPreferencesRepository(private val context: Context) {

    private object Keys {
        val ENABLED_STATS = stringSetPreferencesKey("enabled_stats")
        val SCALE_PERCENT = intPreferencesKey("scale_percent")
        val BACKGROUND_ALPHA = floatPreferencesKey("background_alpha")
        val FONT_SIZE_SP = floatPreferencesKey("font_size_sp")
        val REFRESH_INTERVAL_MS = longPreferencesKey("refresh_interval_ms")
        val POSITION_PRESET = stringPreferencesKey("position_preset")
        val CUSTOM_OFFSET_X = intPreferencesKey("custom_offset_x")
        val CUSTOM_OFFSET_Y = intPreferencesKey("custom_offset_y")
        val HAS_CUSTOM_OFFSET = booleanPreferencesKey("has_custom_offset")
        val LANGUAGE = stringPreferencesKey("app_language")
        val COMPOSITOR_HZ_FALLBACK = booleanPreferencesKey("compositor_hz_fallback")
        val HIDE_DXVK_UNAVAILABLE = booleanPreferencesKey("hide_dxvk_unavailable")

        fun colorKey(statType: StatType) = longPreferencesKey("color_${statType.key}")
    }

    val settingsFlow: Flow<OverlaySettings> = context.statsDataStore.data.map { prefs ->
        val rawSet = prefs[Keys.ENABLED_STATS]
        val enabledStats = if (rawSet == null) {
            StatType.entries.toSet()
        } else {
            rawSet.mapNotNull { StatType.fromKey(it) }.toSet()
        }

        val defaults = DefaultStatColors.defaultMap()
        val colors = StatType.entries.associateWith { stat ->
            prefs[Keys.colorKey(stat)] ?: defaults[stat] ?: DefaultStatColors.CPU
        }

        val hasCustomOffset = prefs[Keys.HAS_CUSTOM_OFFSET] ?: false

        OverlaySettings(
            enabledStats = enabledStats,
            statColors = colors,
            scalePercent = (prefs[Keys.SCALE_PERCENT] ?: 100).coerceIn(75, 150),
            backgroundAlpha = (prefs[Keys.BACKGROUND_ALPHA] ?: 0.92f).coerceIn(0.35f, 1.0f),
            fontSizeSp = (prefs[Keys.FONT_SIZE_SP] ?: 12.5f).coerceIn(10f, 18f),
            refreshIntervalMs = (prefs[Keys.REFRESH_INTERVAL_MS] ?: 1000L).coerceIn(500L, 5000L),
            positionPreset = OverlayPositionPreset.fromKey(prefs[Keys.POSITION_PRESET]),
            customOffsetX = if (hasCustomOffset) prefs[Keys.CUSTOM_OFFSET_X] else null,
            customOffsetY = if (hasCustomOffset) prefs[Keys.CUSTOM_OFFSET_Y] else null,
            language = AppLanguage.fromKey(prefs[Keys.LANGUAGE]),
            useCompositorHzFallback = prefs[Keys.COMPOSITOR_HZ_FALLBACK] ?: false,
            hideDxvkWhenNotDetected = prefs[Keys.HIDE_DXVK_UNAVAILABLE] ?: false,
        )
    }

    suspend fun toggleStat(statType: StatType, enabled: Boolean) {
        context.statsDataStore.edit { prefs ->
            val current = prefs[Keys.ENABLED_STATS]?.toMutableSet()
                ?: StatType.entries.map { it.key }.toMutableSet()
            if (enabled) {
                current.add(statType.key)
            } else {
                // Keep at least one item enabled or allow empty? Allow empty? Better: keep at least 1 item so overlay isn't invisible, or allow toggling freely and show a friendly badge if 0. Let's allow toggling freely, and guard in UI/overlay!
                current.remove(statType.key)
            }
            prefs[Keys.ENABLED_STATS] = current
        }
    }

    suspend fun setEnabledStats(stats: Set<StatType>) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.ENABLED_STATS] = stats.map { it.key }.toSet()
        }
    }

    suspend fun setStatColor(statType: StatType, argbColor: Long) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.colorKey(statType)] = argbColor
        }
    }

    suspend fun resetColors() {
        context.statsDataStore.edit { prefs ->
            DefaultStatColors.defaultMap().forEach { (stat, color) ->
                prefs[Keys.colorKey(stat)] = color
            }
        }
    }

    suspend fun setScalePercent(scalePercent: Int) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.SCALE_PERCENT] = scalePercent.coerceIn(75, 150)
        }
    }

    suspend fun setBackgroundAlpha(alpha: Float) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.BACKGROUND_ALPHA] = alpha.coerceIn(0.35f, 1.0f)
        }
    }

    suspend fun setFontSizeSp(fontSizeSp: Float) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.FONT_SIZE_SP] = fontSizeSp.coerceIn(10f, 18f)
        }
    }

    suspend fun setRefreshIntervalMs(intervalMs: Long) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.REFRESH_INTERVAL_MS] = intervalMs.coerceIn(500L, 5000L)
        }
    }

    suspend fun setPositionPreset(preset: OverlayPositionPreset) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.POSITION_PRESET] = preset.key
            prefs[Keys.HAS_CUSTOM_OFFSET] = false
            prefs.remove(Keys.CUSTOM_OFFSET_X)
            prefs.remove(Keys.CUSTOM_OFFSET_Y)
        }
    }

    suspend fun saveCustomOffset(x: Int, y: Int) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.HAS_CUSTOM_OFFSET] = true
            prefs[Keys.CUSTOM_OFFSET_X] = x
            prefs[Keys.CUSTOM_OFFSET_Y] = y
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.key
        }
    }

    suspend fun setUseCompositorHzFallback(enabled: Boolean) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.COMPOSITOR_HZ_FALLBACK] = enabled
        }
    }

    suspend fun setHideDxvkWhenNotDetected(enabled: Boolean) {
        context.statsDataStore.edit { prefs ->
            prefs[Keys.HIDE_DXVK_UNAVAILABLE] = enabled
        }
    }
}
