package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.BuildEngineMode
import com.example.domain.model.BuildEngineSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.buildSettingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "zip_to_apk_settings")

class BuildSettingsRepository(private val context: Context) {

    private object Keys {
        val ENGINE_MODE = stringPreferencesKey("engine_mode")
        val REMOTE_RUNNER_URL = stringPreferencesKey("remote_runner_url")
        val REMOTE_AUTH_TOKEN = stringPreferencesKey("remote_auth_token")
        val BUILD_VARIANT = stringPreferencesKey("build_variant")
        val UPLOAD_CONSENT_GRANTED = booleanPreferencesKey("upload_consent_granted")
    }

    val settingsFlow: Flow<BuildEngineSettings> = context.buildSettingsDataStore.data.map { prefs ->
        val modeName = prefs[Keys.ENGINE_MODE] ?: BuildEngineMode.LOCAL_DEVICE.name
        val mode = runCatching { BuildEngineMode.valueOf(modeName) }.getOrDefault(BuildEngineMode.LOCAL_DEVICE)
        BuildEngineSettings(
            mode = mode,
            remoteRunnerUrl = prefs[Keys.REMOTE_RUNNER_URL].orEmpty(),
            remoteAuthToken = prefs[Keys.REMOTE_AUTH_TOKEN].orEmpty(),
            buildVariant = prefs[Keys.BUILD_VARIANT] ?: "debug",
            uploadConsentGranted = prefs[Keys.UPLOAD_CONSENT_GRANTED] ?: false,
        )
    }

    suspend fun updateSettings(transform: (BuildEngineSettings) -> BuildEngineSettings) {
        context.buildSettingsDataStore.edit { prefs ->
            val currentMode = runCatching {
                BuildEngineMode.valueOf(prefs[Keys.ENGINE_MODE] ?: BuildEngineMode.LOCAL_DEVICE.name)
            }.getOrDefault(BuildEngineMode.LOCAL_DEVICE)
            val current = BuildEngineSettings(
                mode = currentMode,
                remoteRunnerUrl = prefs[Keys.REMOTE_RUNNER_URL].orEmpty(),
                remoteAuthToken = prefs[Keys.REMOTE_AUTH_TOKEN].orEmpty(),
                buildVariant = prefs[Keys.BUILD_VARIANT] ?: "debug",
                uploadConsentGranted = prefs[Keys.UPLOAD_CONSENT_GRANTED] ?: false,
            )
            val updated = transform(current)
            prefs[Keys.ENGINE_MODE] = updated.mode.name
            prefs[Keys.REMOTE_RUNNER_URL] = updated.remoteRunnerUrl
            prefs[Keys.REMOTE_AUTH_TOKEN] = updated.remoteAuthToken
            prefs[Keys.BUILD_VARIANT] = updated.buildVariant
            prefs[Keys.UPLOAD_CONSENT_GRANTED] = updated.uploadConsentGranted
        }
    }
}
