package com.example.data.preferences

import android.net.Uri
import org.json.JSONObject
import java.net.Inet4Address
import java.net.NetworkInterface

data class PairingPayload(
    val host: String,
    val port: Int,
    val pairingCode: String,
    val secret: String,
    val deviceName: String,
    val useTls: Boolean,
)

object PairingPayloadCodec {

    fun buildCompanionQrUri(
        deviceId: String,
        deviceName: String,
        localIp: String?,
        pairingCode: String,
        secret: String,
    ): String {
        return Uri.Builder()
            .scheme("yahya")
            .authority("pair")
            .appendQueryParameter("role", "companion")
            .appendQueryParameter("deviceId", deviceId)
            .appendQueryParameter("name", deviceName)
            .appendQueryParameter("ip", localIp.orEmpty())
            .appendQueryParameter("code", pairingCode)
            .appendQueryParameter("secret", secret)
            .build()
            .toString()
    }

    fun parseBrainPayload(raw: String): PairingPayload? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null

        // Support yahya://pair?host=...&port=8765&code=123456&secret=...&name=...&tls=0
        if (trimmed.startsWith("yahya://", ignoreCase = true)) {
            return runCatching {
                val uri = Uri.parse(trimmed)
                val host = uri.getQueryParameter("host")
                    ?: uri.getQueryParameter("ip")
                    ?: return@runCatching null
                val port = uri.getQueryParameter("port")?.toIntOrNull() ?: 8765
                val code = uri.getQueryParameter("code").orEmpty()
                val secret = uri.getQueryParameter("secret")
                    ?.takeIf { it.isNotBlank() }
                    ?: code
                val name = uri.getQueryParameter("name") ?: "هاتف الذكاء الاصطناعي"
                val tls = uri.getQueryParameter("tls") == "1" ||
                    uri.getQueryParameter("tls").equals("true", ignoreCase = true)
                if (host.isBlank() || secret.isBlank()) return@runCatching null
                PairingPayload(
                    host = host,
                    port = port,
                    pairingCode = code,
                    secret = secret,
                    deviceName = name,
                    useTls = tls,
                )
            }.getOrNull()
        }

        // Support JSON QR payload {"host":"...","port":8765,"code":"...","secret":"...","name":"..."}
        if (trimmed.startsWith("{")) {
            return runCatching {
                val json = JSONObject(trimmed)
                val host = json.optString("host").ifBlank { json.optString("ip") }
                val port = json.optInt("port", 8765)
                val code = json.optString("code")
                val secret = json.optString("secret").ifBlank { code }
                val name = json.optString("name", "هاتف الذكاء الاصطناعي")
                val tls = json.optBoolean("tls", false)
                if (host.isBlank() || secret.isBlank()) return@runCatching null
                PairingPayload(
                    host = host,
                    port = port,
                    pairingCode = code,
                    secret = secret,
                    deviceName = name,
                    useTls = tls,
                )
            }.getOrNull()
        }

        // Support host:port:code shorthand
        val parts = trimmed.split(":")
        if (parts.size >= 2) {
            val host = parts[0].trim()
            val port = parts[1].trim().toIntOrNull() ?: 8765
            val code = parts.getOrNull(2)?.trim().orEmpty()
            if (host.isNotBlank() && code.isNotBlank()) {
                return PairingPayload(
                    host = host,
                    port = port,
                    pairingCode = code,
                    secret = code,
                    deviceName = "هاتف الذكاء الاصطناعي",
                    useTls = false,
                )
            }
        }
        return null
    }

    fun getLocalWifiIpAddress(): String? {
        return runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.filter { it.isUp && !it.isLoopback }
                ?.flatMap { it.inetAddresses.toList() }
                ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
        }.getOrNull()
    }
}
