package com.example.data.workspace

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.domain.model.ZipSelectionInfo
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SandboxWorkspaceManager(private val context: Context) {

    private val workspacesRoot: File
        get() = File(context.filesDir, "workspaces").apply { mkdirs() }

    private val apkOutputsRoot: File
        get() = File(context.filesDir, "apk_outputs").apply { mkdirs() }

    suspend fun importZipFromUri(uri: Uri): Result<ZipSelectionInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val displayName = resolveDisplayName(uri) ?: "android_project.zip"
            val workspaceId = UUID.randomUUID().toString().take(8)
            val workspaceDir = File(workspacesRoot, workspaceId).apply { mkdirs() }
            val localZipFile = File(workspaceDir, "project.zip")

            context.contentResolver.openInputStream(uri)?.use { rawInput ->
                BufferedInputStream(rawInput).use { input ->
                    FileOutputStream(localZipFile).use { output ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        var totalBytes = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            totalBytes += read
                            if (totalBytes > MAX_ZIP_IMPORT_BYTES) {
                                localZipFile.delete()
                                error("حجم ملف ZIP يتجاوز الحد المسموح في البيئة المعزولة (300 ميجابايت).")
                            }
                            output.write(buffer, 0, read)
                        }
                    }
                }
            } ?: error("تعذر فتح ملف ZIP المختار عبر مدير الملفات.")

            if (!hasZipMagicHeader(localZipFile)) {
                workspaceDir.deleteRecursively()
                error("الملف المختار ليس أرشيف ZIP صالحًا (توقيع PK مفقود).")
            }

            ZipSelectionInfo(
                uriString = uri.toString(),
                displayName = displayName,
                sizeBytes = localZipFile.length(),
                localZipFilePath = localZipFile.absolutePath,
                selectedAtMillis = System.currentTimeMillis(),
            )
        }
    }

    suspend fun extractZipSafely(
        zipFile: File,
        onProgress: ((Int) -> Unit)? = null,
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(zipFile.exists()) { "ملف ZIP المستورد غير موجود في البيئة المعزولة." }
            val workspaceDir = zipFile.parentFile ?: workspacesRoot
            val extractDir = File(workspaceDir, "src").apply {
                if (exists()) deleteRecursively()
                mkdirs()
            }
            val canonicalExtractRoot = extractDir.canonicalPath + File.separator

            var entryCount = 0
            var totalUncompressedBytes = 0L

            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                val buffer = ByteArray(16 * 1024)
                while (true) {
                    val entry = zis.nextEntry ?: break
                    entryCount++
                    if (entryCount > MAX_ZIP_ENTRIES) {
                        error("تم رفض الأرشيف: يتجاوز $MAX_ZIP_ENTRIES عنصرًا (حماية ضد قنبلة الضغط).")
                    }

                    val outFile = File(extractDir, entry.name)
                    val canonicalOutPath = outFile.canonicalPath
                    if (!canonicalOutPath.startsWith(canonicalExtractRoot) && canonicalOutPath != extractDir.canonicalPath) {
                        error("انتهاك أمني (Zip-Slip): تم اكتشاف مسار غير آمن '${entry.name}'.")
                    }

                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        BufferedOutputStream(FileOutputStream(outFile)).use { bos ->
                            while (true) {
                                val read = zis.read(buffer)
                                if (read <= 0) break
                                totalUncompressedBytes += read
                                if (totalUncompressedBytes > MAX_EXTRACTED_BYTES) {
                                    error("تم رفض الأرشيف: الحجم بعد فك الضغط يتجاوز حد 512 ميجابايت.")
                                }
                                bos.write(buffer, 0, read)
                            }
                        }
                    }
                    zis.closeEntry()
                    if (entryCount % 25 == 0) {
                        onProgress?.invoke(entryCount)
                    }
                }
            }

            if (entryCount == 0) {
                error("ملف ZIP فارغ ولا يحتوي على أي ملفات.")
            }
            onProgress?.invoke(entryCount)
            extractDir
        }
    }

    fun createOutputApkFile(preferredFileName: String): File {
        val sanitized = preferredFileName
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .let { if (it.endsWith(".apk", ignoreCase = true)) it else "$it.apk" }
        return File(apkOutputsRoot, "${System.currentTimeMillis()}_$sanitized")
    }

    suspend fun copyApkToSafUri(apkFile: File, targetUri: Uri): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            require(apkFile.exists()) { "APK file does not exist on disk." }
            var copied = 0L
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                BufferedInputStream(FileInputStream(apkFile)).use { input ->
                    val buffer = ByteArray(16 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        copied += read
                    }
                    out.flush()
                }
            } ?: error("Unable to open destination file stream for saving APK.")
            copied
        }
    }

    suspend fun getTempStorageBytes(): Long = withContext(Dispatchers.IO) {
        directorySize(workspacesRoot) + directorySize(apkOutputsRoot)
    }

    suspend fun clearAllWorkspaces(keepApkFilePath: String? = null): Long = withContext(Dispatchers.IO) {
        workspacesRoot.listFiles()?.forEach { it.deleteRecursively() }
        apkOutputsRoot.listFiles()?.forEach { file ->
            if (keepApkFilePath == null || file.absolutePath != keepApkFilePath) {
                file.deleteRecursively()
            }
        }
        getTempStorageBytes()
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun hasZipMagicHeader(file: File): Boolean {
        if (!file.exists() || file.length() < 4) return false
        return runCatching {
            FileInputStream(file).use { fis ->
                val header = ByteArray(4)
                val read = fis.read(header)
                read == 4 &&
                    header[0] == 0x50.toByte() &&
                    header[1] == 0x4B.toByte() &&
                    (header[2] == 0x03.toByte() || header[2] == 0x05.toByte())
            }
        }.getOrDefault(false)
    }

    private fun directorySize(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    companion object {
        private const val MAX_ZIP_IMPORT_BYTES = 300L * 1024L * 1024L
        private const val MAX_EXTRACTED_BYTES = 512L * 1024L * 1024L
        private const val MAX_ZIP_ENTRIES = 25_000
    }
}
