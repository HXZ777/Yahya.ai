package com.example.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.vaultDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "hxz_ai_key_vault",
)

class ApiKeyVault(private val context: Context) {

    private object Keys {
        val ENCRYPTED_GEMINI_KEY = stringPreferencesKey("encrypted_gemini_api_key")
        val KEY_IV = stringPreferencesKey("gemini_key_iv")
        val ENCRYPTION_MODE = stringPreferencesKey("encryption_mode")
    }

    val hasApiKeyFlow: Flow<Boolean> = context.vaultDataStore.data.map { prefs ->
        !prefs[Keys.ENCRYPTED_GEMINI_KEY].isNullOrBlank()
    }

    val maskedApiKeyFlow: Flow<String> = context.vaultDataStore.data.map { prefs ->
        val enc = prefs[Keys.ENCRYPTED_GEMINI_KEY]
        if (enc.isNullOrBlank()) {
            ""
        } else {
            val decrypted = decryptFromPrefs(prefs).orEmpty()
            maskKey(decrypted)
        }
    }

    suspend fun saveApiKey(rawKey: String) {
        val clean = rawKey.trim()
        if (clean.isEmpty()) {
            clearApiKey()
            return
        }
        val encrypted = encrypt(clean)
        context.vaultDataStore.edit { prefs ->
            prefs[Keys.ENCRYPTED_GEMINI_KEY] = encrypted.cipherTextBase64
            prefs[Keys.KEY_IV] = encrypted.ivBase64
            prefs[Keys.ENCRYPTION_MODE] = encrypted.mode
        }
    }

    suspend fun getApiKey(): String? {
        val prefs = context.vaultDataStore.data.first()
        return decryptFromPrefs(prefs)?.takeIf { it.isNotBlank() }
    }

    suspend fun clearApiKey() {
        context.vaultDataStore.edit { prefs ->
            prefs.remove(Keys.ENCRYPTED_GEMINI_KEY)
            prefs.remove(Keys.KEY_IV)
            prefs.remove(Keys.ENCRYPTION_MODE)
        }
    }

    private fun decryptFromPrefs(prefs: Preferences): String? {
        val cipherB64 = prefs[Keys.ENCRYPTED_GEMINI_KEY] ?: return null
        val ivB64 = prefs[Keys.KEY_IV].orEmpty()
        val mode = prefs[Keys.ENCRYPTION_MODE] ?: MODE_KEYSTORE_GCM
        return runCatching {
            when (mode) {
                MODE_KEYSTORE_GCM -> {
                    val key = getOrCreateKeystoreSecretKey() ?: return null
                    val cipher = Cipher.getInstance(TRANSFORMATION)
                    val iv = Base64.decode(ivB64, Base64.NO_WRAP)
                    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
                    val plainBytes = cipher.doFinal(Base64.decode(cipherB64, Base64.NO_WRAP))
                    String(plainBytes, StandardCharsets.UTF_8)
                }
                MODE_TEST_JVM_ONLY -> {
                    String(Base64.decode(cipherB64, Base64.NO_WRAP), StandardCharsets.UTF_8)
                }
                else -> null
            }
        }.getOrNull()
    }

    private fun encrypt(plainText: String): EncryptedPayload {
        val keystoreKey = getOrCreateKeystoreSecretKey()
        if (keystoreKey != null) {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, keystoreKey)
            val cipherBytes = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
            return EncryptedPayload(
                cipherTextBase64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP),
                ivBase64 = Base64.encodeToString(cipher.iv, Base64.NO_WRAP),
                mode = MODE_KEYSTORE_GCM,
            )
        }
        // Only reachable in non-hardware JVM unit/Robolectric environments without AndroidKeyStore
        val encoded = Base64.encodeToString(plainText.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
        return EncryptedPayload(
            cipherTextBase64 = encoded,
            ivBase64 = "",
            mode = MODE_TEST_JVM_ONLY,
        )
    }

    private fun getOrCreateKeystoreSecretKey(): SecretKey? {
        return runCatching {
            val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
            if (existing != null) return existing

            val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGen.init(spec)
            keyGen.generateKey()
        }.getOrNull()
    }

    private data class EncryptedPayload(
        val cipherTextBase64: String,
        val ivBase64: String,
        val mode: String,
    )

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "hxz_ai_gemini_key_aes_gcm"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH_BITS = 128
        private const val MODE_KEYSTORE_GCM = "keystore_aes_gcm"
        private const val MODE_TEST_JVM_ONLY = "jvm_test_fallback"

        fun maskKey(rawKey: String): String {
            val clean = rawKey.trim()
            if (clean.isEmpty()) return ""
            if (clean.length <= 8) return "••••${clean.takeLast(2)}"
            return "${clean.take(4)}••••••••${clean.takeLast(4)}"
        }
    }
}
