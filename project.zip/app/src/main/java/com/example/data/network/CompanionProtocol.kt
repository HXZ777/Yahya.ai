package com.example.data.network

import com.example.domain.model.CompanionCommand
import com.example.domain.model.GlobalDeviceAction
import com.example.domain.model.ScrollDirection
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

sealed interface InboundFrame {
    data class HandshakeAck(
        val brainDeviceName: String,
        val accepted: Boolean,
        val message: String,
    ) : InboundFrame

    data class CommandFrame(
        val command: CompanionCommand,
    ) : InboundFrame

    data class Pong(
        val timestampMs: Long,
    ) : InboundFrame

    data class AuthRejected(
        val reason: String,
    ) : InboundFrame

    data class Unknown(
        val rawType: String,
    ) : InboundFrame
}

object CompanionProtocol {

    fun signPayload(payloadBody: String, secret: String, timestamp: Long, nonce: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val keySpec = SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256")
        mac.init(keySpec)
        val signingInput = "$timestamp.$nonce.$payloadBody"
        val digest = mac.doFinal(signingInput.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyEnvelopeSignature(json: JSONObject, secret: String): Boolean {
        val signature = json.optString("signature")
        val timestamp = json.optLong("timestamp", -1L)
        val nonce = json.optString("nonce")
        val body = json.optJSONObject("payload")?.toString() ?: return false
        if (signature.isBlank() || timestamp <= 0L || nonce.isBlank()) return false
        // Allow up to 5 minutes clock skew between two phones
        val skew = kotlin.math.abs(System.currentTimeMillis() - timestamp)
        if (skew > 5 * 60 * 1000L) return false
        val expected = signPayload(body, secret, timestamp, nonce)
        return MessageDigest.isEqual(
            expected.toByteArray(StandardCharsets.UTF_8),
            signature.lowercase().toByteArray(StandardCharsets.UTF_8),
        )
    }

    fun buildSignedEnvelope(
        type: String,
        deviceId: String,
        secret: String,
        payload: JSONObject,
    ): String {
        val timestamp = System.currentTimeMillis()
        val nonce = UUID.randomUUID().toString().take(12)
        val bodyStr = payload.toString()
        val signature = if (secret.isNotBlank()) {
            signPayload(bodyStr, secret, timestamp, nonce)
        } else {
            ""
        }
        return JSONObject().apply {
            put("protocol", "yahya-companion-v1")
            put("type", type)
            put("deviceId", deviceId)
            put("timestamp", timestamp)
            put("nonce", nonce)
            put("signature", signature)
            put("payload", payload)
        }.toString()
    }

    fun buildHandshake(
        deviceId: String,
        deviceModel: String,
        assistantName: String,
        wakePhrase: String,
        pairingCode: String,
        secret: String,
        accessibilityEnabled: Boolean,
    ): String {
        val payload = JSONObject().apply {
            put("role", "companion_ears_hands")
            put("deviceModel", deviceModel)
            put("assistantName", assistantName)
            put("wakePhrase", wakePhrase)
            put("pairingCode", pairingCode)
            put("accessibilityEnabled", accessibilityEnabled)
        }
        return buildSignedEnvelope("handshake", deviceId, secret, payload)
    }

    fun buildSpeechTranscript(
        deviceId: String,
        secret: String,
        transcript: String,
        language: String,
        triggeredByWakePhrase: Boolean,
    ): String {
        val payload = JSONObject().apply {
            put("messageId", UUID.randomUUID().toString())
            put("text", transcript)
            put("language", language)
            put("triggeredByWakePhrase", triggeredByWakePhrase)
        }
        return buildSignedEnvelope("speech_transcript", deviceId, secret, payload)
    }

    fun buildCommandResult(
        deviceId: String,
        secret: String,
        commandId: String,
        status: String,
        detail: String,
    ): String {
        val payload = JSONObject().apply {
            put("commandId", commandId)
            put("status", status)
            put("detail", detail)
        }
        return buildSignedEnvelope("command_result", deviceId, secret, payload)
    }

    fun buildPing(deviceId: String, secret: String): String {
        val payload = JSONObject().apply {
            put("sentAt", System.currentTimeMillis())
        }
        return buildSignedEnvelope("ping", deviceId, secret, payload)
    }

    fun parseInboundFrame(rawJson: String, secret: String): InboundFrame? {
        return runCatching {
            val root = JSONObject(rawJson)
            val type = root.optString("type")
            val hasSignature = root.has("signature") && root.optString("signature").isNotBlank()
            // Enforce HMAC signature verification when present, or require it for commands
            if (type == "command" && secret.isNotBlank()) {
                if (!hasSignature || !verifyEnvelopeSignature(root, secret)) {
                    return InboundFrame.AuthRejected("فشل التحقق من توقيع الأمان (HMAC) للأمر الوارد.")
                }
            }
            val payload = root.optJSONObject("payload") ?: root

            when (type) {
                "handshake_ack" -> InboundFrame.HandshakeAck(
                    brainDeviceName = payload.optString("deviceName", "هاتف الذكاء الاصطناعي"),
                    accepted = payload.optBoolean("accepted", true),
                    message = payload.optString("message", "تم الإقران بنجاح"),
                )

                "pong" -> InboundFrame.Pong(
                    timestampMs = payload.optLong("sentAt", System.currentTimeMillis()),
                )

                "auth_error" -> InboundFrame.AuthRejected(
                    reason = payload.optString("reason", "رفض الجهاز الآخر رمز الإقران."),
                )

                "command" -> parseCommand(payload)?.let { InboundFrame.CommandFrame(it) }
                    ?: InboundFrame.Unknown("invalid_command")

                else -> InboundFrame.Unknown(type)
            }
        }.getOrNull()
    }

    private fun parseCommand(payload: JSONObject): CompanionCommand? {
        val commandId = payload.optString("commandId").ifBlank { UUID.randomUUID().toString() }
        val action = payload.optString("action").lowercase()
        return when (action) {
            "open_app" -> CompanionCommand.OpenApp(
                commandId = commandId,
                packageName = payload.optString("packageName").ifBlank { null },
                appName = payload.optString("appName").ifBlank { null },
            )

            "open_url" -> {
                val url = payload.optString("url")
                if (url.isBlank()) null else CompanionCommand.OpenUrl(commandId, url)
            }

            "tap", "click" -> CompanionCommand.Tap(
                commandId = commandId,
                targetText = payload.optString("targetText").ifBlank { null },
                x = if (payload.has("x")) payload.optDouble("x").toFloat() else null,
                y = if (payload.has("y")) payload.optDouble("y").toFloat() else null,
            )

            "scroll" -> {
                val dir = when (payload.optString("direction").lowercase()) {
                    "up" -> ScrollDirection.UP
                    "left" -> ScrollDirection.LEFT
                    "right" -> ScrollDirection.RIGHT
                    else -> ScrollDirection.DOWN
                }
                CompanionCommand.Scroll(commandId, dir)
            }

            "type", "input_text" -> {
                val text = payload.optString("text")
                if (text.isBlank()) null
                else CompanionCommand.TypeText(
                    commandId = commandId,
                    text = text,
                    targetHint = payload.optString("targetHint").ifBlank { null },
                )
            }

            "global_action" -> {
                val gAction = when (payload.optString("key").lowercase()) {
                    "home" -> GlobalDeviceAction.HOME
                    "recents" -> GlobalDeviceAction.RECENTS
                    "notifications" -> GlobalDeviceAction.NOTIFICATIONS
                    else -> GlobalDeviceAction.BACK
                }
                CompanionCommand.GlobalAction(commandId, gAction)
            }

            "speak", "tts" -> {
                val text = payload.optString("text")
                if (text.isBlank()) null else CompanionCommand.Speak(commandId, text)
            }

            else -> null
        }
    }
}
