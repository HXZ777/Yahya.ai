package com.example.data.inspector

import com.example.domain.model.EssentialFileStatus
import com.example.domain.model.ProjectInspection
import com.example.domain.model.ProjectType
import java.io.File
import java.io.FileInputStream
import java.util.Properties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class AndroidProjectInspector {

    suspend fun inspectExtractedProject(
        workspaceId: String,
        extractedDir: File,
    ): ProjectInspection = withContext(Dispatchers.IO) {
        val projectRoot = resolveProjectRoot(extractedDir)
        val rootRelative = if (projectRoot.absolutePath == extractedDir.absolutePath) {
            "/"
        } else {
            "/" + projectRoot.relativeTo(extractedDir).path.replace(File.separatorChar, '/')
        }

        val settingsKts = File(projectRoot, "settings.gradle.kts")
        val settingsGroovy = File(projectRoot, "settings.gradle")
        val settingsFile = when {
            settingsKts.exists() -> settingsKts
            settingsGroovy.exists() -> settingsGroovy
            else -> null
        }

        val rootBuildKts = File(projectRoot, "build.gradle.kts")
        val rootBuildGroovy = File(projectRoot, "build.gradle")
        val rootBuildFile = when {
            rootBuildKts.exists() -> rootBuildKts
            rootBuildGroovy.exists() -> rootBuildGroovy
            else -> null
        }

        val wrapperPropsFile = File(projectRoot, "gradle/wrapper/gradle-wrapper.properties")
        val libsTomlFile = File(projectRoot, "gradle/libs.versions.toml")
        val gradlewFile = File(projectRoot, "gradlew")

        val settingsText = settingsFile?.safeReadText().orEmpty()
        val rootBuildText = rootBuildFile?.safeReadText().orEmpty()
        val libsTomlText = libsTomlFile.takeIf { it.exists() }?.safeReadText().orEmpty()

        val modules = parseModules(settingsText).ifEmpty {
            if (File(projectRoot, "app").isDirectory) listOf(":app") else emptyList()
        }

        val primaryModuleName = modules.firstOrNull()?.removePrefix(":")?.replace(':', '/') ?: "app"
        val appModuleDir = File(projectRoot, primaryModuleName).takeIf { it.isDirectory }
            ?: File(projectRoot, "app").takeIf { it.isDirectory }
            ?: projectRoot

        val appBuildFile = when {
            File(appModuleDir, "build.gradle.kts").exists() -> File(appModuleDir, "build.gradle.kts")
            File(appModuleDir, "build.gradle").exists() -> File(appModuleDir, "build.gradle")
            else -> null
        }
        val appBuildText = appBuildFile?.safeReadText().orEmpty()

        val manifestFile = File(appModuleDir, "src/main/AndroidManifest.xml").takeIf { it.exists() }
            ?: findManifestFallback(projectRoot)

        val manifestInfo = manifestFile?.let { parseAndroidManifest(it) }

        val projectName = parseProjectName(settingsText)
            ?: manifestInfo?.appLabel
            ?: projectRoot.name.takeIf { it != "src" }
            ?: "مشروع أندرويد"

        val gradleVersion = parseGradleVersion(wrapperPropsFile)
        val agpVersion = parseAgpVersion(rootBuildText, appBuildText, libsTomlText)
        val kotlinVersion = parseKotlinVersion(rootBuildText, appBuildText, libsTomlText)
        val javaCompat = parseJavaCompatibility(appBuildText, rootBuildText)

        val applicationId = extractValue(appBuildText, Regex("""applicationId\s*[=]?\s*["']([^"']+)["']"""))
            ?: manifestInfo?.packageName
        val namespace = extractValue(appBuildText, Regex("""namespace\s*[=]?\s*["']([^"']+)["']"""))
            ?: manifestInfo?.packageName

        val compileSdk = extractSdkValue(appBuildText, "compileSdk")
        val minSdk = extractSdkValue(appBuildText, "minSdk")
        val targetSdk = extractSdkValue(appBuildText, "targetSdk")
        val versionName = extractValue(appBuildText, Regex("""versionName\s*[=]?\s*["']([^"']+)["']"""))
        val versionCode = extractValue(appBuildText, Regex("""versionCode\s*[=]?\s*(\d+)"""))

        val detectedDependencies = extractDependencies(appBuildText, libsTomlText)

        var ktCount = 0
        var javaCount = 0
        var xmlCount = 0
        var totalFiles = 0
        var totalBytes = 0L
        val embeddedApks = mutableListOf<String>()

        extractedDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                totalFiles++
                totalBytes += file.length()
                when (file.extension.lowercase()) {
                    "kt" -> ktCount++
                    "java" -> javaCount++
                    "xml" -> xmlCount++
                    "apk" -> {
                        val rel = file.relativeTo(extractedDir).path.replace(File.separatorChar, '/')
                        embeddedApks.add(rel)
                    }
                }
            }
        }

        val isLibrary = appBuildText.contains("com.android.library") &&
            !appBuildText.contains("com.android.application")

        val projectType = when {
            settingsFile == null && appBuildFile == null && embeddedApks.isNotEmpty() -> ProjectType.PREBUILT_APK_ARCHIVE
            settingsFile == null && appBuildFile == null && manifestFile == null -> ProjectType.UNKNOWN_ARCHIVE
            isLibrary -> ProjectType.ANDROID_LIBRARY
            modules.size > 1 -> ProjectType.ANDROID_MULTI_MODULE
            ktCount > 0 && javaCount > 0 -> ProjectType.ANDROID_APP_MIXED
            ktCount > 0 || appBuildText.contains("kotlin") -> ProjectType.ANDROID_APP_KOTLIN
            javaCount > 0 -> ProjectType.ANDROID_APP_JAVA
            else -> ProjectType.ANDROID_APP_KOTLIN
        }

        val hasMainSrc = File(appModuleDir, "src/main").isDirectory

        val essentialFiles = listOf(
            EssentialFileStatus(
                label = "إعدادات Gradle",
                relativePath = settingsFile?.relativeTo(projectRoot)?.path ?: "settings.gradle(.kts)",
                present = settingsFile != null,
                detail = if (modules.isNotEmpty()) "${modules.size} وحدة" else null,
            ),
            EssentialFileStatus(
                label = "ملف البناء الرئيسي",
                relativePath = rootBuildFile?.relativeTo(projectRoot)?.path ?: "build.gradle(.kts)",
                present = rootBuildFile != null,
                detail = agpVersion?.let { "AGP $it" },
            ),
            EssentialFileStatus(
                label = "بناء وحدة التطبيق",
                relativePath = appBuildFile?.relativeTo(projectRoot)?.path ?: "app/build.gradle(.kts)",
                present = appBuildFile != null,
                detail = compileSdk?.let { "SDK $it" },
            ),
            EssentialFileStatus(
                label = "ملف AndroidManifest.xml",
                relativePath = manifestFile?.relativeTo(projectRoot)?.path ?: "app/src/main/AndroidManifest.xml",
                present = manifestFile != null,
                detail = namespace ?: applicationId,
            ),
            EssentialFileStatus(
                label = "غلاف Gradle Wrapper",
                relativePath = "gradle/wrapper/gradle-wrapper.properties",
                present = wrapperPropsFile.exists(),
                detail = gradleVersion?.let { "Gradle $it" },
            ),
            EssentialFileStatus(
                label = "ملفات الكود والموارد",
                relativePath = "${appModuleDir.name}/src/main",
                present = hasMainSrc,
                detail = "$ktCount kt • $javaCount java • $xmlCount xml",
            ),
        )

        val missingRequirements = mutableListOf<String>()
        if (settingsFile == null) missingRequirements += "ملف settings.gradle أو settings.gradle.kts غير موجود"
        if (appBuildFile == null && rootBuildFile == null) missingRequirements += "ملف build.gradle(.kts) للتطبيق غير موجود"
        if (manifestFile == null) missingRequirements += "ملف AndroidManifest.xml غير موجود"
        if (isLibrary) missingRequirements += "المشروع من نوع مكتبة (com.android.library) ولا ينتج APK مباشر"

        val isValidAndroidProject = settingsFile != null &&
            (appBuildFile != null || rootBuildFile != null) &&
            manifestFile != null &&
            !isLibrary

        val readinessSummary = when {
            projectType == ProjectType.UNKNOWN_ARCHIVE ->
                "هذا الملف المضغوط لا يطابق هيكل مشروع Android Studio قياسي."
            projectType == ProjectType.PREBUILT_APK_ARCHIVE ->
                "يحتوي الأرشيف على ${embeddedApks.size} ملف APK جاهز بدون ملفات مصدر Gradle."
            isLibrary ->
                "تم اكتشاف مكتبة أندرويد (Library). يلزم وجود تطبيق (com.android.application) لإنتاج APK."
            missingRequirements.isNotEmpty() ->
                "مشروع أندرويد ناقص: يوجد ${missingRequirements.size} متطلب مفقود."
            else ->
                "تم التحقق من مشروع Android Studio بنجاح داخل البيئة المعزولة (${detectedDependencies.size} مكتبة مكتشفة)."
        }

        ProjectInspection(
            workspaceId = workspaceId,
            workspaceDirPath = extractedDir.parentFile?.absolutePath ?: extractedDir.absolutePath,
            projectRootRelativePath = rootRelative,
            projectName = projectName,
            projectType = projectType,
            applicationId = applicationId,
            namespace = namespace,
            versionName = versionName,
            versionCode = versionCode,
            gradleVersion = gradleVersion,
            agpVersion = agpVersion,
            kotlinVersion = kotlinVersion,
            javaCompatibility = javaCompat,
            compileSdk = compileSdk,
            minSdk = minSdk,
            targetSdk = targetSdk,
            modules = modules,
            detectedDependencies = detectedDependencies,
            kotlinFileCount = ktCount,
            javaFileCount = javaCount,
            xmlFileCount = xmlCount,
            totalExtractedFiles = totalFiles,
            extractedSizeBytes = totalBytes,
            hasGradleWrapper = gradlewFile.exists() || wrapperPropsFile.exists(),
            essentialFiles = essentialFiles,
            embeddedApkPaths = embeddedApks,
            missingRequirements = missingRequirements,
            readinessSummary = readinessSummary,
            isValidAndroidProject = isValidAndroidProject,
        )
    }

    private fun extractDependencies(appBuildText: String, tomlText: String): List<String> {
        val deps = linkedSetOf<String>()
        Regex("""(?:implementation|api|ksp|kapt)\s*\(\s*["']([^"':]+:[^"':]+)(?::[^"']+)?["']\s*\)""")
            .findAll(appBuildText)
            .forEach { deps.add(it.groupValues[1]) }

        Regex("""(?:implementation|api|ksp|kapt)\s*\(\s*(libs\.[A-Za-z0-9_.]+)\s*\)""")
            .findAll(appBuildText)
            .forEach { deps.add(it.groupValues[1]) }

        Regex("""group\s*=\s*["']([^"']+)["']\s*,\s*name\s*=\s*["']([^"']+)["']""")
            .findAll(tomlText)
            .forEach { deps.add("${it.groupValues[1]}:${it.groupValues[2]}") }

        Regex("""module\s*=\s*["']([^"']+)["']""")
            .findAll(tomlText)
            .forEach { deps.add(it.groupValues[1]) }

        return deps.take(30)
    }

    private fun resolveProjectRoot(extractedDir: File): File {
        if (hasGradleMarkers(extractedDir)) return extractedDir
        val children = extractedDir.listFiles()?.filter { it.isDirectory && !it.name.startsWith("__MACOSX") }.orEmpty()
        if (children.size == 1 && hasGradleMarkers(children.first())) {
            return children.first()
        }
        val nested = children.firstOrNull { hasGradleMarkers(it) }
        return nested ?: extractedDir
    }

    private fun hasGradleMarkers(dir: File): Boolean {
        return File(dir, "settings.gradle.kts").exists() ||
            File(dir, "settings.gradle").exists() ||
            File(dir, "build.gradle.kts").exists() ||
            File(dir, "build.gradle").exists()
    }

    private fun findManifestFallback(root: File): File? {
        return root.walkTopDown()
            .maxDepth(5)
            .firstOrNull { it.isFile && it.name == "AndroidManifest.xml" && !it.path.contains("/build/") }
    }

    private fun parseProjectName(settingsText: String): String? {
        return extractValue(settingsText, Regex("""rootProject\.name\s*=\s*["']([^"']+)["']"""))
    }

    private fun parseModules(settingsText: String): List<String> {
        val matches = Regex("""include\s*\(([^)]+)\)|include\s+([^\r\n]+)""").findAll(settingsText)
        val result = mutableListOf<String>()
        for (match in matches) {
            val group = match.groupValues.drop(1).firstOrNull { it.isNotBlank() }.orEmpty()
            Regex("""["'](:[^"']+)["']""").findAll(group).forEach { mod ->
                result.add(mod.groupValues[1])
            }
        }
        return result.distinct()
    }

    private fun parseGradleVersion(wrapperPropsFile: File): String? {
        if (!wrapperPropsFile.exists()) return null
        return runCatching {
            val props = Properties()
            FileInputStream(wrapperPropsFile).use { props.load(it) }
            val distUrl = props.getProperty("distributionUrl") ?: return null
            Regex("""gradle-([0-9]+\.[0-9]+(?:\.[0-9]+)?)-""").find(distUrl)?.groupValues?.get(1)
        }.getOrNull()
    }

    private fun parseAgpVersion(rootBuild: String, appBuild: String, toml: String): String? {
        val combined = "$rootBuild\n$appBuild"
        return extractValue(combined, Regex("""com\.android\.application["']\s*\)?\s*version\s*["']([^"']+)["']"""))
            ?: extractValue(combined, Regex("""com\.android\.tools\.build:gradle:([0-9A-Za-z._-]+)"""))
            ?: extractValue(toml, Regex("""agp\s*=\s*["']([^"']+)["']"""))
    }

    private fun parseKotlinVersion(rootBuild: String, appBuild: String, toml: String): String? {
        val combined = "$rootBuild\n$appBuild"
        return extractValue(combined, Regex("""org\.jetbrains\.kotlin\.android["']\s*\)?\s*version\s*["']([^"']+)["']"""))
            ?: extractValue(combined, Regex("""kotlin-gradle-plugin:([0-9A-Za-z._-]+)"""))
            ?: extractValue(toml, Regex("""kotlin\s*=\s*["']([^"']+)["']"""))
    }

    private fun parseJavaCompatibility(appBuild: String, rootBuild: String): String? {
        val combined = "$appBuild\n$rootBuild"
        val source = extractValue(combined, Regex("""JavaVersion\.VERSION_([0-9_]+)"""))?.replace('_', '.')
        val jvmTarget = extractValue(combined, Regex("""jvmTarget\s*=\s*["']([^"']+)["']"""))
            ?: extractValue(combined, Regex("""JvmTarget\.JVM_(\d+)"""))
        return jvmTarget ?: source
    }

    private fun extractSdkValue(buildText: String, key: String): String? {
        return extractValue(buildText, Regex("""$key\s*[=]?\s*(\d+)"""))
            ?: extractValue(buildText, Regex("""$key\s*\{\s*version\s*=\s*release\((\d+)\)"""))
    }

    private fun extractValue(text: String, regex: Regex): String? {
        return regex.find(text)?.groupValues?.getOrNull(1)?.trim()
    }

    private fun File.safeReadText(): String {
        return runCatching {
            if (length() > 1024 * 1024) "" else readText()
        }.getOrDefault("")
    }

    private data class ManifestMeta(val packageName: String?, val appLabel: String?)

    private fun parseAndroidManifest(manifestFile: File): ManifestMeta? {
        return runCatching {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            FileInputStream(manifestFile).use { fis ->
                parser.setInput(fis, "UTF-8")
                var pkg: String? = null
                var label: String? = null
                var eventType = parser.eventType
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        when (parser.name) {
                            "manifest" -> pkg = parser.getAttributeValue(null, "package")
                            "application" -> {
                                val rawLabel = parser.getAttributeValue("http://schemas.android.com/apk/res/android", "label")
                                if (!rawLabel.isNullOrBlank() && !rawLabel.startsWith("@")) {
                                    label = rawLabel
                                }
                            }
                        }
                    }
                    eventType = parser.next()
                }
                ManifestMeta(pkg, label)
            }
        }.getOrNull()
    }
}
