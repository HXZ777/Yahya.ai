package com.example.data.inspector

import com.example.domain.model.EssentialFileStatus
import com.example.domain.model.ProjectInspection
import com.example.domain.model.ProjectType
import java.io.File
import java.io.FileInputStream
import java.util.Properties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class AndroidProjectInspector {

    suspend fun inspectExtractedProject(
        workspaceId: String,
        extractedDir: File,
    ): ProjectInspection = withContext(Dispatchers.IO) {
        val projectRoot = resolveProjectRoot(extractedDir)
        val rootRelative = if (projectRoot.absolutePath == extractedDir.absolutePath) {
            "/"
        } else {
            "/" + projectRoot.relativeTo(extractedDir).path.replace(File.separatorChar, '/')
        }

        val settingsKts = File(projectRoot, "settings.gradle.kts")
        val settingsGroovy = File(projectRoot, "settings.gradle")
        val settingsFile = when {
            settingsKts.exists() -> settingsKts
            settingsGroovy.exists() -> settingsGroovy
            else -> null
        }

        val rootBuildKts = File(projectRoot, "build.gradle.kts")
        val rootBuildGroovy = File(projectRoot, "build.gradle")
        val rootBuildFile = when {
            rootBuildKts.exists() -> rootBuildKts
            rootBuildGroovy.exists() -> rootBuildGroovy
            else -> null
        }

        val wrapperPropsFile = File(projectRoot, "gradle/wrapper/gradle-wrapper.properties")
        val libsTomlFile = File(projectRoot, "gradle/libs.versions.toml")
        val gradlewFile = File(projectRoot, "gradlew")

        val settingsText = settingsFile?.safeReadText().orEmpty()
        val rootBuildText = rootBuildFile?.safeReadText().orEmpty()
        val libsTomlText = libsTomlFile.takeIf { it.exists() }?.safeReadText().orEmpty()

        val modules = parseModules(settingsText).ifEmpty {
            if (File(projectRoot, "app").isDirectory) listOf(":app") else emptyList()
        }

        val primaryModuleName = modules.firstOrNull()?.removePrefix(":")?.replace(':', '/') ?: "app"
        val appModuleDir = File(projectRoot, primaryModuleName).takeIf { it.isDirectory }
            ?: File(projectRoot, "app").takeIf { it.isDirectory }
            ?: projectRoot

        val appBuildFile = when {
            File(appModuleDir, "build.gradle.kts").exists() -> File(appModuleDir, "build.gradle.kts")
            File(appModuleDir, "build.gradle").exists() -> File(appModuleDir, "build.gradle")
            else -> null
        }
        val appBuildText = appBuildFile?.safeReadText().orEmpty()

        val manifestFile = File(appModuleDir, "src/main/AndroidManifest.xml").takeIf { it.exists() }
            ?: findManifestFallback(projectRoot)

        val manifestInfo = manifestFile?.let { parseAndroidManifest(it) }

        val projectName = parseProjectName(settingsText)
            ?: manifestInfo?.appLabel
            ?: projectRoot.name.takeIf { it != "src" }
            ?: "Android Project"

        val gradleVersion = parseGradleVersion(wrapperPropsFile)
        val agpVersion = parseAgpVersion(rootBuildText, appBuildText, libsTomlText)
        val kotlinVersion = parseKotlinVersion(rootBuildText, appBuildText, libsTomlText)
        val javaCompat = parseJavaCompatibility(appBuildText, rootBuildText)

        val applicationId = extractValue(appBuildText, Regex("""applicationId\s*[=]?\s*["']([^"']+)["']"""))
            ?: manifestInfo?.packageName
        val namespace = extractValue(appBuildText, Regex("""namespace\s*[=]?\s*["']([^"']+)["']"""))
            ?: manifestInfo?.packageName

        val compileSdk = extractSdkValue(appBuildText, "compileSdk")
        val minSdk = extractSdkValue(appBuildText, "minSdk")
        val targetSdk = extractSdkValue(appBuildText, "targetSdk")
        val versionName = extractValue(appBuildText, Regex("""versionName\s*[=]?\s*["']([^"']+)["']"""))
        val versionCode = extractValue(appBuildText, Regex("""versionCode\s*[=]?\s*(\d+)"""))

        var ktCount = 0
        var javaCount = 0
        var xmlCount = 0
        var totalFiles = 0
        var totalBytes = 0L
        val embeddedApks = mutableListOf<String>()

        extractedDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                totalFiles++
                totalBytes += file.length()
                when (file.extension.lowercase()) {
                    "kt", "kts" -> if (file.extension.equals("kt", ignoreCase = true)) ktCount++
                    "java" -> javaCount++
                    "xml" -> xmlCount++
                    "apk" -> {
                        val rel = file.relativeTo(extractedDir).path.replace(File.separatorChar, '/')
                        embeddedApks.add(rel)
                    }
                }
            }
        }

        val isLibrary = appBuildText.contains("com.android.library") &&
            !appBuildText.contains("com.android.application")

        val projectType = when {
            settingsFile == null && appBuildFile == null && embeddedApks.isNotEmpty() -> ProjectType.PREBUILT_APK_ARCHIVE
            settingsFile == null && appBuildFile == null && manifestFile == null -> ProjectType.UNKNOWN_ARCHIVE
            isLibrary -> ProjectType.ANDROID_LIBRARY
            modules.size > 1 -> ProjectType.ANDROID_MULTI_MODULE
            ktCount > 0 && javaCount > 0 -> ProjectType.ANDROID_APP_MIXED
            ktCount > 0 || appBuildText.contains("kotlin") -> ProjectType.ANDROID_APP_KOTLIN
            javaCount > 0 -> ProjectType.ANDROID_APP_JAVA
            else -> ProjectType.ANDROID_APP_KOTLIN
        }

        val hasMainSrc = File(appModuleDir, "src/main").isDirectory

        val essentialFiles = listOf(
            EssentialFileStatus(
                label = "Gradle Settings",
                relativePath = settingsFile?.relativeTo(projectRoot)?.path ?: "settings.gradle(.kts)",
                present = settingsFile != null,
                detail = if (modules.isNotEmpty()) "${modules.size} module(s): ${modules.joinToString(", ")}" else null,
            ),
            EssentialFileStatus(
                label = "Root Build Script",
                relativePath = rootBuildFile?.relativeTo(projectRoot)?.path ?: "build.gradle(.kts)",
                present = rootBuildFile != null,
                detail = agpVersion?.let { "AGP $it" },
            ),
            EssentialFileStatus(
                label = "App Module Build",
                relativePath = appBuildFile?.relativeTo(projectRoot)?.path ?: "app/build.gradle(.kts)",
                present = appBuildFile != null,
                detail = compileSdk?.let { "compileSdk $it" },
            ),
            EssentialFileStatus(
                label = "AndroidManifest.xml",
                relativePath = manifestFile?.relativeTo(projectRoot)?.path ?: "app/src/main/AndroidManifest.xml",
                present = manifestFile != null,
                detail = namespace ?: applicationId,
            ),
            EssentialFileStatus(
                label = "Gradle Wrapper",
                relativePath = "gradle/wrapper/gradle-wrapper.properties",
                present = wrapperPropsFile.exists(),
                detail = gradleVersion?.let { "Gradle $it" },
            ),
            EssentialFileStatus(
                label = "Source Set (src/main)",
                relativePath = "${appModuleDir.name}/src/main",
                present = hasMainSrc,
                detail = "$ktCount .kt, $javaCount .java, $xmlCount .xml",
            ),
        )

        val missingRequirements = mutableListOf<String>()
        if (settingsFile == null) missingRequirements += "Missing settings.gradle or settings.gradle.kts"
        if (appBuildFile == null && rootBuildFile == null) missingRequirements += "Missing Android module build.gradle(.kts)"
        if (manifestFile == null) missingRequirements += "Missing AndroidManifest.xml"
        if (isLibrary) missingRequirements += "Module uses com.android.library (libraries produce AAR, not APK)"

        val isValidAndroidProject = settingsFile != null &&
            (appBuildFile != null || rootBuildFile != null) &&
            manifestFile != null &&
            !isLibrary

        val readinessSummary = when {
            projectType == ProjectType.UNKNOWN_ARCHIVE ->
                "Not an Android Studio Gradle project. Essential Gradle and Manifest files were not found."
            projectType == ProjectType.PREBUILT_APK_ARCHIVE ->
                "Archive contains ${embeddedApks.size} pre-built APK file(s), but no Gradle source build scripts."
            isLibrary ->
                "Android Library project detected. An application module (com.android.application) is required to build an APK."
            missingRequirements.isNotEmpty() ->
                "Partial Android project detected with ${missingRequirements.size} missing requirement(s)."
            else ->
                "Valid Android Studio project detected and verified in isolated sandbox."
        }

        ProjectInspection(
            workspaceId = workspaceId,
            workspaceDirPath = extractedDir.parentFile?.absolutePath ?: extractedDir.absolutePath,
            projectRootRelativePath = rootRelative,
            projectName = projectName,
            projectType = projectType,
            applicationId = applicationId,
            namespace = namespace,
            versionName = versionName,
            versionCode = versionCode,
            gradleVersion = gradleVersion,
            agpVersion = agpVersion,
            kotlinVersion = kotlinVersion,
            javaCompatibility = javaCompat,
            compileSdk = compileSdk,
            minSdk = minSdk,
            targetSdk = targetSdk,
            modules = modules,
            kotlinFileCount = ktCount,
            javaFileCount = javaCount,
            xmlFileCount = xmlCount,
            totalExtractedFiles = totalFiles,
            extractedSizeBytes = totalBytes,
            hasGradleWrapper = gradlewFile.exists() || wrapperPropsFile.exists(),
            essentialFiles = essentialFiles,
            embeddedApkPaths = embeddedApks,
            missingRequirements = missingRequirements,
            readinessSummary = readinessSummary,
            isValidAndroidProject = isValidAndroidProject,
        )
    }

    private fun resolveProjectRoot(extractedDir: File): File {
        if (hasGradleMarkers(extractedDir)) return extractedDir
        val children = extractedDir.listFiles()?.filter { it.isDirectory && !it.name.startsWith("__MACOSX") }.orEmpty()
        if (children.size == 1 && hasGradleMarkers(children.first())) {
            return children.first()
        }
        val nested = children.firstOrNull { hasGradleMarkers(it) }
        return nested ?: extractedDir
    }

    private fun hasGradleMarkers(dir: File): Boolean {
        return File(dir, "settings.gradle.kts").exists() ||
            File(dir, "settings.gradle").exists() ||
            File(dir, "build.gradle.kts").exists() ||
            File(dir, "build.gradle").exists()
    }

    private fun findManifestFallback(root: File): File? {
        return root.walkTopDown()
            .maxDepth(5)
            .firstOrNull { it.isFile && it.name == "AndroidManifest.xml" && !it.path.contains("/build/") }
    }

    private fun parseProjectName(settingsText: String): String? {
        return extractValue(settingsText, Regex("""rootProject\.name\s*=\s*["']([^"']+)["']"""))
    }

    private fun parseModules(settingsText: String): List<String> {
        val matches = Regex("""include\s*\(([^)]+)\)|include\s+([^\r\n]+)""").findAll(settingsText)
        val result = mutableListOf<String>()
        for (match in matches) {
            val group = match.groupValues.drop(1).firstOrNull { it.isNotBlank() }.orEmpty()
            Regex("""["'](:[^"']+)["']""").findAll(group).forEach { mod ->
                result.add(mod.groupValues[1])
            }
        }
        return result.distinct()
    }

    private fun parseGradleVersion(wrapperPropsFile: File): String? {
        if (!wrapperPropsFile.exists()) return null
        return runCatching {
            val props = Properties()
            FileInputStream(wrapperPropsFile).use { props.load(it) }
            val distUrl = props.getProperty("distributionUrl") ?: return null
            Regex("""gradle-([0-9]+\.[0-9]+(?:\.[0-9]+)?)-""").find(distUrl)?.groupValues?.get(1)
        }.getOrNull()
    }

    private fun parseAgpVersion(rootBuild: String, appBuild: String, toml: String): String? {
        val combined = "$rootBuild\n$appBuild"
        return extractValue(combined, Regex("""com\.android\.application["']\s*\)?\s*version\s*["']([^"']+)["']"""))
            ?: extractValue(combined, Regex("""com\.android\.tools\.build:gradle:([0-9A-Za-z._-]+)"""))
            ?: extractValue(toml, Regex("""agp\s*=\s*["']([^"']+)["']"""))
    }

    private fun parseKotlinVersion(rootBuild: String, appBuild: String, toml: String): String? {
        val combined = "$rootBuild\n$appBuild"
        return extractValue(combined, Regex("""org\.jetbrains\.kotlin\.android["']\s*\)?\s*version\s*["']([^"']+)["']"""))
            ?: extractValue(combined, Regex("""kotlin-gradle-plugin:([0-9A-Za-z._-]+)"""))
            ?: extractValue(toml, Regex("""kotlin\s*=\s*["']([^"']+)["']"""))
    }

    private fun parseJavaCompatibility(appBuild: String, rootBuild: String): String? {
        val combined = "$appBuild\n$rootBuild"
        val source = extractValue(combined, Regex("""JavaVersion\.VERSION_([0-9_]+)"""))?.replace('_', '.')
        val jvmTarget = extractValue(combined, Regex("""jvmTarget\s*=\s*["']([^"']+)["']"""))
            ?: extractValue(combined, Regex("""JvmTarget\.JVM_(\d+)"""))
        return jvmTarget ?: source
    }

    private fun extractSdkValue(buildText: String, key: String): String? {
        return extractValue(buildText, Regex("""$key\s*[=]?\s*(\d+)"""))
            ?: extractValue(buildText, Regex("""$key\s*\{\s*version\s*=\s*release\((\d+)\)"""))
    }

    private fun extractValue(text: String, regex: Regex): String? {
        return regex.find(text)?.groupValues?.getOrNull(1)?.trim()
    }

    private fun File.safeReadText(): String {
        return runCatching {
            if (length() > 1024 * 1024) "" else readText()
        }.getOrDefault("")
    }

    private data class ManifestMeta(val packageName: String?, val appLabel: String?)

    private fun parseAndroidManifest(manifestFile: File): ManifestMeta? {
        return runCatching {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            FileInputStream(manifestFile).use { fis ->
                parser.setInput(fis, "UTF-8")
                var pkg: String? = null
                var label: String? = null
                var eventType = parser.eventType
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        when (parser.name) {
                            "manifest" -> pkg = parser.getAttributeValue(null, "package")
                            "application" -> {
                                val rawLabel = parser.getAttributeValue("http://schemas.android.com/apk/res/android", "label")
                                if (!rawLabel.isNullOrBlank() && !rawLabel.startsWith("@")) {
                                    label = rawLabel
                                }
                            }
                        }
                    }
                    eventType = parser.next()
                }
                ManifestMeta(pkg, label)
            }
        }.getOrNull()
    }
}
