package com.example.data.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.example.domain.model.DiscoveredBrainDevice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NsdBrainDiscovery(context: Context) {

    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val serviceType = "_yahya-brain._tcp."

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredBrainDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredBrainDevice>> = _discoveredDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private var activeListener: NsdManager.DiscoveryListener? = null

    fun startDiscovery() {
        if (nsdManager == null || activeListener != null) return
        _discoveredDevices.value = emptyList()

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                _isScanning.value = true
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (serviceInfo.serviceType == serviceType || serviceInfo.serviceType.contains("yahya-brain")) {
                    resolveService(serviceInfo)
                }
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                _discoveredDevices.value = _discoveredDevices.value.filterNot {
                    it.serviceName == serviceInfo.serviceName
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                _isScanning.value = false
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                _isScanning.value = false
                stopDiscovery()
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                _isScanning.value = false
            }
        }

        activeListener = listener
        runCatching {
            nsdManager?.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure {
            activeListener = null
            _isScanning.value = false
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveService(serviceInfo: NsdServiceInfo) {
        nsdManager?.resolveService(
            serviceInfo,
            object : NsdManager.ResolveListener {
                override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit

                override fun onServiceResolved(resolved: NsdServiceInfo) {
                    val host = resolved.host?.hostAddress ?: return
                    val port = resolved.port
                    val device = DiscoveredBrainDevice(
                        serviceName = resolved.serviceName,
                        host = host,
                        port = port,
                    )
                    val current = _discoveredDevices.value.filterNot {
                        it.host == host && it.port == port
                    }
                    _discoveredDevices.value = current + device
                }
            },
        )
    }

    fun stopDiscovery() {
        val listener = activeListener ?: return
        activeListener = null
        _isScanning.value = false
        runCatching { nsdManager?.stopServiceDiscovery(listener) }
    }
}
