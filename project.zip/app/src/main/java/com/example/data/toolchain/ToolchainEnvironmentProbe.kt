package com.example.data.toolchain

import android.content.Context
import android.os.Build
import android.os.StatFs
import com.example.domain.model.DeviceToolchainProbe
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ToolchainEnvironmentProbe(private val context: Context) {

    suspend fun probeDeviceEnvironment(): DeviceToolchainProbe = withContext(Dispatchers.IO) {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val sdkInt = Build.VERSION.SDK_INT
        val freeSpace = runCatching {
            val stat = StatFs(context.filesDir.absolutePath)
            stat.availableBlocksLong * stat.blockSizeLong
        }.getOrDefault(0L)

        val javaVersion = System.getProperty("java.version") ?: "Android Runtime (ART)"
        val pathDirs = (System.getenv("PATH") ?: "")
            .split(File.pathSeparator)
            .filter { it.isNotBlank() }
            .map { File(it) }

        val extraDirs = listOf(
            File(context.filesDir, "toolchain/bin"),
            File("/data/data/com.termux/files/usr/bin"),
        )
        val searchDirs = pathDirs + extraDirs

        val hasJavac = hasExecutable("javac", searchDirs)
        val hasGradle = hasExecutable("gradle", searchDirs)
        val hasAapt2 = hasExecutable("aapt2", searchDirs)
        val hasD8 = hasExecutable("d8", searchDirs)
        val androidHome = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
        val hasAndroidSdk = !androidHome.isNullOrBlank() && File(androidHome, "platforms").isDirectory

        val missing = mutableListOf<String>()
        if (!hasJavac) missing += "JDK Compiler (javac / kotlinc)"
        if (!hasGradle) missing += "Gradle Build CLI"
        if (!hasAndroidSdk) missing += "Android SDK Platforms (android.jar)"
        if (!hasAapt2) missing += "Android Asset Packaging Tool (aapt2)"
        if (!hasD8) missing += "DEX Compiler & APK Signer (d8 / apksigner)"

        val ready = hasJavac && hasGradle && hasAndroidSdk && hasAapt2 && hasD8

        DeviceToolchainProbe(
            deviceAbi = abi,
            androidSdkInt = sdkInt,
            freeSpaceBytes = freeSpace,
            javaRuntimeVersion = javaVersion,
            hasLocalJavac = hasJavac,
            hasLocalGradle = hasGradle,
            hasAndroidSdk = hasAndroidSdk,
            hasAapt2 = hasAapt2,
            hasD8 = hasD8,
            localToolchainReady = ready,
            missingToolchainItems = missing,
        )
    }

    private fun hasExecutable(binaryName: String, searchDirs: List<File>): Boolean {
        return searchDirs.any { dir ->
            val candidate = File(dir, binaryName)
            candidate.exists() && candidate.isFile && candidate.canExecute()
        }
    }
}
