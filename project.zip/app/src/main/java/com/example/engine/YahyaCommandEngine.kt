package com.example.engine

import com.example.accessibility.DeviceCommandExecutor
import com.example.data.ai.AiGateway
import com.example.domain.model.AssistantCommand
import com.example.domain.model.AssistantSettings
import com.example.domain.model.WebSource
import com.example.domain.policy.SensitiveInputFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class EngineExecutionResult(
    val success: Boolean,
    val detail: String,
    val sources: List<WebSource> = emptyList(),
)

class YahyaCommandEngine(
    private val deviceExecutor: DeviceCommandExecutor,
    private val aiGateway: AiGateway,
    private val httpClient: OkHttpClient = defaultWebClient(),
) {

    suspend fun executeCommand(
        command: AssistantCommand,
        settings: AssistantSettings,
        apiKey: String?,
    ): EngineExecutionResult {
        return when (command) {
            is AssistantCommand.WebSearch -> {
                if (!settings.webSearchEnabled) {
                    return EngineExecutionResult(
                        success = false,
                        detail = "البحث في الإنترنت معطّل حالياً من الإعدادات.",
                    )
                }
                val key = apiKey?.trim().orEmpty()
                if (key.isEmpty()) {
                    return EngineExecutionResult(
                        success = false,
                        detail = "مفتاح Gemini API مطلوب لإجراء البحث في الإنترنت.",
                    )
                }
                val searchRes = aiGateway.performGroundedWebSearch(
                    query = command.query,
                    apiKey = key,
                    modelId = settings.geminiModelId,
                )
                EngineExecutionResult(
                    success = searchRes.success,
                    detail = if (searchRes.success) {
                        searchRes.summaryText
                    } else {
                        searchRes.errorMessage ?: "تعذر إتمام البحث في الإنترنت."
                    },
                    sources = searchRes.sources,
                )
            }

            is AssistantCommand.FetchWebpage -> {
                if (!settings.webSearchEnabled) {
                    return EngineExecutionResult(
                        success = false,
                        detail = "قراءة صفحات الويب معطّلة لأن البحث في الإنترنت معطّل في الإعدادات.",
                    )
                }
                fetchWebpageText(command.url)
            }

            else -> {
                val localOutcome = withContext(Dispatchers.Main.immediate) {
                    deviceExecutor.executeLocalDeviceCommand(
                        command = command,
                        autoSpeakReplies = settings.autoSpeakReplies,
                    )
                }
                EngineExecutionResult(
                    success = localOutcome.success,
                    detail = localOutcome.detail,
                )
            }
        }
    }

    private suspend fun fetchWebpageText(rawUrl: String): EngineExecutionResult = withContext(Dispatchers.IO) {
        val cleanUrl = rawUrl.trim()
        if (!cleanUrl.startsWith("https://", ignoreCase = true)) {
            return@withContext EngineExecutionResult(
                success = false,
                detail = "تقتصر قراءة صفحات الويب الآمنة على روابط HTTPS فقط.",
            )
        }

        runCatching {
            val req = Request.Builder()
                .url(cleanUrl)
                .header("User-Agent", "HXZ-AI-Android/1.0")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext EngineExecutionResult(
                        success = false,
                        detail = "تعذر قراءة الصفحة (HTTP ${resp.code}).",
                    )
                }
                val contentType = resp.header("Content-Type").orEmpty()
                if (contentType.isNotBlank() &&
                    !contentType.contains("text", ignoreCase = true) &&
                    !contentType.contains("html", ignoreCase = true) &&
                    !contentType.contains("json", ignoreCase = true)
                ) {
                    return@withContext EngineExecutionResult(
                        success = false,
                        detail = "نوع المحتوى غير نصي ولا يمكن تلخيصه ($contentType).",
                    )
                }
                val rawBody = resp.body?.string().orEmpty().take(120_000)
                val extracted = extractReadableTextFromHtml(rawBody)
                val safeText = SensitiveInputFilter.redactSensitiveText(extracted).take(3500)
                if (safeText.isBlank()) {
                    EngineExecutionResult(
                        success = false,
                        detail = "الصفحة لا تحتوي على نص قابل للقراءة.",
                    )
                } else {
                    EngineExecutionResult(
                        success = true,
                        detail = safeText,
                        sources = listOf(WebSource(title = cleanUrl, url = cleanUrl)),
                    )
                }
            }
        }.getOrElse { e ->
            EngineExecutionResult(
                success = false,
                detail = "فشل جلب الصفحة: ${e.localizedMessage ?: "خطأ اتصال"}",
            )
        }
    }

    companion object {
        private val scriptStyleRegex = Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>")
        private val htmlTagRegex = Regex("<[^>]+>")
        private val whitespaceRegex = Regex("\\s+")

        fun extractReadableTextFromHtml(raw: String): String {
            if (raw.isBlank()) return ""
            return raw
                .replace(scriptStyleRegex, " ")
                .replace(htmlTagRegex, " ")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace(whitespaceRegex, " ")
                .trim()
        }

        fun defaultWebClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }
}
