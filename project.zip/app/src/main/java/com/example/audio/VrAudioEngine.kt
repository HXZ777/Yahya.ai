package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class VrAudioEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var sfxEnabled = true
    private var musicEnabled = true
    private var musicJob: Job? = null
    private var lastFootstepMs = 0L
    private var lastCartSoundMs = 0L

    fun updateSettings(sfx: Boolean, music: Boolean) {
        sfxEnabled = sfx
        if (music != musicEnabled) {
            musicEnabled = music
            if (musicEnabled) startAmbientMusic() else stopAmbientMusic()
        } else if (musicEnabled && musicJob?.isActive != true) {
            startAmbientMusic()
        }
    }

    fun playBarcodeBeep() {
        if (!sfxEnabled) return
        playTone(freqHz = 2450.0, durationMs = 95, volume = 0.28f, decay = 4f)
    }

    fun playGrabClick() {
        if (!sfxEnabled) return
        playDualTone(520.0, 780.0, durationMs = 55, volume = 0.22f)
    }

    fun playPlaceThud() {
        if (!sfxEnabled) return
        playTone(freqHz = 185.0, durationMs = 70, volume = 0.25f, decay = 9f)
    }

    fun playDoorWhoosh() {
        if (!sfxEnabled) return
        playDualTone(660.0, 880.0, durationMs = 140, volume = 0.16f)
    }

    fun playPaymentSuccess() {
        if (!sfxEnabled) return
        scope.launch {
            playTone(freqHz = 880.0, durationMs = 90, volume = 0.26f, decay = 5f)
            delay(85)
            playTone(freqHz = 1318.5, durationMs = 170, volume = 0.28f, decay = 4f)
        }
    }

    fun playErrorBuzz() {
        if (!sfxEnabled) return
        playTone(freqHz = 190.0, durationMs = 190, volume = 0.26f, decay = 3f)
    }

    fun playFootstep() {
        if (!sfxEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastFootstepMs < 380L) return
        lastFootstepMs = now
        playNoiseBurst(durationMs = 38, volume = 0.08f, lowFreqHz = 130.0)
    }

    fun playCartRoll() {
        if (!sfxEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastCartSoundMs < 320L) return
        lastCartSoundMs = now
        playNoiseBurst(durationMs = 60, volume = 0.06f, lowFreqHz = 340.0)
    }

    fun startAmbientMusic() {
        if (!musicEnabled || musicJob?.isActive == true) return
        musicJob = scope.launch {
            val sampleRate = 22050
            val chordNotes = listOf(
                doubleArrayOf(261.63, 329.63, 392.00), // C maj
                doubleArrayOf(220.00, 261.63, 329.63), // A min
                doubleArrayOf(174.61, 220.00, 261.63), // F maj
                doubleArrayOf(196.00, 246.94, 293.66)  // G maj
            )
            var chordIndex = 0
            val chunkSamples = sampleRate * 2 // 2 seconds per chord
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(chunkSamples * 2)

            val track = runCatching {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            }.getOrNull() ?: return@launch

            try {
                track.play()
                val buffer = ShortArray(chunkSamples)
                while (isActive && musicEnabled) {
                    val chord = chordNotes[chordIndex % chordNotes.size]
                    chordIndex++
                    for (i in 0 until chunkSamples) {
                        val t = i.toDouble() / sampleRate
                        val env = sin(PI * i / chunkSamples).coerceIn(0.0, 1.0)
                        var mix = 0.0
                        for (f in chord) {
                            mix += sin(2.0 * PI * f * t)
                        }
                        mix = (mix / chord.size) * env * 0.055
                        buffer[i] = (mix * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                    }
                    track.write(buffer, 0, buffer.size)
                }
            } catch (_: Throwable) {
                // Safe audio teardown
            } finally {
                runCatching {
                    track.stop()
                    track.release()
                }
            }
        }
    }

    fun stopAmbientMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    fun release() {
        stopAmbientMusic()
    }

    private fun playTone(freqHz: Double, durationMs: Int, volume: Float, decay: Float) {
        scope.launch {
            val sampleRate = 22050
            val count = (sampleRate * durationMs / 1000).coerceAtLeast(64)
            val samples = ShortArray(count)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val env = exp(-decay * t / (durationMs / 1000.0))
                val v = sin(2.0 * PI * freqHz * t) * env * volume
                samples[i] = (v * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            writeOneShot(sampleRate, samples)
        }
    }

    private fun playDualTone(f1: Double, f2: Double, durationMs: Int, volume: Float) {
        scope.launch {
            val sampleRate = 22050
            val count = (sampleRate * durationMs / 1000).coerceAtLeast(64)
            val samples = ShortArray(count)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val f = if (i < count / 2) f1 else f2
                val env = 1.0 - (i.toDouble() / count) * 0.65
                val v = sin(2.0 * PI * f * t) * env * volume
                samples[i] = (v * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            writeOneShot(sampleRate, samples)
        }
    }

    private fun playNoiseBurst(durationMs: Int, volume: Float, lowFreqHz: Double) {
        scope.launch {
            val sampleRate = 22050
            val count = (sampleRate * durationMs / 1000).coerceAtLeast(64)
            val samples = ShortArray(count)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val env = exp(-6.0 * t / (durationMs / 1000.0))
                val tone = sin(2.0 * PI * lowFreqHz * t) * 0.65 + (Random.nextDouble() * 2.0 - 1.0) * 0.35
                val v = tone * env * volume
                samples[i] = (v * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            writeOneShot(sampleRate, samples)
        }
    }

    private fun writeOneShot(sampleRate: Int, samples: ShortArray) {
        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
        }.getOrNull() ?: return

        runCatching {
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep((samples.size * 1000L / sampleRate) + 40L)
        }
        runCatching {
            track.stop()
            track.release()
        }
    }
}
