package com.example.vr.shizuku;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;

interface IShizukuVrService {
    void destroy();
    int getUid();
    int createVirtualDisplay(in Surface surface, int width, int height, int dpi);
    void resizeVirtualDisplay(int width, int height, int dpi);
    void releaseVirtualDisplay();
    String launchPackageOnDisplay(String packageName, String activityComponent, int displayId);
    boolean isPackageRunningOnDisplay(String packageName, int displayId);
    boolean injectKeyEvent(in KeyEvent event, int displayId);
    boolean injectMotionEvent(in MotionEvent event, int displayId);
    boolean injectTouchEvent(int displayId, int action, float x, float y, long downTimeMs, long eventTimeMs);
    String getLastError();
}
