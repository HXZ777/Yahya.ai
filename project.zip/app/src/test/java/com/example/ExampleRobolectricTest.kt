package com.example

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertContentDescriptionEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.accessibility.DeviceCommandExecutor
import com.example.data.ai.AiGateway
import com.example.data.ai.AiTurnOutcome
import com.example.data.ai.CloudModelsFetchResult
import com.example.data.ai.GeminiResponseParser
import com.example.data.ai.GroundedSearchResult
import com.example.data.ai.ToolExecutionReport
import com.example.data.security.ApiKeyVault
import com.example.domain.model.AiConnectionTestResult
import com.example.domain.model.AssistantCommand
import com.example.domain.model.AssistantSettings
import com.example.domain.model.MicStatus
import com.example.engine.YahyaCommandEngine
import com.example.ui.components.FloatingMicControl
import com.example.ui.theme.YahyaCompanionTheme
import com.example.voice.ArabicTtsEngine
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `official app name and service labels reflect HXZ AI`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("HXZ AI", context.getString(R.string.app_name))
        assertTrue(context.getString(R.string.accessibility_service_label).contains("HXZ AI"))
        assertTrue(context.getString(R.string.voice_notification_title).contains("HXZ AI"))
    }

    @Test
    fun `gemini parser extracts structured function calls`() {
        val json = """
            {
              "candidates": [
                {
                  "content": {
                    "role": "model",
                    "parts": [
                      {
                        "functionCall": {
                          "name": "web_search",
                          "args": { "query": "سعر صرف الريال السعودي اليوم" }
                        }
                      },
                      {
                        "functionCall": {
                          "name": "open_app",
                          "args": { "app_name": "يوتيوب" }
                        }
                      }
                    ]
                  }
                }
              ]
            }
        """.trimIndent()

        val parsed = GeminiResponseParser.parseGenerateContentResponse(json)
        assertNull(parsed.errorMessage)
        assertEquals(2, parsed.toolCalls.size)
        val firstCmd = parsed.toolCalls[0].command
        val secondCmd = parsed.toolCalls[1].command
        assertTrue(firstCmd is AssistantCommand.WebSearch)
        assertEquals("سعر صرف الريال السعودي اليوم", (firstCmd as AssistantCommand.WebSearch).query)
        assertTrue(secondCmd is AssistantCommand.OpenApp)
        assertEquals("يوتيوب", (secondCmd as AssistantCommand.OpenApp).appName)
    }

    @Test
    fun `gemini parser extracts grounding web search sources without duplicates`() {
        val json = """
            {
              "candidates": [
                {
                  "content": {
                    "role": "model",
                    "parts": [
                      { "text": "الطقس في الرياض معتدل اليوم." }
                    ]
                  },
                  "groundingMetadata": {
                    "groundingChunks": [
                      { "web": { "uri": "https://weather.example.com/riyadh", "title": "Weather Example" } },
                      { "web": { "uri": "https://weather.example.com/riyadh", "title": "Duplicate" } },
                      { "web": { "uri": "https://ncm.gov.sa", "title": "المركز الوطني للأرصاد" } }
                    ]
                  }
                }
              ]
            }
        """.trimIndent()

        val parsed = GeminiResponseParser.parseGenerateContentResponse(json)
        assertNull(parsed.errorMessage)
        assertEquals("الطقس في الرياض معتدل اليوم.", parsed.text)
        assertEquals(2, parsed.sources.size)
        assertEquals("https://ncm.gov.sa", parsed.sources[1].url)
    }

    @Test
    fun `api key vault saves retrieves and clears api key`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vault = ApiKeyVault(context)
        vault.saveApiKey("AIzaTest1234567890Secret")
        assertEquals("AIzaTest1234567890Secret", vault.getApiKey())
        vault.clearApiKey()
        assertNull(vault.getApiKey())
    }

    @Test
    fun `command engine refuses web search when disabled in settings`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tts = ArabicTtsEngine(context)
        val engine = YahyaCommandEngine(
            deviceExecutor = DeviceCommandExecutor(context, tts),
            aiGateway = object : AiGateway {
                override suspend fun startUserTurn(userInput: String, apiKey: String, settings: AssistantSettings, deviceContextSummary: String): AiTurnOutcome =
                    AiTurnOutcome.FinalReply("ok")
                override suspend fun submitToolResults(reports: List<ToolExecutionReport>, apiKey: String, settings: AssistantSettings): AiTurnOutcome =
                    AiTurnOutcome.FinalReply("ok")
                override suspend fun performGroundedWebSearch(query: String, apiKey: String, modelId: String): GroundedSearchResult =
                    GroundedSearchResult(true, "should not be called")
                override suspend fun testConnection(apiKey: String, modelId: String): AiConnectionTestResult =
                    AiConnectionTestResult(true, 10, "ok")
                override suspend fun fetchAvailableModels(apiKey: String): CloudModelsFetchResult =
                    CloudModelsFetchResult(true, emptyList())
                override fun clearConversation() = Unit
            },
        )

        val result = engine.executeCommand(
            command = AssistantCommand.WebSearch(query = "أخبار التقنية"),
            settings = AssistantSettings(webSearchEnabled = false),
            apiKey = "AIzaDummy",
        )
        assertFalse(result.success)
        assertTrue(result.detail.contains("معطّل"))
        tts.shutdown()
    }

    @Test
    fun `floating mic control toggles between muted and listening states`() {
        var listeningState by mutableStateOf(false)
        var micStatusState by mutableStateOf(MicStatus.READY)

        composeRule.setContent {
            YahyaCompanionTheme {
                FloatingMicControl(
                    assistantName = "يحيى",
                    isListening = listeningState,
                    micStatus = micStatusState,
                    rmsLevel = 0.4f,
                    onToggleMute = {
                        listeningState = !listeningState
                        micStatusState = if (listeningState) MicStatus.LISTENING else MicStatus.READY
                    },
                )
            }
        }

        composeRule.onNodeWithTag("floating_mic_button")
            .assertIsDisplayed()
            .assertContentDescriptionEquals("إلغاء كتم الميكروفون وبدء الاستماع")
        composeRule.onNodeWithTag("floating_listening_indicator").assertDoesNotExist()

        composeRule.onNodeWithTag("floating_mic_button").performClick()
        composeRule.onNodeWithTag("floating_mic_button")
            .assertContentDescriptionEquals("كتم الميكروفون وإيقاف الاستماع")
        composeRule.onNodeWithTag("floating_listening_indicator").assertIsDisplayed()
        composeRule.onNodeWithText("يحيى يستمع الآن").assertIsDisplayed()

        composeRule.onNodeWithTag("floating_mic_button").performClick()
        composeRule.onNodeWithTag("floating_mic_button")
            .assertContentDescriptionEquals("إلغاء كتم الميكروفون وبدء الاستماع")
        composeRule.onNodeWithTag("floating_listening_indicator").assertDoesNotExist()
    }

    @Test
    fun `gemini parser extracts cloud models supporting generateContent and strips models prefix`() {
        val json = """
            {
              "models": [
                {
                  "name": "models/gemini-2.5-flash",
                  "displayName": "Gemini 2.5 Flash",
                  "supportedGenerationMethods": ["generateContent", "countTokens"]
                },
                {
                  "name": "models/text-embedding-004",
                  "displayName": "Embedding 004",
                  "supportedGenerationMethods": ["embedContent"]
                },
                {
                  "name": "models/gemini-2.0-flash",
                  "displayName": "Gemini 2.0 Flash",
                  "supportedGenerationMethods": ["generateContent"]
                },
                {
                  "name": "models/gemini-embedding-001",
                  "displayName": "Gemini Embedding",
                  "supportedGenerationMethods": ["embedContent"]
                }
              ]
            }
        """.trimIndent()

        val models = GeminiResponseParser.parseAvailableModelsResponse(json)
        assertEquals(2, models.size)
        assertEquals("gemini-2.5-flash", models[0].modelId)
        assertEquals("Gemini 2.5 Flash", models[0].displayName)
        assertEquals("gemini-2.0-flash", models[1].modelId)
    }

    @Test
    fun `gemini parser reports non-stop finishReason when text and toolCalls are empty`() {
        val json = """
            {
              "candidates": [
                {
                  "content": { "role": "model" },
                  "finishReason": "MAX_TOKENS"
                }
              ]
            }
        """.trimIndent()

        val parsed = GeminiResponseParser.parseGenerateContentResponse(json)
        assertTrue(parsed.errorMessage?.contains("MAX_TOKENS") == true)
    }
}
