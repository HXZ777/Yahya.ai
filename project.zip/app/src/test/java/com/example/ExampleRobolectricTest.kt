package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.network.CompanionProtocol
import com.example.data.network.InboundFrame
import com.example.data.network.QrCodeUtils
import com.example.data.preferences.PairingPayloadCodec
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Yahya Assistant - Companion", appName)
    }

    @Test
    fun `companion protocol signs and verifies command frames`() {
        val secret = "super-secret-key-123"
        val payload = JSONObject().apply {
            put("commandId", "cmd-42")
            put("action", "open_url")
            put("url", "https://example.com")
        }
        val envelope = CompanionProtocol.buildSignedEnvelope(
            type = "command",
            deviceId = "rn11p-test",
            secret = secret,
            payload = payload,
        )

        val validFrame = CompanionProtocol.parseInboundFrame(envelope, secret)
        assertTrue(validFrame is InboundFrame.CommandFrame)

        val tamperedFrame = CompanionProtocol.parseInboundFrame(envelope, "wrong-secret")
        assertTrue(tamperedFrame is InboundFrame.AuthRejected)
    }

    @Test
    fun `pairing payload codec round-trips and generates qr bitmap`() {
        val rawUri = "yahya://pair?host=192.168.1.40&port=8765&code=482910&secret=abc123&name=BrainPhone"
        val parsed = PairingPayloadCodec.parseBrainPayload(rawUri)
        assertNotNull(parsed)
        assertEquals("192.168.1.40", parsed?.host)
        assertEquals(8765, parsed?.port)
        assertEquals("482910", parsed?.pairingCode)
        assertEquals("abc123", parsed?.secret)

        val qr = QrCodeUtils.generateQrBitmap(rawUri, 128)
        assertNotNull(qr)
        assertEquals(128, qr?.width)
    }
}
