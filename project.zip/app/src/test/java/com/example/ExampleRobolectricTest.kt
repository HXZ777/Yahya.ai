package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.core.app.ApplicationProvider
import com.example.audio.VrAudioEngine
import com.example.ui.i18n.ArabicStrings
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.VrSettingsScreen
import com.example.ui.theme.VrSupermarketTheme
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.Aabb
import com.example.vr.engine.GameSimulationController
import com.example.vr.engine.GlMath
import com.example.vr.input.XboxControllerManager
import com.example.vr.input.XboxControllerSnapshot
import com.example.vr.model.AllSettingsState
import com.example.vr.model.VrSettingsState
import com.example.vr.model.WorldType
import com.example.vr.world.SupermarketWorldBuilder
import com.example.vr.world.WorldCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app name matches VR Supermarket`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("VR Supermarket", context.getString(R.string.app_name))
    }

    @Test
    fun `ray AABB intersection detects shelf product accurately`() {
        val box = Aabb(-0.25f, 1.0f, -0.25f, 0.25f, 1.5f, 0.25f)
        val hit = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 0f, 0f, -1f, box, 5.0f)
        assertNotNull(hit)
        assertEquals(2.75f, hit!!, 0.05f)
    }

    @Test
    fun `supermarket world builder creates all departments products and NPCs`() {
        val scene = SupermarketWorldBuilder.buildWorld(WorldType.GRAND_SUPERMARKET)
        assertTrue(scene.products.size >= 20)
        assertTrue(scene.npcs.size >= 5)
        assertTrue(scene.solidColliders.isNotEmpty())
        assertEquals(10, WorldCatalog.builtInWorlds.size)
    }

    @Test
    fun `shopping and checkout payment deducts wallet and creates receipt`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val controller = GameSimulationController(
            headTracker = HeadTracker(context),
            xboxManager = XboxControllerManager(),
            audioEngine = VrAudioEngine(),
            onAutoSave = {}
        )
        controller.loadWorld("world_grand_supermarket", WorldType.GRAND_SUPERMARKET, null)
        val apple = controller.worldData.products.first()
        controller.performPrimaryInteraction(explicitProduct = apple)
        assertEquals(apple.id, controller.snapshot.value.heldProduct?.id)

        controller.putHeldItemInCartOrBasket()
        assertEquals(1, controller.snapshot.value.cartItems.size)

        controller.moveAllCartItemsToBelt()
        assertEquals(1, controller.snapshot.value.beltItems.size)

        val initialWallet = controller.snapshot.value.walletBalance
        controller.payAtCheckout(byCard = true)
        assertNotNull(controller.snapshot.value.receipt)
        assertTrue(controller.snapshot.value.walletBalance < initialWallet)
        assertTrue(controller.snapshot.value.hasPaidBag)
    }

    @Test
    fun `main menu displays Arabic Play World Browser and VR Settings`() {
        composeRule.setContent {
            VrSupermarketTheme {
                MainMenuScreen(
                    settings = AllSettingsState(),
                    saveGame = null,
                    xbox = XboxControllerSnapshot(),
                    strings = ArabicStrings,
                    onPlayNew = {},
                    onContinue = {},
                    onOpenWorldBrowser = {},
                    onOpenVrSettings = {},
                    onOpenControls = {},
                    onOpenGraphics = {},
                    onToggleLanguage = {},
                    onExitApp = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("play_button").assertIsDisplayed()
        composeRule.onNodeWithTag("world_browser_button").assertIsDisplayed()
        composeRule.onNodeWithTag("vr_settings_button").assertIsDisplayed()
    }

    @Test
    fun `vr settings screen renders FOV presets 60 to 120 and test button`() {
        composeRule.setContent {
            VrSupermarketTheme {
                VrSettingsScreen(
                    vr = VrSettingsState(fovDegrees = 100f),
                    strings = ArabicStrings,
                    onUpdateVr = {},
                    onCalibrateHeadset = {},
                    onTestVrNow = {},
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("100°").assertIsDisplayed()
        composeRule.onNodeWithTag("fov_preset_60").assertIsDisplayed()
        composeRule.onNodeWithTag("fov_preset_120").assertIsDisplayed()
        composeRule.onNodeWithTag("test_vr_button").assertIsDisplayed()
    }
}
