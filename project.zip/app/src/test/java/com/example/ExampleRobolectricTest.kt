package com.example

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.data.telemetry.SystemTelemetryReader
import com.example.domain.model.DxvkStatus
import com.example.domain.model.OverlaySettings
import com.example.domain.model.StatType
import com.example.domain.model.SystemStatsSnapshot
import com.example.overlay.FloatingOverlayView
import com.example.ui.MainUiState
import com.example.ui.i18n.ArabicStrings
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.StatisticsTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app name matches Statistics`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Statistics", context.getString(R.string.app_name))
    }

    @Test
    fun `proc stat parser extracts total and idle jiffies accurately`() {
        val t1 = SystemTelemetryReader.parseProcStatLine("cpu  1000 50 300 8000 100 20 30 0 0 0")
        val t2 = SystemTelemetryReader.parseProcStatLine("cpu  1400 50 400 8450 100 20 30 0 0 0")
        assertNotNull(t1)
        assertNotNull(t2)
        val totalDelta = t2!!.total - t1!!.total // 950
        val idleDelta = t2.idle - t1.idle // 450
        assertEquals(950L, totalDelta)
        assertEquals(450L, idleDelta)
    }

    @Test
    fun `thermal normalization and power calculation handle real units and reject invalid values`() {
        assertEquals(34.2f, SystemTelemetryReader.normalizeThermalTemp(34200f)!!, 0.05f)
        assertEquals(38.5f, SystemTelemetryReader.normalizeThermalTemp(385f)!!, 0.05f)
        assertNull(SystemTelemetryReader.normalizeThermalTemp(-10f))

        // 4000mV * -1,075,000 uA = 4.3W
        val watts = SystemTelemetryReader.computePowerWatts(voltageMv = 4000, currentRaw = -1_075_000)
        assertNotNull(watts)
        assertEquals(4.3f, watts!!, 0.05f)

        // Invalid current returns null (displays N/A)
        assertNull(SystemTelemetryReader.computePowerWatts(voltageMv = 4000, currentRaw = Int.MIN_VALUE))
        assertNull(SystemTelemetryReader.computePowerWatts(voltageMv = 4000, currentRaw = 0))
    }

    @Test
    fun `floating overlay view displays only selected metrics without empty gaps`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val overlay = FloatingOverlayView(context) { _, _, _ -> }
        overlay.applySettings(
            OverlaySettings(
                enabledStats = setOf(StatType.CPU, StatType.RAM),
            ),
        )
        overlay.renderSnapshot(
            SystemStatsSnapshot(
                cpuPercent = 64,
                ramPercent = 78,
                dxvkStatus = DxvkStatus.NOT_DETECTED,
            ),
        )

        val pillContainer = overlay.getChildAt(0) as LinearLayout
        val visibleTexts = mutableListOf<String>()
        var visibleDividers = 0
        for (i in 0 until pillContainer.childCount) {
            val child = pillContainer.getChildAt(i)
            if (child.visibility == View.VISIBLE) {
                if (child is TextView) {
                    visibleTexts.add(child.text.toString())
                } else {
                    visibleDividers++
                }
            }
        }

        assertEquals(listOf("CPU 64%", "RAM 78%"), visibleTexts)
        assertEquals(1, visibleDividers)
    }

    @Test
    fun `home screen renders Arabic start and stop toggle states`() {
        composeRule.setContent {
            StatisticsTheme {
                HomeScreen(
                    uiState = MainUiState(isOverlayRunning = false),
                    strings = ArabicStrings,
                    contentPadding = PaddingValues(0.dp),
                    onToggleOverlay = {},
                    onRequestOverlayPermission = {},
                    onRequestNotificationPermission = {},
                    onOpenBatterySettings = {},
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("الإحصائيات").assertIsDisplayed()
        composeRule.onNodeWithText("تشغيل المستطيل العائم").assertIsDisplayed()
        composeRule.onNodeWithTag("toggle_overlay_button").assertIsDisplayed()
    }

    @Test
    fun `home screen shows stop button text when overlay is active`() {
        composeRule.setContent {
            StatisticsTheme {
                HomeScreen(
                    uiState = MainUiState(isOverlayRunning = true),
                    strings = ArabicStrings,
                    contentPadding = PaddingValues(0.dp),
                    onToggleOverlay = {},
                    onRequestOverlayPermission = {},
                    onRequestNotificationPermission = {},
                    onOpenBatterySettings = {},
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("إيقاف المستطيل العائم").assertIsDisplayed()
        assertTrue(true)
    }
}
