package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.ui.i18n.ArabicStrings
import com.example.ui.i18n.EnglishStrings
import com.example.ui.screens.AppInfoScreen
import com.example.ui.screens.ControlsScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.SensorDiagnosticsScreen
import com.example.ui.screens.VrGameplayScreen
import com.example.ui.screens.VrSettingsScreen
import com.example.ui.theme.MineVrTheme
import com.example.vr.camera.HeadTracker
import com.example.vr.capture.MinecraftIntegrationManager
import com.example.vr.engine.MineVrRenderer
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.input.PlayStationControllerSnapshot
import com.example.vr.model.AccessibilityBridgeSnapshot
import com.example.vr.model.AppLanguage
import com.example.vr.model.ControllerKind
import com.example.vr.model.ControllerTransport
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.HeadTrackingSnapshot
import com.example.vr.model.MineVrSettingsState
import com.example.vr.model.MinecraftAppStatus
import com.example.vr.model.ProjectionCaptureState
import com.example.vr.model.VrRenderMode
import com.example.vr.model.VrSettingsState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app name matches VR Minecraft`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("VR Minecraft", context.getString(R.string.app_name))
    }

    @Test
    fun `HeadTracker calibration and recenter zero out calibrated yaw cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tracker = HeadTracker(context)
        tracker.applyConfig(horizonLock = true, headSensitivity = 1.0f, headSmoothing = 0.0f)

        tracker.applyFilteredOrientationSample(targetYaw = 45f, targetPitch = 10f, targetRoll = 5f)
        assertEquals(0f, tracker.getCalibratedYawDeg(), 0.5f)
        assertEquals(0f, tracker.rollDeg, 0.01f)

        tracker.applyFilteredOrientationSample(targetYaw = 75f, targetPitch = 20f, targetRoll = 5f)
        assertTrue(tracker.getCalibratedYawDeg() > 5f)

        tracker.resetToCenter()
        assertEquals(0f, tracker.getCalibratedYawDeg(), 0.5f)
    }

    @Test
    fun `Minecraft integration gracefully reports uninstalled on clean Robolectric context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val status = MinecraftIntegrationManager.inspectInstallation(context)
        assertFalse(status.isInstalled)
    }

    @Test
    fun `MainMenuScreen displays START VR, status indicators, and all 4 sub-screen tiles`() {
        composeRule.setContent {
            MineVrTheme {
                MainMenuScreen(
                    settings = MineVrSettingsState(language = AppLanguage.ARABIC),
                    headState = HeadTrackingSnapshot(isGyroSupported = true, activeSensorName = "Game Rotation Vector"),
                    controllerState = PlayStationControllerSnapshot(
                        isConnected = true,
                        deviceName = "DualSense Wireless Controller",
                        controllerKind = ControllerKind.DUALSENSE,
                        transport = ControllerTransport.BLUETOOTH
                    ),
                    minecraftStatus = MinecraftAppStatus(isInstalled = true, versionName = "1.21.0"),
                    strings = ArabicStrings,
                    onStartVr = {},
                    onOpenHeadsetSettings = {},
                    onOpenControllerSettings = {},
                    onOpenSensorDiagnostics = {},
                    onOpenAppInfo = {},
                    onSelectRenderMode = {},
                    onLaunchMinecraft = {},
                    onToggleLanguage = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_vr_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("headset_settings_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("controller_settings_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("sensor_diagnostics_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("app_info_button").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `VrSettingsScreen displays FOV presets, calibration buttons, and live preview`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val headTracker = HeadTracker(context)
        val ctrlMgr = PlayStationControllerManager(context)
        composeRule.setContent {
            MineVrTheme {
                VrSettingsScreen(
                    vr = VrSettingsState(fovDegrees = 100f),
                    headState = HeadTrackingSnapshot(isGyroSupported = true),
                    accessibilityState = AccessibilityBridgeSnapshot(),
                    headTracker = headTracker,
                    controllerManager = ctrlMgr,
                    strings = EnglishStrings,
                    onSaveVr = {},
                    onCalibrateForward = {},
                    onRecenter = {},
                    onResetDefaults = {},
                    onTestSplitScreen = {},
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("100° · 63mm").assertIsDisplayed()
        composeRule.onNodeWithTag("calibrate_head_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("test_vr_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("fov_preset_60").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("fov_preset_120").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `ControlsScreen renders PlayStation DualSense connection and remapping rows`() {
        composeRule.setContent {
            MineVrTheme {
                ControlsScreen(
                    controls = ControlsSettingsState(),
                    controller = PlayStationControllerSnapshot(
                        isConnected = true,
                        deviceName = "DualSense Wireless Controller",
                        controllerKind = ControllerKind.DUALSENSE,
                        transport = ControllerTransport.BLUETOOTH,
                        lastResponseLatencyMs = 3L
                    ),
                    language = AppLanguage.ENGLISH,
                    strings = EnglishStrings,
                    onRefreshDevices = {},
                    onSaveControls = {},
                    onResetDefaults = {},
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Controller Type: PlayStation 5 DualSense").assertIsDisplayed()
        composeRule.onNodeWithTag("remap_btn_CROSS").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("save_controls_button").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `SensorDiagnosticsScreen shows missing sensor warning cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val headTracker = HeadTracker(context)
        composeRule.setContent {
            MineVrTheme {
                SensorDiagnosticsScreen(
                    headState = HeadTrackingSnapshot(isGyroSupported = false, activeSensorName = "Unavailable"),
                    accessibilityState = AccessibilityBridgeSnapshot(),
                    headTracker = headTracker,
                    strings = EnglishStrings,
                    onCalibrateForward = {},
                    onRecenter = {},
                    onTestAccessibilityLook = { false },
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText(EnglishStrings.sensorMissingWarning).assertIsDisplayed()
    }

    @Test
    fun `AppInfoScreen displays technical feasibility categories cleanly`() {
        composeRule.setContent {
            MineVrTheme {
                AppInfoScreen(
                    language = AppLanguage.ENGLISH,
                    strings = EnglishStrings,
                    onBack = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText(EnglishStrings.feasibilityFeasibleNow).performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText(EnglishStrings.feasibilityNeedsGameMod).performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `VrGameplayScreen shows minimal Recenter Pause Exit HUD and handles exit`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val headTracker = HeadTracker(context)
        val ctrlMgr = PlayStationControllerManager(context)
        val renderer = MineVrRenderer(context, headTracker, ctrlMgr)
        var exited = false
        var recentered = false
        composeRule.setContent {
            MineVrTheme {
                VrGameplayScreen(
                    settings = MineVrSettingsState(preferredRenderMode = VrRenderMode.STEREO_VOXEL_SANDBOX),
                    projectionState = ProjectionCaptureState(),
                    isPaused = false,
                    renderer = renderer,
                    strings = EnglishStrings,
                    onStartSensors = {},
                    onStopSensors = {},
                    onRecenterHead = { recentered = true },
                    onTogglePause = {},
                    onStartProjection = { _: Int, _: Intent -> },
                    onStopProjection = {},
                    onSwitchTo3dTest = {},
                    onLaunchMinecraftSplit = {},
                    onExitToMenu = { exited = true }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("hud_recenter_button").assertIsDisplayed().performClick()
        composeRule.onNodeWithTag("hud_pause_button").assertIsDisplayed()
        composeRule.onNodeWithTag("hud_exit_button").assertIsDisplayed().performClick()
        assertTrue(recentered)
        assertTrue(exited)
    }
}
