package com.example

import android.content.Context
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.data.inspector.AndroidProjectInspector
import com.example.data.toolchain.ToolchainEnvironmentProbe
import com.example.data.workspace.SandboxWorkspaceManager
import com.example.domain.model.BuildEngineSettings
import com.example.domain.model.ProjectType
import com.example.ui.MainUiState
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.ZipToApkTheme
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app name matches ZIP to APK`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("ZIP to APK", context.getString(R.string.app_name))
        assertEquals("Convert ZIP to APK", context.getString(R.string.home_headline))
    }

    @Test
    fun `sandbox rejects zip-slip path traversal entries`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = SandboxWorkspaceManager(context)
        val maliciousZip = File(context.cacheDir, "malicious_traversal.zip")
        ZipOutputStream(FileOutputStream(maliciousZip)).use { zos ->
            zos.putNextEntry(ZipEntry("../../evil.txt"))
            zos.write("pwn".toByteArray())
            zos.closeEntry()
        }

        val result = manager.extractZipSafely(maliciousZip)
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("Zip-Slip") == true)
        maliciousZip.delete()
    }

    @Test
    fun `project inspector detects android gradle project metadata accurately`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = SandboxWorkspaceManager(context)
        val projectZip = File(context.cacheDir, "sample_android_app.zip")

        ZipOutputStream(FileOutputStream(projectZip)).use { zos ->
            zos.putNextEntry(ZipEntry("DemoApp/settings.gradle.kts"))
            zos.write(
                """
                rootProject.name = "DemoApp"
                include(":app")
                """.trimIndent().toByteArray(),
            )
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("DemoApp/gradle/wrapper/gradle-wrapper.properties"))
            zos.write(
                "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip".toByteArray(),
            )
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("DemoApp/build.gradle.kts"))
            zos.write(
                """
                plugins {
                    id("com.android.application") version "8.7.2" apply false
                    id("org.jetbrains.kotlin.android") version "2.1.0" apply false
                }
                """.trimIndent().toByteArray(),
            )
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("DemoApp/app/build.gradle.kts"))
            zos.write(
                """
                android {
                    namespace = "com.demo.app"
                    compileSdk = 35
                    defaultConfig {
                        applicationId = "com.demo.app"
                        minSdk = 24
                        targetSdk = 35
                        versionCode = 3
                        versionName = "1.2.0"
                    }
                    compileOptions {
                        sourceCompatibility = JavaVersion.VERSION_17
                    }
                }
                """.trimIndent().toByteArray(),
            )
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("DemoApp/app/src/main/AndroidManifest.xml"))
            zos.write(
                """<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="DemoApp"/></manifest>""".toByteArray(),
            )
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("DemoApp/app/src/main/java/com/demo/app/MainActivity.kt"))
            zos.write("package com.demo.app\nclass MainActivity".toByteArray())
            zos.closeEntry()
        }

        val extracted = manager.extractZipSafely(projectZip).getOrThrow()
        val inspection = AndroidProjectInspector().inspectExtractedProject("test-ws", extracted)

        assertTrue(inspection.isValidAndroidProject)
        assertEquals("DemoApp", inspection.projectName)
        assertEquals(ProjectType.ANDROID_APP_KOTLIN, inspection.projectType)
        assertEquals("com.demo.app", inspection.applicationId)
        assertEquals("8.11.1", inspection.gradleVersion)
        assertEquals("8.7.2", inspection.agpVersion)
        assertEquals("2.1.0", inspection.kotlinVersion)
        assertEquals("17", inspection.javaCompatibility)
        assertEquals("35", inspection.compileSdk)
        assertEquals(1, inspection.kotlinFileCount)

        projectZip.delete()
        extracted.parentFile?.deleteRecursively()
    }

    @Test
    fun `toolchain probe reports missing android sdk honestly on standard device`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val probe = ToolchainEnvironmentProbe(context).probeDeviceEnvironment()
        assertFalse(probe.localToolchainReady)
        assertTrue(probe.missingToolchainItems.isNotEmpty())
    }

    @Test
    fun `home screen renders core branding and select zip button`() {
        composeRule.setContent {
            ZipToApkTheme {
                HomeScreen(
                    uiState = MainUiState(),
                    settings = BuildEngineSettings(),
                    contentPadding = PaddingValues(0.dp),
                    onSelectZipClick = {},
                    onBuildApkClick = {},
                    onClearProject = {},
                    onCleanCache = {},
                    onOpenEngineSettings = {},
                )
            }
        }

        composeRule.onNodeWithText("ZIP to APK").assertIsDisplayed()
        composeRule.onNodeWithText("Convert ZIP to APK").assertIsDisplayed()
        composeRule.onNodeWithTag("select_zip_button").assertIsDisplayed()
        composeRule.onNodeWithTag("open_engine_settings_button").assertIsDisplayed()
    }
}
