package com.example

import com.example.vr.engine.Aabb
import com.example.vr.engine.GlMath
import com.example.vr.model.WorldType
import com.example.vr.world.SupermarketWorldBuilder
import com.example.vr.world.WorldCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `ray AABB intersection detects shelf product accurately`() {
        val box = Aabb(-0.25f, 1.0f, -0.25f, 0.25f, 1.5f, 0.25f)
        val hit = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 0f, 0f, -1f, box, 5.0f)
        assertNotNull(hit)
        assertEquals(2.75f, hit!!, 0.05f)

        val miss = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 1f, 0f, 0f, box, 5.0f)
        assertNull(miss)
    }

    @Test
    fun `sliding collision pushes player cleanly outside shelf collider`() {
        val shelf = listOf(Aabb(-1f, 0f, -1f, 1f, 2f, 1f))
        val (nx, nz) = GlMath.resolveCircleAabbXZ(0.8f, 0f, 0.42f, shelf)
        assertTrue(nx >= 1.41f)
        assertEquals(0f, nz, 0.01f)
    }

    @Test
    fun `supermarket world builder creates all departments products and NPCs`() {
        val scene = SupermarketWorldBuilder.buildWorld(WorldType.GRAND_SUPERMARKET)
        assertTrue(scene.products.size >= 20)
        assertTrue(scene.npcs.size >= 5)
        assertTrue(scene.solidColliders.isNotEmpty())
        assertEquals(10, WorldCatalog.builtInWorlds.size)
        assertEquals(7, WorldCatalog.openSources.size)
    }
}
