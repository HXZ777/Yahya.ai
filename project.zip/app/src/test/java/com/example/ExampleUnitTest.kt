package com.example

import com.example.vr.engine.Aabb
import com.example.vr.engine.GlMath
import com.example.vr.engine.VrBoxOptics
import com.example.vr.model.VrSettingsState
import com.example.vr.model.WorldType
import com.example.vr.world.SupermarketWorldBuilder
import com.example.vr.world.WorldCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `ray AABB intersection detects shelf product accurately`() {
        val box = Aabb(-0.25f, 1.0f, -0.25f, 0.25f, 1.5f, 0.25f)
        val hit = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 0f, 0f, -1f, box, 5.0f)
        assertNotNull(hit)
        assertEquals(2.75f, hit!!, 0.05f)

        val miss = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 1f, 0f, 0f, box, 5.0f)
        assertNull(miss)
    }

    @Test
    fun `sliding collision pushes player cleanly outside shelf collider`() {
        val shelf = listOf(Aabb(-1f, 0f, -1f, 1f, 2f, 1f))
        val (nx, nz) = GlMath.resolveCircleAabbXZ(0.8f, 0f, 0.42f, shelf)
        assertTrue(nx >= 1.41f)
        assertEquals(0f, nz, 0.01f)
    }

    @Test
    fun `supermarket world builder creates all departments products and NPCs`() {
        val scene = SupermarketWorldBuilder.buildWorld(WorldType.GRAND_SUPERMARKET)
        assertTrue(scene.products.size >= 20)
        assertTrue(scene.npcs.size >= 5)
        assertTrue(scene.solidColliders.isNotEmpty())
        assertEquals(10, WorldCatalog.builtInWorlds.size)
        assertEquals(7, WorldCatalog.openSources.size)
    }

    @Test
    fun `fixed VR Box optics keeps 63mm eye center spacing on large wide phones without overlap`() {
        // 6.7-inch 20:9 phone at ~393 DPI in landscape (2400 x 1080)
        val vr = VrSettingsState(ipdMm = 63f, fixedVrBoxMode = true, sideBySideEnabled = true)
        val layout = VrBoxOptics.computeLayout(
            surfaceWidthPx = 2400,
            surfaceHeightPx = 1080,
            xdpi = 393f,
            ydpi = 393f,
            densityDpi = 420,
            vr = vr
        )
        val leftCenter = layout.leftEye.x + layout.leftEye.width * 0.5f
        val rightCenter = layout.rightEye.x + layout.rightEye.width * 0.5f
        val centerDistMm = (rightCenter - leftCenter) / (393f / 25.4f)

        assertEquals(63f, centerDistMm, 1.5f)
        assertTrue(layout.leftEye.x + layout.leftEye.width <= layout.rightEye.x)
        assertTrue(layout.leftEye.x > 0)
        assertTrue(layout.rightEye.x + layout.rightEye.width < 2400)
    }

    @Test
    fun `GlMath forwardVector matches negative yaw right turn convention`() {
        val fwdStraight = GlMath.forwardVector(0f, 0f)
        assertEquals(0f, fwdStraight[0], 0.001f)
        assertEquals(-1f, fwdStraight[2], 0.001f)

        // Turning head right -> yaw = -90 deg -> looks toward +X
        val fwdRight = GlMath.forwardVector(-90f, 0f)
        assertEquals(1f, fwdRight[0], 0.001f)
        assertEquals(0f, fwdRight[2], 0.001f)
    }

    @Test
    fun `world importer allows up to 1 GB file limit`() {
        assertEquals(1024L * 1024L * 1024L, com.example.vr.world.WorldAssetImporter.MAX_FILE_BYTES)
    }
}
