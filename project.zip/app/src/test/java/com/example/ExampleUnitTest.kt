package com.example

import android.view.KeyEvent
import com.example.vr.bridge.HeadLookBridgeMath
import com.example.vr.camera.HeadTracker
import com.example.vr.engine.VrBoxOptics
import com.example.vr.input.PlayStationControllerManager
import com.example.vr.model.ControllerKind
import com.example.vr.model.ControlsSettingsState
import com.example.vr.model.GameAction
import com.example.vr.model.PsButton
import com.example.vr.model.PsButtonMapping
import com.example.vr.model.VrSettingsState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `VR Box optics splits screen cleanly for left and right eyes with IPD spacing`() {
        val vr = VrSettingsState(
            ipdMm = 64f,
            fixedVrBoxMode = true,
            sideBySideEnabled = true,
            vrScale = 1.0f
        )
        val layout = VrBoxOptics.computeLayout(
            surfaceWidthPx = 2400,
            surfaceHeightPx = 1080,
            xdpi = 395f,
            ydpi = 395f,
            densityDpi = 420,
            vr = vr
        )
        val leftCenter = layout.leftEye.x + layout.leftEye.width * 0.5f
        val rightCenter = layout.rightEye.x + layout.rightEye.width * 0.5f
        val centerDistMm = (rightCenter - leftCenter) / (395f / 25.4f)

        assertEquals(64f, centerDistMm, 1.5f)
        assertTrue(layout.leftEye.x + layout.leftEye.width <= layout.rightEye.x)
        assertTrue(layout.leftEye.width > 100)
        assertTrue(layout.rightEye.width > 100)
    }

    @Test
    fun `VR Box optics respects alignment offsets and non-split mode`() {
        val single = VrBoxOptics.computeLayout(
            surfaceWidthPx = 1920,
            surfaceHeightPx = 1080,
            xdpi = 400f,
            ydpi = 400f,
            densityDpi = 400,
            vr = VrSettingsState(sideBySideEnabled = false)
        )
        assertEquals(1920, single.leftEye.width)
        assertEquals(single.leftEye, single.rightEye)

        val shifted = VrBoxOptics.computeLayout(
            surfaceWidthPx = 2400,
            surfaceHeightPx = 1080,
            xdpi = 400f,
            ydpi = 400f,
            densityDpi = 400,
            vr = VrSettingsState(alignXOffset = 0.08f, alignYOffset = -0.05f, vrScale = 0.85f)
        )
        assertTrue(shifted.leftEye.y < (1080 - shifted.leftEye.height) / 2)
    }

    @Test
    fun `PlayStation controller manager detects DualShock 4 and DualSense by Sony VID PID`() {
        assertEquals(
            ControllerKind.DUALSHOCK_4,
            PlayStationControllerManager.classifyController(0x054C, 0x09CC, "Wireless Controller")
        )
        assertEquals(
            ControllerKind.DUALSENSE,
            PlayStationControllerManager.classifyController(0x054C, 0x0CE6, "DualSense Wireless Controller")
        )
        assertEquals(
            ControllerKind.XBOX_OR_GENERIC,
            PlayStationControllerManager.classifyController(0x045E, 0x0B13, "Xbox Wireless Controller")
        )
    }

    @Test
    fun `PlayStation controller button press release and custom remapping dispatch expected actions`() {
        val mgr = PlayStationControllerManager()
        val customMapping = PsButtonMapping().withAction(PsButton.CROSS, GameAction.BREAK_ATTACK)
        mgr.updateSettings(ControlsSettingsState(mapping = customMapping))

        val dispatched = mutableListOf<GameAction>()
        mgr.addActionListener { dispatched.add(it) }

        assertTrue(mgr.processGamepadKeyDown(KeyEvent.KEYCODE_BUTTON_A, kind = ControllerKind.DUALSENSE))
        assertTrue(PsButton.CROSS in mgr.snapshot.value.pressedButtons)
        assertEquals(GameAction.BREAK_ATTACK, dispatched.lastOrNull())

        assertTrue(mgr.processGamepadKeyUp(KeyEvent.KEYCODE_BUTTON_A))
        assertFalse(PsButton.CROSS in mgr.snapshot.value.pressedButtons)

        assertTrue(mgr.processGamepadKeyDown(KeyEvent.KEYCODE_BUTTON_START, kind = ControllerKind.DUALSHOCK_4))
        assertEquals(GameAction.PAUSE_MENU, dispatched.lastOrNull())
    }

    @Test
    fun `HeadTracker angle wrapping and deadzone math behave accurately`() {
        assertEquals(-170f, HeadTracker.wrapAngleDeg(190f), 0.01f)
        assertEquals(170f, HeadTracker.wrapAngleDeg(-190f), 0.01f)
        assertEquals(0f, PlayStationControllerManager.applyDeadzone(0.10f, 0.14f), 0.001f)
        assertTrue(PlayStationControllerManager.applyDeadzone(0.80f, 0.14f) > 0.70f)
    }

    @Test
    fun `HeadLookBridgeMath converts head yaw and pitch deltas into right-half look swipes`() {
        val ignoreMicroJitter = HeadLookBridgeMath.computeLookSwipe(
            screenWidthPx = 2400,
            screenHeightPx = 1080,
            deltaYawDeg = 0.01f,
            deltaPitchDeg = 0.01f,
            sensitivity = 1.0f,
            invertY = false
        )
        assertNull(ignoreMicroJitter)

        val swipeRight = HeadLookBridgeMath.computeLookSwipe(
            screenWidthPx = 2400,
            screenHeightPx = 1080,
            deltaYawDeg = -10f,
            deltaPitchDeg = 4f,
            sensitivity = 1.2f,
            invertY = false
        )
        assertNotNull(swipeRight)
        assertTrue(swipeRight!!.startX >= 1200f)
        assertTrue(swipeRight.endX > swipeRight.startX)
        assertTrue(swipeRight.endY < swipeRight.startY)

        // Continuous step preserves finger position without lifting until boundary is hit
        val contStep = HeadLookBridgeMath.computeContinuousStep(
            screenWidthPx = 2400,
            screenHeightPx = 1080,
            curX = swipeRight.endX,
            curY = swipeRight.endY,
            deltaYawDeg = -2f,
            deltaPitchDeg = 0f,
            sensitivity = 1.0f,
            invertY = false
        )
        assertNotNull(contStep)
        assertFalse(contStep!!.needsReanchor)
        assertEquals(swipeRight.endX, contStep.startX, 0.01f)

        val edgeStep = HeadLookBridgeMath.computeContinuousStep(
            screenWidthPx = 2400,
            screenHeightPx = 1080,
            curX = 2270f,
            curY = 540f,
            deltaYawDeg = -15f,
            deltaPitchDeg = 0f,
            sensitivity = 1.5f,
            invertY = false
        )
        assertNotNull(edgeStep)
        assertTrue(edgeStep!!.needsReanchor)
    }

    @Test
    fun `VrProjectionService scales capture dimensions proportionally with even bounds`() {
        val (w, h) = com.example.vr.capture.VrProjectionService.scaleProportionalEven(2400, 1080, maxDimension = 1920)
        assertEquals(1920, w)
        assertEquals(864, h)
        assertEquals(0, w % 2)
        assertEquals(0, h % 2)
    }
}
