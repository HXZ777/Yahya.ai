package com.example

import android.view.KeyEvent
import com.example.vr.engine.Aabb
import com.example.vr.engine.GlMath
import com.example.vr.engine.VrBoxOptics
import com.example.vr.input.XboxControllerManager
import com.example.vr.model.AlphaMode
import com.example.vr.model.FlyToggleButton
import com.example.vr.model.ImportedMeshData
import com.example.vr.model.PbrMaterialSpec
import com.example.vr.model.SpawnPointEntry
import com.example.vr.model.Transform3D
import com.example.vr.model.VrSettingsState
import com.example.vr.model.WorldLightingConfig
import com.example.vr.model.WorldNodeEntry
import com.example.vr.model.WorldObjectCategory
import com.example.vr.model.WorldProjectState
import com.example.vr.model.WorldType
import com.example.vr.world.FbxAndObjParser
import com.example.vr.world.MeshDiagnosticsHelper
import com.example.vr.world.SupermarketWorldBuilder
import com.example.vr.world.WorldAssetImporter
import com.example.vr.world.WorldCatalog
import com.example.vr.world.WorldEditorManager
import com.example.vr.world.WorldProjectRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.io.path.createTempDirectory

class ExampleUnitTest {

    @Test
    fun `ray AABB intersection detects shelf product accurately`() {
        val box = Aabb(-0.25f, 1.0f, -0.25f, 0.25f, 1.5f, 0.25f)
        val hit = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 0f, 0f, -1f, box, 5.0f)
        assertNotNull(hit)
        assertEquals(2.75f, hit!!, 0.05f)

        val miss = GlMath.rayIntersectsAabb(0f, 1.25f, 3.0f, 1f, 0f, 0f, box, 5.0f)
        assertNull(miss)
    }

    @Test
    fun `sliding collision pushes player cleanly outside shelf collider`() {
        val shelf = listOf(Aabb(-1f, 0f, -1f, 1f, 2f, 1f))
        val (nx, nz) = GlMath.resolveCircleAabbXZ(0.8f, 0f, 0.42f, shelf)
        assertTrue(nx >= 1.41f)
        assertEquals(0f, nz, 0.01f)
    }

    @Test
    fun `supermarket world builder creates all departments products and NPCs`() {
        val scene = SupermarketWorldBuilder.buildWorld(WorldType.GRAND_SUPERMARKET)
        assertTrue(scene.products.size >= 20)
        assertTrue(scene.npcs.size >= 5)
        assertTrue(scene.solidColliders.isNotEmpty())
        assertEquals(10, WorldCatalog.builtInWorlds.size)
        assertEquals(7, WorldCatalog.openSources.size)
    }

    @Test
    fun `fixed VR Box optics keeps 63mm eye center spacing on large wide phones without overlap`() {
        val vr = VrSettingsState(ipdMm = 63f, fixedVrBoxMode = true, sideBySideEnabled = true)
        val layout = VrBoxOptics.computeLayout(
            surfaceWidthPx = 2400,
            surfaceHeightPx = 1080,
            xdpi = 393f,
            ydpi = 393f,
            densityDpi = 420,
            vr = vr
        )
        val leftCenter = layout.leftEye.x + layout.leftEye.width * 0.5f
        val rightCenter = layout.rightEye.x + layout.rightEye.width * 0.5f
        val centerDistMm = (rightCenter - leftCenter) / (393f / 25.4f)

        assertEquals(63f, centerDistMm, 1.5f)
        assertTrue(layout.leftEye.x + layout.leftEye.width <= layout.rightEye.x)
        assertTrue(layout.leftEye.x > 0)
        assertTrue(layout.rightEye.x + layout.rightEye.width < 2400)
    }

    @Test
    fun `GlMath forwardVector matches negative yaw right turn convention`() {
        val fwdStraight = GlMath.forwardVector(0f, 0f)
        assertEquals(0f, fwdStraight[0], 0.001f)
        assertEquals(-1f, fwdStraight[2], 0.001f)

        val fwdRight = GlMath.forwardVector(-90f, 0f)
        assertEquals(1f, fwdRight[0], 0.001f)
        assertEquals(0f, fwdRight[2], 0.001f)
    }

    @Test
    fun `world importer allows up to 1 GB file limit`() {
        assertEquals(1024L * 1024L * 1024L, WorldAssetImporter.MAX_FILE_BYTES)
    }

    @Test
    fun `custom imported world builds standalone scene without supermarket products or NPCs`() {
        val customMesh = ImportedMeshData(
            name = "custom_city.glb",
            positions = floatArrayOf(0f, 0f, 0f, 10f, 0f, 0f, 0f, 5f, -10f),
            normals = floatArrayOf(0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f),
            vertexCount = 3,
            boundsMin = floatArrayOf(-5f, 0f, -10f),
            boundsMax = floatArrayOf(5f, 5f, 0f)
        )
        val scene = SupermarketWorldBuilder.buildCustomImportedWorld(customMesh)
        assertEquals(WorldType.CUSTOM_IMPORTED, scene.worldType)
        assertTrue(scene.products.isEmpty())
        assertTrue(scene.npcs.isEmpty())
    }

    @Test
    fun `resolveSafeSpawnPoint pushes player outside solid walls and clamps ground Y`() {
        val wall = listOf(Aabb(-2f, 0f, -2f, 2f, 4f, 2f))
        val (sx, sy, sz) = SupermarketWorldBuilder.resolveSafeSpawnPoint(0f, -3.5f, 0.2f, wall)
        assertTrue("Expected ground clamp Y >= 0, got $sy", sy >= 0f)
        val insideWall = sx > -2f && sx < 2f && sz > -2f && sz < 2f
        assertFalse("Spawn must not stay inside solid wall: ($sx, $sz)", insideWall)
    }

    @Test
    fun `OBJ and MTL parser extracts materials colors and flags missing textures cleanly`() {
        val tmpDir = createTempDirectory("obj_test").toFile()
        try {
            val mtlFile = File(tmpDir, "scene.mtl")
            mtlFile.writeText(
                """
                newmtl LeafGreen
                Kd 0.15 0.65 0.22
                d 0.9
                map_Kd missing_leaf.png
                """.trimIndent()
            )
            val objFile = File(tmpDir, "tree.obj")
            objFile.writeText(
                """
                mtllib scene.mtl
                o OakTree
                usemtl LeafGreen
                v 0.0 0.0 0.0
                v 2.0 0.0 0.0
                v 1.0 3.0 0.0
                vt 0.0 0.0
                vt 1.0 0.0
                vt 0.5 1.0
                f 1/1 2/2 3/3
                """.trimIndent()
            )
            val parsed = FbxAndObjParser.parseObjFile(objFile, tmpDir, tmpDir, 1024, 500_000)
            assertNotNull(parsed)
            assertEquals(3, parsed!!.vertexCount)
            assertEquals(1, parsed.subMeshes.size)
            assertEquals(1, parsed.materials.size)
            val leafMat = parsed.materials.first()
            assertEquals("LeafGreen", leafMat.name)
            assertEquals("missing_leaf.png", leafMat.missingTextureName)
            assertTrue(parsed.diagnostics.missingTextures.any { it.contains("missing_leaf.png") })
        } finally {
            tmpDir.deleteRecursively()
        }
    }

    @Test
    fun `WorldEditorManager supports whole world, node transform, duplicate, undo redo, grouping and material edit`() {
        val manager = WorldEditorManager()
        val initialMat = PbrMaterialSpec(id = "mat_0", name = "Bark", baseColorArgb = 0xFF6B4423L)
        val node = WorldNodeEntry(
            id = "node_tree",
            name = "Oak_Tree",
            category = WorldObjectCategory.ENVIRONMENT,
            subMeshStartIdx = 0,
            subMeshEndIdx = 0
        )
        val proj = WorldProjectState(
            worldId = "custom_test",
            titleEn = "Test Park",
            titleAr = "حديقة",
            nodes = listOf(node),
            materials = listOf(initialMat),
            spawnPoints = listOf(SpawnPointEntry(id = "sp_1", name = "Gate", x = 0f, y = 0f, z = 8f, isPrimary = true))
        )
        manager.openProject(proj)

        // Move node + duplicate + undo + redo
        manager.applyTransformDelta(dx = 3.5f, dy = 1.0f)
        assertEquals(3.5f, manager.state.value.project!!.nodes.first().transform.posX, 0.001f)
        manager.duplicateSelectedNode()
        assertEquals(2, manager.state.value.project!!.nodes.size)
        manager.undo()
        assertEquals(1, manager.state.value.project!!.nodes.size)
        manager.redo()
        assertEquals(2, manager.state.value.project!!.nodes.size)

        // Whole world rotation 90 deg & uniform scale
        manager.selectWholeWorld()
        manager.rotateQuick(90f)
        manager.setWorldUniformScale(1.5f)
        assertEquals(90f, manager.state.value.project!!.worldTransform.rotY, 0.01f)
        assertEquals(1.5f, manager.state.value.project!!.worldTransform.scaleX, 0.01f)

        // Hierarchy rename + grouping
        manager.renameNode("node_tree", "Hero_Oak")
        manager.createGroupAndAssign("ForestGroup", listOf("node_tree"))
        assertTrue(manager.state.value.project!!.nodes.any { it.isGroup && it.name == "ForestGroup" })
        assertTrue(manager.state.value.project!!.nodes.any { it.name == "Hero_Oak" && it.parentId != null })

        // Material edit marks userModified without touching intact original flag
        manager.updateMaterial(initialMat.copy(metallic = 0.6f, roughness = 0.25f))
        val updatedMat = manager.state.value.project!!.materials.first()
        assertTrue(updatedMat.userModified)
        assertEquals(0.6f, updatedMat.metallic, 0.001f)
    }

    @Test
    fun `Xbox and PlayStation double-press Cross or A toggles Fly Mode and tracks Ascend Descend`() {
        val xbox = XboxControllerManager()
        xbox.updateMapping(com.example.vr.model.XboxButtonMapping(), FlyToggleButton.DOUBLE_A_CROSS)
        var flyCount = 0
        xbox.addFlyToggleListener { flyCount++ }

        xbox.processGamepadKeyDown(KeyEvent.KEYCODE_BUTTON_A, nowMs = 1000L)
        assertTrue(xbox.snapshot.value.isAscendHeld)
        xbox.processGamepadKeyUp(KeyEvent.KEYCODE_BUTTON_A)
        assertFalse(xbox.snapshot.value.isAscendHeld)
        assertEquals(0, flyCount)

        // Second press within 380ms window triggers Fly Mode toggle!
        xbox.processGamepadKeyDown(KeyEvent.KEYCODE_BUTTON_A, nowMs = 1220L)
        assertEquals(1, flyCount)

        // Hold B / Circle sets isDescendHeld
        xbox.processGamepadKeyDown(KeyEvent.KEYCODE_BUTTON_B, nowMs = 1500L)
        assertTrue(xbox.snapshot.value.isDescendHeld)
        xbox.processGamepadKeyUp(KeyEvent.KEYCODE_BUTTON_B)
        assertFalse(xbox.snapshot.value.isDescendHeld)
    }

    @Test
    fun `WorldProjectRepository JSON serialization preserves transforms, spawns, materials and lighting`() {
        val project = WorldProjectState(
            worldId = "w_123",
            titleEn = "Market",
            titleAr = "سوق",
            worldTransform = Transform3D(posY = 2.5f, rotY = 180f, scaleX = 1.25f, scaleY = 1.25f, scaleZ = 1.25f),
            materials = listOf(PbrMaterialSpec(id = "m1", name = "Glass", alpha = 0.45f, alphaMode = AlphaMode.BLEND)),
            lighting = WorldLightingConfig(directionalIntensity = 1.4f, fogDensity = 0.015f, exposure = 1.15f),
            collisionEnabled = false
        )
        val encoded = WorldProjectRepository.encodeProjectJson(project)
        val decoded = WorldProjectRepository.decodeProjectJson(encoded)
        assertNotNull(decoded)
        assertEquals(180f, decoded!!.worldTransform.rotY, 0.001f)
        assertEquals(0.45f, decoded.materials.first().alpha, 0.001f)
        assertEquals(AlphaMode.BLEND, decoded.materials.first().alphaMode)
        assertFalse(decoded.collisionEnabled)
        assertEquals(1.4f, decoded.lighting.directionalIntensity, 0.001f)
    }

    @Test
    fun `MeshDiagnosticsHelper normalizes extreme coordinates and computes clean report`() {
        val hugeTriangle = floatArrayOf(
            0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 1f, 1f, 1f,
            400f, 0f, 0f, 0f, 1f, 0f, 1f, 0f, 1f, 1f, 1f, 1f,
            0f, 400f, 0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f, 1f, 1f
        )
        val sub = com.example.vr.model.WorldSubMeshData(
            name = "GiantTower",
            nodeName = "GiantTower",
            materialIndex = 0,
            interleavedVertices = hugeTriangle,
            vertexCount = 3,
            boundsMin = floatArrayOf(0f, 0f, 0f),
            boundsMax = floatArrayOf(400f, 400f, 0f)
        )
        val result = MeshDiagnosticsHelper.auditAndNormalize(
            worldName = "huge.glb",
            rawSubMeshes = mutableListOf(sub),
            materials = listOf(PbrMaterialSpec(id = "m0", name = "Stone"))
        )
        assertNotNull(result)
        assertTrue(result!!.normalizationScale < 1f)
        assertTrue(result.diagnostics.abnormalScaleNotes.isNotEmpty())
        assertTrue(result.diagnostics.fixesApplied.isNotEmpty())
        assertEquals(WorldObjectCategory.ENVIRONMENT, MeshDiagnosticsHelper.classifyCategory("Oak_Tree_Leaves"))
        assertEquals(WorldObjectCategory.BUILDINGS, MeshDiagnosticsHelper.classifyCategory("Supermarket_Wall_01"))
    }
}
