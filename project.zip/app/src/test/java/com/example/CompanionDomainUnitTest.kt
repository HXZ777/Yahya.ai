package com.example

import com.example.data.security.ApiKeyVault
import com.example.domain.model.AssistantCommand
import com.example.domain.model.RiskLevel
import com.example.domain.model.ScrollDirection
import com.example.domain.policy.CommandSafetyPolicy
import com.example.domain.policy.SensitiveInputFilter
import com.example.domain.voice.ArabicWakeMatcher
import com.example.engine.YahyaCommandEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CompanionDomainUnitTest {

    @Test
    fun wakeMatcher_matchesDefaultArabicWakePhraseAndExtractsCommand() {
        val res = ArabicWakeMatcher.matchWakePhrase("يا يحيى افتح اليوتيوب", "يا يحيى")
        assertTrue(res.matched)
        assertEquals("افتح اليوتيوب", res.remainingCommand)
    }

    @Test
    fun wakeMatcher_handlesAlefVariationsAndDiacritics() {
        val res = ArabicWakeMatcher.matchWakePhrase("يَا يَحْيَا شغّل المنبه", "يا يحيى")
        assertTrue(res.matched)
        assertTrue(res.remainingCommand.contains("المنبه"))
    }

    @Test
    fun wakeMatcher_rejectsUnrelatedSpeech() {
        val res = ArabicWakeMatcher.matchWakePhrase("الطقس جميل اليوم", "يا يحيى")
        assertFalse(res.matched)
    }

    @Test
    fun safetyPolicy_alwaysRequiresConfirmationForSensitiveTap() {
        val cmd = AssistantCommand.Tap(
            commandId = "cmd-1",
            targetText = "تأكيد الدفع الآن",
            x = null,
            y = null,
        )
        val assessment = CommandSafetyPolicy.assess(cmd, confirmSensitiveActions = false)
        assertEquals(RiskLevel.SENSITIVE, assessment.riskLevel)
        assertTrue(assessment.requiresUserConfirmation)
    }

    @Test
    fun safetyPolicy_allowsNormalScrollAndWebSearchWithoutConfirmation() {
        val scroll = AssistantCommand.Scroll(
            commandId = "cmd-2",
            direction = ScrollDirection.DOWN,
        )
        val search = AssistantCommand.WebSearch(
            commandId = "cmd-3",
            query = "طقس الرياض اليوم",
        )
        assertFalse(CommandSafetyPolicy.assess(scroll, confirmSensitiveActions = true).requiresUserConfirmation)
        assertFalse(CommandSafetyPolicy.assess(search, confirmSensitiveActions = true).requiresUserConfirmation)
    }

    @Test
    fun safetyPolicy_requiresConfirmationForHttpFetchWebpageAndSettingsApp() {
        val insecureFetch = AssistantCommand.FetchWebpage(url = "http://example.com")
        val settingsApp = AssistantCommand.OpenApp(packageName = "com.android.settings", appName = "الإعدادات")
        assertTrue(CommandSafetyPolicy.assess(insecureFetch, confirmSensitiveActions = false).requiresUserConfirmation)
        assertTrue(CommandSafetyPolicy.assess(settingsApp, confirmSensitiveActions = false).requiresUserConfirmation)
    }

    @Test
    fun sensitiveInputFilter_redactsOtpPasswordsCardsAndKeys() {
        val raw = "رمز التحقق: 482910 وكلمة المرور mySecret! والبطاقة 4532 1111 2222 3333"
        val redacted = SensitiveInputFilter.redactSensitiveText(raw)
        assertFalse(redacted.contains("482910"))
        assertFalse(redacted.contains("mySecret!"))
        assertFalse(redacted.contains("4532 1111 2222 3333"))
        assertTrue(SensitiveInputFilter.containsSensitiveSecret(raw))
    }

    @Test
    fun htmlExtractor_stripsScriptsAndTagsCleanly() {
        val html = "<html><head><script>alert('x')</script><style>body{}</style></head><body><h1>مرحباً</h1><p>نص &amp; تجريبي</p></body></html>"
        val extracted = YahyaCommandEngine.extractReadableTextFromHtml(html)
        assertEquals("مرحباً نص & تجريبي", extracted)
    }

    @Test
    fun apiKeyVaultMask_masksKeySafely() {
        val masked = ApiKeyVault.maskKey("AIzaSyTestKey1234567890WXYZ")
        assertTrue(masked.startsWith("AIza"))
        assertTrue(masked.endsWith("WXYZ"))
        assertFalse(masked.contains("TestKey"))
    }
}
