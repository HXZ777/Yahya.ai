package com.example

import com.example.domain.model.CompanionCommand
import com.example.domain.model.RiskLevel
import com.example.domain.model.ScrollDirection
import com.example.domain.policy.CommandSafetyPolicy
import com.example.domain.voice.ArabicWakeMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CompanionDomainUnitTest {

    @Test
    fun wakeMatcher_matchesDefaultArabicWakePhraseAndExtractsCommand() {
        val res = ArabicWakeMatcher.matchWakePhrase("يا يحيى افتح اليوتيوب", "يا يحيى")
        assertTrue(res.matched)
        assertEquals("افتح اليوتيوب", res.remainingCommand)
    }

    @Test
    fun wakeMatcher_handlesAlefVariationsAndDiacritics() {
        val res = ArabicWakeMatcher.matchWakePhrase("يَا يَحْيَا شغّل المنبه", "يا يحيى")
        assertTrue(res.matched)
        assertTrue(res.remainingCommand.contains("المنبه"))
    }

    @Test
    fun wakeMatcher_rejectsUnrelatedSpeech() {
        val res = ArabicWakeMatcher.matchWakePhrase("الطقس جميل اليوم", "يا يحيى")
        assertFalse(res.matched)
    }

    @Test
    fun safetyPolicy_alwaysRequiresConfirmationForSensitiveTap() {
        val cmd = CompanionCommand.Tap(
            commandId = "cmd-1",
            targetText = "تأكيد الدفع الآن",
            x = null,
            y = null,
        )
        val assessment = CommandSafetyPolicy.assess(cmd, confirmSensitiveActions = false)
        assertEquals(RiskLevel.SENSITIVE, assessment.riskLevel)
        assertTrue(assessment.requiresUserConfirmation)
    }

    @Test
    fun safetyPolicy_allowsNormalScrollWithoutConfirmation() {
        val cmd = CompanionCommand.Scroll(
            commandId = "cmd-2",
            direction = ScrollDirection.DOWN,
        )
        val assessment = CommandSafetyPolicy.assess(cmd, confirmSensitiveActions = true)
        assertFalse(assessment.requiresUserConfirmation)
    }
}
