# VR Minecraft (MineVR)

Native Android Kotlin + Jetpack Compose + OpenGL ES 3.0 VR Box companion application designed for playing **Minecraft Bedrock Edition** (`com.mojang.minecraftpe`) using a smartphone **Gyroscope**, a **VR Box** headset, and a **PlayStation 4 DualShock 4 / PlayStation 5 DualSense** controller.

---

## 1. Technical Feasibility & Honest Architecture Breakdown

| Capability | Status | Technical Reality |
|---|---|---|
| **VR Box Split-Screen & Barrel Distortion** | ✅ **Native & Ready** | OpenGL ES 3.0 dual-eye viewports calibrated in mm (`VrBoxOptics`: IPD 55–72 mm, X/Y alignment, VR scale, FOV 60°–120°, brightness, image flip, and Brown–Conrady radial distortion `K1`/`K2` + chromatic aberration). |
| **Gyroscope Head Tracking & Anti-Jitter** | ✅ **Native & Ready** | `HeadTracker` prioritizes `TYPE_GAME_ROTATION_VECTOR` → `TYPE_ROTATION_VECTOR` → `TYPE_GYROSCOPE` + `TYPE_ACCELEROMETER`, uses display-rotation-aware matrix extraction (no gimbal lock), low-pass anti-jitter smoothing, sensitivity scaling, horizon lock, and forward calibration / recenter. |
| **PlayStation DualShock 4 / DualSense** | ✅ **Native & Ready** | Detects Sony VID `0x054C` (`DualShock 4` & `DualSense`) over Bluetooth or USB OTG via `InputManager` hot-plug listener, measures response latency, tests all 16 buttons + analog sticks + L2/R2 triggers, and persists custom remappings in DataStore. |
| **True 3D Stereoscopic Voxel Calibration Mode** | ✅ **Native & Ready** | Built-in OpenGL ES 3.0 3D voxel world with separate left/right eye IPD camera matrices so you can verify true 3D depth separation, barrel distortion, head tracking, and DualShock 4 / DualSense controls inside VR Box. |
| **Minecraft Live Screen Capture (`MediaProjection`)** | 🔐 **Requires User Consent** | Android 14+ Foreground Service (`foregroundServiceType="mediaProjection"`) binds `VirtualDisplay` directly to a zero-copy GPU `SurfaceTexture` (`GL_TEXTURE_EXTERNAL_OES`) rendered through the VR Box lens shader. |
| **Head-to-Minecraft Camera Bridge (`AccessibilityService`)** | 🔐 **Optional OS Permission** | `MineVrAccessibilityService` converts head yaw/pitch deltas into right-half touch-drag look gestures (`dispatchGesture`). Requires user enabling Accessibility Service and touch-look in Minecraft; subject to Android gesture rate limits (~42 ms cadence). |
| **True Dual-Camera 3D Inside Minecraft Bedrock** | ⚠️ **Requires Game Mod** | Minecraft Bedrock is a closed-source C++ engine (`libminecraftpe.so`). Capturing its screen via `MediaProjection` yields one 2D frame per refresh (cinema/head-tracked VR view), NOT two distinct 3D eye cameras unless modifying the game itself with a native OpenXR/RenderDragon mod. |
| **Single-Screen Background Pausing** | ⚠️ **Android OS Limit** | On unrooted single-screen phones, keeping MineVR fullscreen pauses background apps. Use **Android Split-Screen** (`Launch Split-Screen` button), **Android 14+ Single-App Capture**, or a secondary display. |

---

## 2. Permissions Used (Least-Privilege & 100% Local)

- `FOREGROUND_SERVICE` & `FOREGROUND_SERVICE_MEDIA_PROJECTION`: Required on Android 14+ to run `VrProjectionService` while capturing screen frames locally.
- `POST_NOTIFICATIONS`: Requested at runtime on Android 13+ so the active MediaProjection foreground notification can be displayed.
- `BLUETOOTH_CONNECT`: Used only to read connected PlayStation controller transport status.
- `BIND_ACCESSIBILITY_SERVICE` (Optional, user-enabled in Android Settings): Used strictly to dispatch touch-look swipes when Head-to-Minecraft Camera Bridge is enabled (`canRetrieveWindowContent="false"`).
- `<queries>` for `com.mojang.minecraftpe` and `com.mojang.minecrafttrialpe`: Play-compliant package detection without `QUERY_ALL_PACKAGES`.

All processing is **100% local on-device**. No screenshots, video streams, or telemetry leave the phone.

---

## 3. How to Pair Your PlayStation Controller

1. **DualShock 4 (PS4) / DualSense (PS5) via Bluetooth:**
   - Press and hold **PS + Share/Create** together for ~3 seconds until the lightbar flashes rapidly.
   - Open Android **Settings → Bluetooth** and pair **Wireless Controller** / **DualSense Wireless Controller**.
   - Open **VR Minecraft → Controller Settings** and press **Refresh Devices** to verify live stick/button response.
2. **Wired USB-C / OTG:**
   - Connect the controller directly using a USB-C data cable or OTG adapter for zero-pairing detection.

> **Controller Routing Note:** When Minecraft Bedrock is in the foreground, Android delivers DualShock 4 / DualSense events natively to Minecraft. Custom mappings inside VR Minecraft govern the VR HUD (Recenter, Pause VR) and the built-in 3D Voxel VR mode.

---

## 4. How to Play Minecraft in VR Box

1. Open **VR Minecraft** and verify **Gyroscope Ready**, **Controller Connected**, and **Minecraft Installed** on the main screen.
2. Open **Headset Settings** (`إعدادات النظارة`), put your phone into your VR Box briefly, and adjust **IPD**, **Barrel Distortion (K1/K2)**, **FOV**, and **Screen Alignment** while watching the live OpenGL ES preview.
3. *(Optional)* Enable **Head-to-Minecraft Camera Bridge** and enable **VR Minecraft** in Android **Accessibility Settings** if you want head movement to drag Minecraft's touch-look camera.
4. Select your display mode on the Main Screen:
   - **Minecraft Live Capture (MediaProjection):** Tap **Launch Split-Screen** (recommended on single-screen phones) or **START VR**, grant screen capture permission, and select Minecraft.
   - **3D Voxel VR:** Tap **START VR** to immediately test true stereoscopic 3D voxel rendering with head tracking and PlayStation controls.
5. During VR playback, use the minimal bottom controls to **Recenter Head**, **Pause / Resume VR**, or **Exit**.

---

## 5. Verification Summary

### Verified Automatically (Unit + Robolectric JVM Tests)
- `VrBoxOptics` physical mm-calibrated dual-eye viewport spacing, IPD clamping (`55–72 mm`), scale, alignment offsets, and single-eye toggle.
- `HeadTracker` yaw wrapping, low-pass anti-jitter filtering, horizon lock, forward calibration, and center reset.
- `PlayStationControllerManager` Sony DualShock 4 & DualSense VID/PID classification, button press/release, deadzone curves, and custom `PsButtonMapping` dispatch.
- `HeadLookBridgeMath` touch-drag swipe vector generation and jitter threshold filtering.
- Compose UI rendering & interactions across all 6 screens (`MainMenuScreen`, `VrSettingsScreen`, `ControlsScreen`, `SensorDiagnosticsScreen`, `AppInfoScreen`, `VrGameplayScreen`).

### Requires Physical Android Device Testing
- Live hardware Gyroscope / Game Rotation Vector drift over extended play sessions.
- Physical Bluetooth / USB-C DualShock 4 and DualSense hardware events.
- Live `MediaProjection` screen capture of `com.mojang.minecraftpe` and `AccessibilityService.dispatchGesture` responsiveness inside a physical VR Box headset.
