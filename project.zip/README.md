# VR Minecraft (MineVR)

Native Android Kotlin + Jetpack Compose + OpenGL ES 3.0 VR Box companion application designed for playing **Minecraft Bedrock Edition** (`com.mojang.minecraftpe`) using a smartphone **Gyroscope**, a **VR Box** headset, and a **PlayStation 4 DualShock 4 / PlayStation 5 DualSense** controller.

---

## 1. Technical Feasibility & Honest Architecture Breakdown

| Capability | Status | Technical Reality |
|---|---|---|
| **VR Box Split-Screen & Barrel Distortion** | ✅ **Native & Ready** | OpenGL ES 3.0 dual-eye viewports calibrated in mm (`VrBoxOptics`: IPD 55–72 mm, X/Y alignment, VR scale, FOV 60°–120°, brightness, image flip, and Brown–Conrady radial distortion `K1`/`K2` + chromatic aberration). |
| **Gyroscope Head Tracking & Anti-Jitter** | ✅ **Native & Ready** | `HeadTracker` prioritizes `TYPE_GAME_ROTATION_VECTOR` → `TYPE_ROTATION_VECTOR` → `TYPE_GYROSCOPE` + `TYPE_ACCELEROMETER`, uses display-rotation-aware matrix extraction (no gimbal lock), low-pass anti-jitter smoothing, sensitivity scaling, horizon lock, and forward calibration / recenter. |
| **PlayStation DualShock 4 / DualSense** | ✅ **Native & Ready** | Detects Sony VID `0x054C` (`DualShock 4` & `DualSense`) over Bluetooth or USB OTG via `InputManager` hot-plug listener, measures response latency, tests all 16 buttons + analog sticks + L2/R2 triggers, and persists custom remappings in DataStore. |
| **True 3D Stereoscopic Voxel Calibration Mode** | ✅ **Native & Ready** | Built-in OpenGL ES 3.0 3D voxel world with separate left/right eye IPD camera matrices so you can verify true 3D depth separation, barrel distortion, head tracking, and DualShock 4 / DualSense controls inside VR Box. |
| **Shizuku Virtual Display (Android 13 Zero-Loop)** | 🔐 **Requires Shizuku Permission (No Root)** | Runs a Shizuku `UserService` (`UID 2000` Shell, never Root) to create an isolated off-screen `VirtualDisplay` bound directly to MineVR's zero-copy OpenGL ES 3.0 `SurfaceTexture`, launches `com.mojang.minecraftpe` on that `displayId` (`am start --display`), monitors activity liveness, injects PS4/PS5 events + touch passthrough, and translates gyro deltas into smooth 60 Hz camera drag events on that `displayId`. |
| **Minecraft Live Screen Capture (`MediaProjection`)** | 🔐 **Requires User Consent** | Android 14+ Foreground Service (`foregroundServiceType="mediaProjection"`) binds `VirtualDisplay` directly to the GPU `SurfaceTexture` (`GL_TEXTURE_EXTERNAL_OES`) rendered with aspect-fit protection (`uTexScale`) through the VR Box lens shader. |
| **Head-to-Minecraft Camera Bridge (`AccessibilityService`)** | 🔐 **Optional OS Permission** | `MineVrAccessibilityService` converts head yaw/pitch deltas into right-half touch-drag look gestures (`dispatchGesture`) for MediaProjection mode. |
| **True Dual-Camera 3D Inside Minecraft Bedrock** | ⚠️ **Requires Game Mod** | Minecraft Bedrock is a closed-source C++ engine (`libminecraftpe.so`). Capturing or rendering its surface from outside yields one 2D camera frame per refresh (head-tracked cinema VR), NOT two distinct 3D eye cameras unless modifying the game itself with a native OpenXR/RenderDragon mod. |
| **OEM VirtualDisplay Restrictions** | ⚠️ **Android OEM Limit** | Some OEM ROMs (e.g., MIUI/HyperOS) restrict Shell `createVirtualDisplay` or `IInputManager.injectInputEvent` unless `USB debugging (Security settings)` is enabled in Developer Options; failures are surfaced verbatim in the VR status card. |

---

## 2. Permissions Used (Least-Privilege & 100% Local)

- **Shizuku (`moe.shizuku.privileged.api`) + `ShizukuProvider`**: Requested at runtime via official `Shizuku.requestPermission`; operates strictly as Shell (`UID 2000`, zero Root/`su`).
- `FOREGROUND_SERVICE` & `FOREGROUND_SERVICE_MEDIA_PROJECTION`: Required on Android 14+ to run `VrProjectionService` when using the MediaProjection fallback mode.
- `POST_NOTIFICATIONS`: Requested at runtime on Android 13+ for foreground capture notifications.
- `BLUETOOTH_CONNECT`: Used only to read connected PlayStation controller transport status.
- `BIND_ACCESSIBILITY_SERVICE` (Optional): Gesture bridge fallback for MediaProjection mode (`canRetrieveWindowContent="false"`).
- `<queries>` for `com.mojang.minecraftpe`, `com.mojang.minecrafttrialpe`, and `moe.shizuku.privileged.api`: Play-compliant package detection without `QUERY_ALL_PACKAGES`.

All processing is **100% local on-device**. No screenshots, video streams, or telemetry leave the phone.

---

## 3. How to Pair Your PlayStation Controller

1. **DualShock 4 (PS4) / DualSense (PS5) via Bluetooth:**
   - Press and hold **PS + Share/Create** together for ~3 seconds until the lightbar flashes rapidly.
   - Open Android **Settings → Bluetooth** and pair **Wireless Controller** / **DualSense Wireless Controller**.
   - Open **VR Minecraft → Controller Settings** and press **Refresh Devices** to verify live stick/button response.
2. **Wired USB-C / OTG:**
   - Connect the controller directly using a USB-C data cable or OTG adapter for zero-pairing detection.

> **Controller Routing Note:** In **Shizuku Virtual Display** mode, PS4/PS5 buttons and analog sticks are automatically forwarded with `displayId` targeting the off-screen Minecraft display (except buttons mapped to MineVR's local **Recenter Head** / **Pause VR** HUD commands, which stay local).

---

## 4. How to Play Minecraft in VR Box

1. Start **Shizuku** via **Wireless Debugging** on Android 13 (no Root needed).
2. Open **VR Minecraft**, verify **Gyroscope Ready**, **Controller Connected**, **Shizuku Ready**, and **Minecraft Installed**, and grant Shizuku permission if prompted.
3. Open **Headset Settings** (`إعدادات النظارة`), put your phone into your VR Box briefly, and tune **IPD**, **Barrel Distortion (K1/K2)**, **FOV**, **VR Scale**, and **Screen Alignment**.
4. Select **Shizuku Virtual Display (Android 13 Zero-Loop)** on the main menu and tap **START VR**:
   - MineVR allocates an isolated off-screen `VirtualDisplay`, launches Minecraft directly onto it, and displays it inside both VR lenses with aspect-fit scaling and zero mirror loopback.
   - Use **Game Touch** (`لمس اللعبة`) in the bottom HUD pill whenever you want to tap Minecraft's menus directly through the lenses.
5. Tap **Exit** (`خروج`) in the bottom HUD pill (or press System Back) to cleanly release the `VirtualDisplay`, input state, and sensors.

---

## 5. Verification Summary

### Verified Automatically (Unit + Robolectric JVM Tests)
- `VrBoxOptics` physical mm-calibrated dual-eye viewport spacing, IPD clamping (`55–72 mm`), scale, alignment offsets, and single-eye toggle.
- `MineVrRenderer.computeAspectFitScale` widescreen aspect-ratio preservation inside VR eye viewports.
- `HeadTracker` yaw wrapping, low-pass anti-jitter filtering, horizon lock, forward calibration, and center reset.
- `PlayStationControllerManager` Sony DualShock 4 & DualSense VID/PID classification, button press/release, deadzone curves, custom `PsButtonMapping` dispatch, and `resolveForwardKeyCode` VirtualDisplay routing.
- `HeadLookBridgeMath` continuous touch-drag step generation and jitter threshold filtering.
- Compose UI rendering & interactions across all 6 screens including Shizuku permission/status UI and `VrGameplayScreen` VirtualDisplay controls.

### Requires Physical Android 13 Device Testing
- Live Shizuku Wireless Debugging connection, `IDisplayManager.createVirtualDisplay`, `am start --display`, and `IInputManager.injectInputEvent` on your specific Android 13 OEM ROM.
- Live hardware Gyroscope drift and physical Bluetooth / USB-C DualShock 4 and DualSense gameplay inside a VR Box headset.
